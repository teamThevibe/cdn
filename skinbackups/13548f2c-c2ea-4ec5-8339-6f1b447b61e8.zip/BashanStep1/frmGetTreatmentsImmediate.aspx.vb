﻿Public Partial Class frmGetTreatmentsImmediate
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim objResult As New System.Text.StringBuilder()
        Dim objSmile As New SmileConnector.SmileConnector()
        objSmile.Url = Application("SmileWebService").ToString()
        Dim strID As String = Request.Form("hidID")
        Dim strType As String = Request.Form("hidType")

        Dim strTreatmentTypeID As String = "", strTreatmentDesc As String = ""
        Dim iCompany As Integer
        Dim ds As DataSet
        Dim dsTreatmentTypeImmediate As DataSet
        Dim dsImmediateTreatments As DataSet

        Try
            iCompany = CInt(Application("CompanyID").ToString())
        Catch ex As Exception
            iCompany = 2
        End Try

        objResult.Append("<HTML><HEAD><TITLE></TITLE>")
        objResult.Append("<meta http-equiv='Cache-Control' content='no-cache'>" & vbCrLf)
        objResult.Append("<meta http-equiv='Pragma' content='no-cache'>" & vbCrLf)
        objResult.Append("<meta http-equiv='Expires' content='0'>" & vbCrLf)
        objResult.Append("<META http-equiv='Content-Type' content='text/html; charset=windows-1255'>")
        objResult.Append("</HEAD>")
        objResult.Append("<BODY>")
        If strType = "3" Then
            Dim iTreatmentValue As Integer = 0
            objResult.Append("<SELECT id='oSelect'>")
            If Trim(strID) <> "" Then
                If Application("Smile") = "1" Then
                    ds = objSmile.GetSmileTreatment("C4675A38-17EF-4158-97A4-A32DCDB55135", strID)
                    If (ds.Tables(0).Rows.Count > 0) Then
                        strID = ds.Tables(0).Rows(0).Item("TreatmentID").ToString()
                    End If
                End If

                iTreatmentValue = objSmile.GetTreatmentTypeByTreatmentID("22274E20-D949-4243-9761-3EB6674657AB", CInt(strID))
                'miz
                'if not immediate the treatment type combo will be empty
                dsTreatmentTypeImmediate = objSmile.GetTreatmentTypesImmediate("BFE468CC-0A57-4487-9CB3-0F28D9D0FD8F", iCompany, 1)
                Dim currRow1 As DataRow
                Dim currRow2 As DataRow
                Dim bIsImmediate As Boolean = False
                If (Not dsTreatmentTypeImmediate Is Nothing) AndAlso (dsTreatmentTypeImmediate.Tables(0).Rows.Count > 0) Then
                    For Each currRow1 In dsTreatmentTypeImmediate.Tables(0).Rows
                        dsImmediateTreatments = objSmile.GetTreatmentsWithOrderImmediate("691E0BF6-6CC2-4875-B87E-D62718B03B5F", Val(currRow1("TreatmenTypetID").ToString()), iCompany, 1)
                        If (Not dsImmediateTreatments Is Nothing) AndAlso (dsImmediateTreatments.Tables(0).Rows.Count > 0) Then
                            For Each currRow2 In dsImmediateTreatments.Tables(0).Rows
                                If currRow2("TreatmentID") = strID Then
                                    bIsImmediate = True
                                    Exit For
                                End If
                            Next
                        End If
                    Next
                End If

                If Not bIsImmediate Then
                    iTreatmentValue = 0
                End If
                'end miz

                ds = objSmile.GetTreatmentsWithOrderImmediate("691E0BF6-6CC2-4875-B87E-D62718B03B5F", iTreatmentValue, iCompany, 1)
                FillComboboxTreatment("TreatmentID", "Treatment", ds, objResult)
            End If
            objResult.Append("</SELECT>")
            objResult.Append("<SELECT id='oSelect1'>")
            If IsNumeric(strID) Then
                ds = objSmile.GetCauses("CD6AEA9F-C78F-4942-A749-38C16DE0AA62", CInt(strID))
                FillComboboxCause("CauseID", "Cause", ds, objResult)
            End If
            objResult.Append("</SELECT>")
            objResult.Append("<INPUT type='hidden' id='txtTreatmentValue' value='" & CStr(iTreatmentValue) & "'>")
        Else
            objResult.Append("<SELECT id='oSelect'>")
            If Trim(strID) <> "" Then
                If strType = "1" Then
                    ds = objSmile.GetTreatmentsWithOrderImmediate("691E0BF6-6CC2-4875-B87E-D62718B03B5F", Val(strID), iCompany, 1)
                    FillComboboxTreatment("TreatmentID", "Treatment", ds, objResult)
                Else
                    ds = objSmile.GetCauses("CD6AEA9F-C78F-4942-A749-38C16DE0AA62", CInt(strID))
                    FillComboboxCause("CauseID", "Cause", ds, objResult)
                End If
            End If
            objResult.Append("</SELECT>")
        End If
        objResult.Append("<INPUT type='hidden' id='txtComboType' value='" & strType & "'>")

        objResult.Append("<SCRIPT>")
        objResult.Append("	window.parent.document.all.oNotification.value = 'OK';")
        objResult.Append("</SCRIPT>")
        objResult.Append("</BODY>")
        objResult.Append("</HTML>")
        Response.Write(objResult.ToString())
    End Sub

    Private Sub FillComboboxTreatment(ByVal strValueField As String, ByVal strDescField As String, ByRef ds As Data.DataSet, ByRef objResult As System.Text.StringBuilder)
        Dim currRow As Data.DataRow
        objResult.Append("<OPTION value='0' from='' BashanCode='0' SmileCode='0'>בחר...</OPTION>")
        Dim strSmileTreatmentID As String = ""
        Dim bSmile As Boolean = CBool(Application("Smile") = "1")
        For Each currRow In ds.Tables(0).Rows
            If bSmile Then
                strSmileTreatmentID = currRow("SmileTreatmentID").ToString()
            Else
                strSmileTreatmentID = currRow(strValueField).ToString()
            End If
            objResult.Append("<OPTION value='" & strSmileTreatmentID & "' from='" & currRow("RangeID").ToString() & "' BashanCode='" & currRow("BashanCode").ToString() & "' SmileCode='" & currRow("SmileTreatmentID").ToString() & "'>" & currRow(strDescField).ToString() & "</OPTION>")
        Next
    End Sub

    Private Sub FillComboboxCause(ByVal strValueField As String, ByVal strDescField As String, ByRef ds As Data.DataSet, ByRef objResult As System.Text.StringBuilder)
        Dim currRow As Data.DataRow
        objResult.Append("<OPTION value='0'>בחר...</OPTION>")
        For Each currRow In ds.Tables(0).Rows
            objResult.Append("<OPTION value='" & currRow(strValueField).ToString() & "'>" & currRow(strDescField).ToString() & "</OPTION>")
        Next
    End Sub
End Class