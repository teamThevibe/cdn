﻿Public Partial Class frmIframeError
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Dim s1 As Char = ""
        'Dim sValidChars As String = ""
        Dim sRegExp As String = Application("RegExpr")
        Dim iCount As Integer
        Dim sMsg As String = ""
        Dim sValueMsg As String = ""
        Dim sFileError As String = ""
        Try
            sFileError = Request.QueryString("FileNameError") + ""
            If (sFileError = "1") Then
                sValueMsg = Request.QueryString("NameValue") + ""
            Else
                sMsg = Request.QueryString("Control") + ""
                If (sMsg = "") Then
                    sValueMsg = Request.QueryString("ControlValue")
                End If
            End If
        Catch ex As Exception
            sMsg = ex.Message
        End Try

        hidControlName.Value = sMsg


        Dim objResult As New System.Text.StringBuilder()
        If (sFileError = "1") Then
            objResult.Append("<HTML><HEAD><TITLE></TITLE>")
            objResult.Append("<meta http-equiv='Cache-Control' content='no-cache'>" & vbCrLf)
            objResult.Append("<meta http-equiv='Pragma' content='no-cache'>" & vbCrLf)
            objResult.Append("<meta http-equiv='Expires' content='0'>" & vbCrLf)
            objResult.Append("<META http-equiv='Content-Type' content='text/html; charset=windows-1255'>")
            objResult.Append("</HEAD>")
            objResult.Append("<BODY>")
            objResult.Append("<INPUT TYPE='hidden' id='ctlBlackResult' value='-1'>")
            objResult.Append("<INPUT TYPE='hidden' id='ctlCheckKind' value='-1' >")
            objResult.Append("<INPUT TYPE='hidden' id='hidControlValue' value='" & sValueMsg & "'>")
            objResult.Append("<SCRIPT>")
            objResult.Append("	window.parent.ProcessFileNamesCheck();")
            objResult.Append("</SCRIPT>")
            objResult.Append("</BODY>")
            objResult.Append("</HTML>")

        Else
            objResult.Append("<HTML><HEAD><TITLE></TITLE>")
            objResult.Append("<meta http-equiv='Cache-Control' content='no-cache'>" & vbCrLf)
            objResult.Append("<meta http-equiv='Pragma' content='no-cache'>" & vbCrLf)
            objResult.Append("<meta http-equiv='Expires' content='0'>" & vbCrLf)
            objResult.Append("<META http-equiv='Content-Type' content='text/html; charset=windows-1255'>")
            objResult.Append("</HEAD>")
            objResult.Append("<BODY>")
            objResult.Append("<INPUT TYPE='hidden' id='ctlWhiteListResult' value='-1' >")
            objResult.Append("<INPUT TYPE='hidden' id='ctlCheckKind' value='-1' >")
            objResult.Append("<INPUT TYPE='hidden' id='hidControlName' value='" & sMsg & "'>")
            objResult.Append("<INPUT TYPE='hidden' id='hidControlValue' value='" & sValueMsg & "'>")
            objResult.Append("<SCRIPT>")
            objResult.Append("	window.parent.document.all.oWLNotification.value = 'OK';")
            objResult.Append("</SCRIPT>")
            objResult.Append("</BODY>")
            objResult.Append("</HTML>")
        End If
        Response.Write(objResult.ToString())

    End Sub

End Class