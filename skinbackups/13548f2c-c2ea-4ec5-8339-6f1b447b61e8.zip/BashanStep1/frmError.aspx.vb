Imports System.Text

Public Class frmError
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Protected WithEvents lblMessage As System.Web.UI.WebControls.Label
    Protected WithEvents cmdCloseWin As System.Web.UI.HtmlControls.HtmlInputButton

    Protected WithEvents cmdBack As System.Web.UI.HtmlControls.HtmlInputButton
#If NewDesign Then
    Protected WithEvents cmdLogout As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents tdTitle As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents trExit As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents txtError As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents ctlBanner As System.Web.UI.HtmlControls.HtmlGenericControl
#Else
    Protected WithEvents aIconlink As System.Web.UI.HtmlControls.HtmlAnchor
    Protected WithEvents divRIcon As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents ctlBanner As System.Web.UI.HtmlControls.HtmlGenericControl
#End If

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

		Try
			Dim str As String

			'If (Not Request.QueryString("newmode") Is Nothing) Then
			'	cmdBack.Visible = False
			'	cmdCloseWin.Visible = True
			'	Master.FindControl("MainTitle").Visible = False
            'Else
            If Not cmdCloseWin Is Nothing Then
                cmdCloseWin.Visible = False
            End If



			'End If


			If Not IsPostBack Then
				Session("BackUrl") = ""
#If Not NewDesign Then
            divRIcon.Visible = False
#End If
				If Application("App_Type").ToString.ToUpper() = "SUPP" Then


				End If
				'   Dim strMessage As String

				Dim encrypt As CEncryption.cEnryption = New CEncryption.cEnryption()
				Dim sMsgFull As String = "" + Request.QueryString("sMsg")
				Dim sFieldDesc As String
				Try
					sMsgFull = encrypt.DecryptStrTripleDESC(sMsgFull)
					sFieldDesc = sMsgFull.Split("|")(1)
				Catch ex As Exception
					Dim s As String = ex.Message
				End Try
				'If (sMsgFull.Split("|").Length = 1) Then
				'    ' cmdBack.Attributes.Clear()
				'    cmdBack.Attributes.Add("onclick", "{window.close(); return false;}")
				'End If
				Dim sFieldValue As String = ""
				Try
					Dim sMsgVal As String = Request.QueryString("sMsgvalue") + ""
					If (sMsgVal <> "") Then
						sMsgVal = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(sMsgVal))
						If (Not IsNothing(Application(sMsgVal))) Then
							sFieldValue = Application(sMsgVal)
							Application(sMsgVal) = Nothing
						End If
					End If
				Catch ex As Exception
					Dim sErr As String = ex.Message
				End Try


				Dim s1 As Char = ""
				Dim sValidChars As String = ""
				Dim sRegExp As String = Application("RegExpr")
				Dim iCount As Integer
				For iCount = 33 To 255
					s1 = Chr(iCount)
					If Char.IsLetterOrDigit(s1) Then
						'   If ((iCount >= 48 And iCount <= 57) Or (iCount >= 65 And iCount <= 90) Or (iCount >= 97 And iCount <= 122) Or (iCount >= 208 And iCount <= 242) Or (iCount = 181) Or (iCount = 192)) Then
					Else
						' s1 = Chr(iCount)
						If System.Text.RegularExpressions.Regex.IsMatch(s1, sRegExp) Then
							sValidChars += s1 + " "
						End If
					End If
				Next

#If EngDesign Then
            str = "Invalid input"
            If sFieldDesc > "" Then
                'Dim Sec As New SecurityService.SecurityService()
                'Sec.Url = Application("SecurityService")
                'sFieldDesc = Sec.GetWhiteListFieldDesc("97E08494-AEB2-4a98-B7ED-57F48C45A4F9", sFormName, sFieldName)
                str += " in field " & "'" & sFieldDesc & "'"
            End If
            str += "<br /><br /><br />"
            str += "Allowed characters: letters, digits" & "<br /><br />"
            str += sValidChars & ":and the following characters " & "<br />"
            ' ! @ + : $ * ? \ / _ [ ] | % . - ,"
            lblMessage.Text = str

            'ctlBanner.InnerText = objUser.GetBanner("83FEABF8-828B-489D-8DD0-EB5A3AB7994E")
#Else
				If sFieldDesc <> "" Then
					str = "���� �� �� ����"

					'Dim Sec As New SecurityService.SecurityService()
					'Sec.Url = Application("SecurityService")
					'sFieldDesc = Sec.GetWhiteListFieldDesc("97E08494-AEB2-4a98-B7ED-57F48C45A4F9", sFormName, sFieldName)
					str += " ���� " & "'" & sFieldDesc & "'"

					str += "<br /><br /><br />"
					str += "����� ������: ������ ������, �������, ����� " & "<br /><br />"
					str += "������� �����: " & sValidChars & "<br />" ' ! @ + : $ * ? \ / _ [ ] | % . - ,"
				ElseIf sFieldValue > "" Then
					str = "<br /><br />" + _
					  "����" + "<br />" + "'" + Utils.AntiXSS(sFieldValue) + "'" + "<br />" + "���� ����� �� ������"
				Else
					str = "���� �� �� ����"
					str += "<br /><br /><br />"
					str += "����� ������: ������ ������, �������, ����� " & "<br /><br />"
					str += "������� �����: " & sValidChars & "<br />" ' ! @ + : $ * ? \ / _ [ ] | % . - ,"
				End If
				lblMessage.Text = str
#End If

			Else

			End If
		Catch ex As Exception
			Dim s As String = ex.Message
		End Try
	End Sub


    Private Sub cmdBack_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdBack.ServerClick
        If Session("BackUrl").ToString() <> "" Then
            Response.Redirect(Session("BackUrl").ToString())
        Else
            Dim encrypt As CEncryption.cEnryption = New CEncryption.cEnryption()
            Dim sMsg As String = "" + Request.QueryString("sMsg")
            If (sMsg <> "") Then
                sMsg = encrypt.DecryptStrTripleDESC(sMsg)

                Dim queryString As String = "" + Request.QueryString("QS")
                If queryString.Length > 0 Then
                    queryString = "&" & encrypt.DecryptStrTripleDESC(queryString)
                End If

                If (sMsg.IndexOf("SecureWhiteList") > 0) Then
                    Session("SecureWhiteList") = True
                End If
                Dim sMsgArr As String() = sMsg.Split("|")
                Dim sForm = sMsgArr(0)

                Response.Redirect((New Utils).GetLinkForNextForm(sForm) & queryString)
            End If
        End If
    End Sub


End Class

