Public Class frmHDPRequestt
    Inherits System.Web.UI.Page

    Protected WithEvents Doctor As Distribution.HDDoctor

    Protected WithEvents cmdReply As Global.System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents lstRequestType As System.Web.UI.WebControls.DropDownList
    Protected WithEvents cmdCopy As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdNewReq As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdNew As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdSend As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents txtInsuredID As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtInsuredName As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtInsuredFamily As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtClaimID As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtDateFrom As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtInvoiceID As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtSum As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtNote As System.Web.UI.HtmlControls.HtmlTextArea
    Protected WithEvents txtAnswer As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents txtError As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtLName As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtFName As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtMaxClaimSum As System.Web.UI.HtmlControls.HtmlInputHidden

    Protected WithEvents hidClinicNumber As System.Web.UI.HtmlControls.HtmlInputHidden


    Protected WithEvents txtToday As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtDoctorType As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtSkipCheck As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt11 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt12 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt13 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt14 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt15 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt16 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt17 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt18 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt21 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt22 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt23 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt24 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt25 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt26 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt27 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt28 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt31 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt32 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt33 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt34 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt35 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt36 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt37 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt38 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt41 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt42 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt43 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt44 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt45 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt46 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt47 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt48 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt91 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt92 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt93 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt94 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt95 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt96 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents chkPan As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents chkStatus As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents chkFace As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents hidWinName As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents verofbrowser As Global.System.Web.UI.HtmlControls.HtmlInputHidden

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

        Dim sMainTitle As String = "����� ��� - " & Page.Title
        CType(Master.FindControl("MainTitle"), Literal).Text = sMainTitle
        Page.Title = sMainTitle

        Dim s As String = ""
        With Request.Browser
            s &= "Browser Capabilities" & vbCrLf
            s &= "Type = " & .Type & vbCrLf
            s &= "Name = " & .Browser & vbCrLf
            s &= "Version = " & .Version & vbCrLf
            s &= "Major Version = " & .MajorVersion & vbCrLf
            s &= "Minor Version = " & .MinorVersion & vbCrLf
            s &= "Platform = " & .Platform & vbCrLf
            s &= "Is Beta = " & .Beta & vbCrLf
            s &= "Is Crawler = " & .Crawler & vbCrLf
            s &= "Is AOL = " & .AOL & vbCrLf
            s &= "Is Win16 = " & .Win16 & vbCrLf
            s &= "Is Win32 = " & .Win32 & vbCrLf
            s &= "Supports Frames = " & .Frames & vbCrLf
            s &= "Supports Tables = " & .Tables & vbCrLf
            's &= "Supports Cookies = " & .Cookies & vbCrLf
            's &= "Supports VBScript = " & .VBScript & vbCrLf
            's &= "Supports JavaScript = " & _
            '    .EcmaScriptVersion.ToString() & vbCrLf
            's &= "Supports Java Applets = " & .JavaApplets & vbCrLf
            's &= "Supports ActiveX Controls = " & .ActiveXControls & _
            'vbCrLf
            's &= "Supports JavaScript Version = " & _
            ' Request.Browser("JavaScriptVersion") & vbCrLf
        End With
        verofbrowser.Value = s

        Dim bAllowPriodontRequest As Boolean = objUser.GetPriodontRequestPermitions("1DDDF20C-5DC6-4656-A2CB-2D83B7CC13D9", User.Identity.Name)
        If Not bAllowPriodontRequest Then
            objUser.AddUserIllegalAction("24304391-6FDE-4237-A9B6-49630958EB26", User.Identity.Name, "frmHDPRequestt")
            Utils.LogOut()
        End If
        If Not IsPostBack Then
            If Session("User_Login_First_Time") = "1" Then
                Response.Redirect("frmUserProp.aspx")
            End If
            If Application("Smile") = "1" Or Application("CompanyID").ToString = "3" Then
                'cmdCopy.Visible = False
                cmdNewReq.Visible = False
                cmdNew.Visible = False
                txtSkipCheck.Value = "1"
            End If
            txtDoctorType.Value = CStr(objUser.GetUserDoctorType("C049B33B-243D-43C1-B2F5-AB4859F9EBD1", User.Identity.Name))
            ''''''''''''''''''''''''txtDoctorType.Value = CStr(objUser.GetHDUserDoctorType("0B776BB2-51E1-11E4-8E10-7F911D5D46B0", User.Identity.Name))
            If Session("BSHN_Independed") = "1" Then
                Doctor.DoctorCare.Visible = False
                Doctor.DoctorCareName.Visible = True
            Else
                Doctor.DoctorCare.Visible = True
                Doctor.DoctorCareName.Visible = False
            End If
            txtToday.Value = Format(DateTime.Today, "ddMMyyyy")
            FillDefaults()
            FillNameAndId()


            If Not Session("HDInsuredID") Is Nothing Then
                If Session("HDInsuredID").ToString <> "" Then
                    txtInsuredID.Value = Session("HDInsuredID").ToString
                End If
            End If

            If Not Session("HDSHEM") Is Nothing Then
                If Session("HDSHEM").ToString <> "" Then
                    txtInsuredName.Value = Session("HDSHEM").ToString
                    txtFName.Value = Session("HDSHEM").ToString
                End If
            End If

            If Not Session("HDMISP") Is Nothing Then
                If Session("HDMISP").ToString <> "" Then
                    txtInsuredFamily.Value = Session("HDMISP").ToString
                    txtLName.Value = Session("HDMISP").ToString

                End If
            End If




        End If
    End Sub

    Private Sub FillDefaults()
        Dim strEmptyTooth As String = "0;0;0;"
        txt11.Value = strEmptyTooth
        txt12.Value = strEmptyTooth
        txt13.Value = strEmptyTooth
        txt14.Value = strEmptyTooth
        txt15.Value = strEmptyTooth
        txt16.Value = strEmptyTooth
        txt17.Value = strEmptyTooth
        txt18.Value = strEmptyTooth
        txt21.Value = strEmptyTooth
        txt22.Value = strEmptyTooth
        txt23.Value = strEmptyTooth
        txt24.Value = strEmptyTooth
        txt25.Value = strEmptyTooth
        txt26.Value = strEmptyTooth
        txt27.Value = strEmptyTooth
        txt28.Value = strEmptyTooth
        txt31.Value = strEmptyTooth
        txt32.Value = strEmptyTooth
        txt33.Value = strEmptyTooth
        txt34.Value = strEmptyTooth
        txt35.Value = strEmptyTooth
        txt36.Value = strEmptyTooth
        txt37.Value = strEmptyTooth
        txt38.Value = strEmptyTooth
        txt41.Value = strEmptyTooth
        txt42.Value = strEmptyTooth
        txt43.Value = strEmptyTooth
        txt44.Value = strEmptyTooth
        txt45.Value = strEmptyTooth
        txt46.Value = strEmptyTooth
        txt47.Value = strEmptyTooth
        txt48.Value = strEmptyTooth
        strEmptyTooth = "0;0;"
        txt91.Value = strEmptyTooth
        txt92.Value = strEmptyTooth
        txt93.Value = strEmptyTooth
        txt94.Value = strEmptyTooth
        txt95.Value = strEmptyTooth
        txt96.Value = strEmptyTooth
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        txtMaxClaimSum.Value = objTreatmentService.GetMaxClaimSum("D2D2CC74-A3CE-4420-B6CE-073F25E8E70A")
        Dim strDoctorCareName As String
        Dim strDoctorCareNumber As String
        Dim strClinicName As String
        Dim strClinicNumber As String
        If objTreatmentService.GetDoctorProperties("7EC6114A-62CD-4DC4-A940-1416BFB136D8", User.Identity.Name, strDoctorCareName, strDoctorCareNumber, strClinicName, strClinicNumber) Then
            '''''''''''''''''''''''''''''If objTreatmentService.GetHdDoctorProperties("C4AEB905-6C91-4FC8-93BE-1486B99518E57", User.Identity.Name, strDoctorCareName, strDoctorCareNumber, strClinicName, strClinicNumber) Then
            If Session("BSHN_Independed") = "1" Then
                Doctor.DoctorCareName.Text = strDoctorCareName
                Doctor.DoctorCareNumber.Value = strDoctorCareNumber
            Else
                Doctor.FillDoctorCare()
                If Doctor.DoctorCare.Items.Count > 1 Then
                Else
                    Doctor.DoctorCareNumber.Value = strDoctorCareNumber
                End If
            End If
            Doctor.ClinicName.Value = strClinicName
            Doctor.ClinicNumber.Value = strClinicNumber
            hidClinicNumber.Value = strClinicNumber
        End If
        txtDateFrom.Value = DateTime.Today.ToString("dd/MM/yyyy")
        lstRequestType.SelectedIndex = 0
        'If Application("Smile") = "1" Or Application("CompanyID").ToString = "3" Then
        If Application("Smile") = "1" Then
            lstRequestType.Style.Add("display", "none")
        End If
    End Sub

    Private Sub SetComboValue(ByRef cbo As DropDownList, ByVal strValue As String)
        Dim li As ListItem = cbo.Items.FindByValue(strValue)
        If Not li Is Nothing Then
            li.Selected = True
        End If
    End Sub

    Private Sub FillNameAndId()
        txtInsuredID.Value = Session("TRequest_InsuredID")
        txtInsuredName.Value = Session("TRequest_InsuredName")
        txtInsuredFamily.Value = Session("TRequest_InsuredFamily")
        txtLName.Value = Session("TRequest_InsuredFamily")
        txtFName.Value = Session("TRequest_InsuredName")

        If Application("Smile") = "1" Or Application("CompanyID").ToString = "3" Then
            ' Smile or Leumit
            txtInsuredID.Attributes.Remove("onblur")
            txtFName.Value = Session("TRequest_InsuredName")
            txtLName.Value = Session("TRequest_InsuredFamily")
            SetReadOnly(txtInsuredID)
            SetReadOnly(txtInsuredName)
            SetReadOnly(txtInsuredFamily)
        Else
            Session("TRequest_InsuredID") = ""
            Session("TRequest_InsuredName") = ""
            Session("TRequest_InsuredFamily") = ""
        End If
    End Sub

    Sub SetReadOnly(ByVal txtField As HtmlInputText)
        txtField.Attributes.Add("readonly", "true")
        txtField.Style.Add("background-Color", "#D6D3CE")
    End Sub

    Private Sub cmdNew_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdNew.ServerClick
        CheckWindowName()
        Dim iIndex As Integer
        If Session("BSHN_Independed") <> "1" Then
            iIndex = Doctor.DoctorCare.SelectedIndex
        End If
        MyBase.ViewState.Clear()
        FillDefaults()
        If Session("BSHN_Independed") <> "1" Then
            Doctor.DoctorCare.SelectedIndex = iIndex
        End If
        txtAnswer.InnerText = ""
        txtLName.Value = ""
        txtFName.Value = ""
        txtInsuredFamily.Value = ""
        txtInsuredName.Value = ""
        Me.txtError.Value = ""
    End Sub

    Private Sub cmdNewReq_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdNewReq.ServerClick
        CheckWindowName()
        Response.Redirect(Utils.Navigation.GetURL("frmRequestt.aspx"))
    End Sub

    Private Sub cmdCopy_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCopy.ServerClick
        CheckWindowName()
        Session("MRequest_InsuredID") = txtInsuredID.Value
        If Session("BSHN_Independed") <> "1" Then
            Session("MRequest_DoctorCare") = CStr(Doctor.DoctorCare.SelectedIndex)
            Session("MRequest_DoctorCareName") = CStr(Doctor.DoctorCare.SelectedValue)
        Else
            Session("MRequest_DoctorCare") = "0"
            Session("MRequest_DoctorCareName") = Doctor.DoctorCareNumber.Value
        End If
        Session("MRequest_InsuredID") = txtInsuredID.Value
        Session("MRequest_InsuredName") = txtFName.Value
        Session("MRequest_InsuredFamily") = txtLName.Value
        Session("MRequest_LName") = txtLName.Value
        Session("MRequest_FName") = txtFName.Value
        Session("MRequest_Source") = "1"

        If Application("Smile") = "1" Or Application("CompanyID").ToString = "3" Then
            Session("MRequest_RequestType") = "1"
        End If
        Response.Redirect(Utils.Navigation.GetURL("frmRequestt.aspx"))
    End Sub

    'Private Sub cmdExit_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdExit.ServerClick
    '    CheckWindowName()
    '    If Application("Smile") = "1" Then
    '        Response.Redirect("frmCheckSM.aspx")
    '    Else
    '        If Application("CompanyID").ToString = "3" Then
    '            Response.Redirect("frmLMCheck.aspx")
    '        Else
    '            Response.Redirect("frmStart.aspx")
    '        End If
    '    End If

    'End Sub

    Private Sub CheckWindowName()
        If Session("winname") = "" Then
            If (hidWinName.Value <> "") Then
                Session("winname") = hidWinName.Value
            End If
        Else
            If hidWinName.Value <> Session("winname") Then
                Response.Redirect("frmInvalidOperation.aspx")
            End If
        End If
    End Sub

    Private Sub cmdReply_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReply.ServerClick
        GetInsuredDetails()

    End Sub
    Private Sub GetInsuredDetails()

        Dim objBO As New BOConnection.BOService
        objBO.Url = Application("BOWebService")

        Dim ds As New DataSet
        If (txtInsuredID.Value = "") Then
            txtError.Value = ""
            Return
        End If
        ds = objBO.GetInsuredDetails("BB91B46E-024D-41F0-97C0-D58FE62388E9", Val(txtInsuredID.Value))

        If ds.Tables(0).Rows.Count = 0 Then
            txtError.Value = "11"

            Session.Remove("HDInsuredID")

            Session.Remove("HDSHEM")

            Session.Remove("HDMISP")

        Else
            txtError.Value = ""
        End If



        'Dim Util As Utils = New Utils
        txtInsuredName.Value = Utils.Values.GetFirstTableFirstRowString(ds, "SHEM")
        txtInsuredFamily.Value = Utils.Values.GetFirstTableFirstRowString(ds, "MISP")
        txtLName.Value = txtInsuredFamily.Value
        txtFName.Value = txtInsuredName.Value

        'FamilyCover.Value = Utils.Values.GetFirstTableFirstRowString(ds, "MSL_TEUR_KISUY_MEVUTAH")
        If txtError.Value <> "11" Then
            Session("HDInsuredID") = Val(txtInsuredID.Value)
            Session("HDSHEM") = txtInsuredName.Value
            Session("HDMISP") = txtInsuredFamily.Value
        End If

    End Sub
End Class
