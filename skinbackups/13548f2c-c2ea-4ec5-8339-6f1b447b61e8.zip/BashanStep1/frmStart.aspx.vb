Imports System.IO
Imports System.Web.Security
Public Class frmStart
    Inherits System.Web.UI.Page

    Private THIS_FRM_ASPX_NAME As String = "frmStart.aspx"

    Protected WithEvents lblMessage As System.Web.UI.WebControls.Label
    'Protected WithEvents cmdLogout As System.Web.UI.HtmlControls.HtmlInputButton
    'Protected WithEvents ctlBanner As System.Web.UI.HtmlControls.HtmlGenericControl
    'Protected WithEvents aIconlink As System.Web.UI.HtmlControls.HtmlAnchor
    'Protected WithEvents txtReportType As System.Web.UI.HtmlControls.HtmlInputHidden
    'Protected WithEvents txtAppType As System.Web.UI.HtmlControls.HtmlInputHidden
    'Protected WithEvents txtFormIdentity As System.Web.UI.HtmlControls.HtmlInputHidden
    'Protected WithEvents cmdHelp As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdUserProp As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents divRIcon As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents aIconLink As System.Web.UI.HtmlControls.HtmlAnchor
    Protected WithEvents cmdHelp As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdLogout As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents SiteInfo As System.Web.UI.HtmlControls.HtmlGenericControl

#If Not NewDesign Then
    Protected WithEvents spnRequest As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents spnDoctorService As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents spnZakaut As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents spnShenSystem As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents spnMRequest As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents spnPRequest As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents spnKeter As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents aIconLink2 As System.Web.UI.HtmlControls.HtmlAnchor
    Protected WithEvents spnUpload As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents spnConsultation As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents spnForiegnWorkers As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents spnKeptAppeal As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents spnShaban As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents spnShabanTxt As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents spnMultiCheck As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents spnManageUsers As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents spnInsuredStatus As System.Web.UI.HtmlControls.HtmlGenericControl
#Else
#If Not EngDesign Then
    Protected WithEvents cmdViewData As System.Web.UI.WebControls.Button
    Protected WithEvents cmdUpload As System.Web.UI.WebControls.Button
    Protected WithEvents cmdDownload As System.Web.UI.WebControls.Button
    Protected WithEvents lnkFavIcon As System.Web.UI.HtmlControls.HtmlControl
    Protected WithEvents tdRightPic As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents imgRightPic As System.Web.UI.HtmlControls.HtmlImage
    Protected WithEvents imgLeftPic As System.Web.UI.HtmlControls.HtmlImage
    Protected WithEvents ctlBanner As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents trUpload As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents trDownload As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents cmdAddReport As System.Web.UI.WebControls.Button
    Protected WithEvents trSendInf As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents cmdTechSupportForm As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents hidSupportSubjects As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidClaimApp As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents trOccasional As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents cmdSend2Occasional As System.Web.UI.WebControls.Button
#End If
#End If

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' YT:

        Session("FW_RequestID") = String.Empty
        'CheckKey()
        'DS prevent return to the page after log out and hitting the back button
        Response.Cache.SetCacheability(HttpCacheability.NoCache)

        If Not Session("PassLoginFromEmail") Is Nothing Then
            If Session("PassLoginFromEmail").ToString <> "" Then
                Session("User_Login_First_Time") = "1"
            End If
        End If

        Session("OnBehalfOf") = User.Identity.Name
        If Session("User_Login_First_Time") = "1" Then
#If NewDesign And Not EngDesign Then
            Response.Redirect((New Utils).GetLinkForNextForm(Application("FORMUserPass")))
#Else
            Response.Redirect("frmUserProp.aspx")
#End If
        End If
        If Not IsPostBack Then

#If Not NewDesign Then
            If "1".Equals(Application("InsuredStatusAsMainScreen")) Then
                spnInsuredStatus.Visible = True
            Else
                spnInsuredStatus.Visible = False
            End If
#End If

            Dim objUser As New UserConnect.UserService()
            objUser.Url = Application("UserWebService").ToString()
            Dim strUserName As String = objUser.GetUserFullName("3371F4F5-F671-4B9D-A054-A4232D3D2177", User.Identity.Name)
            Dim objTreatmentService As New TreatmentConnect.TreatmentService()
            objTreatmentService.Url = Application("TreatmentWebService").ToString()
            Dim strDoctorCareName As String
            Dim strDoctorCareNumber As String
            Dim strClinicName As String
            Dim strClinicNumber As String
            Dim strText As String = ""

            If Application("RightLogo") = "1" Then
#If NewDesign Then
                tdRightPic.Attributes("background") = "pics/BannerTopRightTransp.gif"
                imgRightPic.Attributes("src") = "pics/BannerTopRightTransp.gif"
#End If
                divRIcon.Visible = True
            Else
#If NewDesign Then
                tdRightPic.Attributes("background") = "pics/BannerTopRightPic.gif"
                imgRightPic.Attributes("src") = "pics/BannerTopRightPic.gif"
#End If
                divRIcon.Visible = False
            End If
#If NewDesign Then
            'Getting the application icon path
            Dim strURL As String
            Dim strSERVER_NAME As String
            Dim strIconPath As String

            strURL = Request.ServerVariables("URL")
            strSERVER_NAME = Request.ServerVariables("SERVER_NAME")
            strURL = Path.GetDirectoryName(strURL)
            strURL = strURL.Replace("\", "/")
            strIconPath = Application("HttpsORHttp") & strSERVER_NAME & strURL & "/pics/InfoBay.ico"
            lnkFavIcon.Attributes.Add("HREF", strIconPath)
            Session("ICON_PATH") = strIconPath

#If Not EngDesign Then
            Dim isEng As Boolean = False
            ctlBanner.InnerText = objUser.GetBanner("83FEABF8-828B-489D-8DD0-EB5A3AB7994E", isEng)

            If Application("AllowSend2OccasionalFromUserSite") = "1" And objUser.GetPermitionSend2Occasional("D70BC7D0-E414-4843-95C6-F1B06D073495", User.Identity.Name) Then
                trOccasional.Visible = True
            Else
                trOccasional.Visible = False
            End If
#End If

            'TechSupport
            Dim bIsTechSupportEnabled As Boolean = False
            If Application("WithTechSupport") & "" = "1" Then
                bIsTechSupportEnabled = True
            End If
            Dim bAllowTechSupport As Boolean = objUser.GetTechSupportPermition("S61AD468-275E-409D-B209-BE3C3A4000FF", User.Identity.Name)
            If bIsTechSupportEnabled And bAllowTechSupport Then
                cmdTechSupportForm.Visible = True
            Else
                cmdTechSupportForm.Visible = False
            End If
            Session("TechSupport_RepID") = "0"
            Session("TechSupport_SubUserID") = ""

#End If
#If NewDesign Then
            If Application("HasHani").ToString() = "1" Then
                imgLeftPic.Src = "pics/" & objUser.GetLogoName("17060B94-065E-4DB4-975D-A3988FFD63CC", User.Identity.Name)
            End If
#End If

#If Not NewDesign Then

            objTreatmentService.GetDoctorProperties("7EC6114A-62CD-4DC4-A940-1416BFB136D8", User.Identity.Name, strDoctorCareName, strDoctorCareNumber, strClinicName, strClinicNumber)
            '''''''''''''''''''''''''''''''''''objTreatmentService.GetHdDoctorProperties("C4AEB905-6C91-4FC8-93BE-1486B99518E57", User.Identity.Name, strDoctorCareName, strDoctorCareNumber, strClinicName, strClinicNumber)

            strClinicNumber = Trim(strClinicNumber)

            Dim bBashanZakautPermitions As Boolean = objUser.GetBashanZakautPermitions("8CE02069-9F79-4D39-A07C-5DDE5BD7C3D9", User.Identity.Name)
            If Not bBashanZakautPermitions Then
                bBashanZakautPermitions = objUser.GetCheckZakautHarelPermition("E64600AD-4946-4DFD-9CDD-032FD5B48634", User.Identity.Name)
            End If
            Dim bMultiCheckPermitions As Boolean = False
            Dim bAllowPriodontRequest As Boolean = objUser.GetPriodontRequestPermitions("1DDDF20C-5DC6-4656-A2CB-2D83B7CC13D9", User.Identity.Name)
            Dim bConsultationPermitions As Boolean = objUser.GetConsultationPermitions("AB699114-1C1D-4EB7-8186-033B5306E799", User.Identity.Name)
            spnMultiCheck.Visible = False
            spnManageUsers.Visible = False

            'Avner 290909

            'If Application("Smile") = "1" Then
            If Application("Smile") = "1" Or Application("CompanyID").ToString() = "3" Then
                Session("SmileLast_InsuredID") = ""
                Session("SmileLast_InsuredFamily") = ""
                Session("SmileLast_InsuredName") = ""
                Session("Smile_Porshei_Personel") = ""

                spnRequest.Visible = False
                'Avner 290909 spnZakaut.Visible = False
                spnMRequest.Visible = False
                spnPRequest.Visible = False
                spnKeter.Visible = False
                spnUpload.Visible = False
                spnConsultation.Visible = False
                spnForiegnWorkers.Visible = False
                spnKeptAppeal.Visible = False
                'If Session("BSHN_AllowClaims") = "1" Or bBashanZakautPermitions Or bAllowPriodontRequest Or bConsultationPermitions Then

                'Avner 290909
                If Application("CompanyID").ToString() = "3" Then
                    'Leumit CompanyID=3
                    Session("Leumit_InsuredID") = String.Empty
                    Session("Leumit_CrntInsuredID") = ""
                    System.Diagnostics.Trace.WriteLine(Format("dd.MM.yyyy HH:mm:ss", DateTime.Now) & " User: " & User.Identity.Name & " frmStart.Page_Load.219: InsuredID = ''")
                    Session("Leumit_InsuredFamily") = String.Empty
                    Session("Leumit_InsuredName") = String.Empty
                    Session("Leumit_ClinicID") = String.Empty
                    Session("Leumit_DeclarationOK") = String.Empty
                    Session("Leumit_OnlyServiceBasket") = String.Empty
                    Session("Leumit_Infant") = String.Empty
                    Session("Leumit_CollectionProblem") = String.Empty
                    Session("Leumit_PayerID") = String.Empty
                    Session("Leumit_PayerFName") = String.Empty
                    Session("Leumit_PayerLName") = String.Empty
                    Session("Leumit_AlternativePayerID") = String.Empty
                    Session("Leumit_AlternativePayerFName") = String.Empty
                    Session("Leumit_AlternativePayerLName") = String.Empty
                    Session("Leumit_AlternativeCreditCompany") = String.Empty
                    Session("Leumit_AlternativeCardID") = String.Empty
                    Session("Leumit_PaymentsNumber") = String.Empty
                    spnShaban.Visible = False
                    spnShabanTxt.Visible = False

                    spnZakaut.Attributes.Add("class", "MenuItemOut")
                    spnZakaut.Attributes.Add("onmouseenter", "this.className ='MenuItemOn';")
                    spnZakaut.Attributes.Add("onmouseleave", "this.className='MenuItemOut';")
                    If strClinicNumber = "" Or strClinicNumber = "0" Then
                        spnZakaut.Attributes.Add("onclick", "alert('��� ������ ����� ����� ��� ����� �����. �� ��� ����� ������')")
                    Else
                        spnZakaut.Attributes.Add("onclick", "window.navigate('frmLMCheck.aspx')")
                    End If

                Else

                    Dim isSmileAgrementClinic As Boolean = False
                    If Application("Smile") = "1" Then
                        isSmileAgrementClinic = objUser.CheckIfAgrementClinic("4C29075C-B17E-4EB5-A302-5EB9D5930E99", User.Identity.Name)

                        If isSmileAgrementClinic Then
                            spnShabanTxt.InnerText = "����� ����� ��"
                        End If
                    End If

                    spnZakaut.Visible = False

                    spnShaban.Attributes.Add("class", "MenuItemOut")
                    spnShaban.Attributes.Add("onmouseenter", "this.className ='MenuItemOn';")
                    spnShaban.Attributes.Add("onmouseleave", "this.className='MenuItemOut';")
                    If strClinicNumber = "" Or strClinicNumber = "0" Then
                        spnShaban.Attributes.Add("onclick", "alert('��� ������ ����� ����� ��� ����� �����. �� ��� ����� ������')")
                    Else
                        spnShaban.Attributes.Add("onclick", "window.navigate('frmCheckSM.aspx')")
                    End If
                    'Else
                    '    spnShaban.Visible = False
                    'End If

                End If



                If Not Application("DoctorService") Is Nothing Then
                    spnDoctorService.Attributes.Add("class", "MenuDoctorServiceOut")
                    spnDoctorService.Attributes.Add("onmouseenter", "this.className ='MenuItemOn';")
                    spnDoctorService.Attributes.Add("onmouseleave", "this.className='MenuDoctorServiceOut';")
                    spnDoctorService.Attributes.Add("onclick", "window.open('" & CType(Application("DoctorService"), String) & "')")
                Else
                    spnDoctorService.Visible = False
                End If
            Else
                spnShaban.Visible = False
                spnShabanTxt.Visible = False
                If Session("BSHN_AllowClaims") = "1" Then
                    spnRequest.Attributes.Add("class", "MenuItemOut")
                    spnRequest.Attributes.Add("onmouseenter", "this.className ='MenuItemOn';")
                    spnRequest.Attributes.Add("onmouseleave", "this.className='MenuItemOut';")
                    If strClinicNumber = "" Or strClinicNumber = "0" Then
                        spnRequest.Attributes.Add("onclick", "alert('��� ������ ����� ����� ��� ����� �����. �� ��� ����� ������')")
                    Else
                        spnRequest.Attributes.Add("onclick", String.Format("window.navigate('{0}')", Utils.Navigation.GetURL("frmRequestt.aspx")))
                    End If
                Else
                    spnRequest.Visible = False
                    'spnRequest.Attributes.Add("onmouseenter", "ImgFocus();")
                    'spnRequest.Attributes.Add("onmouseleave", "window.status='';")
                End If

                Dim iDoctorType As Integer = objUser.GetUserDoctorType("C049B33B-243D-43C1-B2F5-AB4859F9EBD1", User.Identity.Name)
                '''''''''''''''''''''''''''''''Dim iDoctorType As Integer = objUser.GetHDUserDoctorType("0B776BB2-51E1-11E4-8E10-7F911D5D46B0", User.Identity.Name)

                If bBashanZakautPermitions Then
                    spnZakaut.Attributes.Add("class", "MenuItemOut")
                    spnZakaut.Attributes.Add("onmouseenter", "this.className ='MenuItemOn';")
                    spnZakaut.Attributes.Add("onmouseleave", "this.className='MenuItemOut';")
                    If strClinicNumber = "" Or strClinicNumber = "0" Then
                        spnZakaut.Attributes.Add("onclick", "alert('��� ������ ����� ����� ��� ����� �����. �� ��� ����� ������')")
                    Else
                        If ((iDoctorType = 1) Or (iDoctorType = 2)) Then
                            spnZakaut.Attributes.Add("onclick", "window.navigate('frmZakautExt.aspx')")
                        Else
                            If Application("CompanyID").ToString() = "0" Or Application("CompanyID").ToString() = "1" Then
                                spnZakaut.Attributes.Add("onclick", "window.navigate('frmZakautExt.aspx')")
                            Else
                                spnZakaut.Attributes.Add("onclick", "window.navigate('frmZakaut.aspx')")
                            End If
                        End If
                    End If
                Else
                    'spnRequest.Attributes.Add("class", "MenuItemOutDis")
                    spnZakaut.Visible = False
                End If

                Dim bAllowMouthRequest As Boolean = objUser.GetMouthRequestPermitions("AC616A4E-9E4B-4B27-BB73-B4A8AC31A63E", User.Identity.Name)

                If Application("App_Type").ToString().ToUpper() = "DIVUR" Then
                    If bAllowMouthRequest Then
                        spnMRequest.Attributes.Add("class", "MenuItemOut")
                        spnMRequest.Attributes.Add("onmouseenter", "this.className ='MenuItemOn';")
                        spnMRequest.Attributes.Add("onmouseleave", "this.className='MenuItemOut';")
                        If strClinicNumber = "" Or strClinicNumber = "0" Then
                            spnMRequest.Attributes.Add("onclick", "alert('��� ������ ����� ����� ��� ����� �����. �� ��� ����� ������')")
                        Else
                            spnMRequest.Attributes.Add("onclick", "window.navigate('frmMRequestt.aspx')")
                        End If
                    Else
                        spnMRequest.Visible = False
                    End If
                Else
                    spnMRequest.Visible = False
                End If

                If Application("App_Type").ToString().ToUpper() = "DIVUR" Then
                    If bAllowPriodontRequest Then
                        spnPRequest.Attributes.Add("class", "MenuItemOut")
                        spnPRequest.Attributes.Add("onmouseenter", "this.className ='MenuItemOn';")
                        spnPRequest.Attributes.Add("onmouseleave", "this.className='MenuItemOut';")
                        If strClinicNumber = "" Or strClinicNumber = "0" Then
                            spnPRequest.Attributes.Add("onclick", "alert('��� ������ ����� ����� ��� ����� �����. �� ��� ����� ������')")
                        Else
                            spnPRequest.Attributes.Add("onclick", "window.navigate('frmPRequestt.aspx')")
                        End If
                    Else
                        spnPRequest.Visible = False
                    End If
                Else
                    spnPRequest.Visible = False
                End If

                Dim bAllowKeter As Boolean = objUser.GetKeterPermitions("8577A6A8-8AAE-402B-A928-9294C241DBCD", User.Identity.Name)

                If bAllowKeter Then
                    spnKeter.Attributes.Add("class", "MenuItemOut")
                    spnKeter.Attributes.Add("onmouseenter", "this.className ='MenuItemOn';")
                    spnKeter.Attributes.Add("onmouseleave", "this.className='MenuItemOut';")
                    spnKeter.Attributes.Add("onclick", "window.navigate('frmKeterStart.aspx')")
                Else
                    spnKeter.Visible = False
                End If
                '#Else
                '        spnMRequest.Visible = False
                If Session("Allow_Action_Type_Upload") = "1" Then
                    spnUpload.Attributes.Add("class", "MenuItemOut")
                    spnUpload.Attributes.Add("onmouseenter", "this.className ='MenuItemOn';")
                    spnUpload.Attributes.Add("onmouseleave", "this.className='MenuItemOut';")
                    spnUpload.Attributes.Add("onclick", "window.navigate('frmUploadt.aspx')")
                Else
                    spnUpload.Visible = False
                End If

                'If Application("CompanyID").ToString() = "0" Then
                If Not Application("DoctorService") Is Nothing Then
                    spnDoctorService.Attributes.Add("class", "MenuDoctorServiceOut")
                    spnDoctorService.Attributes.Add("onmouseenter", "this.className ='MenuItemOn';")
                    spnDoctorService.Attributes.Add("onmouseleave", "this.className='MenuDoctorServiceOut';")
                    spnDoctorService.Attributes.Add("onclick", "window.open('" & CType(Application("DoctorService"), String) & "')")
                Else
                    spnDoctorService.Visible = False
                End If

                If Application("App_Type").ToString().ToUpper() = "DIVUR" Then
                    If bConsultationPermitions Then
                        spnConsultation.Attributes.Add("class", "MenuItemOut")
                        spnConsultation.Attributes.Add("onmouseenter", "this.className ='MenuItemOn';")
                        spnConsultation.Attributes.Add("onmouseleave", "this.className='MenuItemOut';")
                        If strClinicNumber = "" Or strClinicNumber = "0" Then
                            spnConsultation.Attributes.Add("onclick", "alert('��� ������ ����� ����� ��� ����� �����. �� ��� ����� ������')")
                        Else
                            spnConsultation.Attributes.Add("onclick", "window.navigate('frmTRequestt.aspx')")
                        End If
                    Else
                        spnConsultation.Visible = False
                    End If
                Else
                    spnConsultation.Visible = False
                End If

                If (Application("App_Type").ToString().ToUpper() = "DIVUR") And (Application("IfAllowMultiCheckZakaut") = "1") And ((iDoctorType = 1) Or (iDoctorType = 2)) Then
                    bMultiCheckPermitions = objUser.GetMultiCheckZakautPermition("4B29B2CF-68DB-4748-8725-0DBE5F74F371", User.Identity.Name)
                End If

                If bMultiCheckPermitions Then
                    spnMultiCheck.Visible = True
                    spnMultiCheck.Attributes.Add("class", "MenuItemOut")
                    spnMultiCheck.Attributes.Add("onmouseenter", "this.className ='MenuItemOn';")
                    spnMultiCheck.Attributes.Add("onmouseleave", "this.className='MenuItemOut';")
                    If strClinicNumber = "" Or strClinicNumber = "0" Then
                        spnMultiCheck.Attributes.Add("onclick", "alert('��� ������ ����� ����� ��� ����� �����. �� ��� ����� ������')")
                    Else
                        spnMultiCheck.Attributes.Add("onclick", "window.navigate('frmMultiCheck.aspx')")
                    End If
                Else
                    spnMultiCheck.Visible = False
                End If

                If Application("App_Type").ToString.ToUpper = "CLAIM" Or Application("App_Type").ToString.ToUpper = "DIST" Then
                    If Application("HasForigenWorkers") = "1" Then
                        If Session("Allow_ForeignWorkers_Claims") = "1" Then
                            spnForiegnWorkers.Visible = True
                            spnForiegnWorkers.Attributes.Add("class", "MenuItemOut")
                            spnForiegnWorkers.Attributes.Add("onmouseenter", "this.className ='MenuItemOn';")
                            spnForiegnWorkers.Attributes.Add("onmouseleave", "this.className='MenuItemOut';")
                            'spnKeptAppeal.Visible = True	'temporary
                            spnKeptAppeal.Visible = False
                            If objUser.CheckFWDeclaration("3F6DCC54-177C-424D-857A-742B4075E09A", User.Identity.Name) Then
                                spnForiegnWorkers.Attributes.Add("onclick", "window.navigate('frmFWClaim.aspx')")
                            Else
                                spnForiegnWorkers.Attributes.Add("onclick", "window.navigate('frmFWClaimDeclaration.aspx')")
                            End If
                        Else
                            spnForiegnWorkers.Visible = False
                            spnKeptAppeal.Visible = False
                        End If
                    Else
                        spnForiegnWorkers.Visible = False
                        spnKeptAppeal.Visible = False
                    End If
                    Dim sUserID As String = objUser.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", User.Identity.Name)
                    Dim bIsManagerCommunity As Boolean = objUser.IsManagerCommunity("B4900750-FD16-11DF-8CFF-0800200C9A66", CInt(sUserID))
                    If bIsManagerCommunity Then
                        spnManageUsers.Visible = True
                        spnManageUsers.Attributes.Add("onclick", "window.navigate('frmmanageusers.aspx')")
                    End If
                Else
                    spnForiegnWorkers.Visible = False
                    spnKeptAppeal.Visible = False
                End If
            End If

#Else
#If Not EngDesign Then
            If Session("Allow_Action_Type_Upload") <> "1" Then
                trUpload.Visible = False
            End If
            If Session("Allow_Download_Files") <> "1" Then
                trDownload.Visible = False
            End If

            If Session("Dispatch_Ability") = "1" Then
                trSendInf.Visible = True
            Else : Session("Dispatch_Ability") = "0"
                If (Application("IsPool") = "1") Then
                    trSendInf.Visible = objUser.GetSendMailPermition("3B6090B0-4E40-4881-8113-632AB3E144DC", User.Identity.Name)
                Else
                    trSendInf.Visible = False
                End If

            End If

            hidClaimApp.Value = "0"
            If Application("IsPool") & "" = "1" Then
                cmdUserProp.Visible = False
                hidClaimApp.Value = "2"
            End If
#End If
#End If


#If Not NewDesign Then
            '        If objUser.GetShenSystemPermitions("8CE02069-9F79-4D39-A07C-5DDE5BD7C3D9", User.Identity.Name) Then

            '            Dim crypt As New Crypto.Crypto()
            '            Dim strShenSystemURL As String = Application("ShenSystemURL").ToString()
            '            Dim strShenSystemPublicKeyFileName As String = Application("ShenSystemPublicKeyFileName").ToString()
            '            Dim strPublicKeyPath As String
            '            Dim strParams As String
            '            Dim strEncryptParams As String

            '            strPublicKeyPath = Server.MapPath("bin")
            '            strPublicKeyPath = strPublicKeyPath & "\" & strShenSystemPublicKeyFileName

            '            strParams = "$$" & User.Identity.Name & "$$" & DateTime.Now.ToString("yyyyMMddssffff")
            '            strEncryptParams = crypt.EncryptWithCer(strParams, strPublicKeyPath)

            '            spnShenSystem.Attributes.Add("class", "MenuItemOut")
            '            spnShenSystem.Attributes.Add("onmouseenter", "this.className ='MenuItemOn';")
            '            spnShenSystem.Attributes.Add("onmouseleave", "this.className='MenuItemOut';")
            '            spnShenSystem.Attributes.Add("onclick", "window.open('" & strShenSystemURL & "?user=" & strEncryptParams & "')")
            '            '#Else
            '            '            spnShenSystem.Visible = False

            '        Else
            '            'spnRequest.Attributes.Add("class", "MenuItemOutDis")
            spnShenSystem.Visible = False
            '        End If
#End If

            If Application("RightLogo") = "1" Then
                divRIcon.Visible = True
            Else
                divRIcon.Visible = False
            End If

            If Session("Show_Message") = "" Then
                Dim strDate As String = Session("Last_Login_Date")
                Dim strTime As String = Session("Last_Login_Time")
                strText = "����" & " " & strUserName & ". "
                If Len(strDate) > 0 Then
                    strText += "����� ������ ������ ���� ������ " & " " & strDate & " " & " ���" & " " & strTime & "."
                End If
                Session("Show_Message") = "1"
                Session("Message_Text") = "�� �����: " & strUserName
            Else
                strText = Session("Message_Text")
            End If

            'lblMessage.Text = CEncode.StringEncode(strText)
#If NewDesign And Not EngDesign Then
            cmdAddReport.Visible = True
            If Application("HasHani").ToString() = "1" Then
                trSendInf.Visible = False
            Else
                trSendInf.Visible = True
            End If
#End If
        End If
        SiteInfo.InnerHtml = Application("SiteInfo").ToString() & "&nbsp;"
    End Sub

    Private Sub cmdUserProp_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUserProp.ServerClick
        Session("User_Prop_Caller") = "frmStart.aspx"
#If NewDesign And Not EngDesign Then
        If Application("HasCB") = "1" Or Application("HasHani").ToString() = "1" Then
            'Response.Redirect("frmUserInfo.aspx")
            Response.Redirect((New Utils).GetLinkForNextForm("frmUserInfo.aspx"))
        Else
            'Response.Redirect(Application("FORMUserProp") & GetLinkForNextForm(Application("FORMUserProp")))
            Response.Redirect((New Utils).GetLinkForNextForm(Application("FORMUserProp")))
        End If
#Else
        Response.Redirect("frmUserProp.aspx")
#End If
    End Sub

    Private Sub cmdLogout_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdLogout.ServerClick


        Session.Clear()
        Session.Abandon()

        
        Dim SignOut As Boolean = (New Utils).SignOut(Application("FORMLogin"))
    End Sub

#If NewDesign Then
#If Not EngDesign Then
    Private Sub cmdUpload_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUpload.Click
        Response.Redirect("frmUploadt.aspx")
        'Response.Redirect("frmSendFile.aspx")
    End Sub

    Private Sub cmdDownload_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDownload.Click
        Response.Redirect("frmDownloadManager.aspx")
    End Sub

    Private Sub cmdViewData_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdViewData.Click
        Session("RepStat_FromPageName") = "frmStart.aspx"
        'Response.Redirect(Application("FORMRepStat") & GetLinkForNextForm(Application("FORMRepStat")))
        Response.Redirect((New Utils).GetLinkForNextForm(Application("FORMRepStat")))
    End Sub
#End If
#End If

#If NewDesign Then
#If Not EngDesign Then
    Private Sub cmdAddReport_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAddReport.Click
        If (Application("CompanyID") = "1" And Application("App_Type").ToString.ToLower = "claim") OrElse _
           (Application("IsPool") = "1") Then
            Response.Redirect("frmSendFile.aspx")
        Else
            Response.Redirect("frmAddReport.aspx")
        End If
    End Sub

    Private Sub cmdTechSupportForm_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdTechSupportForm.ServerClick

        Dim nextForm As String = Application("FORMfrmTechSupportAddReport") '"frmTechSupportAddReport.aspx"

        If Application("HasHani").ToString() = "1" Then
            'nextForm = "frmAccTechSupportAddReport.aspx"
            Session("prev2frmAccTechSupportAddReport") = THIS_FRM_ASPX_NAME
        End If

        'Response.Redirect("frmTechSupportAddReport.aspx")
        Session("SupportSubjects") = hidSupportSubjects.Value
        Response.Redirect((New Utils).GetLinkForNextForm(nextForm.ToLower()))
    End Sub

    Private Sub cmdSend2Occasional_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSend2Occasional.Click
        Dim nextForm As String = "frmSendOccasional.aspx"
        Response.Redirect((New Utils).GetLinkForNextForm(nextForm.ToLower()))
    End Sub
#End If
#End If
End Class
