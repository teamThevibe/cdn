Imports System.Web.Security
Imports System.Text.RegularExpressions
Imports VB = Microsoft.VisualBasic


Public Class frmUserProp
    Inherits System.Web.UI.Page
    Protected WithEvents cmdReturn As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdConfirmation As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents ErrorMessage As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents ExtraIdAnswer As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtQuestion As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFName As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtLName As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtUserName As System.Web.UI.WebControls.TextBox
    Protected WithEvents cmdCancel As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents txtPhone As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtMobile As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtFax As System.Web.UI.WebControls.TextBox
    Protected WithEvents UserNameConfirmation As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents PasswordConfirmation As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtEMail As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtCFName As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtCPhone As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtCLName As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtCMobile As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtCFax As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtCEMail As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtError As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAppType As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtNewPassword As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtConfirmPassword As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents chkPassword As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents txtPassword As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents cmdLogout As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cboService1 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents cboProf1 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents cboService2 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents cboProf2 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents cboService3 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents cboProf3 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents cboService4 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents cboProf4 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents cboService5 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents cboProf5 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents cboService6 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents cboGridRowCount As System.Web.UI.WebControls.DropDownList
    Protected WithEvents txtBank As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtBranch As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtAccount As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtStreet As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtHouse As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtCity As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtZIP As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtMailStreet As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtMailPhone As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtMailHouse As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtMailEMail As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtMailCity As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtMailZIP As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtCStreet As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtCHouse As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtCCity As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtCZIP As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtClinicID As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtClinicName As System.Web.UI.WebControls.TextBox
    'Protected WithEvents txtDoctorID As System.Web.UI.WebControls.TextBox
    Protected WithEvents cmdBack As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdOK As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents txtUserType As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtErrorType As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents cboBanks As System.Web.UI.HtmlControls.HtmlSelect
    Protected WithEvents txtExpired As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents cmdHelp As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents txtFormIdentity As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents aIconlink As System.Web.UI.HtmlControls.HtmlAnchor
    Protected WithEvents divRIcon As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents cboSection As System.Web.UI.WebControls.DropDownList
    Protected WithEvents cboCare As System.Web.UI.WebControls.DropDownList
    Protected WithEvents hidCare As System.Web.UI.HtmlControls.HtmlInputHidden

    Protected WithEvents trBshnPerm As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents trSuppPref As System.Web.UI.HtmlControls.HtmlTableRow

    Protected WithEvents trExtraQuestion As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents trExtraAnswer As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents trEmail As System.Web.UI.HtmlControls.HtmlTableRow
    'Protected WithEvents trMiscSep As System.Web.UI.HtmlControls.HtmlTableRow
    'Protected WithEvents trClinic As System.Web.UI.HtmlControls.HtmlTableRow
#If NewDesign Then
    Protected WithEvents trSuppPrefShila As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents cboSubSuppliers As System.Web.UI.WebControls.DropDownList
    Protected WithEvents trchkExtra As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents chkExtra As System.Web.UI.HtmlControls.HtmlInputCheckBox

    Protected WithEvents divUserName As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents tdRightPic As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents imgRightPic As System.Web.UI.HtmlControls.HtmlImage
    Protected WithEvents imgLeftPic As System.Web.UI.HtmlControls.HtmlImage
    Protected WithEvents trMiscSep As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents trClinic As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents tdClinicID As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents tdClinicName As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents txtHasCB As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidClaimApp As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents divPromtTitle As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents imgPassDescr As System.Web.UI.HtmlControls.HtmlImage
    Protected WithEvents QuestionMark1 As System.Web.UI.HtmlControls.HtmlAnchor

#If Not EngDesign Then
    Protected WithEvents hidNoFailCurrentPasswordLocal As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidNoFailCurrentPasswordGeneral As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents trCarePref As System.Web.UI.HtmlControls.HtmlTableRow
#End If

#Else
    Protected WithEvents lblMessage As System.Web.UI.WebControls.Label
    Protected WithEvents trMiscSep As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents trClinic As System.Web.UI.HtmlControls.HtmlTableRow
#End If

    Protected WithEvents txtNewEMail As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents aIconLink2 As System.Web.UI.HtmlControls.HtmlAnchor
    Protected WithEvents lblPasswordError As System.Web.UI.WebControls.Label
    Protected WithEvents Tr1 As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents cmdDoctors As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents divPasswordError As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents tblTabs As System.Web.UI.WebControls.Table
    Protected WithEvents UserConfirmation As UserConfirmation

    Enum btns 'tab_buttons
        BTN_COMMON_PROP = 1
        BTN_BANK = 2
        BTN_SERVICE = 3
        BTN_MAIL = 4
        BTN_CONTACT = 5
        BTN_MISC = 6
        BTN_PWD = 7
    End Enum

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim strUserType As String

#If NewDesign Then
        Dim FormUserProp As String = Application("FORMUserProp") 'frmUserProp.aspx / frmSMUserProp.aspx
        Dim check As Boolean = (New Utils).CheckKey(FormUserProp.ToLower)
#End If

        If Not IsPostBack Then
#If Not EngDesign Then
            If Session("User_Login_First_Time") = "1" Then
                'Response.Redirect("frmUserPass.aspx")

                'If "1".Equals(Application("InsuredStatusAsMainScreen")) Then
                '    Response.Redirect((New Utils).GetLinkForNextForm("frmHDUserPass.aspx"))
                'Else
                '    Response.Redirect((New Utils).GetLinkForNextForm("frmUserPass.aspx"))
                'End If
                Response.Redirect((New Utils).GetLinkForNextForm(Application("FORMUserPass")))

            End If
#End If
            aIconlink.HRef = Application("ClientSiteLink")
            Dim objUser As New UserConnect.UserService()
            objUser.Url = Application("UserWebService").ToString()

#If NewDesign And Not EngDesign Then

            If Application("HasCB") = "1" Then
                txtHasCB.Value = "1"
            Else
                txtHasCB.Value = "0"
            End If
            hidClaimApp.Value = "0"
            If Application("IsDorAlon") = "1" Then
                hidClaimApp.Value = "1"
            End If

#End If
#If NewDesign Then
            If Application("HasHani").ToString() = "1" Then
                cmdBack.Visible = False
            End If

#End If

#If NewDesign And Not EngDesign Then
            Dim sMailMobileExist As String = objUser.CheckIsEMailAndMobileExist("1E65EA6F-23E3-4EE6-ACEB-8CA20F658CC5", User.Identity.Name)
            Select Case (sMailMobileExist)
                Case "00"
                    txtError.Value = "�����  ������ �� ����� ����""�  ����� �����" + vbNewLine + "�����  ������ �� ������ �����  ����� �����"
                Case "01"
                    txtError.Value = "�����  ������ �� ������ �����  ����� �����"
                Case "10"
                    txtError.Value = "�����  ������ �� ������ �����  ����� �����"
                Case "11"
                    txtError.Value = ""
            End Select

            Dim iUserSiteID As Integer = objUser.GetUserSite("331EE612-6669-495A-A7CB-733603CF816D", User.Identity.Name)
            If iUserSiteID = 13 Then
                tdClinicID.InnerText = "��� �''� :"
                tdClinicName.InnerText = "�� �''� :"
            Else
                tdClinicID.InnerText = "��� ����� :"
                tdClinicName.InnerText = "�� ����� :"
            End If
#End If
#If NewDesign Then
            If Application("HasHani").ToString() = "1" Then
                imgLeftPic.Src = "pics/" & objUser.GetLogoName("17060B94-065E-4DB4-975D-A3988FFD63CC", User.Identity.Name)
            End If
#End If

            If Application("RightLogo") = "1" Then
#If NewDesign Then
                tdRightPic.Attributes("background") = "pics/BannerTopRightTransp.gif"
                imgRightPic.Attributes("src") = "pics/BannerTopRightTransp.gif"
#End If
                divRIcon.Visible = True
            Else
#If NewDesign Then
                tdRightPic.Attributes("background") = "pics/BannerTopRightPic.gif"
                imgRightPic.Attributes("src") = "pics/BannerTopRightPic.gif"
#End If
                divRIcon.Visible = False
            End If
#If Not NewDesign Then
            divRIcon.Visible = False
#End If
            Dim strUserName As String = User.Identity.Name
            Dim strFName As String
            Dim strLName As String
            Dim strStreet As String
            Dim strHouse As String
            Dim strCity As String
            Dim strZIP As String
            Dim strPhone As String
            Dim strMobile As String
            Dim strFax As String
            Dim strEMail As String
            Dim strCFName As String
            Dim strCLName As String
            Dim strCStreet As String
            Dim strCHouse As String
            Dim strCCity As String
            Dim strCZIP As String
            Dim strCPhone As String
            Dim strCMobile As String
            Dim strCFax As String
            Dim strCEMail As String
            Dim strBank As String
            Dim strBranch As String
            Dim strAccount As String
            Dim strMailStreet As String
            Dim strMailPhone As String
            Dim strMailHouse As String
            Dim strMailEMail As String
            Dim strMailCity As String
            Dim strMailZIP As String
            Dim strService1 As String
            Dim strService2 As String
            Dim strService3 As String
            Dim strService4 As String
            Dim strService5 As String
            Dim strService6 As String
            Dim strProf1 As String
            Dim strProf2 As String
            Dim strProf3 As String
            Dim strProf4 As String
            Dim strProf5 As String
            Dim strClinicID As String
            Dim strClinicName As String
            Dim strDoctorID As String
            Dim strSupplierID As String
            Dim strSection As String
            Dim strCare As String
            Dim strDefaultExecutor As String = ""
            Dim strGridRowCount As String
            Dim iSection As Integer = -1
            Dim iSupplierID As Integer
            Dim iShilaSupplier As Integer = objUser.IsShilaSupplier("4DA7CCB6-14A5-4D27-9DF3-AD449A470103", User.Identity.Name)

            Dim strExtraIdQuestion As String
            Dim strExtraIdAnswer As String
            'Dim objUser As New UserConnect.UserService()
            'objUser.Url = Application("UserWebService").ToString()
            Dim dsServices As Data.DataSet = objUser.GetServices("8BEF9B3C-5CCB-43E8-8253-4DCD6E5334F6")

            cboService1.DataSource = dsServices
            cboService1.DataBind()
            cboService2.DataSource = dsServices
            cboService2.DataBind()
            cboService3.DataSource = dsServices
            cboService3.DataBind()
            cboService4.DataSource = dsServices
            cboService4.DataBind()
            cboService5.DataSource = dsServices
            cboService5.DataBind()
            cboService6.DataSource = dsServices
            cboService6.DataBind()

            Dim dsProf As Data.DataSet = objUser.GetProficiencies("7EF9182D-B6D5-48F1-8719-DE71CB54A522")

            cboProf1.DataSource = dsProf
            cboProf1.DataBind()
            cboProf2.DataSource = dsProf
            cboProf2.DataBind()
            cboProf3.DataSource = dsProf
            cboProf3.DataBind()
            cboProf4.DataSource = dsProf
            cboProf4.DataBind()
            cboProf5.DataSource = dsProf
            cboProf5.DataBind()
            cboBanks.DataSource = objUser.GetBanksList("905F4392-6BDE-4788-B8EF-12416DAF9212")
            cboBanks.DataBind()

            Dim arrValues() As Integer = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15}

            cboGridRowCount.DataSource = arrValues
            cboGridRowCount.DataBind()
            'cboGridRowCount.SelectedIndex = 4

            objUser.GetProperties("305A57FB-F38A-4592-AA8E-882D66B1DEFC", strUserName, strUserType, strFName, strLName, strStreet, strHouse, strCity, strZIP, strPhone, strMobile, strFax, strEMail, _
                                  strCFName, strCLName, strCStreet, strCHouse, strCCity, strCZIP, strCPhone, strCMobile, strCFax, strCEMail, _
                                  strBank, strBranch, strAccount, strMailStreet, strMailPhone, strMailHouse, strMailEMail, strMailCity, strMailZIP, _
                                  strService1, strService2, strService3, strService4, strService5, strService6, strProf1, strProf2, strProf3, strProf4, _
                                  strProf5, strClinicID, strClinicName, strDoctorID, strSupplierID, strSection, strCare, strGridRowCount, strExtraIdQuestion, strExtraIdAnswer)
            txtUserName.Text = Utils.AntiXSSHtml(strUserName)

            Dim objRequest As New SupplierConnect.RequestClaim()
            objRequest.Url = Application("SupplierWebService").ToString()
            If IsNumeric(strSupplierID) Then
                iSupplierID = CInt(strSupplierID)
            End If

#If NewDesign And Not EngDesign Then

            Dim strDefaultSection = "0", strDefaultCare As String = "0"
            Dim bComboSectionEnabled = True, bComboCareEnabled As Boolean = True

            If iUserSiteID = 11 Then
                objUser.GetSectionCareRules("25532FD8-CEC7-4DFF-86CE-B4517AC0986A", Val(strSupplierID), bComboSectionEnabled, bComboCareEnabled, strDefaultSection, strDefaultCare)

                If Not bComboSectionEnabled Then
                    strSection = strDefaultSection
                End If

                If Not bComboCareEnabled Then
                    strCare = strDefaultCare
                End If
            End If

            If iShilaSupplier = 1 Then
                Dim strDefCareTye As String = ""
                Dim strDefReceptCause As String = ""
                Dim strDefActionType As String = ""

                objUser.GetCBUserDefaultValues("06559352-AB48-40A4-83FE-89281166ECDD", User.Identity.Name, strDefCareTye, strDefReceptCause, strDefActionType, strDefaultExecutor)
                cboSubSuppliers.Enabled = False
            End If
#End If
            Dim ds As Data.DataSet = objRequest.GetSectionsList("0CBD2A1A-C450-424E-801C-8E90FDC01998", iSupplierID)
            Dim currRow As Data.DataRow
#If EngDesign Then
            cboSection.Items.Add(New ListItem("Select Section", ""))
#Else
            cboSection.Items.Add(New ListItem("��� ���", ""))
#End If
            For Each currRow In ds.Tables(0).Rows
                cboSection.Items.Add(New ListItem(currRow("SectionName").ToString(), currRow("SectionCode").ToString()))
            Next
            If IsNumeric(strSection) Then
                iSection = CInt(strSection)
            End If
            ds = objRequest.GetCareBySection("491AE412-CF31-4644-AC7C-59DD8505B5A1", iSection)
#If EngDesign Then
            cboCare.Items.Add(New ListItem("Select Treatment", ""))
#Else
            cboCare.Items.Add(New ListItem("��� �����", ""))
#End If
            For Each currRow In ds.Tables(0).Rows
                cboCare.Items.Add(New ListItem(currRow("CareName").ToString(), currRow("CareID").ToString()))
            Next

            Dim strToday As String = Date.Today.ToString("ddMMyyyy")
            ds = objRequest.GetSubSuppliersList("949BE198-F48B-4E9D-8B4A-5983224F93EC", iSupplierID, strToday)
#If NewDesign Then
#If EngDesign Then
            cboSubSuppliers.Items.Add(New ListItem("Select ..", ""))
#Else
            cboSubSuppliers.Items.Add(New ListItem("���", ""))
#End If
            For Each currRow In ds.Tables(0).Rows
                Dim sSupDesc As String = currRow("SupID").ToString() & " - " & currRow("SupName").ToString()
                cboSubSuppliers.Items.Add(New ListItem(sSupDesc, currRow("SupID").ToString()))
            Next
#End If

            Dim bBshnPerm As Boolean = False
            Dim bSuppPref As Boolean = False
            Dim bCarePref As Boolean = False

            Select Case Application("App_Type").ToString.ToUpper()
                Case "DIST"
                    'cmdHelp.Disabled = True
                    If Session("AS400_User") = "1" Then
                        strUserType = "4"
                    Else
                        strUserType = "3"
                    End If
                    If Session("Allow_Action_Type_Upload") = "1" Then
                        cmdReturn.Visible = True
                    Else
                        cmdReturn.Visible = False
                    End If
#If Not NewDesign Then
                    trMiscSep.Visible = False
                    trClinic.Visible = False
#End If
                Case "DIVUR"
                    cmdHelp.Disabled = False
                    txtClinicID.ReadOnly = True
                    txtClinicID.Attributes.Remove("onfocus")
                    txtClinicID.Attributes.Remove("onblur")
                    txtClinicID.CssClass = "cssDisabledTextBox"
                    txtClinicName.ReadOnly = True
                    txtClinicName.Attributes.Remove("onfocus")
                    txtClinicName.Attributes.Remove("onblur")
                    txtClinicName.CssClass = "cssDisabledTextBox"
                    bBshnPerm = True
                Case "CLAIM", "ENG"
                    cmdHelp.Disabled = False
                    trEmail.Visible = False
                    trMiscSep.Visible = False
                    trClinic.Visible = False

                    If Session("AS400_User") = "1" Then
                        strUserType = "4"
                    End If
                    If Session("Allow_Action_Type_Upload") = "1" Then
                        cmdReturn.Visible = True
                    Else
                        cmdBack.Visible = False
                        cmdReturn.Visible = False
                    End If
                Case "DOAR"
                    cmdHelp.Disabled = False
                    strUserType = 30
                    cmdReturn.Value = "�����"
                    cmdReturn.Attributes("onclick") = "window.close();return;"
#If NewDesign Then
                    cmdReturn.Style.Item("display") = "inline"
                    cmdBack.Visible = False
#End If
                Case "SUPP"
                    bCarePref = True
                    'trEmail.Visible = False
                    cmdOK.Attributes.Remove("onclick")
                    cmdOK.Attributes("onclick") = "UserConfirmation.RequestPassword(this);return;"
                    txtClinicID.ReadOnly = True
                    txtClinicID.Attributes.Remove("onfocus")
                    txtClinicID.Attributes.Remove("onblur")
                    txtClinicID.CssClass = "cssDisabledTextBox"
                    txtClinicName.ReadOnly = True
                    txtClinicName.Attributes.Remove("onfocus")
                    txtClinicName.Attributes.Remove("onblur")
                    txtClinicName.CssClass = "cssDisabledTextBox"
#If NewDesign And Not EngDesign Then
                    If iUserSiteID = 11 Then
                        If bComboCareEnabled Then
                            cboCare.Enabled = True
                        Else
                            cboCare.Enabled = False
                            cboCare.Attributes.Remove("onfocus")
                            cboCare.Attributes.Remove("onblur")
                            cboCare.CssClass = "cssDisabledTextBox"
                        End If

                        If bComboSectionEnabled Then
                            cboSection.Enabled = True
                        Else
                            cboSection.Enabled = False
                            cboSection.Attributes.Remove("onfocus")
                            cboSection.Attributes.Remove("onblur")
                            cboSection.CssClass = "cssDisabledTextBox"
                        End If
                    End If
#End If

                    If Session("SUPP_AllowClaims") <> "1" And Session("SUPP_HospitalClaim") <> "1" Then
                        cboSection.Enabled = False
                        cboSection.Attributes.Remove("onfocus")
                        cboSection.Attributes.Remove("onblur")
                        cboSection.CssClass = "cssDisabledTextBox"
                        cboCare.Enabled = False
                        cboCare.Attributes.Remove("onfocus")
                        cboCare.Attributes.Remove("onblur")
                        cboCare.CssClass = "cssDisabledTextBox"
                    End If

                    cmdHelp.Disabled = False
                    strUserType = "40"
                    bSuppPref = True

                    SetComboValue(cboSection, strSection)
                    SetComboValue(cboCare, strCare)
#If NewDesign Then
                    SetComboValue(cboSubSuppliers, strDefaultExecutor)

#End If
            End Select
            txtUserType.Value = strUserType 'support old design

            trBshnPerm.Visible = bBshnPerm
            trSuppPref.Visible = bSuppPref

            txtAppType.Value = Application("App_Type").ToString
#If NewDesign Then
#If Not EngDesign Then




            trCarePref.Visible = bCarePref
#End If
            trSuppPrefShila.Visible = IIf(iShilaSupplier = 1, True, False)
            divUserName.InnerText = Trim(strFName & " " & strLName)
#End If
            txtFName.Text = strFName
            txtLName.Text = strLName
            txtStreet.Text = strStreet
            txtHouse.Text = strHouse
            txtCity.Text = strCity
            txtZIP.Text = strZIP
            txtPhone.Text = strPhone
            txtMobile.Text = strMobile
            txtFax.Text = strFax
            txtEMail.Text = Trim(strEMail)
            'txtCFName.Text = strCFName
            'txtCLName.Text = strCLName
            'txtCStreet.Text = strCStreet
            'txtCHouse.Text = strCHouse
            'txtCCity.Text = strCCity
            'txtCZIP.Text = strCZIP
            'txtCPhone.Text = strCPhone
            'txtCMobile.Text = strCMobile
            'txtCFax.Text = strCFax
            'txtCEMail.Text = Trim(strCEMail)
            txtBank.Text = strBank
            txtBranch.Text = strBranch
            txtAccount.Text = strAccount
            txtMailStreet.Text = strMailStreet
            txtMailPhone.Text = strMailPhone
            txtMailHouse.Text = strMailHouse
            txtMailEMail.Text = Trim(strMailEMail)
            txtMailCity.Text = strMailCity
            txtMailZIP.Text = strMailZIP
            txtClinicID.Text = strClinicID
            txtClinicName.Text = strClinicName
            'txtDoctorID.Text = strDoctorID


            SetComboValue(cboService1, strService1)
            SetComboValue(cboService2, strService2)
            SetComboValue(cboService3, strService3)
            SetComboValue(cboService4, strService4)
            SetComboValue(cboService5, strService5)
            SetComboValue(cboService6, strService6)
            SetComboValue(cboProf1, strProf1)
            SetComboValue(cboProf2, strProf2)
            SetComboValue(cboProf3, strProf3)
            SetComboValue(cboProf4, strProf4)
            SetComboValue(cboProf5, strProf5)
            SetSelectValue(cboBanks, strBank)
            SetComboValue(cboGridRowCount, strGridRowCount)

            Dim ExtraIdQuestionFromTable As String = ""
            Dim ExtraIdAnswerFromTable As String = ""

            '            If Application("AllowExtraID") = "1" Then
            '                objUser.GetExtraId("204A61C3-ACD7-4719-88B8-1B13313E9844", strUserName, ExtraIdQuestionFromTable, ExtraIdAnswerFromTable)
            '            End If

            '            If Application("App_Type").ToString.ToUpper() = "CLAIM" Then
            '                If Application("AllowExtraID") = "1" Then
            '                    trchkExtra.Visible = True
            '                    trExtraQuestion.Visible = True
            '                    trExtraAnswer.Visible = True
            '                    'chkPassword.Disabled = True
            '                    Tr1.Visible = True
            '                Else
            '                    trchkExtra.Visible = False
            '                    trExtraQuestion.Visible = False
            '                    trExtraAnswer.Visible = False
            '                    Tr1.Visible = False
            '                End If
            '#If NewDesign Then
            '                'If Application("IsDorAlon") <> "1" Then
            '                '    trchkExtra.Visible = False
            '                'End If
            '#End If
            '                ElseIf Application("App_Type").ToString.ToUpper() = "SUPP" Or Application("App_Type").ToString.ToUpper() = "ENG" Then
            '                    trExtraQuestion.Visible = True
            '                    trExtraAnswer.Visible = True
            '                    Tr1.Visible = True
            '#If NewDesign Then
            '                    trchkExtra.Visible = True
            '                    txtQuestion.Disabled = False
            '                    If Len(ExtraIdAnswerFromTable) = 0 Then
            '                        chkExtra.Checked = True
            '                        txtQuestion.Attributes("class") = "InputStyle"
            '                        ExtraIdAnswer.Attributes("class") = "InputStyle"
            '                        chkExtra.Disabled = True 'force any way
            '                        'If Session("User_Login_First_Time") = "1" Then
            '                        '    chkExtra.Disabled = True
            '                        'End If
            '                    Else
            '                        chkExtra.Checked = False
            '                        txtQuestion.Attributes("class") = "InputDis"
            '                        ExtraIdAnswer.Attributes("class") = "InputDis"
            '                    End If
            '#End If
            '            Else
            '                trchkExtra.Visible = False
            '                trExtraQuestion.Visible = False
            '                trExtraAnswer.Visible = False
            '                Tr1.Visible = False
            '            End If

#If NewDesign Then
            Dim bShowExtra As Boolean = (Application("AllowExtraID") = "1")
            If Application("App_Type").ToString.ToUpper() = "SUPP" Then
                bShowExtra = True
            End If

            If bShowExtra Then
                trExtraQuestion.Visible = True
                trExtraAnswer.Visible = True

                Me.txtQuestion.Value = strExtraIdQuestion
                ExtraIdAnswer.Value = strExtraIdAnswer



                Tr1.Visible = True
                objUser.GetExtraId("204A61C3-ACD7-4719-88B8-1B13313E9844", strUserName, ExtraIdQuestionFromTable, ExtraIdAnswerFromTable)
                If Len(ExtraIdAnswerFromTable) = 0 Then
                    chkExtra.Checked = True
                    'txtQuestion.Attributes("class") = "InputStyle"
                    'ExtraIdAnswer.Attributes("class") = "InputStyle"
                Else
                    chkExtra.Checked = False
                    'txtQuestion.Attributes("class") = "InputDis"
                    'ExtraIdAnswer.Attributes("class") = "InputDis"
                End If

            Else
                trchkExtra.Style.Add("display", "none")
                chkExtra.Checked = False
                trExtraQuestion.Style.Add("display", "none")
                trExtraAnswer.Style.Add("display", "none")
                Tr1.Style.Add("display", "none")
            End If
#Else
            trExtraQuestion.Style.Add("display", "none")
            trExtraAnswer.Style.Add("display", "none")
            Tr1.Style.Add("display", "none")
#End If


#If Not NewDesign Then
            lblMessage.Text = Utils.AntiXSSHtml (Session("Message_Text"))
#End If

            If Session("User_Login_First_Time") = "1" Then
#If EngDesign Then
                txtError.Value = "You must change password"
#Else
                txtError.Value = "�� ����� �����"
                'tdOldPass.focus()

#End If
                txtExpired.Value = "1"
                If Application("App_Type").ToString.ToUpper() = "SUPP" Then
                    trExtraQuestion.Visible = True
                    trExtraAnswer.Visible = True

                    Me.txtQuestion.Value = strExtraIdQuestion
                    ExtraIdAnswer.Value = strExtraIdAnswer

                    chkPassword.Disabled = True
                    Tr1.Visible = True
#If NewDesign Then
                    trchkExtra.Visible = True
                    'chkExtra.Checked = True
#End If
                End If

                If Application("App_Type").ToString.ToUpper() = "CLAIM" Or Application("App_Type").ToString.ToUpper() = "ENG" Then
                    If Application("AllowExtraID") = "1" Then
                        trExtraQuestion.Visible = True
                        trExtraAnswer.Visible = True

                        Me.txtQuestion.Value = strExtraIdQuestion
                        ExtraIdAnswer.Value = strExtraIdAnswer

                        'chkPassword.Disabled = True
                        Tr1.Visible = True
                    Else
                        trExtraQuestion.Visible = False
                        trExtraAnswer.Visible = False
                        Tr1.Visible = False
                    End If
                End If

                'ik #If Not NewDesign Then
                txtNewEMail.Value = Trim(strEMail)
                '#End If
            Else
                trEmail.Visible = False
                txtExpired.Value = ""
            End If

#If NewDesign Then
            Dim sInstr As String = ""
#If EngDesign Then
            sInstr = objUser.GetPassInstructionExt("B8CD9DE5-95C1-466d-AC29-E8170E3BCA2E", 1)
#Else
            sInstr = objUser.GetPassInstruction("B8CD9DE5-95C1-466d-AC29-E8170E3BCA2E")
#End If
            divPromtTitle.InnerHtml = sInstr
            'imgPassDescr.Style.Add("display", "block")
            QuestionMark1.Style.Add("display", "block")
#End If



#If NewDesign And Not EngDesign Then

            Dim bRet As Boolean = objUser.GetUserAllowChangePassword("32B79620-E74B-11DF-9492-0800200C9A66", _
                                                                       User.Identity.Name)

            setAllowChangePassword(bRet)

            If (bRet) Then


                Dim iNoFailCurrentPasswordLocal As Integer

                Dim iNoFailCurrentPasswordGeneral As _
                Integer = objUser.GetNoFailCurrentPassword("7496C790-E751-11DF-9492-0800200C9A66")

                hidNoFailCurrentPasswordGeneral.Value = iNoFailCurrentPasswordGeneral

            End If
#End If


        Else
            strUserType = txtUserType.Value
            divPasswordError.Visible = False
#If NewDesign Then
            If Application("App_Type").ToString.ToUpper() = "SUPP" Then
                If chkExtra.Checked Then
                    txtQuestion.Attributes("class") = "InputStyle"
                    ExtraIdAnswer.Attributes("class") = "InputStyle"
                Else
                    txtQuestion.Attributes("class") = "InputDis"
                    ExtraIdAnswer.Attributes("class") = "InputDis"
                End If
            End If
#End If
        End If


#If NewDesign And Not EngDesign Then




        ShowTabsByUserType(strUserType)
#End If

    End Sub

    Private Sub SetComboValue(ByRef cbo As DropDownList, ByVal strValue As String)
        Dim li As ListItem = cbo.Items.FindByValue(strValue)
        If Not li Is Nothing Then
            li.Selected = True
        End If
    End Sub

    Private Sub SetSelectValue(ByRef cbo As HtmlSelect, ByVal strValue As String)
        Dim li As ListItem = cbo.Items.FindByValue(strValue)
        If Not li Is Nothing Then
            li.Selected = True
        End If
    End Sub

    Private Function GetComboValue(ByVal cbo As DropDownList) As String
        Dim strRetValue As String = "0"
        Dim li As ListItem = cbo.SelectedItem
        If Not li Is Nothing Then
            '/If (Not strRetValue.Equals("")) Then
            strRetValue = li.Value
            '/End If
        End If
        Return strRetValue
    End Function

    Private Sub cmdOK_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdOK.Load

    End Sub

    Private Sub cmdOK_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdOK.ServerClick
#If NewDesign Then
        If (Not UserConfirmation.CheckUser()) Then
            Return
        End If
#End If



        Dim strUserName As String = User.Identity.Name
        Dim strPassword As String
        Dim emailvalue As String

        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

		If objUser.GetUserAllowChangePassword("32B79620-E74B-11DF-9492-0800200C9A66", User.Identity.Name) Then
			If chkPassword.Disabled Then
				chkPassword.Checked = True
			End If
        End If

        If chkPassword.Checked = True Then
            strPassword = Trim(txtPassword.Value)
            If Len(strPassword) = 0 Then
#If EngDesign Then
                ShowError("Missing Password")
#Else
                '''''''''''''''''''''''''''setNoFailCurrentPassword()

                ShowError("���� �����")
#End If
                Return
            End If

            Dim iResult As Integer = objUser.CheckUser("79D565C1-784C-4606-935B-68BA32141600", strUserName, strPassword, "0", -1, Request.UserHostAddress, User.Identity.Name)
            If iResult = -20 Then
                Dim SignOut As Boolean = (New Utils).SignOut(Application("FORMLogin"))
            End If
            If iResult <> 0 And iResult <> 10 Then
#If EngDesign Then
                ShowError("Incorrect password")
#Else

                setNoFailCurrentPassword()

                ShowError("������ ������� �����")
#End If
                Return
            End If
            If Trim(txtNewPassword.Value) <> Trim(txtConfirmPassword.Value) Then
#If EngDesign Then
                ShowError("Password confirmation not identical to the new password.")
#Else
                ''''''''''''''''''setNoFailCurrentPassword()

                ShowError("����� ����� �� ��� ������ �����")
#End If
                Return
            End If
            If LCase(Trim(txtNewPassword.Value)) = LCase(Trim(txtUserName.Text)) Then
#If EngDesign Then
                ShowError("Password must be different from the user name.")
#Else

                ''''''''''''''''''''setNoFailCurrentPassword()

                ShowError("���� ������� ���� ��� ��� ������")
#End If
                Return
            End If
            strPassword = Trim(txtNewPassword.Value)
            If Trim(txtPassword.Value) = strPassword Then
#If EngDesign Then
                ShowError("The new password must be different from the old.")
#Else
                '''''''''''''''''''''''setNoFailCurrentPassword()

                ShowError("���� ������� ����� ���� ��� ������ �������")
#End If
                Return
            End If

            If (CBool(Application("PasswordVerification"))) Then
                Dim strRegEx As String = Application("PasswordRegEx").ToString() & ""
                Dim nCheck As Integer = objUser.CheckNewPasswordEx("2DDEF6A6-4053-491A-8642-CF441B81BA46", strPassword, strRegEx)
                Select Case nCheck
                    Case 4, 5
#If EngDesign Then
                        divPasswordError.InnerHtml = "<ul dir=ltr >" & _
                                                    "<li>" & _
                                                    "<div align=left><span class=884111608-11102007><font face=Arial size=2 color=Red>Password must contain at least 8 characters</font></span></div>" & _
                                                    "<li>" & _
                                                    "<div align=left><span class=884111608-11102007><font face=Arial size=2 color=Red>Password must contain characters and digits</font></span></div>" & _
                                                    "<li>" & _
                                                    "<div align=left><span class=884111608-11102007><font face=Arial size=2 color=Red>Password must contain only characters and digits</font></span></div></li>" & _
                                                    "<li>" & _
                                                    "<div align=left><span class=884111608-11102007><font face=Arial size=2 color=Red>Password can not be the same as user name</font></span></div></li>" & _
                                                    "<li>" & _
                                                    "<div align=left><span class=884111608-11102007><font face=Arial size=2 color=Red>Characters can not be repeated sequentially more than twice</font></span></div></li>" & _
                                            "</ul>"
#Else
                        divPasswordError.InnerHtml = objUser.GetPassInstruction("B8CD9DE5-95C1-466d-AC29-E8170E3BCA2E")
#End If
                        txtErrorType.Value = "2"
                        divPasswordError.Visible = True

                        '''''''''''''''''''''''''setNoFailCurrentPassword()

                        Return
                        '                    Case 5
                        '#If EngDesign Then
                        '                                        ShowError("Do not repeat letter or number more then twice continuously.")
                        '#Else
                        '                        ShowError("��� ����� �� ���� ���� �� ����� ���� ������� ����")
                        '#End If
                        '                        Return
                    Case 6
#If EngDesign Then
                        ShowError("Do not use sequence numbers.")
#Else
                        ShowError("����� ����� ���")

                        ''''''''''''''''''''''''''''setNoFailCurrentPassword()

#End If
                        Return
                End Select
            Else
                Select Case objUser.CheckNewPassword("2A8A46F2-A060-4FD9-B74E-3784FEC1C0EF", strPassword)
                    Case 1
                        'too short or too long
#If EngDesign Then
                    ShowError("Password length must be between 6 and 10 signs")
#Else

                        ''''''''''''''''''''''''''''''''setNoFailCurrentPassword()

                        ShowError("���� ������ ���� ����� ��� 6 � 10 �����")
#End If
                        Return
                    Case 2
                        'invalid char
#If EngDesign Then
                    ShowError("Use only letters and numbers")
#Else

                        '''''''''''''''''''''''''''''setNoFailCurrentPassword()

                        ShowError("�� ������ ������� ������� ����")
#End If
                        Return
                    Case 3
                        'one char
#If EngDesign Then
                        ShowError("Do not repeat letter or number more then twice.")
#Else

                        '''''''''''''''''''''''''''''''''setNoFailCurrentPassword()

                        ShowError("��� ����� �� ���� ���� �� ����� ���� �������")
#End If
                        Return
                End Select
            End If
            ' If Application("App_Type").ToString.ToUpper() <> "CLAIM" And Application("App_Type").ToString.ToUpper() <> "ENG" Then

            If objUser.CheckPasswordHistory("6BC8399D-247C-48E4-8312-7FC05ECA207E", strUserName, strPassword) Then
                'one char
#If EngDesign Then
                        ShowError("You already used this Password")
#Else
                '''''''''''''''''''''''''setNoFailCurrentPassword()
                ShowError("������ ����� ���� ��� ������")
#End If
                Return
            End If
            'End If
        End If



        If Not CheckRegularexpression() Then
            Return
        End If


        If Application("App_Type").ToString.ToUpper() = "SUPP" Or Application("App_Type").ToString.ToUpper() = "CLAIM" Or Application("App_Type").ToString.ToUpper() = "ENG" Then
            If Application("AllowExtraID") = "1" Then
                Dim bChng As Boolean = False
#If NewDesign Then
                If Application("App_Type").ToString.ToUpper() = "SUPP" Then
                    bChng = chkExtra.Checked
                Else
                    bChng = Session("User_Login_First_Time") = "1" Or chkExtra.Checked
                End If
#End If
                If bChng Then

                    If Trim(txtQuestion.Value) = "" Then
#If EngDesign Then
                        ShowError("Login question missing")
#Else

                        ''''''''''''''''''''''''setNoFailCurrentPassword()

                        ShowError("���� ���� �����")
#End If
                        Return
                    End If

                    If Trim(ExtraIdAnswer.Value) = "" Then
#If EngDesign Then
                        ShowError("Login Response missing")
#Else
                        '''''''''''''''''''''''''setNoFailCurrentPassword()

                        ShowError("���� ����� �����")
#End If
                        Return
                    End If

                    If Regex.IsMatch(ExtraIdAnswer.Value, "[^0-9�-�a-zA-Z]") Then
#If EngDesign Then
                        ShowError("Invalid Login details. Please type letters and digits only.")
#Else

                        ''''''''''''''''''''''''''''''setNoFailCurrentPassword()

                        ShowError("��� ����� ���� �� ���� - ���� ������ �� ������ �������")
#End If
                        Return
                    End If
                    objUser.UpdateExstraId("7C2895C8-6FFC-4999-B6EF-A5CB7E522EC6", strUserName, txtQuestion.Value, ExtraIdAnswer.Value, User.Identity.Name)
                End If
            End If
        Else
            If Session("User_Login_First_Time") = "1" Then
                If Application("App_Type").ToString.ToUpper() <> "CLAIM" And Application("App_Type").ToString.ToUpper() <> "ENG" Then

                    '                    If Trim(txtEMail.Text) = "" Then
                    '#If EngDesign Then
                    '                        ShowError("Please enter email address.")
                    '#Else
                    '                        ShowError("�� ���� ����� ���� ���������")
                    '#End If
                    '                        Return
                    '                    End If
                    '/----------- Ilia -------------
                    '''''''                    Dim sRegExpr As String
                    '''''''                    emailvalue = txtEMail.Text.ToLower
                    '''''''                    If (emailvalue.Trim().Length() > 0) Then
                    '''''''                        sRegExpr = objUser.GetEmailValidation("E600F1B9-D4C7-4FC4-B1B6-922F3967456E")
                    '''''''                        '/ If Not objUser.GetEmailValidation("E600F1B9-D4C7-4FC4-B1B6-922F3967456E") Then
                    '''''''                        If Not Regex.IsMatch(emailvalue, sRegExpr) Then
                    '''''''#If EngDesign Then
                    '''''''                   ShowError("Invalid eMail address")
                    '''''''#Else
                    '''''''                            ShowError("����� ����''� �� �����")
                    '''''''#End If
                    '''''''                            Return
                    '''''''                        End If

                    '''''''                    End If

                    If Not CheckRegularexpression() Then
                        Return
                    End If

                    '/------------------------------
                End If
            End If
        End If

        If chkPassword.Checked = True Then
            If objUser.UpdatePassword("5561A874-D4D7-4E5C-AA3D-4EC0EBAA8B7F", strUserName, strPassword, 1, User.Identity.Name) And Application("App_Type").ToString.ToUpper() = "SUPP" Then
                Session("User_Password") = strPassword
            End If
        End If

        Dim strService1 As String = GetComboValue(cboService1)
        Dim strService2 As String = GetComboValue(cboService2)
        Dim strService3 As String = GetComboValue(cboService3)
        Dim strService4 As String = GetComboValue(cboService4)
        Dim strService5 As String = GetComboValue(cboService5)
        Dim strService6 As String = GetComboValue(cboService6)
        Dim strProf1 As String = GetComboValue(cboProf1)
        Dim strProf2 As String = GetComboValue(cboProf2)
        Dim strProf3 As String = GetComboValue(cboProf3)
        Dim strProf4 As String = GetComboValue(cboProf4)
        Dim strProf5 As String = GetComboValue(cboProf5)
        Dim strSection As String = GetComboValue(cboSection)
        Dim strCare As String = hidCare.Value '/GetComboValue(cboCare)
        Dim iExecutor As Integer
        Dim iGridRowCount As Integer
        Dim iShilaSupplier As Integer = objUser.IsShilaSupplier("4DA7CCB6-14A5-4D27-9DF3-AD449A470103", User.Identity.Name)

        iGridRowCount = CInt(cboGridRowCount.SelectedItem.Value)

        Dim sTxtStreet As String = VB.Left(Trim(txtStreet.Text), 24)
        Dim sTxtZIP As String = VB.Left(Trim(txtZIP.Text), 6)

        If objUser.UpdateProperties("0D792E26-D8BA-40B9-8A93-51B685CF92FD", strUserName, txtFName.Text, txtLName.Text, sTxtStreet, txtHouse.Text, txtCity.Text, sTxtZIP, _
                                    txtPhone.Text, txtMobile.Text, txtFax.Text, txtEMail.Text, "", "", "", "", "", "", "", "", "", "", _
                                    txtBank.Text, txtBranch.Text, txtAccount.Text, txtMailStreet.Text, txtMailPhone.Text, txtMailHouse.Text, _
                                    txtMailEMail.Text, txtMailCity.Text, txtMailZIP.Text, strService1, strService2, strService3, strService4, _
                                    strService5, strService6, strProf1, strProf2, strProf3, strProf4, strProf5, txtClinicID.Text, txtClinicName.Text, "", strSection, strCare, iGridRowCount, User.Identity.Name) Then
            '/-------------------------------------
            Dim currRow As Data.DataRow
            Dim objRequest As New SupplierConnect.RequestClaim()
            objRequest.Url = Application("SupplierWebService").ToString()

            Dim ds As Data.DataSet = Nothing

            If Not strSection.Equals("") Then
                ds = objRequest.GetCareBySection("491AE412-CF31-4644-AC7C-59DD8505B5A1", strSection)
            End If

            cboCare.Items.Clear()
#If EngDesign Then
            cboCare.Items.Add(New ListItem("Select Treatment", ""))
#Else
            cboCare.Items.Add(New ListItem("��� �����", ""))
#End If
            If Not ds Is Nothing Then
                If Application("TikshuvEnabled").ToString() = "1" Then
                    cboCare.Items.Add(New ListItem("���", "0"))
                End If

                For Each currRow In ds.Tables(0).Rows
                    cboCare.Items.Add(New ListItem(currRow("CareName").ToString(), currRow("CareID").ToString()))
                Next

                SetComboValue(cboCare, strCare)
            End If
            '/-----------------------------------------------------
#If NewDesign Then
                'If iShilaSupplier = 1 Then
                '    iExecutor = Val(GetComboValue(cboSubSuppliers))
                '    objUser.UpdateUserDefaults("136DBF9B-FF38-41EA-9797-CFF271203427", strUserName, "", "", "", iExecutor)
                'End If
#End If


                If Session("User_Login_First_Time") = "1" Then
                    Session("User_Login_First_Time") = ""
                    Select Case Application("App_Type").ToString().ToUpper()
                        Case "INPOST"
                            Session("User_Prop_Caller") = "frmPostEntry.aspx"
                        Case "SUPP"
                            Session("User_Prop_Caller") = Application("FORMClaimMenu")
                        Case Else
                            Session("User_Prop_Caller") = Application("FORMRepStat")
                    End Select
                End If

                chkPassword.Disabled = False
                chkPassword.Checked = False
#If NewDesign Then
                If Application("App_Type").ToString.ToUpper() = "SUPP" Then
                    chkExtra.Disabled = False
                    chkExtra.Checked = False
                    ''Avner 201210 txtQuestion.Value = ""
                    txtQuestion.Attributes("class") = "InputDis"
                    ''Avner 201210ExtraIdAnswer.Value = ""
                    ExtraIdAnswer.Attributes("class") = "InputDis"
                End If
#End If

#If EngDesign Then
            txtError.Value = "Data Updated Successfully"
#Else
                txtError.Value = "������� ������ ������"
#End If
                txtErrorType.Value = ""
                txtExpired.Value = ""
            Else
#If EngDesign Then
            txtError.Value = "Error while updating data!"
#Else
                txtError.Value = "���� ��� ����� �������!"
#End If
            End If
    End Sub

    Private Sub ShowError(ByVal strMessage As String)
        txtError.Value = strMessage
        txtErrorType.Value = "1"
    End Sub

    Private Sub cmdCancel_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.ServerClick
        If Session("User_Prop_Caller") <> "" Then
            'Response.Redirect(Session("User_Prop_Caller") & GetLinkForNextForm(Session("User_Prop_Caller")))
            Response.Redirect((New Utils).GetLinkForNextForm(Session("User_Prop_Caller")))
        ElseIf Session("PrevForm") <> "" Then
            'Response.Redirect(Session("PrevForm") & GetLinkForNextForm(Session("PrevForm")))
            Response.Redirect((New Utils).GetLinkForNextForm(Session("PrevForm")))
        End If
    End Sub

    Private Sub cmdLogout_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdLogout.ServerClick
        Dim SignOut As Boolean
        If Application("HKLLDP") <> "" Then
            SignOut = (New Utils).SignOut("LoginHKL.aspx?out=1")
        Else
            SignOut = (New Utils).SignOut(Application("FORMLogin"))
        End If
    End Sub

    Private Sub cmdReturn_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.ServerClick
        Select Case Application("App_Type").ToString().ToUpper()
            Case "KUPA_INFO"
                Response.Redirect("KupaInfoMenu.aspx")
            Case "SUPP"                
                Response.Redirect((New Utils).GetLinkForNextForm(Application("FORMClaimMenu")))
            Case Else
                'Response.Redirect("frmStart.aspx" & GetLinkForNextForm("frmStart.aspx"))
                Response.Redirect((New Utils).GetLinkForNextForm(Application("FORMStart")))
        End Select
    End Sub



    '    Private Sub cmdConfirmation_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdConfirmation.ServerClick

    '        ErrorMessage.InnerText = String.Empty

    '        Dim UserName As String = User.Identity.Name
    '        Dim Password As String = Trim(PasswordConfirmation.Value)
    '        PasswordConfirmation.Value = String.Empty
    '        Dim Confirmation As String = Trim(UserNameConfirmation.Value)
    '        UserNameConfirmation.Value = String.Empty


    '        If UserName <> Confirmation Then
    '#If EngDesign Then
    '			'ErrorMessage.InnerText = "Wrong User Name"
    '			ErrorMessage.InnerText = "User identification failed"
    '#Else
    '            setNoFailCurrentPassword()

    '            'ErrorMessage.InnerText = "�� ����� ����"
    '            ErrorMessage.InnerText = "����� ����� ����"
    '#End If
    '            Return
    '        End If

    '        If Len(Password) = 0 Then
    '#If EngDesign Then
    '			ErrorMessage.InnerText = "Missing Password"
    '#Else

    '            '''''''''''''''''''''''''''''setNoFailCurrentPassword()

    '            ErrorMessage.InnerText = "���� �����"
    '#End If
    '            Return
    '        End If


    '        Dim objUser As New UserConnect.UserService()
    '        objUser.Url = Application("UserWebService").ToString()

    '        Dim iResult As Integer = objUser.CheckUser("79D565C1-784C-4606-935B-68BA32141600", Confirmation, Password, "0", -1, Request.UserHostAddress, UserName)
    '        If iResult <> 0 And iResult <> 10 Then
    '#If EngDesign Then
    '			ErrorMessage.InnerText ="User identification failed!"
    '#Else
    '            setNoFailCurrentPassword()

    '            ErrorMessage.InnerText = "����� ����� ����!"
    '#End If
    '            Return
    '        End If

    '        ' All OK, Continue
    '        cmdOK_ServerClick(sender, e)

    '    End Sub

    'Protected Overrides Sub OnError(ByVal e As System.EventArgs)
    '    Response.Clear()
    '    Dim strResult As String = "<html><head><meta http-equiv='Content-Type' content='text/html; charset=windows-1255'/></head><body dir=rtl>"
    '    strResult += "<DIV style='font-family:Arial;font-size:16pt;font-weight:bold;width:100%;text-align:center'>����� ��� ����� ������, ��� ��� ����� ����</DIV><BR><DIV style='font-family:Arial;font-size:9pt'>" & txtFormIdentity.Value & "</DIV></body></html>"
    '    Response.Write(strResult)
    '    'Dim ex As Exception = Server.GetLastError
    '    'Response.Write(ex.Message)
    '    Response.End()
    'End Sub

    Private Sub cmdBack_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdBack.ServerClick

        Dim FormUserProp As String = Application("FORMUserProp") 'frmUserProp.aspx / frmSMUserProp.aspx

        'mesh
        If Application("HasCB") = "1" Then
            Response.Redirect("frmCBMenu.aspx")

        ElseIf Application("App_Type").ToString.ToUpper() = "ENG" Then
            cmdBack.Attributes.Remove("onclick")
            If Session("User_Login_First_Time") = "1" Then
                'Response.Redirect("frmUserProp.aspx")
                Response.Redirect((New Utils).GetLinkForNextForm(FormUserProp))
            Else
                'Response.Redirect(Application("FORMRepStat") & GetLinkForNextForm(Application("FORMRepStat")))
                Response.Redirect((New Utils).GetLinkForNextForm(Application("FORMRepStat")))
            End If
        ElseIf Application("App_Type").ToString().ToUpper() = "CLAIM" Then
            cmdBack.Attributes.Remove("onclick")
            If Session("User_Login_First_Time") = "1" Then
                'Response.Redirect("frmUserProp.aspx")
                Response.Redirect((New Utils).GetLinkForNextForm(FormUserProp))
            ElseIf (Application("IsDorAlon") = "1") Then
                Response.Redirect("frmAlonMenu.aspx")
            Else
                'Response.Redirect("frmStart.aspx" & GetLinkForNextForm("frmStart.aspx"))
                Response.Redirect((New Utils).GetLinkForNextForm(Application("FORMStart")))
            End If

        ElseIf Application("App_Type").ToString().ToUpper() = "SUPP" Then

            cmdBack.Attributes.Remove("onclick")
            If Session("User_Login_First_Time") = "1" Then
                'Response.Redirect("frmUserProp.aspx")
                Response.Redirect((New Utils).GetLinkForNextForm(FormUserProp))
            End If

            Dim url As String = Application("FORMLogin")

            If Not Session("User_Population_Type") = "0" And Session("User_Population_Type") <> "" Then
                Select Case Session("User_Population_Type")
                    Case "101", "501", "701"                        
                        url = (New Utils).GetLinkForNextForm(Application("FORMClaimMenu"))
                    Case Else
                        Session("User_Population_Type") = "0"
                        'url = Application("FORMRepStat") & GetLinkForNextForm(Application("FORMRepStat"))
                        url = (New Utils).GetLinkForNextForm(Application("FORMRepStat"))
                End Select

            End If
            'Response.Redirect(url)
            Response.Redirect((New Utils).GetLinkForNextForm(url))

        End If

        'meshend

    End Sub

    Private Sub ShowTabsByUserType(ByVal strUserType As String)
        Dim tr As TableRow
        'row 0 is an empty row ! remove items in descending order.
        If Application("HKLLDP") <> "" Then
            tr = tblTabs.Rows(btns.BTN_PWD) : tblTabs.Rows.Remove(tr)
            tr = tblTabs.Rows(btns.BTN_CONTACT) : tblTabs.Rows.Remove(tr)
            tr = tblTabs.Rows(btns.BTN_MAIL) : tblTabs.Rows.Remove(tr)
            tr = tblTabs.Rows(btns.BTN_SERVICE) : tblTabs.Rows.Remove(tr)
            tr = tblTabs.Rows(btns.BTN_BANK) : tblTabs.Rows.Remove(tr)
        Else
            Select Case strUserType
                Case "1"
                    tr = tblTabs.Rows(btns.BTN_SERVICE) : tblTabs.Rows.Remove(tr)
                    tr = tblTabs.Rows(btns.BTN_BANK) : tblTabs.Rows.Remove(tr)
                Case "2"
                    tr = tblTabs.Rows(btns.BTN_CONTACT) : tblTabs.Rows.Remove(tr)
                Case "3", "8" ' ? , DorAlon
                    tr = tblTabs.Rows(btns.BTN_MISC) : tblTabs.Rows.Remove(tr)
                    tr = tblTabs.Rows(btns.BTN_CONTACT) : tblTabs.Rows.Remove(tr)
                    tr = tblTabs.Rows(btns.BTN_MAIL) : tblTabs.Rows.Remove(tr)
                    tr = tblTabs.Rows(btns.BTN_SERVICE) : tblTabs.Rows.Remove(tr)
                    tr = tblTabs.Rows(btns.BTN_BANK) : tblTabs.Rows.Remove(tr)
                Case "4"
                    tr = tblTabs.Rows(btns.BTN_PWD) : tblTabs.Rows.Remove(tr)
                    tr = tblTabs.Rows(btns.BTN_CONTACT) : tblTabs.Rows.Remove(tr)
                    tr = tblTabs.Rows(btns.BTN_MAIL) : tblTabs.Rows.Remove(tr)
                    tr = tblTabs.Rows(btns.BTN_SERVICE) : tblTabs.Rows.Remove(tr)
                    tr = tblTabs.Rows(btns.BTN_BANK) : tblTabs.Rows.Remove(tr)
                Case "5", "6"
                    If Application("App_Type").ToString().ToUpper() = "CLAIM" Then
                        tr = tblTabs.Rows(btns.BTN_CONTACT)
                        tblTabs.Rows.Remove(tr)
                        tr = tblTabs.Rows(btns.BTN_MAIL)
                        tblTabs.Rows.Remove(tr)
                        tr = tblTabs.Rows(btns.BTN_SERVICE)
                        tblTabs.Rows.Remove(tr)
                        tr = tblTabs.Rows(btns.BTN_BANK)
                        tblTabs.Rows.Remove(tr)
                    Else
                        tr = tblTabs.Rows(btns.BTN_CONTACT) : tblTabs.Rows.Remove(tr)
                    End If
                Case "30"
                    tr = tblTabs.Rows(btns.BTN_PWD) : tblTabs.Rows.Remove(tr)
                    tr = tblTabs.Rows(btns.BTN_MISC) : tblTabs.Rows.Remove(tr)
                    tr = tblTabs.Rows(btns.BTN_CONTACT) : tblTabs.Rows.Remove(tr)
                    tr = tblTabs.Rows(btns.BTN_MAIL) : tblTabs.Rows.Remove(tr)
                    tr = tblTabs.Rows(btns.BTN_SERVICE) : tblTabs.Rows.Remove(tr)
                    tr = tblTabs.Rows(btns.BTN_BANK) : tblTabs.Rows.Remove(tr)
                Case "40"
                    tr = tblTabs.Rows(btns.BTN_CONTACT) : tblTabs.Rows.Remove(tr)
                    tr = tblTabs.Rows(btns.BTN_MAIL) : tblTabs.Rows.Remove(tr)
                    tr = tblTabs.Rows(btns.BTN_SERVICE) : tblTabs.Rows.Remove(tr)
                    tr = tblTabs.Rows(btns.BTN_BANK) : tblTabs.Rows.Remove(tr)
                Case "101" 'manager
                    tr = tblTabs.Rows(btns.BTN_SERVICE) : tblTabs.Rows.Remove(tr)
                    tr = tblTabs.Rows(btns.BTN_BANK) : tblTabs.Rows.Remove(tr)
                Case "501" 'launcher
                    tr = tblTabs.Rows(btns.BTN_CONTACT) : tblTabs.Rows.Remove(tr)
                Case "701" 'Addresse
                    tr = tblTabs.Rows(btns.BTN_CONTACT) : tblTabs.Rows.Remove(tr)
                Case Else
                    tr = tblTabs.Rows(btns.BTN_MISC) : tblTabs.Rows.Remove(tr)
                    tr = tblTabs.Rows(btns.BTN_PWD) : tblTabs.Rows.Remove(tr)
                    tr = tblTabs.Rows(btns.BTN_CONTACT) : tblTabs.Rows.Remove(tr)
                    tr = tblTabs.Rows(btns.BTN_MAIL) : tblTabs.Rows.Remove(tr)
                    tr = tblTabs.Rows(btns.BTN_SERVICE) : tblTabs.Rows.Remove(tr)
                    tr = tblTabs.Rows(btns.BTN_BANK) : tblTabs.Rows.Remove(tr)
            End Select
        End If
    End Sub

    Private Sub setAllowChangePassword(ByVal isAllowChangePassword As Boolean)
#If NewDesign And Not EngDesign Then
        If isAllowChangePassword Then

            chkPassword.Disabled = False
            txtPassword.Disabled = False
            txtNewPassword.Disabled = False
            txtConfirmPassword.Disabled = False
            chkExtra.Disabled = False
            txtQuestion.Disabled = False
            ExtraIdAnswer.Disabled = False

        Else
            chkPassword.Checked = False
            chkPassword.Disabled = True
            txtPassword.Disabled = True
            txtNewPassword.Disabled = True
            txtConfirmPassword.Disabled = True
            chkExtra.Checked = False
            chkExtra.Disabled = True
            txtQuestion.Disabled = True
            ExtraIdAnswer.Disabled = True

        End If
#End If
    End Sub

    Private Sub setNoFailCurrentPassword()
#If NewDesign And Not EngDesign Then
        Dim iHidNoFailCurrentPasswordLocal As Integer
        Dim iHidNoFailCurrentPasswordGeneral As Integer
        If hidNoFailCurrentPasswordLocal.Value <> "" Then
            iHidNoFailCurrentPasswordLocal = CInt(hidNoFailCurrentPasswordLocal.Value)
        Else
            iHidNoFailCurrentPasswordLocal = 0
        End If

        iHidNoFailCurrentPasswordLocal = iHidNoFailCurrentPasswordLocal + 1
        hidNoFailCurrentPasswordLocal.Value = iHidNoFailCurrentPasswordLocal


        If hidNoFailCurrentPasswordGeneral.Value <> "" Then
            iHidNoFailCurrentPasswordGeneral = CInt(hidNoFailCurrentPasswordGeneral.Value)
        Else
            iHidNoFailCurrentPasswordGeneral = 0
        End If


        If iHidNoFailCurrentPasswordLocal >= iHidNoFailCurrentPasswordGeneral Then

            Dim objUser As New UserConnect.UserService()
            objUser.Url = Application("UserWebService").ToString()

            setAllowChangePassword(False)

            objUser.UpdateAllowChangePassword("78EA0AF0-E7E7-11DF-9492-0800200C9A66", _
                                              User.Identity.Name, User.Identity.Name, 0)

        End If
#End If




    End Sub

    Private Function CheckRegularexpression() As Boolean
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim emailvalue As String
        Dim sRegExpr As String
        emailvalue = txtEMail.Text.ToLower
        If (emailvalue.Trim().Length() > 0) Then
            sRegExpr = objUser.GetEmailValidation("E600F1B9-D4C7-4FC4-B1B6-922F3967456E")
            '/ If Not objUser.GetEmailValidation("E600F1B9-D4C7-4FC4-B1B6-922F3967456E") Then
            If Not Regex.IsMatch(emailvalue, sRegExpr) Then
#If EngDesign Then
                   ShowError("Invalid eMail address")
#Else
                ShowError("����� ����''� �� �����")
#End If
                Return False
            End If

        End If
        Return True
    End Function
End Class
