﻿Imports System.IO
Imports System.Web.UI.WebControls
Imports System.Text

Public Class UserConfirmation
    Inherits CompositeControl

    Private Class Messages
#If EngDesign Then
        Public Const ConfirmationText As String = "OK"
        Public Const UserName As String = "User Name:"
        Public Const Password As String = "Password:"
        Public Const Cancel As String = "Cancel"
        Public Const UserIdentificationFailed As String = "User identification failed!"
        Public Const MissingPassword As String = "Missing Password"
        Public Const MissingUserName As String = "Missing User Name"
#Else
        Public Const ConfirmationText As String = "אישור"
        Public Const UserName As String = "שם משתמש:"
        Public Const Password As String = "סיסמה:"
        Public Const Cancel As String = "ביטול"
        Public Const UserIdentificationFailed As String = "זיהוי משתמש נכשל!"
        Public Const MissingPassword As String = "חסרה סיסמה"
        Public Const MissingUserName As String = "חסר שם משתמש"
#End If
    End Class

#Region "Public Functions"

    Public Function CheckUser() As Boolean

        If IsNothing(UserNameConfirmation) Or (UserNameConfirmation.Value.Trim() = String.Empty) Then
            ErrorMessage.Value = Messages.MissingUserName
            Return False
        End If
        If IsNothing(PasswordConfirmation) Or (PasswordConfirmation.Value.Trim() = String.Empty) Then
            ErrorMessage.Value = Messages.MissingPassword
            Return False
        End If
		Dim strPrefix As String = ""
		If Me.Context.Application("App_Type").ToString.ToUpper = "DIST" Then
			strPrefix = "ts"
		End If
		Dim strUserNameConfirmation As String = strPrefix & UserNameConfirmation.Value.ToLower()
        If Me.Context.User.Identity.Name.ToLower() <> strUserNameConfirmation Then
            ErrorMessage.Value = Messages.UserIdentificationFailed
            Return False
        End If
        Dim result As Integer = (New Utils).CheckUser( _
            Me.Context.Application("Database_ConnectionString"), _
            Me.Context.Request.UserHostAddress, _
            strUserNameConfirmation, _
            PasswordConfirmation.Value, _
            Me.Context.User.Identity.Name)

        If result <> 0 And result <> 10 And result <> 100 Then
            ErrorMessage.Value = Messages.UserIdentificationFailed
            Return False
        End If

        Return True

    End Function

#End Region

#Region "Private Functions"

    Private EventElementName As HiddenField
    Private UserNameConfirmation As HiddenField
    Private PasswordConfirmation As HiddenField
    Private Confirmation As Button
    Private ErrorMessage As HtmlInputText

    Private Function GetCurrentURL() As String
        Dim sb As New StringBuilder()
        sb.Append(Context.Request.Url.Scheme)
        sb.Append(Context.Request.Url.SchemeDelimiter)
        sb.Append(Context.Request.Url.Host)
        sb.Append(Context.Request.Url.Segments(0))
		Dim s As String = Context.Request.Url.Segments(1)
		If InStr(s, ".aspx", CompareMethod.Text) = 0 Then
			sb.Append(Context.Request.Url.Segments(1))
		End If
        Return sb.ToString()
    End Function

    Private Function GetTableRow(ByVal cells As Integer) As TableRow
        Dim row As New TableRow()
        Dim cell As TableCell
        For index As Integer = 1 To cells
            cell = New TableCell()
            cell.Attributes.Add("noWrap", "noWrap")
            row.Cells.Add(cell)
        Next
        Return row
    End Function

    Private Function GetTable(ByVal cells As Integer, ByVal rows As Integer) As Table

        Dim row As TableRow
        Dim currentTable As New Table()

        For index As Integer = 1 To rows
            row = GetTableRow(cells)
            currentTable.Rows.Add(row)
        Next

        Return currentTable

    End Function

    Private Function GetContentTable() As Table

        '<table border="0" width="100%" dir="rtl" bgcolor="#669acc">
        '    <tr>
        '        <td class="TDRightLabel" valign="top">
        '        שם(משתמש)
        '        </td>
        '        <td valign="top">
        '            <input class="InputStyle" id="UserName" tabIndex="60"  dir="ltr" style="font-size: 12px;text-align: center" maxlength="25" onblur="focusInput()"
        '                onchange="$('#UserNameConfirmation').val(this.value)" onfocus="focusInput()" />
        '        </td>
        '        <td class="TDRightLabel">
        '            <input class="ButtonGray100 Behavior" id="cmdConfirmation" type="button" value="אישור"
        '                name="cmdConfirmation" runat="server" tabIndex="62" style="font-size: 12px;">
        '        </td>
        '    </tr>
        '    <tr>
        '        <td class="TDRightLabel">
        'סיסמה:
        '        </td>
        '        <td valign="top">
        '            <input  class="InputStyle" tabIndex="61" type="password" maxlength="11" onblur="focusInput()"
        '                onfocus="focusInput()" style="font-family:Verdana;font-size: 12px;text-align: center" onchange="$('#PasswordConfirmation').val(this.value)"
        '                autocomplete="off" dir="ltr" runat="server" />
        '        </td>
        '        <td>
        '            <input class="ButtonGray100 Behavior" type="button" value="בטל" tabIndex="63" style="font-size: 12px;" onclick="CloseRequest();">
        '        </td>
        '    </tr>
        '    <tr>
        '        <td  colspan=3 runat="server" id="ErrorMessage" dir="rtl"  style="font-family:Verdana;font-size: 14px;color:Red;text-align: center"></td>
        '    </tr>
        '</table>

        Dim contentTable As Table = GetTable(3, 4)

        contentTable.Attributes.Add("width", "100%")
        contentTable.Attributes.Add("border", "0")
        '''''''contentTable.Attributes.Add("dir", "rtl")

        contentTable.CssClass = "CompositeControlContentTable" ' !!! I use it for seek contentTable in JS

        Dim row As TableRow


        ' First row
        row = contentTable.Rows(0)
        row.Cells(0).CssClass = "TDRightLabel"
        row.Cells(0).Text = "נא הקלד שוב את שם המשתמש והסיסמה שלך"

        row.Cells(0).ColumnSpan = 3
        row.Cells.Remove(row.Cells(1))
        row.Cells.Remove(row.Cells(1))

        ' First row
        row = contentTable.Rows(1)
        row.Cells(0).CssClass = "TDRightLabel"
        row.Cells(0).Text = Messages.UserName
        row.Cells(1).Controls.Add(GetUserNameControl())
        row.Cells(2).Controls.Add(GetConfirmationControl())

        ' Second row
        row = contentTable.Rows(2)
        row.Cells(0).CssClass = "TDRightLabel"
        row.Cells(0).Text = Messages.Password
        row.Cells(1).Controls.Add(GetPasswordControl())
        row.Cells(2).Controls.Add(GetCloseControl())

        ' Third row
        row = contentTable.Rows(3)
        'row.CssClass = "CompositeControlRow"
        row.Cells.Remove(row.Cells(0))
        row.Cells.Remove(row.Cells(0))
        row.Cells(0).ColumnSpan = 3
        row.Cells(0).Controls.Add(GetErrorMessageControl())

        Return contentTable
    End Function

    Private Function GetMainTable() As HtmlGenericControl

        Dim divControl As New HtmlGenericControl()

        divControl.TagName = "div"
        divControl.Attributes.Add("class", "basic-modal-content")
        divControl.Attributes.Add("dir", "rtl")

        Dim mainTable As Table = GetTable(3, 3)
        'mainTable.Attributes.Add("dir", "ltr")
        mainTable.Attributes.Add("cellspacing", "0")
        mainTable.Attributes.Add("cellpadding", "0")
        'mainTable.Attributes.Add("width", "95%")
        mainTable.Attributes.Add("border", "0")

        Dim row As TableRow

        ' First row
        row = mainTable.Rows(0)
        row.CssClass = "CompositeControlRow"
        row.Cells(0).CssClass = "CompositeControlTR"
        row.Cells(1).CssClass = "CompositeControlTM"
        row.Cells(2).CssClass = "CompositeControlTL"

        ' second row
        row = mainTable.Rows(1)
        row.VerticalAlign = VerticalAlign.Top
        row.Cells(0).CssClass = "CompositeControlMR"
        row.Cells(1).CssClass = "CompositeControlMM"
        row.Cells(2).CssClass = "CompositeControlML"
        'row.Cells(1).VerticalAlign = VerticalAlign.Top
        Dim center As TableCell = row.Cells(1)


        ' Third row
        row = mainTable.Rows(2)
        row.CssClass = "CompositeControlRow"
        row.Cells(0).CssClass = "CompositeControlBR"
        row.Cells(1).CssClass = "CompositeControlBM"
        row.Cells(2).CssClass = "CompositeControlBL"

        Dim cell As TableCell = mainTable.Rows(1).Cells(1)
        cell.Controls.Add(GetContentTable())

        divControl.Controls.Add(mainTable)

        Return divControl

    End Function

    Private Function GetCSSLinkControl() As HtmlLink
        Dim input As New HtmlLink()
        input.Href = Path.Combine(GetCurrentURL(), "UC/UserConfirmation.css")
        input.Attributes.Add("rel", "stylesheet")
        input.Attributes.Add("type", "text/css")
        Return input
    End Function

    Private Function GetUserNameControl() As HtmlInputText
        Dim input As New HtmlInputText()
        input.Attributes.Add("TabIndex", "1000")
        input.Attributes.Add("class", "InputStyle CompositeControlInputField")
        input.Name = "UserName"
        input.ID = "UserName"
        input.MaxLength = 25
        Return input
    End Function

    Private Function GetConfirmationControl() As Button
        Confirmation = New Button()
        Confirmation.Attributes.Add("TabIndex", "1002")
        Confirmation.CssClass = "ButtonGray100 CompositeControlInputField"
        Confirmation.ID = "Confirmation"
        Confirmation.Text = Messages.ConfirmationText
        Confirmation.Attributes.Add("onclick", "UserConfirmation.ConfirmationRequest();")
        Return Confirmation
    End Function

    Private Function GetPasswordControl() As TextBox
        Dim input As New TextBox()
        input.Attributes.Add("TabIndex", "1001")
        input.TextMode = TextBoxMode.Password
        input.MaxLength = 11
        input.CssClass = "InputStyle CompositeControlInputField"
        input.AutoCompleteType = AutoCompleteType.None
        input.ID = "Password"
        Return input
    End Function

    Private Function GetCloseControl() As HtmlButton
        Dim input As New HtmlButton()
        input.Attributes.Add("TabIndex", "1003")
        input.InnerText = Messages.Cancel
        input.Attributes.Add("class", "ButtonGray100 CompositeControlInputField")
        input.ID = "Close"
        input.Attributes.Add("onclick", "UserConfirmation.CloseRequest();")
        Return input
    End Function

    Private Function GetErrorMessageControl() As HtmlInputText
        ErrorMessage = New HtmlInputText()
        ErrorMessage.Attributes.Add("class", "CompositeControlErrorMessage")
        ErrorMessage.Attributes.Add("readonly", "true")
        ErrorMessage.Style.Value = "color: Red !important; border: 0px none #000000 !important; background-color: #669acc !important"
        ErrorMessage.ID = "ErrorMessage"
        ErrorMessage.Value = String.Empty

        Return ErrorMessage
    End Function

    Private Function GetUserNameConfirmationControl() As HiddenField
        UserNameConfirmation = New HiddenField()
        UserNameConfirmation.ID = "UserNameConfirmation"
        Return UserNameConfirmation
    End Function

    Private Function GetEventElementNameControl() As HiddenField
        EventElementName = New HiddenField()
        EventElementName.ID = "EventElementName"
        Return EventElementName
    End Function

    Private Function GetPasswordConfirmationControl() As HiddenField
        PasswordConfirmation = New HiddenField()
        PasswordConfirmation.ID = "PasswordConfirmation"
        Return PasswordConfirmation
    End Function

    Private Function GetJSVariables() As String
        Dim sb As New StringBuilder()
        sb.Append(String.Format("UserConfirmationID='#{0}';", Me.ClientID))
        sb.Append(String.Format("UserConfirmationMissingPassword='{0}';", Messages.MissingPassword))
        sb.Append(String.Format("UserConfirmationMissingUserName='{0}';", Messages.MissingUserName))
        Return sb.ToString()
    End Function

#End Region

#Region "Protected CreateChildControls"

    Protected Overrides Sub CreateChildControls()

        Me.Controls.Add(GetCSSLinkControl())
        Me.Controls.Add(GetMainTable())

        Me.Controls.Add(GetEventElementNameControl())
        Me.Controls.Add(GetUserNameConfirmationControl())
        Me.Controls.Add(GetPasswordConfirmationControl())



        Me.Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "UserConfirmation", String.Format("<script src='{0}' type='text/javascript'></script>", Path.Combine(GetCurrentURL(), "UC/UserConfirmation.js")), False)
        Me.Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "UserConfirmationVariables", GetJSVariables(), True)

        MyBase.CreateChildControls()

    End Sub














#End Region

End Class

