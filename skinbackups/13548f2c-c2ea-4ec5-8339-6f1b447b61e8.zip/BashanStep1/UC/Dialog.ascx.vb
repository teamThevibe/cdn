﻿Public Class Dialog
    Inherits System.Web.UI.UserControl

    Dim _isAddScripts As Boolean = True

    Property isAddScripts() As Boolean
        Set(ByVal value As Boolean)
            _isAddScripts = value
        End Set
        Get
            Return _isAddScripts
        End Get
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim AbsolutePath As String = String.Format("{0}{1}{2}{3}", Request.Url.Scheme, Request.Url.SchemeDelimiter, Request.Url.Host, Request.ApplicationPath)
        If isAddScripts Then
            If (Not Page.IsClientScriptBlockRegistered("jQuery")) Then
                Page.RegisterClientScriptBlock("jQuery", String.Format("<script src='{0}/js/jQuery/jquery-1.3.2.min.js' type='text/javascript'></script>", AbsolutePath))
            End If
            If (Not Page.IsClientScriptBlockRegistered("jQuery-ui")) Then
                Page.RegisterClientScriptBlock("jQuery-ui", String.Format("<script src='{0}/js/jQuery/jquery-ui.min.js' type='text/javascript'></script>", AbsolutePath))
            End If
            If (Not Page.IsClientScriptBlockRegistered("jQuery-css")) Then
                Page.RegisterClientScriptBlock("jQuery-css", String.Format("<link href='{0}/css/jQuery/jquery.css' rel='stylesheet' type='text/css' />", AbsolutePath))
            End If
        End If
        If (Not Page.IsClientScriptBlockRegistered("Dialog")) Then
            Page.RegisterClientScriptBlock("Dialog", String.Format("<script src='{0}/UC/Dialog.js' type='text/javascript'></script>", AbsolutePath))
        End If

    End Sub

End Class


