﻿
// We generate next JS Variables on server:
// UserConfirmationID
// UserConfirmationMissingPassword
// UserConfirmationMissingUserName

var UserConfirmationObject;
var UserConfirmation = new Object();

UserConfirmation.CloseRequest = function() {
    $.modal.close();
    $("input[id$=ErrorMessage]", ".CompositeControlContentTable").val("");
};

UserConfirmation.RequestPassword = function(srcElement) {
    $("input[id$=UserName]", ".CompositeControlContentTable").val(UserConfirmationObject.find('input[id$=UserNameConfirmation]').val());
    UserConfirmationObject.find('input[id$=EventElementName]').val(srcElement.name);
    $("input[id$=UserName]", ".CompositeControlContentTable").select();
    $('.basic-modal-content').attr("align", "center").modal();
};

UserConfirmation.ConfirmationRequest = function() {
    __doPostBack(UserConfirmationObject.find('input[id$=EventElementName]').val(), '');
};

UserConfirmation.FocusInput = function(me, eventName) {
    if (eventName == 'focus') {
        if ($(me).attr("DefaultColor") == undefined) {
            $(me).attr("DefaultColor", me.style.borderColor);
        }
        me.style.borderColor = '#FF0000';
    }
    else {

        if ($(me).attr("DefaultColor") != undefined) {
            me.style.borderColor = $(me).attr("DefaultColor");
        }
    }
};

$(document).ready(function() {

    UserConfirmationObject = $(UserConfirmationID);

    $("input[id$=UserName]", ".CompositeControlContentTable").bind("focus", function() {
        UserConfirmation.FocusInput(this, "focus");
    }).bind("blur", function() {
        UserConfirmation.FocusInput(this, "blur");
    }).bind("change", function() {
        UserConfirmationObject.find('input[id$=UserNameConfirmation]').val(this.value);
    }).keypress(function(e) {
        $("input[id$=ErrorMessage]", ".CompositeControlContentTable").val("");
        if ((e.keyCode ? e.keyCode : e.which) == 13) {
            $("input[id$=Confirmation]", ".CompositeControlContentTable").click();
        }
    });
    $("input[id$=Password]", ".CompositeControlContentTable").bind("focus", function() {
        UserConfirmation.FocusInput(this, "focus");
    }).bind("blur", function() {
        UserConfirmation.FocusInput(this, "blur");
    }).bind("change", function() {
        UserConfirmationObject.find('input[id$=PasswordConfirmation]').val(this.value);
    }).keypress(function(e) {
        $("input[id$=ErrorMessage]", ".CompositeControlContentTable").val("");
        if ((e.keyCode ? e.keyCode : e.which) == 13) {
            UserConfirmationObject.find('input[id$=PasswordConfirmation]').val(this.value);
            $("input[id$=Confirmation]", ".CompositeControlContentTable").click();
        }
    });
    if ($("input[id$=ErrorMessage]", ".CompositeControlContentTable").val().length > 0) {
        UserConfirmation.RequestPassword(UserConfirmationObject);
    }
});

