﻿Partial Public Class HDDoctor
    Inherits System.Web.UI.UserControl

    Dim _ShortCut As Boolean = False

    Public Property ShortCut() As Boolean
        Set(ByVal value As Boolean)
            _ShortCut = value
        End Set
        Get
            Return _ShortCut
        End Get
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        ''''''''''''''''''''''''''''''FillDoctorCare()
        If Not Session("sSaveDocNameId") Is Nothing Then
            If Session("sSaveDocNameId").ToString <> "" Then
                Dim iSaveDocNameId As Integer = Session("sSaveDocNameId").ToString
                Utils.SetComboValue(DoctorCare, iSaveDocNameId)
                DoctorCareNumber.Value = iSaveDocNameId.ToString
            End If
        End If

    End Sub

    Public Sub FillDoctorCare()

        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        DoctorCare.DataSource = objUser.GetDoctorList("03407803-DE6A-41AA-87DC-60D1D0329753", Page.User.Identity.Name)
        DoctorCare.DataBind()
        If DoctorCare.Items.Count > 1 Then
            DoctorCare.Items.Insert(0, New ListItem("בחר...", "0"))
        End If

        If Not Session("HDDoctorCareName") Is Nothing Then
            If Session("HDDoctorCareName").ToString <> "" Then
                Dim sDoctorCareName As String = Session("HDDoctorCareName").ToString
                DoctorCare.Items.FindByText(sDoctorCareName).Selected = True
            End If
        End If

        If Not Session("HDDoctorCareNumber") Is Nothing Then
            If Session("HDDoctorCareNumber").ToString <> "" Then
                DoctorCareNumber.Value = Session("HDDoctorCareNumber").ToString
            End If
        End If

    End Sub

    Public ReadOnly Property GetDoctorCareName() As String
        Get
            If Session("BSHN_Independed") = "1" Then
                Return DoctorCareName.Text
            Else
                Return Utils.GetComboText(DoctorCare)
            End If
        End Get
    End Property

    Public ReadOnly Property GetDoctorCareNumber() As String
        Get
            Return DoctorCareNumber.Value
        End Get
    End Property

End Class