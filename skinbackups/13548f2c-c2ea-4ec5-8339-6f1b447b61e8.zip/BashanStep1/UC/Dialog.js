﻿$(function() {
    if (typeof jQuery.ui.dialog == 'function') {
        $("#dialog").dialog({
            autoOpen: false,
                bgiframe: true,
                width: 600,
                modal: true
            });
    }
});

function ShowDialog(context, title, c, v, b, n) {
    if (title == undefined) {
        $('#dialog').dialog('option', 'title', 'הודעת מערכת');
    }
    $('#dialog').find('#content').text(context);
    $('#dialog').dialog('open');
    return false;
}

function ShowMessage(context, title) {
    ShowDialog(context, title);
    return false;
}

var CustomFunctionCallOnClose;
var ShowQuestionReturnValue = false;

function ShowQuestionCallOnClose(event, ui) {
    if (typeof CustomFunctionCallOnClose == "function") {
        CustomFunctionCallOnClose(event, ui, ShowQuestionReturnValue)
    }
}

$(function() {
    if (typeof jQuery.ui.dialog == 'function') {
        $("#question").dialog({
            autoOpen: false,
            bgiframe: true,
            width: 800,
            modal: true,
            close: function(event, ui) { ShowQuestionCallOnClose(event, ui) },
            resizable: false,
            height: 300,
            resizable: false,
            modal: true,
            buttons: {
                'אישור': function() {
                    ShowQuestionReturnValue = true;
                    $(this).dialog('close');
                },
                'ביטול': function() {
                    $(this).dialog('close');
                }
            }
        });        
    }
});

function ShowQuestion(context, OnClose, title, height) {

    var $question = $('#question');

    if (title == undefined) {
        $question.dialog('option', 'title', 'אישור ביצוע פעולה');
    }
    else {
        $question.dialog('option', 'title', title);
    }
    if (height != undefined) {
        $question.dialog('option', 'height', height);
    }
    if (OnClose != undefined) {
        CustomFunctionCallOnClose = OnClose;
    }
    $question.find('#content').html(context);
    $question.dialog('open');
    return false;
}

