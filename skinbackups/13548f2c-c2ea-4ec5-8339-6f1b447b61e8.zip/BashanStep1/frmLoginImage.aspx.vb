Imports System
Imports System.Collections
Imports System.Text
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Drawing.Drawing2D

Public Class frmLoginImage
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim objBitmap As Bitmap
        Dim rni As RandomNumberImg = New RandomNumberImg()
        Dim iBlackWhite As Integer = 0
        If "" + Request.QueryString("BlackWhite") <> "" Then
            iBlackWhite = CInt(Request.QueryString("BlackWhite"))
        End If

        Dim bBlackWhite As Boolean = (iBlackWhite > 0)
        If (bBlackWhite) Then
            objBitmap = rni.DrawBlackWhite()
        Else
            objBitmap = rni.Draw(bBlackWhite)
        End If
        objBitmap.Save(Response.OutputStream, ImageFormat.Gif)
    End Sub

End Class

Public Class RandomNumberImg
    Private SECRET_SIZE As Integer = 6

    Private Function Number2StringArray(ByVal secretNumber As Integer) As String()

        Dim temp As String = String.Format("{0:d6}", secretNumber)

        Dim retValue As String()
        Dim i As Integer
        ReDim retValue(5)

        For i = 0 To 5
            retValue(i) = temp.Substring(i, 1)
        Next i

        Return retValue
    End Function

    Public Function DrawBlackWhite() As Bitmap
        Dim objBitmap As Bitmap
        Dim objGraphics As Graphics

        Dim objPath As GraphicsPath
        Dim objBrush As PathGradientBrush

        ' Create Bitmap
        objBitmap = New Bitmap(140, 45) ' New Bitmap(90, 30)

        ' Create Graphics
        objGraphics = Graphics.FromImage(objBitmap)

        ' Create Path
        objPath = New GraphicsPath()
        objPath.AddRectangle(New Rectangle(0, 0, 146, 45))   'AddRectangle(New Rectangle(0, 0, 96, 30))


        ' Create PathGradient Brush
        objBrush = New PathGradientBrush(objPath)
        objBrush.CenterColor = Color.White

        objBrush.SurroundColors = New Color() {Color.White}

        ' Draw Path
        objGraphics.FillPath(objBrush, objPath)
        Dim rnd As Random = New Random()

        Dim secretNumber As Integer = rnd.Next(111111, 999999)
        If Not System.Web.HttpContext.Current Is Nothing Then
            System.Web.HttpContext.Current.Session("SecretNumber") = secretNumber
        End If

        Dim secretArray As String() = Number2StringArray(secretNumber)
        Dim i As Integer

        For i = 0 To 5
            'Dim iColor As Integer = rnd.Next(40, 68)
            Dim myBrush As SolidBrush = New SolidBrush(Color.FromKnownColor(KnownColor.Black))

            Dim iFontSize As Integer = rnd.Next(20, 24)
            '           Dim iFontSize As Integer = rnd.Next(16, 20)
            Dim iFont As Integer = rnd.Next(5, 9)
            Dim objFont As Font = New Font(FontFamily.GetFamilies(objGraphics)(iFont), iFontSize, FontStyle.Bold)
            objGraphics.DrawString(secretArray(i), objFont, myBrush, 10 + (16 * i), -1)

        Next

        ' Display Bitmap
        Return objBitmap

    End Function

    Public Function Draw(ByVal bBlackWhite As Boolean) As Bitmap

        Dim objBitmap As Bitmap
        Dim objGraphics As Graphics

        Dim objPath As GraphicsPath
        Dim objBrush As PathGradientBrush

        ' Create Bitmap
        objBitmap = New Bitmap(90, 30)

        ' Create Graphics
        objGraphics = Graphics.FromImage(objBitmap)

        ' Create Path
        objPath = New GraphicsPath()
        objPath.AddRectangle(New Rectangle(0, 0, 96, 30))


        ' Create PathGradient Brush
        objBrush = New PathGradientBrush(objPath)
        objBrush.CenterColor = Color.White

        If bBlackWhite Then
            objBrush.SurroundColors = New Color() {Color.White, Color.GhostWhite}
        Else
            objBrush.SurroundColors = New Color() {Color.Yellow, Color.Violet}
        End If

        ' Draw Path
        objGraphics.FillPath(objBrush, objPath)
        Dim rnd As Random = New Random()

        Dim secretNumber As Integer = rnd.Next(111111, 999999)
        If Not System.Web.HttpContext.Current Is Nothing Then
            System.Web.HttpContext.Current.Session("SecretNumber") = secretNumber
        End If

        Dim secretArray As String() = Number2StringArray(secretNumber)
        Dim i As Integer

        For i = 0 To 5
            Dim iFontSize As Integer = rnd.Next(16, 20)
            Dim iFont As Integer = rnd.Next(5, 9)
            Dim objFont As Font = New Font(FontFamily.GetFamilies(objGraphics)(iFont), iFontSize, FontStyle.Bold)

            If bBlackWhite Then
                Dim myBrush As New PathGradientBrush(objPath)
                myBrush.SurroundColors = New Color() {Color.Gray, Color.Black}
                objGraphics.DrawString(secretArray(i), objFont, myBrush, 10 + (12 * i), -1)
            Else
                Dim iColor As Integer = rnd.Next(40, 68)
                Dim myBrush As New SolidBrush(Color.FromKnownColor(CType(iColor, KnownColor)))
                objGraphics.DrawString(secretArray(i), objFont, myBrush, 10 + (12 * i), -1)
            End If
        Next

        ' Display Bitmap
        Return objBitmap

    End Function

End Class
