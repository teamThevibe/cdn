Imports System.Text.RegularExpressions

Public Class frmCheckRequestFields
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Dim regexWhiteList As Regex
        'regexWhiteList = CType(Application("WhiteList"), Regex)
        Dim objResult As New System.Text.StringBuilder()
        objResult.Append("<HTML><HEAD><TITLE></TITLE>")
        objResult.Append("<meta http-equiv='Cache-Control' content='no-cache'>" & vbCrLf)
        objResult.Append("<meta http-equiv='Pragma' content='no-cache'>" & vbCrLf)
        objResult.Append("<meta http-equiv='Expires' content='0'>" & vbCrLf)
        objResult.Append("<META http-equiv='Content-Type' content='text/html; charset=windows-1255'>")
        objResult.Append("</HEAD>")
        objResult.Append("<BODY>")
        Dim strWhiteListResult As String = ""

        Dim strWL1 As String = Request.Form("hidWL1")
        Dim strWL2 As String = Request.Form("hidWL2")
        Dim strWL3 As String = Request.Form("hidWL3")
        Dim strWL4 As String = Request.Form("hidWL4")
        Dim strWL5 As String = Request.Form("hidWL5")
        Dim strWL6 As String = Request.Form("hidWL6")
        Dim strWL7 As String = Request.Form("hidWL7")
        Dim strWL8 As String = Request.Form("hidWL8")
        Dim strWL9 As String = Request.Form("hidWL9")
        Dim strWL10 As String = Request.Form("hidWL10")
        Dim strWL11 As String = Request.Form("hidWL11")
        Dim strWL12 As String = ""
        Try
            strWL12 = Request.Form("hidWL12")
        Catch
        End Try
        Dim strWL13 As String = ""
        Try
            strWL13 = Request.Form("hidWL13")
        Catch
        End Try
        Dim sCheckKind As String = "1"
        Try
            If (Not IsNothing(Request.Form("hidCheckKind"))) Then
                sCheckKind = Request.Form("hidCheckKind")
            End If

        Catch
        End Try

        'Dim strWL1 As String = HttpUtility.UrlDecode(Request.Form("hidWL1"))
        'Dim strWL2 As String = HttpUtility.UrlDecode(Request.Form("hidWL2"))
        'Dim strWL3 As String = HttpUtility.UrlDecode(Request.Form("hidWL3"))
        'Dim strWL4 As String = HttpUtility.UrlDecode(Request.Form("hidWL4"))
        'Dim strWL5 As String = HttpUtility.UrlDecode(Request.Form("hidWL5"))
        'Dim strWL6 As String = HttpUtility.UrlDecode(Request.Form("hidWL6"))
        'Dim strWL7 As String = HttpUtility.UrlDecode(Request.Form("hidWL7"))
        'Dim strWL8 As String = HttpUtility.UrlDecode(Request.Form("hidWL8"))
        'Dim strWL9 As String = HttpUtility.UrlDecode(Request.Form("hidWL9"))
        'Dim strWL10 As String = HttpUtility.UrlDecode(Request.Form("hidWL10"))
        'Dim strWL11 As String = HttpUtility.UrlDecode(Request.Form("hidWL11"))
        'Dim strWL12 As String = ""
        'Try
        '    strWL12 = HttpUtility.UrlDecode(Request.Form("hidWL12"))
        'Catch
        'End Try
        'Dim strWL13 As String = ""
        'Try
        '    strWL13 = HttpUtility.UrlDecode(Request.Form("hidWL13"))
        'Catch
        'End Try

        If IsNothing(strWL12) Then
            strWL12 = ""
        End If
        If IsNothing(strWL13) Then
            strWL13 = ""
        End If

        'Try
        '    If Not (regexWhiteList.IsMatch(strWL1) And _
        '            regexWhiteList.IsMatch(strWL2) And _
        '            regexWhiteList.IsMatch(strWL3) And _
        '            regexWhiteList.IsMatch(strWL4) And _
        '            regexWhiteList.IsMatch(strWL5) And _
        '            regexWhiteList.IsMatch(strWL6) And _
        '            regexWhiteList.IsMatch(strWL7) And _
        '            regexWhiteList.IsMatch(strWL8) And _
        '            regexWhiteList.IsMatch(strWL9) And _
        '            regexWhiteList.IsMatch(strWL10) And _
        '            regexWhiteList.IsMatch(strWL11) And _
        '            regexWhiteList.IsMatch(strWL12) And _
        '            regexWhiteList.IsMatch(strWL13)) Then
        '        strWhiteListResult = "-1"
        '    Else
        '        
        '    End If
        'Catch ex As Exception
        '    strWhiteListResult = "-1"
        'End Try
        strWhiteListResult = "1"

        objResult.Append("<INPUT TYPE='hidden' id='ctlWhiteListResult' value='" & strWhiteListResult & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlCheckKind' value='" & sCheckKind & "'>")
        objResult.Append("<SCRIPT>")
        objResult.Append("	window.parent.document.all.oWLNotification.value = 'OK';")
        objResult.Append("</SCRIPT>")
        objResult.Append("</BODY>")
        objResult.Append("</HTML>")
        Response.Write(objResult.ToString())
    End Sub
End Class
