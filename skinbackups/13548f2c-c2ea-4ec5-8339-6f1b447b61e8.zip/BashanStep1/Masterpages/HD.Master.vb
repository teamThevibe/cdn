﻿Imports System.Text.RegularExpressions
Imports System.Web.Security

Public Class HDMasterPage
    Inherits System.Web.UI.MasterPage
    'Public iSessionTimeout As Integer = 0 'default - no warnning
    'Public iSessionWarn As Integer

    Public SessionTimeout As Integer = 0 'default - no warnning
    Public SessionWarning As Integer
    Protected FORMLogin As System.Web.UI.WebControls.HiddenField

    Protected WithEvents ReportType As System.Web.UI.WebControls.HiddenField
    Protected WithEvents ScrollPosition As System.Web.UI.WebControls.HiddenField
    Protected WithEvents hidDoctorService As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents HdStartFromTikMevhutach As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents Body As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents hidDisabledMenu As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents HidbdikatZakhut As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents HidGoToRepList As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents HidWin As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents ReportRepeater As System.Web.UI.WebControls.Repeater
    Protected WithEvents MainTitle As System.Web.UI.WebControls.Literal
    Protected WithEvents cmdExit As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents MasterUsers As System.Web.UI.WebControls.DropDownList
    Protected WithEvents hidUserChanged As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidInretActive As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents Logo As System.Web.UI.HtmlControls.HtmlImage
    Protected WithEvents headerMerging As System.Web.UI.HtmlControls.HtmlGenericControl

    Public frmRequestURL As String = Utils.Navigation.GetURL("frmRequestt.aspx")

    Private Sub Page_PreRender(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.PreRender

        ' Create a new PostBackOptions object and set its properties.
        Dim myPostBackOptions As PostBackOptions = New PostBackOptions(Me)
        Me.Page.ClientScript.GetPostBackEventReference(myPostBackOptions)

        If Request.Url.LocalPath.ToLower.IndexOf("frmHDRepList".ToLower()) > 0 Then
            ReportType.Value = Utils.EncryptString(Session("Report_List_ReportType"))
        End If

        If Not Session("MoodChangedFromMasterPage") Is Nothing Then
            If Session("MoodChangedFromMasterPage") = "1" Then
                ReportType.Value = Utils.EncryptString(Session("Report_List_ReportType"))
            End If
        End If

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        If "1".Equals(Application("WarnSessionTimeout").ToString()) Then
            SessionTimeout = HttpContext.Current.Session.Timeout
            SessionWarning = Val(Application("WarnSessionTimeoutMinutes"))
        End If
        FORMLogin.Value = Application("FORMLogin")

        If Session.IsNewSession Then
            Response.Redirect("Login.aspx")
        End If

        'If Not IsPostBack() Then
        If Not IsPostBack Then
            BindUsers()
            BindReportList()
            If Not Application("DoctorService") Is Nothing Then
                hidDoctorService.Value = Application("DoctorService").ToString
            End If
            ScrollPosition.Value = Session("ScrollPosition")
        Else
            Session("ScrollPosition") = ScrollPosition.Value
        End If

        If Not Request.QueryString("HidGoToRepList") Is Nothing Then
            If Request.QueryString("HidGoToRepList").ToString = "1" Then
                HidGoToRepList.Value = "1"
            End If
        End If

        If Not Request.QueryString("ScrollPosition") Is Nothing Then
            ScrollPosition.Value = Request.QueryString("ScrollPosition")
        End If



        If Me.HidbdikatZakhut.Value = "1" Then
            Session.Remove("MoodChangedFromMasterPage")
            Response.Redirect("frmHDStart.aspx?HidbdikatZakhut=1")

        End If


        '*******************************************************************
        'Next version 180214
        '*******************************************************************
        '' '' '' ''Dim sHdStartFromTikMevhutach = HdStartFromTikMevhutach.Value

        '' '' '' ''If Me.HidbdikatZakhut.Value = "1" Then
        '' '' '' ''    Session.Remove("MoodChangedFromMasterPage")

        '' '' '' ''    '''''''''''''''''''''''''''''''''''''''''Response.Redirect("frmHDStart.aspx?HidbdikatZakhut=1")

        '' '' '' ''    Dim sFilePath As String = Me.Page.Request.FilePath.ToUpper

        '' '' '' ''    If sFilePath.IndexOf("FRMHDSTART.ASPX") > -1 Then

        '' '' '' ''        Dim i As Integer = DirectCast(Me.Page, frmHDStart).GetComeMevhutach()

        '' '' '' ''        If sHdStartFromTikMevhutach <> "1" Then

        '' '' '' ''            DirectCast(Me.Page, frmHDStart).SetComeMevhutach(1)
        '' '' '' ''            DirectCast(Me.Page, frmHDStart).SetComeMevhutachForHdstart(1)
        '' '' '' ''            DirectCast(Me.Page, frmHDStart).SetBbdikatZakhutStart(1)
        '' '' '' ''            DirectCast(Me.Page, frmHDStart).SetShowZakaut()
        '' '' '' ''        End If


        '' '' '' ''    Else
        '' '' '' ''        Response.Redirect("frmHDStart.aspx?HidbdikatZakhut=1")
        '' '' '' ''    End If


        '' '' '' ''End If
        '*******************************************************************





    End Sub

    Private Sub cmdExit_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdExit.ServerClick
        Session.Clear()
        Session.Abandon()
        Response.Redirect(Application("FORMLogin"))
    End Sub

    Private Sub BindReportList()

        Dim User As New UserConnect.UserService()
        User.Url = Application("UserWebService").ToString()
        Dim UserID As String = User.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", Page.User.Identity.Name)

        Dim ReportService As New ReportConnect.ReportService()
        ReportService.Url = Application("ReportWebService").ToString()
        Dim isUnion As Integer = 1
        Dim ds As DataSet = ReportService.GetReportsStatistics("28B2AB64-641B-4F09-969F-B4DD6B250009", UserID, Session("SubUserID"), isUnion)
        Dim dv As DataView = Nothing

        If Not ds Is Nothing AndAlso ds.Tables.Count > 0 Then
            Dim dr As DataRow
            Dim dc As DataColumn = New DataColumn()
            Dim dc1 As DataColumn = New DataColumn()
            dc.ColumnName = "ReportDescription"
            dc1.ColumnName = "ReportDescriptionFull"

            dc.DataType = System.Type.GetType("System.String")
            dc1.DataType = System.Type.GetType("System.String")

            ds.Tables(0).Columns.Add(dc)
            ds.Tables(0).Columns.Add(dc1)

            Dim ReportDescriptionLength As Integer
            Dim MaxReportDescriptionLength As Integer = 20
            Dim ReportTypeName As String = String.Empty

            For Each dr In ds.Tables(0).Rows
                ReportDescriptionLength = Utils.Values.GetDataRowString(dr, "ReportTypeName").Length + _
                Utils.Values.GetDataRowString(dr, "NotReadRep").Length + _
                Utils.Values.GetDataRowString(dr, "AllRep").Length + 2
                ReportTypeName = Utils.Values.GetDataRowString(dr, "ReportTypeName")

                If Convert.ToInt32(dr("ReportType")) > -1 Then
                    dr("ReportDescriptionFull") = String.Format("{0} {1}/{2}", ReportTypeName, Utils.Values.GetDataRowString(dr, "NotReadRep"), Utils.Values.GetDataRowString(dr, "AllRep"))
                Else
                    dr("ReportDescriptionFull") = ""
                End If

                If ReportDescriptionLength > MaxReportDescriptionLength Then
                    If ReportTypeName.Length > ReportDescriptionLength - MaxReportDescriptionLength Then
                        ReportTypeName = ReportTypeName.Substring(0, ReportTypeName.Length - ReportDescriptionLength + MaxReportDescriptionLength)
                    Else
                        ReportTypeName = String.Empty
                    End If
                    ReportTypeName = ReportTypeName + "..."
                End If
                If Convert.ToInt32(dr("ReportType")) > -1 Then
                    dr("ReportDescription") = String.Format("{0} {1}/{2}", ReportTypeName, Utils.Values.GetDataRowString(dr, "NotReadRep"), Utils.Values.GetDataRowString(dr, "AllRep"))
                Else
                    dr("ReportDescription") = ReportTypeName
                End If
            Next
            ds.AcceptChanges()
            dv = New DataView(ds.Tables(0), String.Empty, "OrderNumberForDisplay", DataViewRowState.CurrentRows)
        End If

        ReportRepeater.DataSource = dv
        ReportRepeater.DataBind()

    End Sub

    Protected Function EncodeField(ByVal obj As Object) As String
        Return Utils.AntiXSSHtml(obj.ToString())
    End Function

    Protected Function EncryptField(ByVal obj As Object) As String
        Return Utils.EncryptString(obj.ToString(), False)
    End Function

    Protected Function SetExtCode(ByVal obj As Object) As String
        If obj.ToString() = -1 Then
            Return "1"
        Else
            Return "0"
        End If
    End Function

    Private Sub ReportRepeater_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles ReportRepeater.ItemDataBound

        Dim item As RepeaterItem = e.Item
        Select Case (item.ItemType)
            Case ListItemType.Item, ListItemType.AlternatingItem
        End Select

    End Sub

    Protected Sub ReportType_ValueChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ReportType.ValueChanged



        Dim URL As String
        Dim sCurrName As String = Me.Page.ToString
        Dim iFnd As Integer = sCurrName.ToUpper.IndexOf("FRMHDSTART")

        If ReportType.Value = "Demi" Then
            ReportType.Value = Utils.EncryptString("-1")
        End If

        If Utils.DecryptString(ReportType.Value) = "-1" Then
            If iFnd < 0 Then
                Session("MoodChangedFromMasterPage") = "1"
                Session("Report_List_ReportType") = Utils.DecryptString(ReportType.Value)
                Response.Redirect((New Utils).GetLinkForNextForm("frmHDstart.aspx?HidbTikMevhutach=1"))
            Else
                Session("MoodChangedFromMasterPage") = "1"
                Session("Report_List_ReportType") = Utils.DecryptString(ReportType.Value)
                DirectCast(Me.Page, frmHDStart).SetTikMevhutach()
                DirectCast(Me.Page, frmHDStart).MoodChangedFromMasterPage()
                Return
            End If
        End If

        If (ReportType.Value.ToLower() = "UserProperty".ToLower()) Then
            Session("User_Prop_Caller") = Application("FORMStart")
            URL = Utils.Navigation.GetURL("frmUserProp.aspx")
            Response.Redirect((New Utils).GetLinkForNextForm(URL))
            Return
        End If
        If (ReportType.Value.ToLower() = "UserNewProperty".ToLower()) Then
            Session("User_Prop_Caller") = Application("FORMStart")
            URL = ConfigurationSettings.AppSettings("UserPropertyScreen")
            Response.Redirect((New Utils).GetLinkForNextForm(URL))
            Return
        End If

        Session("Report_List_ReportType") = Utils.DecryptString(ReportType.Value)

        If Application("App_Type").ToString <> "dist" Then
            Dim User As New UserConnect.UserService()
            User.Url = Application("UserWebService").ToString()
            Dim UserID As String = User.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", Page.User.Identity.Name)
            Session("Report_List_Current_User") = UserID
        End If

        If "1".Equals(Application("ShowInterActiveReport")) Then
            Response.Redirect((New Utils).GetLinkForNextForm("frmHDRepList.aspx?HidGoToRepList=1"))
        Else
            URL = Utils.Navigation.GetURL("frmRepList.aspx", Utils.DecryptString(ReportType.Value))
            Response.Redirect((New Utils).GetLinkForNextForm(URL))
        End If

        ' YT:TODO
        'Response.Redirect((New Utils).GetLinkForNextForm(Application("FORMRepList")))

    End Sub

    Public Sub SetDisableMenu(ByVal sDisable As String)
        Me.hidDisabledMenu.Value = sDisable
    End Sub

    Public Function SetCursorForMenu() As String
        If Me.hidDisabledMenu.Value = "1" Then
            Return "cursor:none"
        Else
            Return "cursor:pointer"
        End If
    End Function

    Private Sub BindUsers()

        Dim User As New UserConnect.UserService()
        User.Url = Application("UserWebService").ToString()

        Dim UserID As String = User.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", Page.User.Identity.Name)
        Dim ds As Data.DataSet = User.GetSubUsers("6A2B8CB2-B464-4C16-A415-933DABD1FD10", Page.User.Identity.Name)
        MasterUsers.DataTextField = "ClinicName" 'FullName
        MasterUsers.DataValueField = "SysUserID"
        MasterUsers.DataSource = ds
        MasterUsers.DataBind()

        If MasterUsers.Items.Count < 2 Then
            MasterUsers.Visible = False
        Else
            If IsNothing(Session("SubUserID")) Then
                MasterUsers.SelectedValue = UserID
            Else
                MasterUsers.SelectedValue = Session("SubUserID")
            End If
        End If
        Session("SubUserID") = MasterUsers.SelectedItem.Value
        Session("SubUserIDForRepList") = MasterUsers.SelectedItem.Value
    End Sub

    Protected Sub MasterUsers_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles MasterUsers.SelectedIndexChanged
        Session("SubUserID") = MasterUsers.SelectedItem.Value
        BindReportList()
        hidUserChanged.Value = "1"

        Session("SubUserIDForRepList") = MasterUsers.SelectedItem.Value

    End Sub

    Public Sub SetUnSelected()


        Body.Attributes.Add("ondragstart", "return false")

        Body.Attributes.Add(" onselectstart", "return false")


    End Sub


    Public Sub SetSelected()


        Body.Attributes.Add("ondragstart", "return true")

        Body.Attributes.Add(" onselectstart", "return true")


    End Sub

    Public Sub SetInterActive(ByVal iSugDivuach)


        '-----------
        If iSugDivuach = eSugDivuach.eRequests Then
            '-----------

            hidInretActive.Value = "U2htc0NkL05tVk5sOXJtUGdjRmgxUT09"

        End If

        '-----------
        If iSugDivuach = eSugDivuach.eConsultations Then
            '-----------

            hidInretActive.Value = "UU04TmdLa1V2MVdEaDI4Tk9xZXhoZz09"

        End If

        '-----------
        If iSugDivuach = eSugDivuach.eAccount Then
            '-----------

            hidInretActive.Value = "aHgrZFFyTng0TElicW9saDdSTGRnQT09"

        End If

    End Sub


    Enum eSugDivuach As Integer
        eRequests = 11
        eConsultations = 41
        eAccount = 10

    End Enum

End Class