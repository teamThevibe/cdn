﻿
var flagTikMevutach;
var flagComeMevhutach = "0"



//***************************************
$(document).ready(function() {
    //***************************************
    //    $("#mp_dialog_wait").dialog({
    //        modal: true,
    //        autoOpen: false,
    //        resizable: false,
    //        closeOnEscape: false,
    //        showTitle: false,
    //        height: 150,
    //        width: 300,
    //        modal: true,
    //        position: ['center', 300],
    //        draggable: false,
    //        bgiframe: true,
    //        open: function(event, ui) {
    //            $(".ui-dialog-titlebar").hide();
    //        }
    //    });


    //----------
    document.documentElement.style.overflowX = "hidden";

    //----------
    var strQueryString = "";

    //----------
    if ($('input[id$=hidDisabledMenu]').val() == "1") {
        strQueryString = "&DisabledMenu=1"
    }

    //----------
    $.ajax({
        //----------
        cache: false,
        type: "GET",
        url: "Handlers/GetMainMenu.ashx?key=" + (new Date()).getMilliseconds() + strQueryString,
        dataType: "text", //"text", "json"
        async: true, // importent !
        success: function(response, status) {

            $("#MainMenu").html(response);
            $("li.SubMenuItem").hover(
                function() {
                    $(this).addClass('SubMenuHover').children().addClass("SubMenuHover"); ;
                },
                function() {
                    $(this).removeClass('SubMenuHover').children().removeClass('SubMenuHover');
                }

            //----------  
            ); ////$.ajax({
            //----------


            $("li.SubMenuItem").click(function() {

            });

            //***************************************
            //***************************************
            // select Menu item
            //***************************************
            //***************************************


            if ($('input[id$=HidGoToRepList]').val() == "1") {

                $('input[id$=HidGoToRepList]').val('0')

                return;

            }

            if ($('input[id$=HidSetMasacRhasi]').val() == "2") {

                $('input[id$=HidSetMasacRhasi]').val('0')
                SelectBdikatZakhut();
                return;

            }

            if ($('input[id$=HidSetMasacRhasi]').val() == "1") {
                $('input[id$=HidSetMasacRhasi]').val('0')
                SelectMasachRhashiCont();
                return;

            }

            if ($('input[id$=HidComeMevhutach]').val() == "1") {
                $('input[id$=HidComeMevhutach]').val('0');
                $('input[id$=HidComeMevhutachForHdstart]').val('0');

                if ($('input[id$=HidbdikatZakhutStart]').val() == "1") {
                    SelectItembdikatZakhut();
                    return;
                }

                else {
                    SelectMasachRhashi();
                    return;
                }


            }

            if (flagTikMevutach == "1") {
                flagTikMevutach = "0"
                return;
            }

            SelectMenuitem();


            $("#MainMenu").parents("div:first").scrollTop(GetScrollPosition(0));
        },
        error: function(response, status) {
            alert("error: " + response.responseText);
        }

        //----------
    }); //$(document).ready(function() {
    //----------



    if ($('input[id$=hidDoctorService]').val() != "") {
        if ($('input[id$=hidDisabledMenu]').val() == "1") {
            return;
        }
        else {
            $("#mnuDoctorService").click(function() {
                window.open($('input[id$=hidDoctorService]').val());
            });
        }
    }
    else {
        $("#mnuDoctorService").css("display", "none");
    }


    //***************************************
    //***************************************
    // select Submenu item
    //***************************************
    //***************************************



    if ($('input[id$=HidSetMasacRhasi]').val() == "1") {

        return;
    }

    if ($('input[id$=HidSetMasacRhasi]').val() == "2") {
        return;
    }

    if ($('input[id$=HidComeMevhutach]').val() == "1") {
        return;
    }


    var a = $('ul[id=Reports]');

    var n = a.parent().find("input[id$=ReportType]").val();
    if (n.length > 0) {

        if (n == "UHZqZDBqdmVpaEVCZkZSdXVzYW1JQT09") {

            flagTikMevutach = "1";
            SelectItemTikMevhutach();
        }


        else {

            SelectItem(a.find("a." + n), 1);
        }
    }


    else
    
     {

        var $iInretActive = $("input[id$=hidInretActive]");
        var iInretActive = $iInretActive.val();

        if (iInretActive != "") {

            SelectItem(a.find("a." + iInretActive), 1);
        
        }

        flagTikMevutach = "0";


    }


    a.parents("div:first").scrollTop(GetScrollPosition(1));


});                 


//-----------------------------
function GetScrollPosition(place) {
    //-----------------------------
    var $ScrollPosition = $("input[id$=ScrollPosition]");
    var ScrollPosition = $ScrollPosition.val();
    if (place === undefined) {
        return ScrollPosition;
    }
    if (ScrollPosition.length == 0) {
        ScrollPosition = "0;0";
    }
    var Position = ScrollPosition.split(";")
    return Position[place];
}

//-----------------------------
function SetScrollPosition(value, place) {
    //-----------------------------
    var $ScrollPosition = $("input[id$=ScrollPosition]");
    var ScrollPosition = $ScrollPosition.val();
    if (ScrollPosition.length == 0) {
        ScrollPosition = "0;0";
    }
    var Position = ScrollPosition.split(";")
    Position[place] = value;
    $ScrollPosition.val(Position.join(";"));
}

//-----------------------------
function MainMenuScroll(me) {
    //-----------------------------
    SetScrollPosition($(me).scrollTop(), 0);
}

//-----------------------------
function ReportsScroll(me) {
    //-----------------------------
    SetScrollPosition($(me).scrollTop(), 1);
}


//-----------------------------
function SelectItem($item, place) {
    //-----------------------------

    $item.css("color", "#b3d4fc").parent().css("background", "#003b7e");
    
    
     ShowNewPatinet();
}

//-----------------------------
function inProcess() {
    //-----------------------------
    $("#mp_dialog_wait").dialog("open");
}

//-----------------------------
function endProcess() {
    //-----------------------------
    $("#mp_dialog_wait").dialog("close");
}

//--------------------------
function ShowNewPatinet() 
    //-----------------------------
    {//1



        if ($('input[id$=HidbTikMevhutach]').val() == "1") 
        {//2
        
            if ( $('input[id$=InsuredID]').val()  != "" )
            {//3
            
                 if  ( $('input[id$=LastName]').val()  != "" ) {//4
                 
                 
                      if ($('input[id$=HidbShowNewPatinet]').val() == "1")
                      {
                          $('div[id$=dvNewPatient]').css("display", "block");
                      }
                      else {

                          if ($('input[id$=HidbShowNewPatinet]').val() == "2") {
                              $('div[id$=dvNewPatient]').css("display", "block");
                              $('div[id$=dvNewPatient]').html('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' +
                              '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + 'אין מידע להצגה בטווח התאריכים המבוקש');
                          }
                          else {


                              $('div[id$=dvNewPatient]').css("display", "none");
                          }
                      }



                    } //4
                    else //4
                    {//4
                        $('div[id$=dvNewPatient]').css("display", "none");
                    } //4

                } //3
                else //3
                {//3
                    $('div[id$=dvNewPatient]').css("display", "none");
                 } //3

            } //2
            else //2
            {//2
                $('div[id$=dvNewPatient]').css("display", "none");
         } //2



     } //1

     //-----------------------------
     function SelectMasachRhashi() {
         //-----------------------------


                // window.navigate('frmHDstart.aspx?ScrollPosition=' + GetScrollPosition() + '&FromMenu=1' + '&SetMasacRhasi=1');
         //__doPostBack('frmHDstart.aspx?ScrollPosition=' + GetScrollPosition() + '&FromMenu=1' + '&SetMasacRhasi=1');

         var a = window.location.pathname

         if (a.indexOf("frmHDRepList") > -1) {

             window.navigate('frmHDstart.aspx?ScrollPosition=' + GetScrollPosition() + '&FromMenu=1' + '&SetMasacRhasi=1');
         
         }
         else 
         {


             $('input[id$=HidSetMasacRhasi]').val('1');
             __doPostBack();
         }
                  
                  
                  return "1"

              }

              //-----------------------------
              function SelectMasachRhashiCont() {
                  //-----------------------------
                  //document.title = 'מערכת הוד - מסך ראשי';

                  $("#MainMenu")[0].all[0].style.backgroundColor = '003B7E';
                  $("#MainMenu")[0].all[1].style.color = 'white';

                  

              } 
    
    
//-----------------------------
function SelectBdikatZakhut() {
    //-----------------------------
    
    var a = window.location.pathname.split("/");
    if (a.length > 0) {
        //var n = a[a.length - 1].split(".")[0];
        var n = "bdikatZakhut";
        var i = $("#MainMenu").find("a[onclick*=" + n + "]");
        if (i.length > 0) SelectItem(i, 0);
    }

}

//-----------------------------
function SelectItembdikatZakhut() {
    //-----------------------------

    if ($('input[id$=HidbdikatZakhutStart]').val() == "1") {

        if (flagTikMevutach == "1") {
            flagTikMevutach = "0";
            return;
        }

        var a = window.location.pathname.split("/");
        if (a.length > 0) {
            //var n = a[a.length - 1].split(".")[0];
            var n = "bdikatZakhut";
            var i = $("#MainMenu").find("a[onclick*=" + n + "]");
            if (i.length > 0) SelectItem(i, 0);
        }
    }

}


//-----------------------------
function SelectItembdikatZakhutFirst() {
    //-----------------------------

    

        if (flagTikMevutach == "1") {
            flagTikMevutach = "0";
            return;
        }

        var a = window.location.pathname.split("/");
        if (a.length > 0) {
            //var n = a[a.length - 1].split(".")[0];
            var n = "bdikatZakhut";
            var i = $("#MainMenu").find("a[onclick*=" + n + "]");
            if (i.length > 0) SelectItem(i, 0);
        }


}


//-----------------------------
function SelectItemTikMevhutach() {
    //-----------------------------
    if ($('input[id$=HidbTikMevhutach]').val() == "1") {



        var a = $('ul[id=Reports]');
        var n = "UHZqZDBqdmVpaEVCZkZSdXVzYW1JQT09";
        if (n.length > 0) {
            SelectItem(a.find("a." + n), 1);
        }
    }
    else {



        if ($('input[id$=HidTikMevurachInner]').val() == "1") {



            var a = $('ul[id=Reports]');
            var n = "UHZqZDBqdmVpaEVCZkZSdXVzYW1JQT09";
            if (n.length > 0) {
                SelectItem(a.find("a." + n), 1);
            }
        }  
    
    
    
    
    
    
    
    
    
    }

}


var MessModalTitle;
var MessModalHeight;
var MessModalWidth;

//-----------------------------
function displayError(message, options) {
    //-----------------------------
    setDesign();
    options = $.extend(true, {
        modal: true,
        autoOpen: true,
        resizable: false,
        height: MessModalHeight,
        width: MessModalWidth,
        title: MessModalTitle,
        modal: true,
        position: "center",
        draggable: false,
        buttons: { "סגור": function() { $(this).dialog("close"); } },
        focus: function(event, ui) {
            $(".ui-dialog-content", $(this)).css({ "padding": "0 0 0 0" });
            $(".ui-dialog-titlebar").css({ "padding-top": "3", "padding-bottom": "2" });
        },
        close: function(event, ui) { $(this).dialog("destroy"); },
        bgiframe: true
    }, options)

    $("#mp_dialog_err").html(message).dialog(options);

    MessModalTitle = ""
    MessModalHeight = "";
    MessModalWidth = "";
}

//-----------------------------
function setDesign()
//-----------------------------
{
    if (MessModalTitle == "") {
        MessModalTitle = "הודעה";
    }
    if (MessModalHeight == "") {
        MessModalHeight = 150;
    }
    if (MessModalWidth == "") {
        MessModalWidth = 300;
    }
}

//-----------------------------
function SelectReport(me) {

    if (!onMenuItemClick()) 
        return;

    //-----------------------------
    if ($('input[id$=hidDisabledMenu]').val() == "1") {
        return;
    }

    $('input[id$=HdStartFromTikMevhutach]').val('1');
    
    
    var $ReportType = $('input[id$=ReportType]');
    var ReportType = $(me).attr("class");
    
    if ($ReportType.val() != ReportType) { // if selected another report...
        $ReportType.val(ReportType);
        submitPage($ReportType);
    }
    else {
        var extCode = $(me).attr("extCode");
        if (extCode == "1") {
            $ReportType.val("Demi");
           //$ReportType.val(ReportType);
            submitPage($ReportType);        
        }
    
    
    }
}

//-----------------------------
function Complaints(url) {
    if (!onMenuItemClick()) 
        return;
    if (event.altKey && event.altLeft) {
        url = url.replace("frmHDNRequestt", "frmRequestt");
    }
    window.navigate(url);
}

//-----------------------------
function UserProperty() {

    if (!onMenuItemClick()) 
        return;

    //-----------------------------
    if ($('input[id$=hidDisabledMenu]').val() == "1") {
        return;
    }
    var $ReportType = $('input[id$=ReportType]');
    //
    var altLeft = false;
    try {
        if (event.altLeft) {
            altLeft = true;
        }
    } catch (e) {
    }
    if (altLeft) {
        $ReportType.val("UserNewProperty");
    }
    else {
        $ReportType.val("UserProperty");
    }
    //    
    submitPage($ReportType);
}

//-----------------------------
function DisabledUl() {
    //-----------------------------
    var arr1 = document.getElementsByTagName("UL");

    for (var i = 0; i < arr1.length; i++) {
        arr1[i].disabled = true;
        arr1[i].style.cursor = 'finger';
        arr1[i].onclick = null;
    }
}

//-----------------------------
function DisabledReportRepeater() {
    //-----------------------------
    $('ul').each(function() {
        $(this).attr('disabled', 'disabled');
        $(this).css('cursor', 'none');
        $(this).attr('onclick', '').unbind('click');
    });
}

//-----------------------------
function DisabledmnuDoctorService() {
    //-----------------------------
    $("#mnuDoctorService").attr('disabled', 'disabled');
    $("#mnuUserProp").attr('disabled', 'disabled');
    $("#mnuDoctorService").css('cursor', 'none');
    $("#mnuUserProp").css('cursor', 'none');
    $("#mnuDoctorService").css('class', 'button');
    $("#mnuUserProp").css('class', 'button info-button');
}

//-----------------------------
var windowNavigate = window.navigate // for דיווח לחברה navigation...
//-----------------------------

//-----------------------------
window.navigate = function(address) {
//-----------------------------
    if (this.location.href.indexOf(address) < 0) {
        windowNavigate(address);
    }
}

//-----------------------------
function submitPage($me) {
    //-----------------------------
    __doPostBack($me.attr("name"), '');
}

//-----------------------------
function bdikatZakhut() {

    if (!onMenuItemClick()) 
        return;

    //-----------------------------
    $('input[id$=HdStartFromTikMevhutach]').val('0');
    $('input[id$=HidbdikatZakhut]').val('1');
    __doPostBack();
}

//-----------------------------
function InformOfChange() {
    //-----------------------------

    //debugger;
    
    $('select[id$=lstUsers]').find('option[value=' + $('select[id$=MasterUsers]').val() + ']').attr('selected', 'yes')
}

//-----------------------------
function SelectMenuitem() {
    //-----------------------------
    //debugger;
    var a = window.location.pathname.split("/");
    if (a.length > 0) {
        var n = a[a.length - 1].split(".")[0];
        // var n = "bdikatZakhut";
        var i = $("#MainMenu").find("a[onclick*=" + n + "]");

        if (n == "frmHDNRequestt" && i.length<=0) {
            i = $("#MainMenu").find("a[onclick*=frmRequestt]");
        }

        if (i.length > 0) {
            SelectItem(i, 0);
        }
        else {
            SelectItembdikatZakhutFirst();
        }
    }

}

function onMenuItemClick() {
    return true;
}