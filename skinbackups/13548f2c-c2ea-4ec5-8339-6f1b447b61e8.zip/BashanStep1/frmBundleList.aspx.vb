Public Class frmBundleList
    Inherits System.Web.UI.Page
    Protected WithEvents grdList As System.Web.UI.WebControls.DataGrid
    Protected WithEvents txtRepID As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtSubUserID As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtIsTechSupport As System.Web.UI.HtmlControls.HtmlInputHidden


    Protected WithEvents HidIsDelegateAnswer As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents HidRepIDSupportRequests As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents spnGl As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents cmdSend As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents txtRemark As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents titleRemark As System.Web.UI.WebControls.TextBox
    Dim isDelegateAnswer As Integer = 0
    Dim iRepIDSupportRequests As Integer = 0



#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not IsPostBack Then


            Dim isExcel As String = Request.QueryString("isExcel")

            If (Request.QueryString("isDelegateAnswer") <> Nothing) Then

                isDelegateAnswer = Request.QueryString("isDelegateAnswer")
                HidIsDelegateAnswer.Value = isDelegateAnswer.ToString

                If (Request.QueryString("RepIDSupportRequests") <> Nothing) Then
                    HidRepIDSupportRequests.Value = Request.QueryString("RepIDSupportRequests")
                End If



            End If

            txtRepID.Value = Request.QueryString("RepID") & ""
            txtSubUserID.Value = Request.QueryString("SubUserID") & ""
            txtIsTechSupport.Value = Request.QueryString("IsTechSupport") & ""
            If txtIsTechSupport.Value = "1" Then
                grdList.Columns(3).Visible = True
                'grdList.Columns(2).Visible = False
            Else
                'grdList.Columns(3).Visible = False
                grdList.Columns(2).Visible = True
            End If
            If IsNumeric(txtRepID.Value) And IsNumeric(txtSubUserID.Value) Then

                BindGrid()
                If isExcel = "1" Then
                    ExportExcel(Me.grdList)
                Else

                End If
            End If

        End If
    End Sub

    Private Sub BindGrid()
        Dim showFilesAtt As Boolean = True
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim strUserID As String = objUser.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", User.Identity.Name)
        Dim objReportsList As New ReportConnect.ReportService()
        objReportsList.Url = Application("ReportWebService").ToString()
        Dim ds As DataSet = objReportsList.GetReportBundle("D8FB32D6-77C3-4C06-98AC-17F14691C645", Val(strUserID), Val(txtSubUserID.Value), Val(txtRepID.Value), isDelegateAnswer)
        Dim iCount As Integer = ds.Tables(0).Rows.Count

        Dim iPageCount As Integer = (iCount - 1) \ grdList.PageSize
        If grdList.CurrentPageIndex > iPageCount Then
            grdList.CurrentPageIndex = iPageCount
        End If

        If Me.isDelegateAnswer = 1 Then

            txtRemark.Visible = True
            Me.cmdSend.Visible = True
            titleRemark.Visible = True

            Dim dr As DataRow
            Dim i As Integer = 0
            For Each dr In ds.Tables(0).Rows
                Dim _fileName As String = ds.Tables(0).Rows(i)("filename")
                Dim fileExt As String = System.IO.Path.GetExtension(_fileName)
                If (fileExt = ".htm" Or fileExt = ".html") Then
                    Me.spnGl.Style.Add("visibility", "hidden")
                    showFilesAtt = False

                End If

            Next

        End If

        If showFilesAtt Then

            grdList.DataSource = ds
            grdList.DataBind()
            If iPageCount > 0 Then
                grdList.PagerStyle.Visible = True
            Else
                grdList.PagerStyle.Visible = False
            End If
        End If

    End Sub

    Private Sub grdList_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdList.ItemDataBound
        Dim dgItem As DataGridItem = e.Item
        Select Case (dgItem.ItemType)
            Case ListItemType.Item, ListItemType.AlternatingItem
                dgItem.Attributes.Add("onclick", "SelectRow(this);")
        End Select
    End Sub

    Protected Function FormatFileName(ByRef objCode As Object) As String
        Dim strReturn As String = ""
        If Not IsDBNull(objCode) Then
            strReturn = objCode.ToString()
        End If
        Return strReturn
    End Function

    Protected Function FormatFileType(ByRef objCode As Object) As String
        Dim strReturn As String = ""
        Try
#If EngDesign Then
            If Not IsDBNull(objCode) Then
                If objCode.ToString() = 9 Then
                    strReturn = "File"
                Else
                    strReturn = "Message"
                End If

            End If
#Else
            If Not IsDBNull(objCode) Then
                If objCode.ToString() = 9 Then
                    strReturn = "����"
                Else
                    strReturn = "�����"
                End If

            End If

#End If

        Catch ex As Exception
        End Try

        Return strReturn
    End Function

    Private Sub grdList_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles grdList.PageIndexChanged
        grdList.CurrentPageIndex = e.NewPageIndex
        BindGrid()
    End Sub

    Protected Function FormatDateTime(ByRef dtViewDate As Object) As String
        If IsDBNull(dtViewDate) Then
            Return ""
        Else
            Return Format(dtViewDate, "dd/MM/yyyy")
        End If
    End Function

    Public Sub ExportExcel(ByVal _DataGrid As System.Web.UI.WebControls.DataGrid)
        Dim file As String = ""
        file = ""
        Response.Clear()
        'Response.Buffer= true; 
        'Response.ContentType = "application/vnd.ms-excel"; 
        Response.AddHeader("content-disposition", "attachment;filename=Sapak-muslam.xls")
        Response.Charset = "UTF-8"
        'Response.Cache.SetCacheability(HttpCacheability.NoCache); 
        Dim i As Integer
        Response.ContentType = "application/vnd.xls"

        _DataGrid.EnableViewState = False

        Dim oStringWriter As New System.IO.StringWriter()
        Dim oHtmlTextWriter As New System.Web.UI.HtmlTextWriter(oStringWriter)
        ''''''''''''''''''Me.ClearControls(_DataGrid(i))
        _DataGrid.RenderControl(oHtmlTextWriter)

        file = file + oStringWriter.ToString()

        Response.Write(file)

        Response.[End]()
    End Sub

    Private Sub ClearControls(ByVal Ctrl As Control)
        Dim i As Integer

        For i = Ctrl.Controls.Count - 1 To 0 Step i - 1
            ClearControls(Ctrl.Controls(i))
        Next

        If Not TypeOf Ctrl Is TableCell Then
            If Not Ctrl.GetType().GetProperty("SelectedItem") Is Nothing Then
                Dim Lt As LiteralControl = New LiteralControl()
                Ctrl.Parent.Controls.Add(Lt)
                Try
                    Lt.Text = CType(Ctrl.GetType().GetProperty("SelectedItem").GetValue(Ctrl, Nothing), String)
                Catch

                End Try

                Ctrl.Parent.Controls.Remove(Ctrl)
            ElseIf Not Ctrl.GetType().GetProperty("Text") Is Nothing Then
                Dim Lt As LiteralControl = New LiteralControl()
                Ctrl.Parent.Controls.Add(Lt)
                Lt.Text = CType(Ctrl.GetType().GetProperty("Text").GetValue(Ctrl, Nothing), String)
                Ctrl.Parent.Controls.Remove(Ctrl)
            End If

        End If

    End Sub


    Private Sub cmdSend_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSend.ServerClick
        Dim startUpScript As String

        Try

            Dim objRep As New ReportConnect.ReportService()
            objRep.Url = Application("ReportWebService").ToString()
            Dim iStatus As Integer = 10 ' Updated
            Dim fRet As Boolean
            fRet = objRep.UpdateTechSupportReport("4E790640-F603-4614-A836-54989275300C", Val(HidRepIDSupportRequests.Value), _
                                           User.Identity.Name, iStatus, Me.txtRemark.Value, 0, 0)

            If fRet Then
                objRep.UpdateTechSupportUserReplay("DD0FAF53-6016-4F3E-9283-17635F1AB1E0", Val(HidRepIDSupportRequests.Value), 1)
            End If

        Catch ex As Exception

            startUpScript = "<script language=Javascript>alert('���� ������ �������');</script>"
            Page.RegisterStartupScript(Page.UniqueID & "Error", startUpScript)
            Return

        End Try

        startUpScript = "<script language=Javascript>alert('������� ������ ������');</script>"
        Page.RegisterStartupScript(Page.UniqueID & "Success", startUpScript)
    End Sub

    Protected Function setLongFileName(ByRef objFileName As Object, ByRef objLongFileName As Object) As String
        Dim strReturn As String = ""
        Try
            If Not IsDBNull(objLongFileName) Then

                strReturn = objLongFileName.ToString()

            Else

                strReturn = objFileName.ToString()

            End If

        Catch ex As Exception
        End Try

        Return strReturn
    End Function
End Class
