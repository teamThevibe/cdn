Imports System.Text

Public Class LogBeforeFileDownload
    Inherits System.Web.UI.Page

    Protected WithEvents userPwd As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents cmdOk As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents txtError As System.Web.UI.HtmlControls.HtmlInputHidden
    
#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub cmdOk_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdOk.ServerClick
        Dim strUserName As String = User.Identity.Name
        Dim strPassword As Byte()
        Dim FilePassword As Byte()
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        FilePassword = objUser.GetFilePassword("BC3C5D81-7DC0-40ff-9421-550C8ECB0B4B", strUserName)
        strPassword = Encoding.Unicode.GetBytes(userPwd.Value)
        ReDim Preserve strPassword(63)

        If Not FilePassword Is Nothing Then

            If CompareByteArrays(strPassword, FilePassword) Then

                ShowError("Ok")
            Else
#If EngDesign Then
                ShowError("����� ������ ����� �����")
#Else
                ShowError("����� ������ ����� �����")
#End If
                Return
            End If

        Else
#If EngDesign Then
            ShowError("����� ������ ����� �����")
#Else
                ShowError("����� ������ ����� �����")
#End If
            Return

        End If

    End Sub

    Private Sub ShowError(ByVal strMessage As String)
        txtError.Value = strMessage
    End Sub

    Private Function CompareByteArrays(ByVal data1 As Byte(), ByVal data2 As Byte()) As Boolean

        Dim i As Integer = 0

        If data1.Length <> data2.Length Then

            Return False

        End If

        While i < data1.Length - 1

            If data1(i) <> data2(i) Then
                Return False
            End If
            i = i + 1

        End While

        Return True

    End Function

End Class
