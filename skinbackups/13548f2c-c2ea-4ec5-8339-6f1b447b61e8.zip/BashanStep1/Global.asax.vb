Imports System.Web
Imports System.Web.SessionState
Imports System.Text.RegularExpressions
Imports System.Xml
Imports System.IO

Public Class [Global]
    Inherits System.Web.HttpApplication
    Private Const DefaultValue As Integer = 2
#Region " Component Designer Generated Code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
    End Sub

#End Region


    Sub SetHDNavigation()

        Dim ConfigFileName As String = Path.Combine(Context.Request.PhysicalApplicationPath, "HDnavigation.xml")
        If Not File.Exists(ConfigFileName) Then
            Return
        End If
        'If "1".Equals(Application("InsuredStatusAsMainScreen")) Then
        '    Return
        'End If

        Dim sr As New StreamReader(ConfigFileName)
        Dim Document As XmlDocument = New XmlDocument()
        Document.LoadXml(sr.ReadToEnd())

        Application("HDnavigation") = Document
        'Application("FORMStart") = Utils.Navigation.GetURL("frmMenu.aspx")
        Application("FORMStart") = Utils.Navigation.GetURL("frmHDstart.aspx")

    End Sub

    Sub Application_Start(ByVal sender As Object, ByVal e As EventArgs)


        ' '' ''Ak 061114 lARGE FILES '' '' '' ''Application("MaxFileUploadInBytes") = ConfigurationSettings.AppSettings("MaxFileUploadInBytes")
        ' '' '' '' '' '' ''If (IsNothing(Application("MaxFileUploadInBytes"))) Then
        ' '' '' '' '' '' ''    Application("MaxFileUploadInBytes") = "5242880"
        ' '' '' '' '' '' ''End If


        If ConfigurationSettings.AppSettings("SecurityCheck") Is Nothing Then
            Application("SecurityCheck") = "0"
        Else
            Application("SecurityCheck") = ConfigurationSettings.AppSettings("SecurityCheck")
        End If

        Dim strVersion As String = ConfigurationSettings.AppSettings("ApplicationVersion")

        Application("AutoConnect") = "" & ConfigurationSettings.AppSettings("AutoConnect")
        Application("Timeinterval") = "" & ConfigurationSettings.AppSettings("AutoConnectTimeOut")

        Dim strUploadLargeFiles As String = ConfigurationSettings.AppSettings("UploadLargeFiles")
        If (Not IsNothing(strUploadLargeFiles)) AndAlso (strUploadLargeFiles <> "") Then
            Application("UploadLargeFiles") = ConfigurationSettings.AppSettings("UploadLargeFiles").ToString
        Else
            Application("UploadLargeFiles") = "0"
        End If

        If "11075".Equals(ConfigurationSettings.AppSettings("Entropy")) Then
            Application("Entropy") = "11075"
        Else
            Application("Entropy") = "28234"
        End If

        If "1".Equals(ConfigurationSettings.AppSettings("SettlingAccountsUpdate")) Then
            Application("SettlingAccountsUpdate") = "1" ' Settling Accounts Update allowed
        Else
            Application("SettlingAccountsUpdate") = "0"
        End If

        Application("App_Type") = ConfigurationSettings.AppSettings("ApplicationType")
        Application("App_Version") = " ......... (Version - " & strVersion & ") "

        Application("App_Code_Version") = strVersion

        Application("ClientSiteLink") = ConfigurationSettings.AppSettings("ClientSiteLink")
        Application("RightLogo") = ConfigurationSettings.AppSettings("RightLogo")
        Dim strTimeout As String = "" & ConfigurationSettings.AppSettings("ClaimTimeout")
        If Not IsNumeric(strTimeout) Then
            strTimeout = "10"
        End If

        If "1".Equals(ConfigurationSettings.AppSettings("ShowInterActiveReport")) Then
            Application("ShowInterActiveReport") = "1"
        Else
            Application("ShowInterActiveReport") = "0"
        End If

        Application("ViewerDirectory") = ConfigurationSettings.AppSettings("ViewerDirectory")

        Application("ClaimTimeout") = strTimeout

        strTimeout = "" & ConfigurationSettings.AppSettings("ClaimTimeoutIncrement")
        If Not IsNumeric(strTimeout) Then
            strTimeout = "0"
        End If

        Application("FWWebService") = ConfigurationSettings.AppSettings("FWWebServiceURL")

        Application("ClaimTimeoutIncrement") = strTimeout
        Application("BSHN_WorkerIDRequired") = ConfigurationSettings.AppSettings("WorkerIDRequired")
        Application("ShowCal") = ConfigurationSettings.AppSettings("ShowCal")
        Application("LoginUrlForRemindPassword") = ConfigurationSettings.AppSettings("LoginUrlForRemindPassword")
        Application("DoctorService") = ConfigurationSettings.AppSettings("DoctorService")
        Application("SearchByRepName") = "" & ConfigurationSettings.AppSettings("SearchByRepName")
        Application("PostEntryWebService") = ConfigurationSettings.AppSettings("PostEntryWebServiceURL")
        Application("ReportWebService") = ConfigurationSettings.AppSettings("ReportWebServiceURL")
        Application("SupplierWebService") = ConfigurationSettings.AppSettings("SupplierWebServiceURL")
        Application("TreatmentWebService") = ConfigurationSettings.AppSettings("TreatmentWebServiceURL")
        Application("TikshuvWebService") = ConfigurationSettings.AppSettings("TikshuvWebServiceURL")
        Application("YoetzWebService") = ConfigurationSettings.AppSettings("YoetzWebServiceURL")
        Application("TherapistsServiceURL") = ConfigurationSettings.AppSettings("TherapistsServiceURL")
        Application("QuestWebServiceURL") = ConfigurationSettings.AppSettings("QuestWebServiceURL")
        Application("UserWebService") = ConfigurationSettings.AppSettings("UserWebServiceURL")
        Application("ZakautConnectorService") = ConfigurationSettings.AppSettings("ZakautConnectorServiceURL")
        Application("ErrorReportConnectorService") = ConfigurationSettings.AppSettings("ErrorReportConnectorServiceURL")
        Application("KtrConnectorService") = ConfigurationSettings.AppSettings("KtrServiceURL")
        Application("HKLConnectorService") = ConfigurationSettings.AppSettings("HKLServiceURL")
        Application("CBConnectorService") = ConfigurationSettings.AppSettings("CBServiceURL")
        Application("UploadWebService") = ConfigurationSettings.AppSettings("UploadWebServiceURL")
        Application("ErrorBatchFile") = ConfigurationSettings.AppSettings("ErrorBatchFile")
        Application("ShenSystemURL") = ConfigurationSettings.AppSettings("ShenSystemURL")
        Application("ShenSystemPublicKeyFileName") = ConfigurationSettings.AppSettings("ShenSystemPublicKeyFileName")
        Application("SiteType") = ConfigurationSettings.AppSettings("SiteType")
        Application("AllowExtraID") = ConfigurationSettings.AppSettings("AllowExtraID")
        Application("ClaimMQ") = ConfigurationSettings.AppSettings("ClaimMQ")
        Application("ClaimMQAnswer") = ConfigurationSettings.AppSettings("ClaimMQAnswer")
        Application("PathForTikshuv") = ConfigurationSettings.AppSettings("PathForTikshuv")
        Application("CheckJpgHeader") = ConfigurationSettings.AppSettings("CheckJpgHeader")
        Application("TeethMode") = ConfigurationSettings.AppSettings("TeethMode")
        Application("CheckDoctorID") = ConfigurationSettings.AppSettings("CheckDoctorID")
        Application("HKLAdmiEMail") = ConfigurationSettings.AppSettings("HKLAdmiEMail")
        Application("CandidateLockTimeout") = ConfigurationSettings.AppSettings("CandidateLockTimeout")
        Application("UndercoverWebService") = ConfigurationSettings.AppSettings("UndercoverWebServiceURL")
        Application("DownloadMamager_URL") = ConfigurationSettings.AppSettings("DownloadMamager_URL")
        Application("SecurityService") = ConfigurationSettings.AppSettings("SecurityServiceURL")
        Application("DoctorsAbroadWebService") = ConfigurationSettings.AppSettings("DoctorsAbroadURL")
        Application("PasswordVerification") = ConfigurationSettings.AppSettings("PasswordVerification")
        Application("PasswordRegEx") = ConfigurationSettings.AppSettings("PasswordRegEx")
        Application("LetterWebServiceURL") = ConfigurationSettings.AppSettings("LetterWebServiceURL")
        Application("BOReportEncoding") = "" & ConfigurationSettings.AppSettings("BOReportEncoding")
        Application("FreeSearchDoctorsAbroadWebServiceURL") = ConfigurationSettings.AppSettings("FreeSearchDoctorsAbroadWebServiceURL")

        Dim sPoolService As String = ConfigurationSettings.AppSettings("PoolServiceURL")
        If (Not IsNothing(sPoolService)) AndAlso (sPoolService <> "") Then
            Application("PoolServiceURL") = sPoolService
        End If

        'Application("NotShowNotificationOnUserActive") = "0"
        'Dim sNotShowNotificationOnUserActive As String = ConfigurationSettings.AppSettings("NotShowNotificationOnUserActive")
        'If (Not IsNothing(sNotShowNotificationOnUserActive)) AndAlso (sNotShowNotificationOnUserActive <> "") Then
        '    Application("NotShowNotificationOnUserActive") = sNotShowNotificationOnUserActive
        'End If

        Application("IsShumera") = "0"
        Dim sIsShumera As String = ConfigurationSettings.AppSettings("IsShumera")
        If (Not IsNothing(sIsShumera)) AndAlso (sIsShumera <> "") Then
            Application("IsShumera") = sIsShumera
        End If

        Application("HideSendPassword") = "" & ConfigurationSettings.AppSettings("HideSendPassword")

        Dim sInfoUploadURL As String = ConfigurationSettings.AppSettings("InfoUploadURL")
        If (Not IsNothing(sInfoUploadURL)) AndAlso (sInfoUploadURL <> "") Then
            Application("InfoUploadURL") = sInfoUploadURL
        End If


        ' Max File Upload In Bytes Kllal
        Application("MaxFileUploadInBytes") = ConfigurationSettings.AppSettings("MaxFileUploadInBytes")
        If (IsNothing(Application("MaxFileUploadInBytes"))) Then
            Application("MaxFileUploadInBytes") = "6000000"
        End If

        Application("CompSystemPath") = ConfigurationSettings.AppSettings("CompSystemPath")
        If (IsNothing(Application("CompSystemPath"))) Then
            Application("CompSystemPath") = ""
        End If

        Application("AgreementsWebService") = ConfigurationSettings.AppSettings("AgreementsWebServiceURL")
        Application("MenuWebService") = ConfigurationSettings.AppSettings("MenuWebServiceURL")
        Application("AlonWebService") = ConfigurationSettings.AppSettings("AlonWebServiceUrl")
        Application("KarnitWebService") = ConfigurationSettings.AppSettings("KarnitWebServiceURL")
        Application("FWWebService") = "" & ConfigurationSettings.AppSettings("FWServiceURL")
        Application("BOWebService") = "" & ConfigurationSettings.AppSettings("BOWebServiceURL")
        Application("HaniWebService") = "" & ConfigurationSettings.AppSettings("HaniWebServiceURL")
        Application("LoginUrlForRemindPassword") = "" & ConfigurationSettings.AppSettings("LoginUrlForRemindPassword")
        Application("FreeSearchDoctorsAbroadWebService") = ConfigurationSettings.AppSettings("FreeSearchDoctorsAbroadWebServiceURL")
        'Application("ViewFilesExt") = "" & ConfigurationSettings.AppSettings("ViewFilesExt")

        Application("SecureCookies") = ConfigurationSettings.AppSettings("SecureCookies")
        If IsNothing(Application("SecureCookies")) Then
            Application("SecureCookies") = "0"
        End If

        Dim sCheckUserDetails As String = ConfigurationSettings.AppSettings("CheckUserDetails")
        If (Not IsNothing(sCheckUserDetails)) AndAlso (sCheckUserDetails <> "") Then
            Application("CheckUserDetails") = sCheckUserDetails
        End If


        Application("MushlamInvoiceFaxService") = "" & ConfigurationSettings.AppSettings("MushlamInvoiceFaxServiceURL")

        '=============================
        'ExternalSource
        '=============================
        Application("ExpirationTimeInMinutesForExternalSourch") = ConfigurationSettings.AppSettings("ExpirationTimeInMinutesForExternalSourch")
        If (IsNothing(Application("ExpirationTimeInMinutesForExternalSourch"))) Then
            Application("ExpirationTimeInMinutesForExternalSourch") = "5"
        End If
        Application("ExternalSource") = Val(ConfigurationSettings.AppSettings("ExternalSource") & "")

        Application("InsuredStatusAsMainScreen") = String.Empty & ConfigurationSettings.AppSettings("InsuredStatusAsMainScreen")

        '----------------------------------------
        '---       new screens flags          ---
        '----------------------------------------

        If "1".Equals(ConfigurationSettings.AppSettings("FORMLogin")) Then
            Application("FORMLogin") = "frmLogin.aspx"
        Else
            Application("FORMLogin") = "Login.aspx"
        End If
        If "1".Equals(ConfigurationSettings.AppSettings("FORMUserPass")) Then
            Application("FORMUserPass") = "frmUserDetails.aspx"
            'Application("FORMUserProp") = "frmUserDetails.aspx"
        Else

            If "1".Equals(Application("InsuredStatusAsMainScreen")) Then
                Application("FORMUserPass") = "frmHDUserPass.aspx"
            Else
                Application("FORMUserPass") = "frmUserPass.aspx"
            End If
            'Application("FORMUserProp") = "frmUserProp.aspx"
        End If

        If "1".Equals(ConfigurationSettings.AppSettings("FORMUserPass")) Then
            Application("FORMUserProp") = "frmUserDetails.aspx"
        ElseIf "1".Equals(ConfigurationSettings.AppSettings("FORMUserProp")) Then
            Application("FORMUserProp") = "frmSMUserProp.aspx"
        Else
            Application("FORMUserProp") = "frmUserProp.aspx"
        End If
        If Application("App_Type").ToString().ToUpper() = "SUPP" Then
            If "1".Equals(ConfigurationSettings.AppSettings("FORMUserProp")) Then
                Application("FORMUserProp") = "frmSMUserProp.aspx"
            Else
                Application("FORMUserProp") = "frmUserProp.aspx"
            End If
        End If

        If "1".Equals(ConfigurationSettings.AppSettings("FORMRepStat")) Then
            Application("FORMRepStat") = "frmReportStat.aspx"
        Else
            Application("FORMRepStat") = "frmRepStat.aspx"
        End If
        If "1".Equals(ConfigurationSettings.AppSettings("FORMRepList")) Then
            Application("FORMRepList") = "frmReportList.aspx"
        Else
            If "1".Equals(Application("InsuredStatusAsMainScreen")) Then
                Application("FORMRepList") = "frmHDRepList.aspx"
            Else
                Application("FORMRepList") = "frmRepList.aspx"
            End If
        End If
        If "1".Equals(ConfigurationSettings.AppSettings("FORMStart")) Then
            Application("FORMStart") = "frmMenu.aspx"
        Else
            If "2".Equals(ConfigurationSettings.AppSettings("FORMStart")) Then
                Application("FORMStart") = "frmSmMenu.aspx"
            Else
                Application("FORMStart") = "frmStart.aspx"
            End If
        End If
        If "1".Equals(Application("InsuredStatusAsMainScreen")) Then
            Application("FORMStart") = "frmHDstart.aspx"
        End If

        If "1".Equals(ConfigurationSettings.AppSettings("FORMClaimMenu")) Then
            Application("FORMClaimMenu") = "frmSMMenu.aspx"
        Else

            If Application("App_Type").ToString().ToUpper() = "DOAR" Then
                Application("FORMClaimMenu") = "MenuElyahu.aspx"
            Else
                Application("FORMClaimMenu") = "ClaimMenu.aspx"
            End If
        End If

        Application("FORMNewClaimWithAttachments") = "frmSMNewClaimAttach.aspx"
        'If "1".Equals(ConfigurationSettings.AppSettings("FORMNewClaimWithAttachments")) Then
        '    Application("FORMNewClaimWithAttachments") = "frmSMNewClaimAttach.aspx"
        'Else
        '    Application("FORMNewClaimWithAttachments") = "NewClaimWithAttachments.aspx"
        'End If
        If "1".Equals(ConfigurationSettings.AppSettings("SendFiles")) Then
            Application("SendFiles") = "frmSendFiles.aspx"
            'ElseIf "2".Equals(ConfigurationSettings.AppSettings("SendFiles")) Then
            '    Application("SendFiles") = "frmSendFiles2.aspx"
        ElseIf "3".Equals(ConfigurationSettings.AppSettings("SendFiles")) Then
            Application("SendFiles") = "frmSendFileElyahu.aspx"
        Else
            Application("SendFiles") = "frmAddNewReport.aspx"
        End If
        If "1".Equals(ConfigurationSettings.AppSettings("FORMAddNewReport")) Then
            Application("SendFiles") = "frmSendInfo.aspx"
        End If
        '//

        If "2".Equals(ConfigurationSettings.AppSettings("SendFiles")) Then
            Application("SendFiles") = "frmSendFiles2.aspx"
        End If
        If "4".Equals(ConfigurationSettings.AppSettings("SendFiles")) Then
            Application("SendFiles") = "frmSendFiles3.aspx"
        End If


        '//
        If "1".Equals(ConfigurationSettings.AppSettings("FORMfrmNewClaim")) Then
            Application("FORMfrmNewClaim") = "frmSMNewClaimRequest.aspx"
        Else
            Application("FORMfrmNewClaim") = "frmNewClaim.aspx"
        End If
        '// hani overwirte
        If "1".Equals(ConfigurationSettings.AppSettings("FORMfrmTechSupportAddReport")) Then
            Application("FORMfrmTechSupportAddReport") = "frmTechSupportSend.aspx"
        Else
            Application("FORMfrmTechSupportAddReport") = "frmTechSupportAddReport.aspx"
        End If
        '//
        If "1".Equals(ConfigurationSettings.AppSettings("FORMfrmTechSupportRequest")) Then
            Application("FORMfrmTechSupportRequest") = "frmTechSupportItem.aspx"
        Else
            Application("FORMfrmTechSupportRequest") = "frmTechSupportRequest.aspx"
        End If
        '//
        Application("FORMNewClaim") = "frmSMNewClaimReg.aspx"
        'If "1".Equals(ConfigurationSettings.AppSettings("FORMNewClaim")) Then
        '    Application("FORMNewClaim") = "frmSMNewClaimReg.aspx"
        'Else
        '    Application("FORMNewClaim") = "NewClaim.aspx"
        'End If

        If "1".Equals(ConfigurationSettings.AppSettings("FORMSupplierPaymentRequest")) Then
            Application("FORMSupplierPaymentRequest") = "frmSMSupplierPaymentRequest.aspx"
        Else
            Application("FORMSupplierPaymentRequest") = "frmSupplierPaymentRequest.aspx"
        End If

        Application("FORMNewClaimShela") = "frmSMNewClaimShela.aspx"
        'If "1".Equals(ConfigurationSettings.AppSettings("FORMNewClaimShela")) Then
        '    Application("FORMNewClaimShela") = "frmSMNewClaimShela.aspx"
        'Else
        '    Application("FORMNewClaimShela") = "NewClaimShela.aspx"
        'End If

        If "1".Equals(ConfigurationSettings.AppSettings("FORMSendInfoSL")) Then
            Application("FORMSendInfoSL") = "frmSendInfoSL.aspx"
        Else
            Application("FORMSendInfoSL") = "frmSendFile.aspx"
        End If

        If "1".Equals(ConfigurationSettings.AppSettings("WarnSessionTimeout")) Then
            Application("WarnSessionTimeout") = 1
            If (ConfigurationSettings.AppSettings("WarnSessionTimeoutMinutes") <> "") Then
                Application("WarnSessionTimeoutMinutes") = ConfigurationSettings.AppSettings("WarnSessionTimeoutMinutes")
            Else
                Application("WarnSessionTimeoutMinutes") = DefaultValue
            End If

        Else
            Application("WarnSessionTimeout") = 0
        End If

        If ("1".Equals(ConfigurationSettings.AppSettings("IsInternetSite"))) Then
            Application("IsInternetSite") = "1"
        Else
            Application("IsInternetSite") = "0"
        End If

        If "" & (ConfigurationSettings.AppSettings("LinkToDoctorStatus") <> "") Then

            Application("LinkToDoctorStatus") = ConfigurationSettings.AppSettings("LinkToDoctorStatus").ToString

        End If


        Dim strTemp As String = "" & ConfigurationSettings.AppSettings("SmileServiceURL")
        'If strTemp = "" Then
        'strTemp = My.Settings.Distribution_SmileConnector_SmileRequest
        'End If
        Application("SmileWebService") = strTemp
        Application("MTOMTransURL") = ConfigurationSettings.AppSettings("MTOMTransURL")
        Application("FWWebService") = "" & ConfigurationSettings.AppSettings("FWWebServiceURL")
        Dim strChartServiceURL As String = ""
        Try
            strChartServiceURL = ConfigurationSettings.AppSettings("InfobayChartServiceURL")
            If (Not IsNothing(strChartServiceURL)) AndAlso (strChartServiceURL <> "") Then
                If Not strChartServiceURL.EndsWith("/") Then
                    strChartServiceURL = strChartServiceURL & "/"
                End If


                '        Dim sUrl As String = DirectCast(Me.Context.Request, System.Web.HttpRequest).Url.AbsoluteUri
                '        Dim sPath As String = DirectCast(Me.Context.Request, System.Web.HttpRequest).Url.AbsolutePath
                '        Dim iPath = sUrl.IndexOf(sPath)
                '        Dim sBasePath As String = sUrl.Substring(0, iPath) + "/"


                '        'Dim sReq = Request.ServerVariables("SERVER_NAME") & Request.ServerVariables("URL")
                '        Application("TempChartService_URL") = sUrl
                '        Application("TempChartPath_URL") = sPath
                '        Application("InfobayChartService_URL") = +strChartServiceURL ' sBasePath & strChartServiceURL
            Else
                Application("InfobayChartService_URL") = ""
            End If
        Catch ex As Exception
            Application("InfobayChartService_URL") = ""
        End Try

        Dim strBufferSZ As String = "" & ConfigurationSettings.AppSettings("MTOMBufferSize")
        Dim iBufferSize As Integer = 0
        If IsNumeric(strBufferSZ) Then
            iBufferSize = Val(strBufferSZ)
        End If
        If iBufferSize = 0 Then
            iBufferSize = 64
        End If
        Application("MTOMBufferSize") = CStr(iBufferSize)

        Application("HKLLDP") = "" & ConfigurationSettings.AppSettings("HKLLDP")
        'YUG 19.11.08
        Application("PasswordUpdateTermination") = "" & ConfigurationSettings.AppSettings("PasswordUpdateTermination")
        Application("PasswordUpdateTermination") = Application("PasswordUpdateTermination").ToUpper()

        'YUG 18.05.09 - may be temporary
        Dim sChkAllUsers As String = "" + ConfigurationSettings.AppSettings("ShowChkAllUsers")
        If (sChkAllUsers.ToUpper() = "FALSE") Then
            Application("ChkAllUsers") = "False"
        Else
            Application("ChkAllUsers") = "True"
        End If


        'Dim sHasMainMenu As String = "" + ConfigurationSettings.AppSettings("HasMainMenu")
        'If (sHasMainMenu.ToUpper() = "TRUE") Then
        '    Application("HasMainMenu") = True
        'Else
        '    Application("HasMainMenu") = False
        'End If

        Dim objSys As New UserConnect.UserService()
        objSys.Url = Application("UserWebService").ToString()

        If objSys.IfConnect2OutlookEnabled("C8797B7C-0607-47FA-8161-20C72A590BF7") Then
            Application("IfConnect2Outlook") = "1"
        Else
            Application("IfConnect2Outlook") = ""
        End If

        If objSys.IfAllowMultiCheckZakaut("3585ED0B-0BB7-4231-B166-15B608B6C177") Then
            Application("IfAllowMultiCheckZakaut") = "1"
        Else
            Application("IfAllowMultiCheckZakaut") = ""
        End If

        ' Occasional user
        Application("OccasionalURL") = ConfigurationSettings.AppSettings("OccasionalURL")
        If (IsNothing(Application("OccasionalURL"))) Then
            Application("OccasionalURL") = String.Empty
        End If
        Application("MaxLinkNo") = ConfigurationSettings.AppSettings("MaxLinkNo")
        If (IsNothing(Application("MaxLinkNo"))) Then
            Application("MaxLinkNo") = "3"
        End If
        Application("MaxSMSNo") = Val(objSys.GetGeneralParameter("3FCAAB6E-4AAD-4231-A9F2-B9CCA67EE079", "OccasionalMaxSMSNumber")).ToString()
        Application("OccasionalReferenceToEMail") = Val(objSys.GetGeneralParameter("3FCAAB6E-4AAD-4231-A9F2-B9CCA67EE079", "OccasionalReferenceToEMail")).ToString()

        Application("SiteInfo") = objSys.GetSiteInfo("5037AD93-EC38-4002-8628-7C6E112A1514")
        Application("CompanyID") = ConfigurationSettings.AppSettings("CompanyID")
        Application("Paging") = "" & ConfigurationSettings.AppSettings("Paging")










        Application("LoginUrlForRemindPassword") = ConfigurationSettings.AppSettings("LoginUrlForRemindPassword")

        Application("Smile_Platinum_18_Supported") = "" & ConfigurationSettings.AppSettings("SmilePlatinum18Supported")
        Application("Check_Clalit_Insured") = "" & ConfigurationSettings.AppSettings("CheckClalitInsured")

        Dim bHasHKL As Boolean = objSys.IfHKLEnabled("08E5EFDA-609C-4777-82CF-60A87E08D1F8")
        If bHasHKL Then
            Application("HasHKL") = "1"
        Else
            Application("HasHKL") = ""
        End If

        Dim bHasCB As Boolean = objSys.IfCBEnabled("ADE5761B-8202-4B5F-B98F-8C53CE0FBC1E")
        If bHasCB Then
            Application("HasCB") = "1"
        Else
            Application("HasCB") = ""
        End If


        Dim bIsDorAlon As Boolean = objSys.IsDorAlonEnabled("B7924B79-2149-4D55-AC0F-9E0BC75AB89E")
        If bIsDorAlon Then
            Application("IsDorAlon") = "1"
        Else
            Application("IsDorAlon") = ""
        End If

        Dim bWithTechSupport As Boolean = objSys.IsTechSupportEnabled("B7924B79-2149-4D55-AC0F-9E0BC75AB89E")
        If bWithTechSupport Then
            Application("WithTechSupport") = "1"
        Else
            Application("WithTechSupport") = ""
        End If

        Dim bHasHani As Boolean = objSys.IfHaniEnabled("9AD92D26-41B3-4A4E-9EBA-2B8FDA071406")
        If bHasHani Then
            Application("HasHani") = "1"
            Application("FORMfrmTechSupportAddReport") = "frmAccTechSupportAddReport.aspx"
            Application("FORMfrmTechSupportRequest") = "frmTechSupportRequest.aspx"
        Else
            Application("HasHani") = ""
        End If

        If objSys.IfSend2BOEnabled("A702AFF6-4C74-403A-933F-FE85A2AD131B") Then
            Application("Send2BOEnabled") = "1"
        Else
            Application("Send2BOEnabled") = ""
        End If

        If objSys.IfDispatchGroupEnabled("5F5FB020-14ED-4908-8AF3-DAAB6BFC2C3D") Then
            Application("DispatchGroupEnabled") = "1"
        Else
            Application("DispatchGroupEnabled") = ""
        End If

        'Tikshuv
        If objSys.IfTikshuvEnabled("15A48041-07E7-4CE2-A6F1-76F828C07971") Then
            Application("TikshuvEnabled") = "1"
        Else
            Application("TikshuvEnabled") = ""
        End If
        If Val(ConfigurationSettings.AppSettings("LogTikshuvFile") & "") > 0 Then
            Application("Tikshuv_LogSendFile") = True
        Else
            Application("Tikshuv_LogSendFile") = False
        End If


        If Val("" + ConfigurationSettings.AppSettings("LogExceptions")) > 0 Then
            Application("LogExceptions") = "1"
        Else
            Application("LogExceptions") = "0"
        End If

        If objSys.IfYoetzEnabled("6E113F26-4240-4439-8E28-5F8E72F2A65B") Then
            Application("YoetzEnabled") = "1"
        Else
            Application("YoetzEnabled") = ""
        End If

        If objSys.IfUCCEnabled("52DCF69C-0732-445D-8CE6-325B9FD7EA33") Then
            Application("UCCEnabled") = "1"
        Else
            Application("UCCEnabled") = ""
        End If

        If objSys.IfAgreementsEnabled("947B4301-71C4-45B3-A454-80FF4B978ACF") Then
            Application("AgreementsEnabled") = "1"
        Else
            Application("AgreementsEnabled") = ""
        End If

        If objSys.IfClalbitEnabled("EE7BA6A2-4371-4598-BE06-D5AC0C3FCCF2") Then
            Application("IfClalbitEnabled") = "1"
        Else
            Application("IfClalbitEnabled") = ""
        End If

        If objSys.IfForeignWorkersEnabled("25416D84-E61D-46ED-BDD2-001CADEA03E5") Then
            Application("HasForigenWorkers") = "1"
        Else
            Application("HasForigenWorkers") = ""
        End If

        If objSys.IfReport2PDFConversionEnabled("F6968D37-D5E6-4700-A0E1-C01456332947") Then
            Application("Report2PDFConversion") = "1"
        Else
            Application("Report2PDFConversion") = ""
        End If

        If objSys.IfSmileEnabled("04D1B5F3-56D4-4BEB-A4B4-2D92F366C20F") Then
            Application("Smile") = "1"
        Else
            Application("Smile") = ""
        End If

#If NewDesign Then
        If objSys.IfPoolEnabled("42AE12D3-D4DF-445C-A158-0C7A29F8A8A0") Then
            Application("IsPool") = "1"
        Else
            Application("IsPool") = ""
        End If
        If objSys.AllowSend2OccasionalFromUserSite("CF7F8CAC-FFF4-4A59-AD2A-04769913C5C7") Then
            Application("AllowSend2OccasionalFromUserSite") = "1"
        Else
            Application("AllowSend2OccasionalFromUserSite") = ""
        End If

        If objSys.IfOccasionalReplyEnabled("1C553AEA-A3C5-4998-9AAF-31285D1C9CCB") Then
            Application("OccasionalReplyEnabled") = "1"
        Else
            Application("OccasionalReplyEnabled") = ""
        End If

        If objSys.IfAllowReportType4Group("63D7DFA4-FCC5-4E94-99AD-67E4FC82452B") Then
            Application("AllowReportType4Group") = "1"
        Else
            Application("AllowReportType4Group") = ""
        End If

        If objSys.IfAdvancedSenderEnabled("1A8C7F07-8339-44BE-8EB2-7EA5340A5F2D") Then
            Application("AllowAdvancedSender") = "1"
        Else
            Application("AllowAdvancedSender") = ""
        End If

        If objSys.IfReportType2BOIDEnabled("D9C793EF-6898-44E6-BF58-946EC97043A0") Then
            Application("AllowReportType2BOID") = "1"
        Else
            Application("AllowReportType2BOID") = ""
        End If

        If objSys.IfAllowSend2Group("E22A12CE-A6E1-42ED-B5D8-A4427AC795B3") Then
            Application("AllowSend2Group") = "1"
        Else
            Application("AllowSend2Group") = ""
        End If
#End If

        Application("MapSitePath") = ConfigurationSettings.AppSettings("MapSitePath")
        Application("MapServerURL") = "" & ConfigurationSettings.AppSettings("MapServerURL")
        'Application("SendMapXML") = "" & ConfigurationSettings.AppSettings("SendMapXML")

        Dim strRegExString As String
        Try
            strRegExString = objSys.GetRegExpr("603100D7-0A18-4A0B-8927-17D4D2C9054E")
        Catch ex As Exception
            strRegExString = ""
        End Try

        Application("RegExpr") = strRegExString
        If strRegExString = "" Then
            strRegExString = "^[\p{L}\p{Zs}\p{Lu}{0-9}\p{Ll}\'\!\@\+\:\$\,\.\*\?\;\\\(\)\/_*\[\]\-\=\|\%]{0,4096}$"
        End If
        Dim regexWhiteList As Regex = New Regex(strRegExString, RegexOptions.Compiled)
        Application("WhiteList") = regexWhiteList
        'Application("WhiteListForms") = ConfigurationSettings.AppSettings("WhiteListForms")

        Application("BOReportEncoding") = "" & ConfigurationSettings.AppSettings("BOReportEncoding")
        Application("LogFileName") = "" & ConfigurationSettings.AppSettings("LogFileName")

        Dim strTmp As String = "" & ConfigurationSettings.AppSettings("MTOMTransURL")
        If Trim(strTmp) = "" Then
            Application("MTOM_Enabled") = ""
        Else
            Application("MTOM_Enabled") = "1"
        End If

        FillWhiteListHashtable()

        strRegExString = "<(.*?)[ |>]"
        Application("RegularExpressionForEditor") = New Regex(strRegExString, RegexOptions.Compiled)

        strRegExString = "u,em,strong,bold,b,strike,sub,sup,p,ol,li,ul,p,br,blockquote,font,hr,img,table,tbody,tr,td,div"
        Application("AllowedTagListForEditor") = String.Format(",{0},", strRegExString).ToLower()

        strRegExString = "class,style"
        Application("NotAllowedAttributesForEditor") = strRegExString.ToLower()

        If Application("App_Type").ToString().ToUpper() <> "CLAIM" And Application("App_Type").ToString().ToUpper() <> "ENG" Then
            strTemp = Application("TreatmentWebService").ToString()
            If strTemp <> "" Then
                Dim objTreatmentService As New TreatmentConnect.TreatmentService()
                objTreatmentService.Url = strTemp
                Application("AttachTypesDS") = objTreatmentService.GetAttachTypes("34E108A0-761B-4AD9-B226-61227A144F2F", 0)
                Application("AttachTypesHS") = objTreatmentService.GetAttachTypes("34E108A0-761B-4AD9-B226-61227A144F2F", 1)
            End If
        End If

        Application("OccasionalUserName") = objSys.GetGeneralParameter("3FCAAB6E-4AAD-4231-A9F2-B9CCA67EE079", "OccasionalUserName")
        Application("ViewFilesExt") = LCase("" & objSys.GetPreviewFileExtensions("EEE015C6-783F-4A97-A824-128DF2F1ECQ1"))

        'Get WhitelistFileExtensions
        Dim strWhitelistFileExtensions As String = objSys.GetWhitelistFileExtensions("EEE015C6-783F-4A97-A824-128DF2F1ECA9") & ""
        Application("WhitelistFileExtensions") = strWhitelistFileExtensions
        Dim sRightFileExtensions = String.Empty
        If strWhitelistFileExtensions <> String.Empty Then
            Dim WhiteList() As String = strWhitelistFileExtensions.Split(";")
            sRightFileExtensions = GetRightExtensions(WhiteList)
        End If
        Application("RightFileExtensions") = sRightFileExtensions

        'Get WhitelistFileExtensions4Request
        Dim sWhitelistFileExtensions4Request As String = objSys.GetWhitelistFileExtensions4Request("F9BC212B-F866-4FCC-8A5B-0E30A88209AA") & ""
        'GetWhitelistFileExtensions4Request("F9BC212B-F866-4FCC-8A5B-0E30A88209AA") & ""
        Application("WhitelistFileExtensions4Request") = sWhitelistFileExtensions4Request
        Dim sRightFileExtensions4Request = String.Empty
        If sWhitelistFileExtensions4Request <> String.Empty Then
            Dim WhiteList() As String = sWhitelistFileExtensions4Request.Split(";")
            sRightFileExtensions4Request = GetRightExtensions(WhiteList)
        End If
        Application("RightFileExtensions4Request") = sRightFileExtensions4Request

        'Get WhitelistFileExtensions4Picture
        Dim sWhitelistFileExtensions4Picture As String = objSys.GetGeneralParameter("3FCAAB6E-4AAD-4231-A9F2-B9CCA67EE079", "WhitelistFileExtensions4Picture") & ""
        Application("WhitelistFileExtensions4Picture") = sWhitelistFileExtensions4Picture
        Dim sRightFileExtensions4Picture = String.Empty
        If sWhitelistFileExtensions4Picture <> String.Empty Then
            Dim WhiteList() As String = sWhitelistFileExtensions4Picture.Split(";")
            sRightFileExtensions4Picture = GetRightExtensions(WhiteList)
        End If
        Application("RightFileExtensions4Picture") = sRightFileExtensions4Picture
        Application("BOReportEncoding") = "" & ConfigurationSettings.AppSettings("BOReportEncoding")
        Application("DisableMultibrowserSupport") = "" & ConfigurationSettings.AppSettings("DisableMultibrowserSupport")

        'Leumit
        Application("LeumitShvaWebService") = ConfigurationSettings.AppSettings("LeumitShvaWebService") & String.Empty
        Application("LMShvaMasof") = ConfigurationSettings.AppSettings("LMShvaMasof") & String.Empty
        Application("LMShvaUserName") = ConfigurationSettings.AppSettings("LMShvaUserName") & String.Empty
        Application("LMShvaTimeStamp") = ConfigurationSettings.AppSettings("LMShvaTimeStamp") & String.Empty
        Application("LMShvaSendCardOwnerIDNumber") = ConfigurationSettings.AppSettings("LMShvaSendCardOwnerIDNumber") & String.Empty
        Application("LMCheckCardLog") = ConfigurationSettings.AppSettings("LMCheckCardLog") & String.Empty
        Application("SalMaxAge") = ConfigurationSettings.AppSettings("SalMaxAge") & ""

        Application("GovernmentTreatments") = "" & objSys.GetGeneralParameter("3FCAAB6E-4AAD-4231-A9F2-B9CCA67EE079", "GovernmentTreatments")
        Application("ShowOldTreatments") = ConfigurationSettings.AppSettings("ShowOldTreatments") & ""
        Application("MilkTeeth") = ConfigurationSettings.AppSettings("MilkTeeth") & ""

        'DoctorId Check for Mushlam
        If "1".Equals(ConfigurationSettings.AppSettings("CheckDoctor")) Then
            Application("CheckDoctor") = "1"
        End If


#If Not EngDesign Then
        Utils.FillBrowserObjects()
#End If

        Dim strVirusCheckInputDirectory As String = ConfigurationSettings.AppSettings("VirusCheckInputDirectory") & ""
        If (strVirusCheckInputDirectory.Length > 0) AndAlso _
           (strVirusCheckInputDirectory.LastIndexOf("\") < strVirusCheckInputDirectory.Length - 1) Then
            strVirusCheckInputDirectory += "\"
        End If

        Application("VirusCheckInputDirectory") = strVirusCheckInputDirectory

        Dim strVirusCheckOutputDirectory As String = ConfigurationSettings.AppSettings("VirusCheckOutputDirectory") & ""
        If (strVirusCheckOutputDirectory.Length > 0) AndAlso _
           (strVirusCheckOutputDirectory.LastIndexOf("\") < strVirusCheckOutputDirectory.Length - 1) Then
            strVirusCheckOutputDirectory += "\"
        End If

        Application("VirusCheckOutputDirectory") = strVirusCheckOutputDirectory


        If "1".Equals(ConfigurationSettings.AppSettings("AllowUrgentMessage")) Then
            Application("AllowUrgentMessage") = True
        Else
            Application("AllowUrgentMessage") = False
        End If

        SetHDNavigation()

        strTmp = "" & ConfigurationSettings.AppSettings("USE_HTTP_X_FORWARDED")
        '''NO FUCKING "1".Equals!!!
        If Trim(strTmp) = "1" Then
            Application("USE_HTTP_X_FORWARDED") = "1"
        Else
            Application("USE_HTTP_X_FORWARDED") = ""
        End If
        Application("ErrorApplicationName") = "" & ConfigurationSettings.AppSettings("ErrorApplicationName")
        Application("ErrorMessLength") = Val(objSys.GetGeneralParameter("3FCAAB6E-4AAD-4231-A9F2-B9CCA67EE079", "ErrorMessLength")).ToString()


        Dim objReportService As New ReportConnect.ReportService()
        objReportService.Url = Application("ReportWebService").ToString()
        Application("GreenStyle") = objReportService.GetGreenStyle()
        Application("MergingDate") = objReportService.GetMergingDate()
        Application("CompanyDescription") = objReportService.GetCompanyDescription()

    End Sub

    Sub Session_Start(ByVal sender As Object, ByVal e As EventArgs)


        Try

            If (Request.IsSecureConnection = True) Then
                Response.Cookies("ASP.NET_SessionId").Secure = True
            End If

        Catch ex As Exception

        End Try


        If Application("HttpsORHttp") Is Nothing Then

            Dim HttpsORHttp As String

            HttpsORHttp = HttpContext.Current.Request.ServerVariables("HTTPS")

            If HttpsORHttp = "off" Then
                Application("HttpsORHttp") = "http://"
            Else
                Application("HttpsORHttp") = "https://"
            End If

        End If



        ' Fires when the session is started
        Session("winname") = ""
        Session("HasMainMenu") = "0"
        Session("hidCountErr") = "0"
        Session("User_Prop_Caller") = ""
        Session("Report_List_ReportType") = ""
        Session("Report_List_Current_User") = ""
        Session("Filter_From_Date") = ""
        Session("Filter_To_Date") = ""
        Session("Filter_Report_Type") = ""
        Session("Filter_Report_ID") = ""
        Session("Filter_On") = ""
        Session("Filter_Viewed") = ""
        Session("Filter_NotViewed") = ""
        Session("Filter_InsuredID") = ""
        Session("Filter_InsuredName") = ""
        Session("RepStat_PageNum") = ""
        Session("Show_Message") = ""
        Session("Message_Text") = ""
        Session("Last_Login_Date") = ""
        Session("Last_Login_Time") = ""
        Session("User_Login_First_Time") = ""
        Session("AS400_User") = ""
        Session("User_Password") = ""
        Session("BSHN_Independed") = ""
        Session("BSHN_AllowClaims") = ""
        Session("UploadFileSize") = "0"
        Session("GeneralUploadFileSize") = "0"
        Session("SUPP_Check") = ""
        Session("SUPP_AllowClaims") = ""
        Session("SUPP_AdvisorClaim") = ""
        Session("SUPP_ID") = ""
        Session("SUPP_FN") = ""
        Session("SUPP_LN") = ""
        Session("SUPP_CRNT_USER") = ""
        Session("SUPP_SUB_USER") = ""
        Session("Request_Report_From_Date") = "00000000"
        Session("Request_Report_To_Date") = "00000000"
        Session("Request_Report_Viewed") = ""
        Session("Request_Report_NotViewed") = ""
        Session("Request_Report_InsuredID") = ""
        Session("Request_Report_Name") = ""
        Session("Request_Report_ClinicID") = ""
        Session("Request_Report_UserID") = 0
        Session("Request_Report_SubUserID") = 0
        Session("Request_Report_DoctorID") = ""
        Session("Claim_Type") = "0"
        Session("ReferenceID") = ""
        Session("CrntUser") = ""
        Session("CrntCandidate") = ""
        Session("SavedSearchForReConfirmation") = Nothing
        Session("SavedUsersListhForReConfirmation") = ""
        Session("ReConfirmationSeriesDS") = Nothing
        Session("CorrelationID") = ""
        Session("CorrelationID1") = ""
        Session("CorrelationID2") = ""
        Session("CorrelationID3") = ""
        Session("CorrelationID4") = ""
        Session("CorrelationID5") = ""
        Session("CorrelationID6") = ""
        Session("CorrelationID7") = ""
        Session("CorrelationID8") = ""
        Session("CorrelationID9") = ""
        Session("CorrelationID10") = ""
        Session("WebInterfaceAllow") = ""
        Session("MRequest_InsuredID") = ""
        Session("MRequest_DoctorCare") = ""
        Session("MRequest_InsuredName") = ""
        Session("MRequest_InsuredFamily") = ""
        Session("MRequest_LName") = ""
        Session("MRequest_FName") = ""
        Session("MRequest_Source") = ""
        Session("MRequest_RequestType") = ""
        Session("MRequest_PolGovTreatment") = ""
        Session("TRequest_PolGovTreatment") = ""
        Session("Step") = 0
        Session("KTR_PolicyNum") = ""
        Session("KTR_DoctorID") = ""
        Session("KTR_DoctorName") = ""
        Session("Allow_Action_Type_Upload") = ""
        Session("CB_UpdateRequest") = "0"
        Session("CB_Crnt_RequestID") = ""
        Session("CB_LastRequestActionType") = "0"
        Session("CB_LastUserID") = "0"
        Session("CandidateID") = "0"
        Session("DoctorSourceId") = "1"
        Session("ReqUnConfBackCode") = ""
        Session("DoctorFormId") = "1"

        Session("Smile_RequestID") = ""
        Session("SmileLast_InsuredID") = ""
        Session("SmileLast_InsuredName") = ""
        Session("SmileLast_InsuredFamily") = ""
        Session("Smile_OnlyServiceBasketNet") = ""
        Session("Smile_Porshei_Personel") = ""
        Session("Smile_Platinum_18") = ""
        Session("Smile_InsuredBirthDate") = ""
        Session("Smile_Policy") = ""
        Session("Smile_ShilaWorker") = ""

        Session("HOD_MultiCheck_Reference") = ""

        Session("Yoetz_Search_Name") = ""
        Session("Yoetz_Search_License") = ""
        Session("Yoetz_Search_TZ") = ""
        Session("Yoetz_Search_SpecialtyID") = ""
        Session("Yoetz_Search_RegionID") = ""
        Session("Yoetz_Search_SubSpecialtyID") = ""
        Session("Yoetz_Search_HospitalID") = ""
        Session("Yoetz_Search_Status") = ""
        Session("Yoetz_SubSpeciality_Updated") = ""
        Session("Yoetz_SubSpeciality_CandidateID") = ""

        Session("DDoc_Search_PageIndex") = ""
        Session("DDoc_Search_Name") = ""
        Session("DDoc_Search_Specialty") = ""
        Session("DDoc_Search_Procedure") = ""
        Session("DDoc_Search_Organ") = ""
        Session("DDoc_Search_Diagnosis") = ""
        Session("DDoc_Search_DiagnosisIDs") = ""
        Session("DDoc_Search_SpecIDs") = ""
        Session("DDoc_Search_ProcIDs") = ""
        Session("DDoc_Search_OrganIDs") = ""
        Session("DDoc_Search_Countries") = ""
        Session("DDoc_Search_States") = ""
        Session("DDoc_Search_Sort") = ""
        Session("DDoc_Search_CountryDirection") = "0"
        Session("DDocSearchType") = ""
        Session("DDoc_FreeSearch_text") = ""
        Session("DDoc_FreeSearch_Location") = ""

        ' for frmReConfirmationList - when step = 5 and InvoicePermission = 1 
        Session("TMP_CLAIM_ID") = 0
        Session("TMP_INSHURED_ID") = "0"
        Session("TMP_InsuredLastName") = ""
        Session("TMP_InsuredFirstName") = ""
        Session("InvoicePermission") = 0
        Session("BackUrl") = ""
        Session("Supplier_Name") = ""

        Session("Allow_Yoetz") = ""
        Session("Allow_Tikshuv") = ""
        Session("Allow_Agreements") = ""
        Session("Allow_Attach_Archive") = ""
        Session("Allow_DoctorAbroad") = "0"
        Session("Allow_GroupManage") = "0"
        Session("COMMUNTY_GROUP_ID") = "0"
        Session("CompanyLogo") = ""

        'AddReport
        Session("AddReport_AddresseeSelected") = ""
        Session("AddReport_SystemID") = ""
        Session("AddReport_UserLetterGroupID") = "0"
        Session("AddReport_FromPageName") = ""

        'TechSupport
        Session("TechSupport_RepID") = "0"
        Session("TechSupport_SubUserID") = ""

        'frmRepStat
        Session("RepStat_FromPageName") = ""

        'Doctor Abroad
        Session("MedCenterId") = ""
        Session("MedDiklaId") = ""

        'for frmUCCSubSuppliersMarking.aspx
        Session("UCC_SubSupplierID") = ""
        Session("UCC_SortField") = ""
        Session("UCC_PageIndex") = ""
        Session("Filter_UCC_MarkClientID") = ""
        Session("Filter_UCC_Suppliers") = ""
        Session("Filter_UCC_SuppliersDesc") = ""
        Session("UCC_Mark_FromForm") = ""
        Session("DefaultValues") = Nothing
        Session("Allow_UCC") = ""
        Session("Filter_UCC_CheckStatus") = ""
        Session("Filter_UCC_ReportDateFrom") = ""
        Session("Filter_UCC_ReportDateTo") = ""
        Session("Filter_UCC_MarkDateFrom") = ""
        Session("Filter_UCC_MarkDateTo") = ""
        Session("Filter_UCC_SelSubSuppliers") = ""
        Session("Filter_UCC_SubSupplierID") = ""
        Session("Filter_UCC_SubSupplierName") = ""
        Session("Filter_UCC_CityID") = ""
        Session("Filter_UCC_CityName") = ""

        Session("TRequest_InsuredID") = ""
        Session("TRequest_InsuredName") = ""
        Session("TRequest_InsuredFamily") = ""
        Session("TRequest_InsuredName") = ""
        Session("TRequest_LName") = ""
        Session("TRequest_FName") = ""

        Session("SendFile_ReportType") = ""

        Session("ExpirationLevel") = "0"
        Session("Expiration_NextPage") = ""
        Session("ExpirationRestDays") = "999999999"
        Session("ExpirationRestTimes") = ""

        'Questionnaire
        Session("QR_Tables") = Nothing
        Session("QR_IsTemplate") = ""
        Session("QR_FormID") = ""
        Session("QR_VersionID") = ""
        Session("QR_QuestionID") = ""
        Session("QR_QuestionMode") = ""
        Session("QR_QuestionIsPermanent") = ""
        Session("QR_OldVersionNo") = ""
        Session("QR_NewFormName") = ""

        'Providers
        Session("ProviderID") = ""
        'Session("PlaceID") = ""
        Session("ProviderDoctorID") = ""
        Session("ProviderActivDiv") = ""
        Session("SupplierSearch") = Nothing
        Session("MainFrameEntrance") = "0"
        Session("DetailsUrl") = ""
        'for Dynamiv menus
        Session("SavedDDLAction") = ""

        'Agreements
        Session("AgreementsUpdate") = "0"
        Session("AgExpDocParameters") = Nothing
        Session("AgExpAgreementParameters") = Nothing
        Session("NewMainProvider") = ""
        Session("Ag_PlaceID") = ""
        Session("Ag_NewPlaceInserted") = ""
        Session("Ag_CurrentDoctor") = ""
        Session("Ag_UpdatePriceList") = ""
        Session("Ag_UpdatePriceListForPlace") = ""
        Session("AgPlaceParam") = Nothing
        Session("AgDoctorParam") = Nothing
        Session("AgSectionParam") = Nothing
        Session("AgAppendixParam") = Nothing


        'Dynamic Reports
        Session("DynR_SystemID") = ""
        Session("DynR_ReportID") = ""
        Session("DynR_StructureMode") = ""

        'Service Map
        Session("SRVM_Region") = ""
        Session("SRVM_Service") = ""
        Session("SRVM_Kind") = ""

        Session("SRVM_IsSearch") = ""
        Session("SRVM_SelectedAreas") = ""
        Session("SRVM_SelectedRegionIds") = ""
        Session("SRVM_SelectedCitiesIds") = ""
        Session("SRVM_CategoryCode") = ""
        Session("SRVM_SelectGroupIds") = ""
        Session("SRVM_SelectedTreatmentIds") = ""
        Session("SRVM_SelectedDoctors") = ""

        Session("SRVM_PlaceNames") = ""
        Session("SRVM_CategoryNames") = ""
        Session("SRVM_SpecNames") = ""
        Session("SRVM_DoctorNames") = ""

        Session("SRVM_CategoryIds") = ""
        Session("SRVM_PlacesIds") = ""
        Session("SRVM_SpecIds") = ""
        Session("SRVM_ConsultationId") = ""
        Session("SRVM_RowList") = ""
        Session("SRVM_CurrentPage") = ""
        Session("SRVM_SearchFields") = ""


        'Leumit
        Session("Leumit_InsuredID") = ""
        Session("Leumit_InsuredFamily") = ""
        Session("Leumit_InsuredName") = ""
        Session("Leumit_Insured_Age") = ""
        Session("Leumit_ClinicID") = ""
        Session("Leumit_DeclarationOK") = ""
        Session("Leumit_CrntInsuredID") = ""
        Session("Leumit_OnlyServiceBasket") = ""
        Session("Leumit_Infant") = ""
        Session("Leumit_CollectionProblem") = ""
        Session("Leumit_PayerID") = ""
        Session("Leumit_PayerFName") = ""
        Session("Leumit_PayerLName") = ""
        Session("Leumit_AlternativePayerID") = ""
        Session("Leumit_AlternativePayerFName") = ""
        Session("Leumit_AlternativePayerLName") = ""
        Session("Leumit_AlternativeCreditCompany") = ""
        Session("Leumit_AlternativeCardID") = ""
        Session("Leumit_PaymentsNumber") = ""

        'Clalit Bakara
        Session("CB_SubmitRequests") = ""
        Session("CB_UploadFile") = ""

        'Dor Alon
        Session("Alon_RepKind") = ""
        Session("Alon_SelCustomers") = ""
        Session("Alon_DateFrom") = ""
        Session("Alon_TimeFrom") = ""
        Session("Alon_DateTo") = ""
        Session("Alon_TimeTo") = ""
        Session("Alon_SelectedCars") = ""
        Session("Alon_SelectedStations") = ""
        Session("Alon_SelectedDepartments") = ""

        Session("Alon_CustomersNames") = ""
        Session("Alon_CarsNames") = ""
        Session("Alon_StationsNames") = ""
        Session("Alon_DepartmentsNames") = ""

        Session("ExternalLink") = ""
        Session("UserRegLevel") = "0"

        'Session("OrgName") = ""
        'Session("UniqName") = "" ' YT: this string cancel Uniq Name for Silverlight upload process...

        Session("SupplierID_Series") = ""

        Dim strChartServiceURL As String = ""
        Dim sUrl As String = Request.Url.AbsoluteUri()
        Dim sPath As String = Request.Url.AbsolutePath
        Dim iPath = sUrl.IndexOf(sPath)
        Dim sBasePath As String = sUrl.Substring(0, iPath) + "/"

        Try
            strChartServiceURL = ConfigurationSettings.AppSettings("InfobayChartServiceURL")
            If (Not IsNothing(strChartServiceURL)) AndAlso (strChartServiceURL <> "") Then
                If Not strChartServiceURL.EndsWith("/") Then
                    strChartServiceURL = strChartServiceURL & "/"
                End If
                Session("InfobayChartService_URL") = sBasePath & strChartServiceURL
                'Session("ChartServiceURL") = strChartServiceURL
            Else
                Session("InfobayChartService_URL") = ""
            End If
        Catch ex As Exception
            Session("InfobayChartService_URL") = ""
        End Try

        Try
            strChartServiceURL = ConfigurationSettings.AppSettings("ChartServiceURL")
            If (Not IsNothing(strChartServiceURL)) AndAlso (strChartServiceURL <> "") Then
                If Not strChartServiceURL.EndsWith("/") Then
                    strChartServiceURL = strChartServiceURL & "/"
                End If
                Session("ChartServiceURL") = sBasePath & strChartServiceURL
            Else
                Session("ChartServiceURL") = ""
            End If
        Catch ex As Exception
            Session("ChartServiceURL") = ""
        End Try

        If "1".Equals(ConfigurationSettings.AppSettings("IsUploadingLargeFilesInSM")) Then
            Application("IsUploadingLargeFilesInSM") = "1"
        Else
            Application("IsUploadingLargeFilesInSM") = "0"
        End If

        'Karnit
        Session("Karnit_OrganizationCode") = ""
        Session("Karnit_AgreementCode") = ""
        Session("Karnit_CarNumber") = ""
        Session("Karnit_AccidentDate") = ""
        Session("Karnit_Dataset") = Nothing
        Session("Karnit_DataMsg") = ""

        Session("Login_User") = ""

        'UploadFileSize from tblGeneral
        Dim objSys As New UserConnect.UserService()
        objSys.Url = Application("UserWebService").ToString()
        If Application("App_Type").ToString().ToUpper() = "SUPP" Then
            Dim iGeneralUploadFileSize As Integer = objSys.GetGeneralUploadFileSize("DZ76C311-D7D8-425E-BD0B-AE04E9C567AD")
            Session("GeneralUploadFileSize") = iGeneralUploadFileSize.ToString
        End If

        'Doctors in Israel
        Session("UpperTitle") = "������ ����"

        'InvoiceMsg
        Session("InvoiceMsgToSuppliers") = ""
        Session("Reply_Caller") = ""
        Session("Reply_ReportID") = ""
        Session("From_Consultation") = ""
        Session("Back_Consultation") = ""

    End Sub

    Sub Application_BeginRequest(ByVal sender As Object, ByVal e As EventArgs)

        ' Fires at the beginning of each request

        'Dim aCookie As New HttpCookie("version")
        'aCookie.Value = DateTime.Now.ToString
        'aCookie.Expires = DateTime.Now.AddDays(200)
        'Response.Cookies.Add(aCookie)

        ''Response.Cookies("ver").Value = Application("App_Code_Version").ToString
        ''Response.Cookies("ver").Expires = DateTime.Now.AddDays(360)

        'If Request.Cookies("ver") Is Nothing Then

        '    Response.Cache.SetExpires(DateTime.Now)
        '    Response.CacheControl = "no-cache"
        '    Response.AddHeader("Pragma", "no-cache")
        '    Response.Expires = -1

        '    Response.Cookies("ver").Value = Application("App_Code_Version").ToString
        '    Response.Cookies("ver").Expires = DateTime.Now.AddDays(360)

        'Else

        '    If (Response.Cookies("ver").Value <> Application("App_Code_Version").ToString) Then


        '        Response.Cache.SetExpires(DateTime.Now)
        '        Response.CacheControl = "no-cache"
        '        Response.AddHeader("Pragma", "no-cache")
        '        Response.Expires = -1

        '        Response.Cookies("ver").Value = Application("App_Code_Version").ToString

        '        '  HttpResponse.RemoveOutputCacheItem("/pages/default.aspx")\

        '    End If

        'End If




    End Sub

    Sub Application_AuthenticateRequest(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires upon attempting to authenticate the use
    End Sub

      Private Function GetErrorPageURL() As String
        Dim sUrl as String = LCase(context.Request.Url.AbsoluteUri)
		Dim sAppPath as String = LCase(Context.Request.ApplicationPath)
		Dim iIndex as Integer = sUrl.IndexOf(sAppPath)+sAppPath.Length 
		sUrl = sUrl.Substring(0, iIndex)
		Return sUrl+"/frmError.aspx"
    End Function

    Sub Application_Error(ByVal sender As Object, ByVal e As EventArgs)

        Const cSoShortMessage = "Server was unable to process request."
        Const cUnaleToCastMessage = "Unable to cast object of type "

        Dim exCheck As Exception = Server.GetLastError()
        If (exCheck.Message.IndexOf("UploadFile.ashx") > 0) Then
            Return
        End If

        '' ''Ak 061114 lARGE FILES '' '' ''Dim exCheck1 As Exception = Server.GetLastError()
        '' '' '' '' ''If (exCheck1.Message.IndexOf("MaxFileUploadInBytesAchieved") > -1) Then

        '' '' '' '' ''    Server.ClearError()
        '' '' '' '' ''    'Dim sForm As String = "frmRequestt.aspx"
        '' '' '' '' ''    'Response.Redirect(sForm)

        '' '' '' '' ''    Dim sForm As String = "frmIframeError.aspx"
        '' '' '' '' ''    'Dim sControlName As String = s(3)
        '' '' '' '' ''    'If (sControlName <> "") Then
        '' '' '' '' ''    'Dim encrypt As CEncryption.cEnryption = New CEncryption.cEnryption()
        '' '' '' '' ''    'If (s(3) <> "") Then
        '' '' '' '' ''    '    sForm = sForm + "?Control=" & Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(cryptComtec.RijndaelSimple.EncryptSimple(Left(s(3), iErrorMessageMaxLength))))
        '' '' '' '' ''    'ElseIf (s.Length >= 6) Then
        '' '' '' '' ''    '    sForm = sForm + "?ControlValue=" & Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(cryptComtec.RijndaelSimple.EncryptSimple(Left(s(5), iErrorMessageMaxLength))))
        '' '' '' '' ''    'End If
        '' '' '' '' ''    'Session("ErrClassName") = s(3)
        '' '' '' '' ''    Response.Redirect(sForm)


        '' '' '' '' ''    Return
        '' '' '' '' ''End If

        ' Error may occur in \Handlers and this is not good ...
        Dim ErrorPageURL As String = GetErrorPageURL()

        Dim iErrorMessageMaxLength As Integer = Application("ErrorMessLength")
        If (iErrorMessageMaxLength = 0) Then
            iErrorMessageMaxLength = 256
        End If

        '// ToDo: exCheck.GetType.Name may be Nothing
        If (exCheck.GetType.Name = "HttpRequestValidationException") Then
            'Response.Redirect("ErrorReqValidate.htm")
            Response.Redirect(ErrorPageURL)
        ElseIf (exCheck.GetType.Name = "RequestLengthException") Then
            Server.ClearError()
            Dim encrypt As CEncryption.cEnryption = New CEncryption.cEnryption()
            Dim sMsg = exCheck.Message
            sMsg = Server.UrlEncode(encrypt.EncryptStrTripleDESC(Left(exCheck.Message, iErrorMessageMaxLength)))
            Response.Redirect("frmRequestError.aspx?sMsg=" & sMsg, True)

        ElseIf (exCheck.GetType.Name = "InvalidContainerException") Then
            Dim s() As String
            Dim sMsg As String = exCheck.Message
            s = sMsg.Split("|")
            If s.Length >= 3 Then
                Dim sForm As String = "frmIframeError.aspx"
                'Dim sControlName As String = s(3)
                'If (sControlName <> "") Then
                'Dim encrypt As CEncryption.cEnryption = New CEncryption.cEnryption()
                If (s(3) <> "") Then
                    sForm = sForm + "?Control=" & Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(cryptComtec.RijndaelSimple.EncryptSimple(Left("'" + s(3) + "'", iErrorMessageMaxLength))))
                ElseIf (s.Length >= 6) Then
                    sForm = sForm + "?ControlValue=" & Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(cryptComtec.RijndaelSimple.EncryptSimple(Left(s(5), iErrorMessageMaxLength))))

                    'Dim G As String = Guid.NewGuid().ToString()
                    'Dim sG = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(G))
                    'Application(G) = Left(s(5), iErrorMessageMaxLength)

                    'sForm = sForm + "?ControlValue=" & Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(cryptComtec.RijndaelSimple.EncryptSimple(Left(s(1) + "/" + s(2) + "|" + sG, iErrorMessageMaxLength))))
                End If
                'Session("ErrClassName") = s(3)
                Response.Redirect(sForm)
            End If
        ElseIf (exCheck.GetType.Name = "InvalidFileContainerException") Then
            Dim sForm As String = "frmIframeError.aspx?FileNameError=1"
            Dim s() As String
            Dim sMsg As String = exCheck.Message
            s = sMsg.Split("|")
            If ((s.Length >= 6) AndAlso (s(5) <> "")) Then
                sForm += "&NameValue=" & Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(cryptComtec.RijndaelSimple.EncryptSimple(Left(s(5), iErrorMessageMaxLength))))
            End If
            Response.Redirect(sForm)
        ElseIf (LCase(exCheck.Source) = "securewhitelist") Then ' OrElse (LCase(exCheck.Source) = "securewhitelist2") Then
            Dim sMsg As String = exCheck.Message
            Server.ClearError()
            Dim encrypt As CEncryption.cEnryption = New CEncryption.cEnryption()
            Dim queryString As String = GetQueryString()
            Try
                Dim sArgs As String = ErrorPageURL
                Dim s() As String
                s = sMsg.Split("|")
                If s.Length < 4 Then
                    sArgs += "?sMsg=" + Server.UrlEncode(encrypt.EncryptStrTripleDESC("GoBack")) & "&QS=" & Server.UrlEncode(encrypt.EncryptStrTripleDESC(queryString))
                Else
                    sArgs += "?sMsg=" + Server.UrlEncode(encrypt.EncryptStrTripleDESC(s(1) & "|" & s(3) & "|GoBack" & "|" & s(2))) & "&QS=" & Server.UrlEncode(encrypt.EncryptStrTripleDESC(queryString))
                    If ((s.Length >= 6) AndAlso (s(5) <> "")) Then
                        Dim G As String = Guid.NewGuid().ToString()
                        sArgs += "&sMsgvalue=" + Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(G))
                        Application(G) = Left(s(5), iErrorMessageMaxLength)
                    End If
                End If
                Response.Redirect(sArgs)
            Catch ex As Exception
                ' Exception may be in UrlEncode/EncryptStrTripleDESC - as Redirect only 
                Response.Redirect(ErrorPageURL & "?sMsg=ERROR!!!") ' & Server.UrlEncode(encrypt.EncryptStrTripleDESC("GoBack")) & "&QS=" & Server.UrlEncode(encrypt.EncryptStrTripleDESC(queryString)))
            End Try
        Else
            If ((Not IsNothing(exCheck.InnerException)) AndAlso (exCheck.InnerException.Source = "NoScreen_Exception")) Then
                Dim sForm As String = "frmIframeError.aspx?FileNameError=1"
                sForm += "&NameValue=" & Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(cryptComtec.RijndaelSimple.EncryptSimple("����� �� ����")))
                Response.Redirect(sForm)
            End If

            '  Dim strStack As String = "" + Server.GetLastError.InnerException.StackTrace
            Dim sErrMessage As String = ""
            Dim strSubject As String
            Dim strMessage As String
            Dim sStackTrace As String

            If (IsNothing(Server.GetLastError.InnerException)) Then
                If (TypeOf exCheck Is SystemException) Then
                    sStackTrace = DirectCast(Server.GetLastError, SystemException).StackTrace
                Else
                    sStackTrace = Server.GetLastError.StackTrace
                End If
                sErrMessage = exCheck.Message
            Else
                If (TypeOf exCheck.InnerException Is SystemException) Then
                    sStackTrace = DirectCast(Server.GetLastError.InnerException, SystemException).StackTrace
                Else
                    sStackTrace = exCheck.InnerException.StackTrace
                End If
                sErrMessage = exCheck.InnerException.Message
            End If

            sErrMessage = RemoveSpecialCharacters(sErrMessage).Replace(">", "").Replace("<", "")
            Dim nPoint As Integer = 0
            Dim nStartPoint As Integer = 0
            If (sErrMessage.IndexOf(": ") > 0) Then
                nStartPoint = sErrMessage.LastIndexOf(": ") + 2
            End If

            Dim sSubjMessage As String = sErrMessage.Substring(nStartPoint)

            If (sSubjMessage.IndexOf(cSoShortMessage) > -1) Then
                Dim sDescription = sSubjMessage.Substring(cSoShortMessage.Length + 1)
                nPoint = sDescription.IndexOf(".")
                If (nPoint < 0) Then
                    nPoint = sDescription.IndexOf(":")
                End If
                If (nPoint < 0) Then
                    nPoint = Math.Min(40, sDescription.Length - 1)
                End If
                nPoint += cSoShortMessage.Length + 1
            ElseIf (sSubjMessage.IndexOf(cUnaleToCastMessage) > -1) Then
                nPoint = sSubjMessage.Length() - 1
            Else
                nPoint = sSubjMessage.IndexOf(".")
                If nPoint = -1 Then
                    nPoint = sSubjMessage.Length - 1
                End If
            End If

            Dim sApplicationName = Application("ErrorApplicationName").ToString()
            If (String.IsNullOrEmpty(sApplicationName)) Then
                sApplicationName = "Undefined"
            End If

            strSubject = sSubjMessage.Substring(0, nPoint + 1)
            strMessage = "System:" & sApplicationName & "; User:" & User.Identity.Name & "; UserAddress:" & Request.UserHostAddress & "; URL:" & Request.Url.AbsoluteUri & "; Message:" & sErrMessage & "; StackTrace:" & sStackTrace

            Dim sUrl As String = Request.Url.AbsoluteUri

            Dim sPathForm As String = ""

            Dim iQuestionMarkInd = sUrl.IndexOf("?")
            If (iQuestionMarkInd >= 0) Then
                sPathForm = sUrl.Substring(0, iQuestionMarkInd)
            Else
                sPathForm = sUrl
            End If
            Dim nStartForm As Integer = sPathForm.LastIndexOf("/")

            '"Server was unable to process request."
            strSubject = "Application Error: " + strSubject + "; Form: " + sPathForm.Substring(nStartForm + 1)
            Dim nQuestionMark As Integer = strSubject.ToLower().IndexOf("?key")
            If (nQuestionMark > -1) Then ' We should remove "?key=XXX" from subject
                strSubject = strSubject.Substring(0, nQuestionMark)
            End If

            If (User.Identity.Name <> "") Then
                strSubject += " User:" & User.Identity.Name
            End If

            Dim strUrl As String = Application("ErrorReportConnectorService").ToString()
            If strUrl <> "" Then
                Dim bConnectionError As Boolean = False
                Dim objUser As New UserConnect.UserService()
                objUser.Url = Application("UserWebService").ToString()
                Dim objErrorReportConnect As New ErrorReportConnect.ErrorReportConnector()
                objErrorReportConnect.Url = strUrl
                Dim iTestValue As Integer
                Try
                    iTestValue = objUser.CheckWS()
                    If iTestValue < 3 Then
                        bConnectionError = True
                    End If
                Catch ex As Exception
                    strMessage = strMessage & "<br><br>" & Request.Url.AbsoluteUri & "; Message:" & ex.Message & ";Source:" & ex.Source & ";StackTrace:" & ex.StackTrace
                    If (Not IsNothing(ex.InnerException)) Then
                        strMessage = strMessage & "<br>InnerException: Message:" & ex.InnerException.Message & ";Source:" & ex.InnerException.Source & ";StackTrace:" & ex.InnerException.StackTrace
                    End If
                    bConnectionError = True
                Finally
                    If (iTestValue = -1) Then
                        strMessage = strMessage & "<br><br>CheckWS:FileService Exception"
                    End If
                    If (iTestValue = -2) Then
                        strMessage = strMessage & "<br><br>CheckWS:UserService Exception"
                    End If
                End Try
                Try
                    'objErrorReportConnect.SendError("FF1CC557-AAAB-472F-8282-BC7E083A53B9", strMessage, bConnectionError)
                    objErrorReportConnect.SendErrorWithSubject("9F8D01F4-6CBF-4852-B5E0-1FD2A3AB7F60", strMessage, strSubject, bConnectionError)
                    If bConnectionError Then
                        Dim strBatch As String = Trim(Application("ErrorBatchFile").ToString())
                        If Len(strBatch) > 0 Then
                            System.Threading.Thread.Sleep(1000)
                            Dim startInfo As System.Diagnostics.ProcessStartInfo
                            Dim pStart As New System.Diagnostics.Process()
                            startInfo = New System.Diagnostics.ProcessStartInfo(strBatch)
                            pStart.StartInfo = startInfo
                            pStart.Start()
                        End If
                    End If
                Catch ex1 As Exception
                    '
                End Try
            End If

#If NewDesign Then

            If (Application("LogExceptions") = "1") Then
                Try

                    Dim objSec As New SecurityService.SecurityService()
                    objSec.Url = Application("SecurityService")

                    Dim iType As Integer = 2
                    Dim sErrUser As String = User.Identity.Name
                    Dim sUserAddress As String = Request.UserHostAddress
                    Dim nSlash As Integer = sUrl.IndexOf("//")

                    Dim sServer As String = sUrl.Substring(nSlash + 2)
                    nSlash = sServer.IndexOf("/")
                    sServer = sServer.Substring(0, nSlash)

                    Dim dtNow As DateTime = DateTime.Now
                    Dim sForm As String = sUrl.Substring(nStartForm + 1)
                    Dim iQuestionMark As Integer = sForm.IndexOf("?")
                    If iQuestionMark > 0 Then
                        sForm = sForm.Substring(0, iQuestionMark)
                    End If

                    'sErrMessage
                    'sStackTrace
                    Dim bOk As Boolean = objSec.SaveExceptionData("C9087ED6-EFBF-4286-955E-A55E4436F5B3", iType, sErrUser, sUserAddress, dtNow, sServer, sForm, sErrMessage, sStackTrace)                    

                Catch ex As Exception
                    ' Do notning we don't want to have recurcive exception
                End Try

            End If
#End If

        End If

    End Sub

    Private Function GetQueryString()

        Dim i As Integer
        Dim QueryString As String = String.Empty

        For i = 0 To Context.Request.QueryString.Keys.Count - 1
            If (QueryString.Length > 0) Then
                QueryString += "&"
            End If
            If (Context.Request.QueryString.Keys(i) <> "key") Then
                QueryString += Context.Request.QueryString.Keys(i) & "=" & Context.Request.QueryString(Context.Request.QueryString.Keys(i))
            End If
        Next

        Return QueryString

    End Function

    Sub Session_End(ByVal sender As Object, ByVal e As EventArgs)
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        objUser.UpdateLastLogout("DD947C22-CFCA-4BD4-A2CD-B9C916B39B28", Session.SessionID, Val(Application("SiteType")))

    End Sub

    Sub Application_End(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the application ends
    End Sub

    Private Sub FillWhiteListHashtable()

        Dim hWhiteListForms As New Hashtable()
        Dim hWhiteListFields As Hashtable = Nothing
        Dim r As Data.DataRow

        Dim ss As New SecurityService.SecurityService()
        ss.Url = Application("SecurityService")

        Dim dsWhiteListFields As DataSet = ss.GetWhiteListFields("99B37A89-6006-4F06-BF0F-00A09799714A", True)

        Dim sCurrentField As String = ""
        For Each r In dsWhiteListFields.Tables(0).Select("SecLevel=1 OR SecLevel=3")
            sCurrentField = r("FormName").ToString().ToLower() + r("ParentFormName").ToString().ToLower()
            If (Not hWhiteListForms.Contains(sCurrentField)) Then
                hWhiteListFields = New Hashtable()
                hWhiteListForms.Add(sCurrentField, hWhiteListFields)
            End If
            ' hWhiteListFields.Add(r("FieldName").ToString().ToLower(), r("FieldDesc")) 'r("SecLevel")  
            Dim hWhiteListData As New WhiteListClass(r("SecLevel"), r("FieldName").ToString().ToLower(), r("FieldDesc").ToString().ToLower(), r("ParentFormName").ToString().ToLower())
            hWhiteListFields.Add(r("FieldName").ToString().ToLower(), hWhiteListData)
        Next
        Application("FormsHashtable") = hWhiteListForms

        'Dim dsWhiteListFields As DataSet = ss.GetWhiteList2Fields("16D5F259-6DD8-41C4-AF9E-29A5B5618441", True)

        'Dim sCurrentField As String = ""
        'For Each r In dsWhiteListFields.Tables(0).Select("SecLevel=1 OR SecLevel=3")
        '	sCurrentField = r("FormName").ToString().ToLower() + r("ParentFormName").ToString().ToLower()
        '	If (Not hWhiteListForms.Contains(sCurrentField)) Then
        '		hWhiteListFields = New Hashtable()
        '		hWhiteListForms.Add(sCurrentField, hWhiteListFields)
        '	End If			
        '	Dim hWhiteListData As New WhiteListClassExt(r("SecLevel"), r("FieldName").ToString().ToLower(), r("FieldDesc").ToString().ToLower(), r("ParentFormName").ToString().ToLower(), r("ExcludeFlag"))
        '	hWhiteListFields.Add(r("FieldName").ToString().ToLower(), hWhiteListData)
        'Next
        'Application("FormsHashtable") = hWhiteListForms

        hWhiteListForms = New Hashtable()
        dsWhiteListFields = ss.GetWhiteListFields("99B37A89-6006-4F06-BF0F-00A09799714A", True)
        For Each r In dsWhiteListFields.Tables(0).Select("SecLevel=2")
            If (Not hWhiteListForms.Contains(r("FormName"))) Then
                hWhiteListFields = New Hashtable()
                hWhiteListForms.Add(r("FormName"), hWhiteListFields)
            End If
            hWhiteListFields.Add(r("FieldName"), r("FieldDesc")) 'r("SecLevel")     
        Next
        Application("EditorHashtable") = hWhiteListForms

    End Sub

    Function GetRightExtensions(ByVal arrWhiteList() As String) As String
        Dim sRes As String = String.Empty
        Dim arrRes(arrWhiteList.Length) As String

        Dim arrExt() As String
        Dim sExt As String
        Dim sResExt As String

        Try
            Dim i As Integer
            For i = 0 To arrWhiteList.Length - 1
                arrExt = arrWhiteList(i).Split(",")
                sExt = UCase(arrExt(0) & "")

                Dim iPos As Integer = sExt.IndexOf("(")
                If iPos > 0 Then
                    sExt = Left(sExt, iPos)
                End If

                For Each sResExt In arrRes
                    If sResExt = sExt Then
                        sExt = ""
                    End If
                Next
                If sExt <> "" Then
                    arrRes(i) = sExt
                    sRes = sRes & IIf(sRes = String.Empty, String.Empty, ",") & sExt
                End If
            Next
        Catch ex As Exception

        End Try

        Return sRes
    End Function

    Private Sub Global_EndRequest(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.EndRequest
        'Dim authCookie As String = FormsAuthentication.FormsCookieName
        For Each cookie As String In Response.Cookies
            'If cookie.Equals(authCookie) Then
            If (Response.Cookies.Item(cookie).Path.IndexOf("HttpOnly") < 0) Then
                Response.Cookies.Item(cookie).Path += ";HttpOnly"
            End If
            If (Application("SecureCookies").ToString() = "1") Then
                Response.Cookies.Item(cookie).Secure = True
            End If
            'End If
        Next
    End Sub

    Private Function RemoveSpecialCharacters(ByVal inputStr As String) As String
        Dim sb = New System.Text.StringBuilder(inputStr.Length)
        For i As Integer = 0 To inputStr.Length - 1
            If ((inputStr(i) >= " ") OrElse (inputStr(i) = Chr(10)) OrElse (inputStr(i) = Chr(13)) OrElse (inputStr(i) = Chr(9))) Then
                sb.Append(inputStr(i))
            End If
        Next

        Return sb.ToString()
    End Function
End Class


