Imports System.IO
Imports System.Security.Cryptography
Imports System.Text

Namespace CEncryption
    Public Class cEnryption

        Public Function EncryptStr(ByVal strSource As String) As String
            Dim des As New DESCryptoServiceProvider()
#If OLD_ENCRYPTION Then
        Dim Key As Byte() = {33, 155, 130, 233, 66, 25, 60, 218}
        Dim IV As Byte() = {47, 209, 92, 205, 174, 176, 36, 113}
#Else
            Dim dpapiKeyFileName As String = "dpapiKey.lic"
            Dim dpapiIVFileName As String = "dpapiIV.lic"
            If Not System.Web.HttpContext.Current Is Nothing Then  ' If this module used in Web App
                dpapiKeyFileName = System.Web.HttpContext.Current.Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "\\" + dpapiKeyFileName)
                dpapiIVFileName = System.Web.HttpContext.Current.Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "\\" + dpapiIVFileName)
                'dpapiKeyFileName = System.Web.HttpContext.Current.Server.MapPath(dpapiKeyFileName)
                'dpapiIVFileName = System.Web.HttpContext.Current.Server.MapPath(dpapiIVFileName)
            Else                                                   ' If used as Win App      
                dpapiKeyFileName = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\" + dpapiKeyFileName
                dpapiIVFileName = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\" + dpapiIVFileName
            End If

            Dim Key As Byte() = cryptComtec.DPAPI.ReadFromDiskAndSecureRetrive(dpapiKeyFileName)
            Dim IV As Byte() = cryptComtec.DPAPI.ReadFromDiskAndSecureRetrive(dpapiIVFileName)


#End If
            Dim plainBytes As Byte() = System.Text.Encoding.Unicode.GetBytes(strSource)
            Dim byRetArray As Byte()
            Dim ms As New MemoryStream()
            Dim cs As New CryptoStream(ms, des.CreateEncryptor(Key, IV), CryptoStreamMode.Write)
            Try
                cs.Write(plainBytes, 0, plainBytes.Length)
                cs.FlushFinalBlock()
                byRetArray = ms.ToArray()
            Catch ex As Exception
                'Console.WriteLine(ex.Message)
            Finally
                ms.Close()
                cs.Close()
            End Try
            Return Convert.ToBase64String(byRetArray)
        End Function

        Public Function EncryptStrTripleDESC(ByVal strSource As String) As String
            Dim tdes As New TripleDESCryptoServiceProvider()
#If OLD_ENCRYPTION Then
            Dim Key As Byte() = {24, 243, 246, 111, 145, 245, 82, 13, 81, 158, 123, 196, 95, 167, 40, 187, 87, 33, 48, 159, 116, 36, 31, 153}
            Dim IV As Byte() = {69, 88, 158, 213, 82, 136, 135, 115}
#Else
            Dim dpapiKeyFileName As String = "dpapiKey3.lic"
            Dim dpapiIVFileName As String = "dpapiIV3.lic"
            If Not System.Web.HttpContext.Current Is Nothing Then  ' If this module used in Web App
                dpapiKeyFileName = System.Web.HttpContext.Current.Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "\\" + dpapiKeyFileName)                
                dpapiIVFileName = System.Web.HttpContext.Current.Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "\\" + dpapiIVFileName)
                'System.Web.HttpContext.Current.Server.MapPath(dpapiKeyFileName)
                'System.Web.HttpContext.Current.Server.MapPath(dpapiIVFileName)
            Else                                                   ' If used as Win App      
                dpapiKeyFileName = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\" + dpapiKeyFileName
                dpapiIVFileName = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\" + dpapiIVFileName
            End If

            Dim Key As Byte() = cryptComtec.DPAPI.ReadFromDiskAndSecureRetrive(dpapiKeyFileName)
            Dim IV As Byte() = cryptComtec.DPAPI.ReadFromDiskAndSecureRetrive(dpapiIVFileName)

#End If

            Dim plainBytes As Byte() = System.Text.Encoding.Unicode.GetBytes(strSource)
            Dim byRetArray As Byte()
            Dim ms As New MemoryStream()
            Dim cs As New CryptoStream(ms, tdes.CreateEncryptor(Key, IV), CryptoStreamMode.Write)
            Try
                cs.Write(plainBytes, 0, plainBytes.Length)
                cs.FlushFinalBlock()
                byRetArray = ms.ToArray()
            Catch ex As Exception
                'Console.WriteLine(ex.Message)
            Finally
                ms.Close()
                cs.Close()
            End Try
            Return Convert.ToBase64String(byRetArray)
        End Function

        Public Function DecryptStr(ByVal strSource As String) As String
            Dim des As New DESCryptoServiceProvider()
#If OLD_ENCRYPTION Then
        Dim Key As Byte() = {33, 155, 130, 233, 66, 25, 60, 218}
        Dim IV As Byte() = {47, 209, 92, 205, 174, 176, 36, 113}
#Else
            Dim dpapiKeyFileName As String = "dpapiKey.lic"
            Dim dpapiIVFileName As String = "dpapiIV.lic"
            If Not System.Web.HttpContext.Current Is Nothing Then  ' If this module used in Web App
                dpapiKeyFileName = System.Web.HttpContext.Current.Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "\\" + dpapiKeyFileName)
                dpapiIVFileName = System.Web.HttpContext.Current.Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "\\" + dpapiIVFileName)
                'dpapiKeyFileName = System.Web.HttpContext.Current.Server.MapPath(dpapiKeyFileName)
                'dpapiIVFileName = System.Web.HttpContext.Current.Server.MapPath(dpapiIVFileName)
            Else                                                   ' If used as Win App      
                dpapiKeyFileName = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\" + dpapiKeyFileName
                dpapiIVFileName = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\" + dpapiIVFileName
            End If

            Dim Key As Byte() = cryptComtec.DPAPI.ReadFromDiskAndSecureRetrive(dpapiKeyFileName)
            Dim IV As Byte() = cryptComtec.DPAPI.ReadFromDiskAndSecureRetrive(dpapiIVFileName)


#End If
            Dim ms As New System.IO.MemoryStream()
            Dim cs As New CryptoStream(ms, des.CreateDecryptor(Key, IV), CryptoStreamMode.Write)
            Dim byRetArray As Byte()
            Try
                Dim bySource As Byte() = Convert.FromBase64String(strSource)
                cs.Write(bySource, 0, bySource.Length)
                cs.FlushFinalBlock()
                byRetArray = ms.ToArray()
            Catch ex As Exception
                'Console.WriteLine(ex.Message)
            Finally
                cs.Close()
                ms.Close()
            End Try

            Return System.Text.Encoding.Unicode.GetString(byRetArray)
        End Function

        Public Function DecryptStrTripleDESC(ByVal strSource As String) As String
            Dim tdes As New TripleDESCryptoServiceProvider()
#If OLD_ENCRYPTION Then
            Dim Key As Byte() = {24, 243, 246, 111, 145, 245, 82, 13, 81, 158, 123, 196, 95, 167, 40, 187, 87, 33, 48, 159, 116, 36, 31, 153}
            Dim IV As Byte() = {69, 88, 158, 213, 82, 136, 135, 115}
#Else
            Dim dpapiKeyFileName As String = "dpapiKey3.lic"
            Dim dpapiIVFileName As String = "dpapiIV3.lic"
            If Not System.Web.HttpContext.Current Is Nothing Then  ' If this module used in Web App
                dpapiKeyFileName = System.Web.HttpContext.Current.Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "\\" + dpapiKeyFileName)
                dpapiIVFileName = System.Web.HttpContext.Current.Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "\\" + dpapiIVFileName)
                'dpapiKeyFileName = System.Web.HttpContext.Current.Server.MapPath(dpapiKeyFileName)
                'dpapiIVFileName = System.Web.HttpContext.Current.Server.MapPath(dpapiIVFileName)
            Else                                                   ' If used as Win App      
                dpapiKeyFileName = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\" + dpapiKeyFileName
                dpapiIVFileName = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\" + dpapiIVFileName
            End If

            Dim Key As Byte() = cryptComtec.DPAPI.ReadFromDiskAndSecureRetrive(dpapiKeyFileName)
            Dim IV As Byte() = cryptComtec.DPAPI.ReadFromDiskAndSecureRetrive(dpapiIVFileName)

#End If

            Dim ms As New System.IO.MemoryStream()
            Dim cs As New CryptoStream(ms, tdes.CreateDecryptor(Key, IV), CryptoStreamMode.Write)
            Dim byRetArray As Byte()
            Try
                Dim bySource As Byte() = Convert.FromBase64String(strSource)
                cs.Write(bySource, 0, bySource.Length)
                cs.FlushFinalBlock()
                byRetArray = ms.ToArray()
            Catch ex As Exception
                'Console.WriteLine(ex.Message)
            Finally
                cs.Close()
                ms.Close()
            End Try
            Return System.Text.Encoding.Unicode.GetString(byRetArray)
        End Function



        Public Function EncryptStrToBytes(ByVal strSource As String) As Byte()
            Dim des As New DESCryptoServiceProvider()
#If OLD_ENCRYPTION Then
            Dim Key As Byte() = {33, 155, 130, 233, 66, 25, 60, 218}
            Dim IV As Byte() = {47, 209, 92, 205, 174, 176, 36, 113}
#Else

            Dim dpapiKeyFileName As String = "dpapiKey.lic"
            Dim dpapiIVFileName As String = "dpapiIV.lic"
            If Not System.Web.HttpContext.Current Is Nothing Then  ' If this module used in Web App
                dpapiKeyFileName = System.Web.HttpContext.Current.Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "\\" + dpapiKeyFileName)
                dpapiIVFileName = System.Web.HttpContext.Current.Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "\\" + dpapiIVFileName)
                'dpapiKeyFileName = System.Web.HttpContext.Current.Server.MapPath(dpapiKeyFileName)
                'dpapiIVFileName = System.Web.HttpContext.Current.Server.MapPath(dpapiIVFileName)
            Else                                                   ' If used as Win App      
                dpapiKeyFileName = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\" + dpapiKeyFileName
                dpapiIVFileName = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\" + dpapiIVFileName
            End If
            Dim Key As Byte() = cryptComtec.DPAPI.ReadFromDiskAndSecureRetrive(dpapiKeyFileName)
            Dim IV As Byte() = cryptComtec.DPAPI.ReadFromDiskAndSecureRetrive(dpapiIVFileName)

#End If

            Dim plainBytes As Byte() = Encoding.Unicode.GetBytes(strSource)
            Dim byRetArray As Byte()
            Dim ms As New MemoryStream()
            Dim cs As New CryptoStream(ms, des.CreateEncryptor(Key, IV), CryptoStreamMode.Write)
            Try
                cs.Write(plainBytes, 0, plainBytes.Length)
                cs.FlushFinalBlock()
                byRetArray = ms.ToArray()
            Catch ex As Exception
                'Console.WriteLine(ex.Message)
            Finally
                ms.Close()
                cs.Close()
            End Try
            Return byRetArray
        End Function

        Public Function DecryptBytesToStr(ByVal bySource As Byte()) As String
            Dim des As New DESCryptoServiceProvider()
#If OLD_ENCRYPTION Then
            Dim Key As Byte() = {33, 155, 130, 233, 66, 25, 60, 218}
            Dim IV As Byte() = {47, 209, 92, 205, 174, 176, 36, 113}
#Else

            Dim dpapiKeyFileName As String = "dpapiKey.lic"
            Dim dpapiIVFileName As String = "dpapiIV.lic"
            If Not System.Web.HttpContext.Current Is Nothing Then  ' If this module used in Web App
                dpapiKeyFileName = System.Web.HttpContext.Current.Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "\\" + dpapiKeyFileName)
                dpapiIVFileName = System.Web.HttpContext.Current.Server.MapPath(System.Web.HttpContext.Current.Request.ApplicationPath + "\\" + dpapiIVFileName)

                'dpapiKeyFileName = System.Web.HttpContext.Current.Server.MapPath(dpapiKeyFileName)
                'dpapiIVFileName = System.Web.HttpContext.Current.Server.MapPath(dpapiIVFileName)
            Else                                                   ' If used as Win App      
                dpapiKeyFileName = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\" + dpapiKeyFileName
                dpapiIVFileName = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\" + dpapiIVFileName
            End If
            Dim Key As Byte() = cryptComtec.DPAPI.ReadFromDiskAndSecureRetrive(dpapiKeyFileName)
            Dim IV As Byte() = cryptComtec.DPAPI.ReadFromDiskAndSecureRetrive(dpapiIVFileName)

#End If

            Dim ms As New System.IO.MemoryStream()
            Dim cs As New CryptoStream(ms, des.CreateDecryptor(Key, IV), CryptoStreamMode.Write)
            Dim byRetArray As Byte()
            Try
                cs.Write(bySource, 0, bySource.Length)
                cs.FlushFinalBlock()
                byRetArray = ms.ToArray()
            Catch ex As Exception
                'Console.WriteLine(ex.Message)
            Finally
                cs.Close()
                ms.Close()
            End Try
            Return System.Text.Encoding.Unicode.GetString(byRetArray)
        End Function

    End Class


 

End Namespace