﻿Public Partial Class frmGetLoginMessage
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim logonMessageImage As Byte()
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

        Dim isEng As Boolean = False
#If EngDesign Then
        isEng = True
#End If
        logonMessageImage = objUser.GetLoginMessageImage("AA1E650B-EC4A-4B0C-91C6-B132CBBB415D", isEng)
        If Not IsNothing(logonMessageImage) Then
            Response.BinaryWrite(logonMessageImage)
        End If

    End Sub

End Class