Imports System.Web.Security
Imports System.Drawing
Imports System.Text.RegularExpressions

Public Class frmRepStat
    Inherits System.Web.UI.Page

    Protected WithEvents txtError As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents grdList As System.Web.UI.WebControls.DataGrid
    Protected WithEvents cmdHelp As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdReports As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdUserProp As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdReturn As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents txtReportType As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents cmdLogout As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents lstUsers As System.Web.UI.WebControls.DropDownList
    Protected WithEvents chkFilter As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents cmdApplyFilter As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents lstReportType As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lblMessage As System.Web.UI.WebControls.Label
    Protected WithEvents chkViewed As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents chkNotViewed As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents lblBOUserID As System.Web.UI.WebControls.Label
    Protected WithEvents tdDistTitle As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents tdRow1Cell2 As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents txtAppType As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtFormIdentity As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents aIconLink As System.Web.UI.HtmlControls.HtmlAnchor
    Protected WithEvents divRIcon As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents cboGridRowCount As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ctlBanner As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents tdGridRowCount As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents ctlTitle As System.Web.UI.HtmlControls.HtmlGenericControl

#If Not EngDesign Then
#If Not NewDesign Then
    Protected WithEvents trTitleRow1 As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents trTitleRow2 As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents tdTitleClinic2 As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents tdchkFilter As System.Web.UI.HtmlControls.HtmlTableCell
#End If
#End If
   
#If NewDesign Then
    Protected WithEvents tdRightPic As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents imgRightPic As System.Web.UI.HtmlControls.HtmlImage
    Protected WithEvents imgLeftPic As System.Web.UI.HtmlControls.HtmlImage
    Protected WithEvents txtInshuredID As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtName As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents hidSiteID As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtHasCB As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents trBanner As System.Web.UI.HtmlControls.HtmlTableRow
    'Menu
    Protected WithEvents tableMenu As System.Web.UI.HtmlControls.HtmlTable
    Protected WithEvents divMenu As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents hidMenuPar As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents cmdMenu As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents hidClaimApp As System.Web.UI.HtmlControls.HtmlInputHidden
#If Not EngDesign Then
    Protected WithEvents txtDateFrom As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtDateTo As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents lblNotice As System.Web.UI.WebControls.Label
#Else
    Protected WithEvents txtDateFrom As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtDateTo As System.Web.UI.HtmlControls.HtmlInputHidden
#End If
#Else
    Protected WithEvents txtDateFrom As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtDateTo As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents aIconLink2 As System.Web.UI.HtmlControls.HtmlAnchor
#If Not EngDesign Then
    Protected WithEvents tdUsers As System.Web.UI.HtmlControls.HtmlTableCell
#End If
#End If

    Dim g_fAllowUserSelect As Boolean

#If Not NewDesign And Not EngDesign Then
    Private Const col_grdList_AllRep As Integer = 0
    Private Const col_grdList_NotReadRep As Integer = 1
    Private Const col_grdList_ReadRep As Integer = 2
    Private Const col_grdList_LastReport As Integer = 3
    Private Const col_grdList_ReportTypeName As Integer = 4
    Private Const col_grdList_Pointer As Integer = 5
#Else
    Private Const col_grdList_AllRep As Integer = 0
    Private Const col_grdList_NotReadRep As Integer = 1
    Private Const col_grdList_ReadRep As Integer = 2
    Private Const col_grdList_ReportTypeName As Integer = 3
    Private Const col_grdList_Pointer As Integer = 4
#End If

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.

        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
#If NewDesign Then
        Dim check As Boolean = (New Utils).CheckKey("frmrepstat.aspx")
#End If
        'If Not CrossCheck() Then
        '    Session("BackUrl") = "frmRepStat.aspx"
        '    Response.Redirect("frmError.aspx")
        '    Return
        'End If

        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

        Dim iGridRowCount As Integer
        Dim strAllowUserSelect As String

        Dim isEng As Boolean = False
#If EngDesign Then
        isEng = True
#End If

        If Not IsPostBack Then
#If Not NewDesign Then
            If LCase(Application("App_Type").ToString) = "divur" Then
                tdchkFilter.InnerText = ""
                chkFilter.Visible = False
            End If
#End If

            'SiteID
#If NewDesign And Not EngDesign Then
            Dim iUserSiteID As Integer = objUser.GetUserSite("331EE612-6669-495A-A7CB-733603CF816D", User.Identity.Name)
            hidSiteID.Value = iUserSiteID
#End If
        End If

#If NewDesign And Not EngDesign Then
        If Application("HasCB") = "1" Then
            txtHasCB.Value = "1"
        Else
            txtHasCB.Value = "0"
        End If
#End If

        'Chk Prm
        If Application("App_Type").ToString.ToUpper() = "SUPP" Then
            If Session("SUPP_AllowClaims") <> "1" And Session("SUPP_HospitalClaim") <> "1" And Session("SUPP_ReportGeneration") <> "1" Then
                objUser.AddUserIllegalAction("24304391-6FDE-4237-A9B6-49630958EB26", User.Identity.Name, "frmRepStat")
                Response.Redirect(Application("FORMLogin"))
            End If
        Else
            If Session("WebInterfaceAllow") <> "1" Then
                objUser.AddUserIllegalAction("24304391-6FDE-4237-A9B6-49630958EB26", User.Identity.Name, "frmRepStat")
                Response.Redirect(Application("FORMLogin"))
            End If
        End If

        iGridRowCount = objUser.GetGridRowCount("9CDE451A-D418-40EC-9588-64CA4592AC55", User.Identity.Name)

        tdGridRowCount.Visible = False

        If LCase(Application("App_Type").ToString) = "dist" Or LCase(Application("App_Type").ToString) = "claim" Or LCase(Application("App_Type").ToString) = "supp" Or LCase(Application("App_Type").ToString) = "divur" Or LCase(Application("App_Type").ToString) = "doar" Or LCase(Application("App_Type").ToString) = "eng" Then
            grdList.PagerStyle.HorizontalAlign = HorizontalAlign.Right
            tdGridRowCount.Visible = True
            If Not IsPostBack Then
                Dim arrValues() As Integer = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15}
                cboGridRowCount.DataSource = arrValues
                cboGridRowCount.DataBind()
                cboGridRowCount.SelectedIndex = iGridRowCount - 1
                'If Not Session("GridRowCount") Is Nothing Then
                '    iGridRowCount = Session("GridRowCount")
                'End If



            End If

        End If

        If Application("App_Type").ToString = "dist" Then
            g_fAllowUserSelect = False
        Else
            strAllowUserSelect = objUser.GetUserSelectPermition("5CF99E07-9412-400C-89C9-6391758C6098", User.Identity.Name)
            If strAllowUserSelect <> "" Then
                If strAllowUserSelect = "1" Then
                    g_fAllowUserSelect = True
                Else
                    g_fAllowUserSelect = False
                End If
            Else
                g_fAllowUserSelect = True
                'If Application("App_Type").ToString = "dist" Then
                '    g_fAllowUserSelect = False
                'Else
                '    g_fAllowUserSelect = True
                'End If
            End If
        End If

        If Not g_fAllowUserSelect Then
            lstUsers.Visible = False
        Else
            lstUsers.Visible = True
        End If

        If Not IsPostBack Then
            aIconLink.HRef = Application("ClientSiteLink")

            If Application("RightLogo") = "1" Then

#If NewDesign Then
                tdRightPic.Attributes("background") = "pics/BannerTopRightTransp.gif"
                imgRightPic.Attributes("src") = "pics/BannerTopRightTransp.gif"
#End If
                divRIcon.Visible = True
            Else
#If NewDesign Then
                tdRightPic.Attributes("background") = "pics/BannerTopRightPic.gif"
                imgRightPic.Attributes("src") = "pics/BannerTopRightPic.gif"
#End If
                divRIcon.Visible = False
            End If

            If Session("User_Login_First_Time") = "1" Then
#If NewDesign And Not EngDesign Then
                If Application("HasCB") = "1" Or Application("HasHani").ToString() = "1" Then
                    'Response.Redirect("frmUserInfo.aspx")
                    Response.Redirect((New Utils).GetLinkForNextForm("frmUserInfo.aspx"))
                Else
                    'Response.Redirect("frmUserProp.aspx")
                    Response.Redirect((New Utils).GetLinkForNextForm("frmUserProp.aspx"))
                End If
#Else
                'Response.Redirect("frmUserProp.aspx")
                Response.Redirect((New Utils).GetLinkForNextForm("frmUserProp.aspx"))
#End If
            End If

            'Dim objUser As New UserConnect.UserService()
            'objUser.Url = Application("UserWebService").ToString()
            Dim strUserName As String = objUser.GetUserFullName("3371F4F5-F671-4B9D-A054-A4232D3D2177", User.Identity.Name)
            Dim strText As String = ""



            If Session("Show_Message") = "" Then
                Dim strDate As String = Session("Last_Login_Date")
                Dim strTime As String = Session("Last_Login_Time")
#If EngDesign Then
                strText = "Hello" & " " & strUserName & ". "
#Else
                strText = "����" & " " & strUserName & ". "
#End If
                If Len(strDate) > 0 Then
#If EngDesign Then
                    strText += "Last Login on " & " " & strDate & " " & strTime & "."
#Else
                    strText += "����� ������ ������ ����� ������ " & " " & strDate & " " & " ���" & " " & strTime & "."
#End If
                End If
                Session("Show_Message") = "1"
#If EngDesign Then
                Session("Message_Text") = "User Name: " & strUserName
#Else
                Session("Message_Text") = "�� �����: " & strUserName
#End If
            Else
                strText = CEncode.StringEncode(Session("Message_Text"))
            End If
            If LCase(Application("App_Type").ToString) <> "kupa_info" Then
                lblMessage.Text = strText
            End If
            BindCombo()
            If Session("Filter_On") = "1" Then
                Dim strDate As String = "" & Session("Filter_From_Date")
                If strDate <> "" Then
                    strDate = Left(strDate, 2) & "/" & Mid(strDate, 3, 2) & "/" & Mid(strDate, 5, 4)
                    txtDateFrom.Value = strDate
                Else
                    txtDateFrom.Value = "00000000"
                End If
                strDate = "" & Session("Filter_To_Date")
                If strDate <> "" Then
                    strDate = Left(strDate, 2) & "/" & Mid(strDate, 3, 2) & "/" & Mid(strDate, 5, 4)
                    txtDateTo.Value = strDate
                Else
                    txtDateTo.Value = "00000000"
                End If
                If Session("Filter_Report_Type") <> "" Then
                    SetComboValue(lstReportType, Session("Filter_Report_Type"))
                End If
                chkFilter.Checked = True
                If Session("Filter_Viewed") <> "" Then
                    chkViewed.Checked = True
                Else
                    chkViewed.Checked = False
                End If
                If Session("Filter_NotViewed") <> "" Then
                    chkNotViewed.Checked = True
                Else
                    chkNotViewed.Checked = False
                End If
            Else
                chkViewed.Checked = True
                chkNotViewed.Checked = True
                txtDateFrom.Value = "00000000"
                txtDateTo.Value = "00000000"
            End If



            If LCase(Application("App_Type").ToString) = "dist" Then
#If EngDesign Then
                ctlTitle.InnerText = "Information Types"
                cmdReports.Value = "Display"
                tdDistTitle.InnerText = "Information File Types"
#Else
                ctlTitle.InnerText = "���� ����"
                cmdReports.Value = "����"
                tdDistTitle.InnerText = "���� ���� ����"
#End If
                'cmdHelp.Disabled = True
                tdDistTitle.Width = "100%"
                tdDistTitle.Style("text-align") = "center"
                lstUsers.Visible = False
                lblBOUserID.Visible = False


                'grdList.Width = Unit.Percentage(60)
                'grdList.Columns(0).Visible = False
                'grdList.Columns(1).Visible = False
                'grdList.Columns(2).Visible = False
#If EngDesign Then
                tdRow1Cell2.InnerText = "Information File Type"
#Else
                tdRow1Cell2.InnerText = "��� ���� ����"
#End If
                If Session("Allow_Action_Type_Upload") = "1" Then
                    cmdReturn.Visible = True
                Else
                    cmdReturn.Value = "�����"
                End If

                'iGridRowCount = CInt(cboGridRowCount.SelectedItem.Value)



            Else
                tdDistTitle.Style("text-align") = "left"
#If EngDesign Then
                ctlTitle.InnerText = "Report Types"
                cmdReports.Value = "Reports"
                tdRow1Cell2.InnerText = "Report Type"
#Else
                ctlTitle.InnerText = "������ ����"
                'cmdReports.Value = "�����"
                'tdRow1Cell2.InnerText = "��� ���"
#End If
                cmdHelp.Disabled = False

                If Application("App_Type").ToString().ToLower() = "doar" Then
                    cmdReturn.Attributes("onclick") = "window.close();return;"
                End If
#If Not NewDesign And Not EngDesign Then				
                If Application("App_Type").ToString().ToLower() = "divur" Then
                    grdList.BorderColor = System.Drawing.Color.Black
					grdList.Columns(col_grdList_LastReport).Visible = True
					grdList.Columns(col_grdList_AllRep).HeaderText = "�� ���"
					grdList.Columns(col_grdList_NotReadRep).HeaderText = "�� ����"
					grdList.Columns(col_grdList_ReadRep).HeaderText = "����"
					grdList.Columns(col_grdList_ReportTypeName).HeaderText = "�� ����"
					tdDistTitle.InnerText = "����� ����� �" & "-"
				Else
					grdList.Columns(col_grdList_LastReport).Visible = False
                End If
#End If
                If Application("App_Type").ToString().ToLower() = "divur" Or Application("App_Type").ToString().ToLower() = "kupa_info" Or Application("App_Type").ToString().ToLower = "supp" Then
                    cmdReturn.Visible = True

                    'If LCase(Application("App_Type").ToString) <> "supp" Then
                    '    cmdReturn.Value = "�����"
                    '    cmdReturn.Visible = True
                    'End If

                Else
#If EngDesign Then
                    cmdReturn.Visible = True
#Else
                    If Session("HasMainMenu") = "1" Then
                        cmdReturn.Visible = True
                        If Session("Allow_ForeignWorkers_Claims") = "1" Then
                            cmdReturn.Value = "����"
                        End If
                        'If Application("HasMainMenu") Then
                        '    cmdReturn.Visible = True
                        'ElseIf Session("Allow_Action_Type_Upload") = "1" Then
                        '    cmdReturn.Visible = True
                        'ElseIf Session("Allow_ForeignWorkers_Claims") = "1" Then
                        '    cmdReturn.Visible = True
                        '    cmdReturn.Value = "����"
                    Else
                        If Application("IsDorAlon") = "1" Then
                            cmdReturn.Value = "����"
                        ElseIf (Application("IsPool") & "" = "1") Then
                            cmdReturn.Value = "����"
                        ElseIf (Application("HasCB") <> "1") Then
                            cmdReturn.Value = "�����"
                        End If
                    End If

                    If Application("IsPool") & "" = "1" Then
                        cmdUserProp.Visible = False
                    End If

#End If
                End If

                    BindUsers()
                    End If

#If NewDesign Then
                    If Application("HasHani").ToString() = "1" Then
                        strUserName = objUser.GetUserNameByID("C5C4C694-E524-41D3-8ECD-38CE8434FE4B", lstUsers.SelectedItem.Value)
                        Session("CompanyLogo") = "pics/" & objUser.GetLogoName("17060B94-065E-4DB4-975D-A3988FFD63CC", strUserName)
                        imgLeftPic.Src = Session("CompanyLogo")
                    End If
                    If Application("App_Type").ToString().ToUpper() = "CLAIM" Then
                        trBanner.Visible = True
                        ctlBanner.InnerText = objUser.GetBanner("83FEABF8-828B-489D-8DD0-EB5A3AB7994E", isEng)
                    Else
                        trBanner.Visible = False
                    End If
                    hidClaimApp.Value = "0"
                    If Application("IsDorAlon") = "1" Then
                        hidClaimApp.Value = "1"
                    ElseIf (Application("IsPool") & "" = "1") Then
                        hidClaimApp.Value = "2"
                    End If
#End If
                    txtAppType.Value = Application("App_Type").ToString
#If Not NewDesign Then
            If LCase(Application("App_Type").ToString) <> "kupa_info" Then
                ctlBanner.InnerText = objUser.GetBanner("83FEABF8-828B-489D-8DD0-EB5A3AB7994E", isEng)
            End If
#End If
                    If iGridRowCount > 0 Then
                        grdList.PageSize = iGridRowCount
                    End If
                    BindGrid()
                    If Application("App_Type").ToString().ToUpper() = "CLAIM" Or Application("App_Type").ToString().ToUpper() = "SUPP" Then
                        lstReportType.Items.Clear()
                        BindCombo()
                    End If
        End If
#If NewDesign Then
#If Not EngDesign Then
        Dim menuBuilder As New MenuBuilder()
        menuBuilder.BuildMenuTable(Request.FilePath, tableMenu)

        Dim objReports As New ReportConnect.ReportService()
        objReports.Url = Application("ReportWebService").ToString()
        Dim strUserID As String = objUser.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", User.Identity.Name)
        Dim strNotice As String = ""
        If IsNumeric(strUserID) Then
            Dim ds As DataSet = objReports.GetUserNotices("7929A2DE-808F-4998-A9A2-18F4D5DA9844", CInt(strUserID))
            If ds.Tables(0).Rows.Count > 0 Then
                Dim currRow As DataRow
                For Each currRow In ds.Tables(0).Rows
                    strNotice = strNotice & currRow("ReportTypeName").ToString() & "; "
                Next
            End If
        End If
        If Len(strNotice) > 2 Then
            lblNotice.Text = "�����/�� �����/�� ������� �� �: " & Left(strNotice, Len(strNotice) - 2)
        Else
            lblNotice.Visible = False
        End If
#End If
#End If
    End Sub

    Private Sub BindCombo()

        Dim objReportsList As New ReportConnect.ReportService()
        objReportsList.Url = Application("ReportWebService").ToString()

        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim strUserID As String = objUser.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", User.Identity.Name)

        Dim ds As Data.DataSet

        Dim SubUserID As String

        If Session("Report_List_Current_User") = "" Then
            SubUserID = strUserID
        Else
            SubUserID = Session("Report_List_Current_User")
        End If

        If Application("App_Type").ToString().ToUpper() = "CLAIM" Or Application("App_Type").ToString().ToUpper() = "SUPP" Then
#If NewDesign And Not EngDesign Then
            If Application("HasCB") = "1" Then
                ds = objReportsList.GetReportTypes("31542C17-B112-416F-877D-5C5E2DC59639")
            Else
                ds = objReportsList.GetSelectedReportTypeList("28B2AB64-641B-4F09-969F-B4DD6B250009", Val(strUserID), Val(SubUserID), 0)
                If ds.Tables(0).Rows.Count = 0 Then
                    ds.Clear()
                    ds = objReportsList.GetReportTypesForPermit("C4FEAF1D-D2B6-4BA4-8605-D879E3A7EBC8", Val(strUserID), Val(SubUserID), 0)
                End If
            End If
#Else
#If NewDesign Then
            ds = objReportsList.GetSelectedReportTypeList("28B2AB64-641B-4F09-969F-B4DD6B250009", Val(strUserID), Val(SubUserID), 0)
            If ds.Tables(0).Rows.Count = 0 Then
                ds.Clear()
                ds = objReportsList.GetReportTypesForPermit("C4FEAF1D-D2B6-4BA4-8605-D879E3A7EBC8", Val(strUserID), Val(SubUserID), 0)
            End If
#Else
            ds = objReportsList.GetReportTypes("31542C17-B112-416F-877D-5C5E2DC59639")
#End If
#End If
        Else

            ds = objReportsList.GetReportTypeListFull("28B2AB64-641B-4F09-969F-B4DD6B250009")
        End If

        'Avner 241109***************
        Dim iShowAllFoldersForSelect As Integer

        iShowAllFoldersForSelect = objUser.GetShowAllFoldersForSelect("CF8763B0-D8F4-11DE-8A39-0800200C9A66")

        If iShowAllFoldersForSelect = 1 Then


#If EngDesign Then
                lstReportType.Items.Add(New ListItem("All", 0))
#Else
        lstReportType.Items.Add(New ListItem("�� ������", 0))
#End If

        End If
        'End avner 241109*******************

        Dim currRow As DataRow
        For Each currRow In ds.Tables(0).Rows
            lstReportType.Items.Add(New ListItem(currRow("ReportTypeName").ToString(), currRow("ReportType").ToString()))
        Next
    End Sub

    Private Sub BindGrid()
        Dim objReportsList As New ReportConnect.ReportService()
        objReportsList.Url = Application("ReportWebService").ToString()
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim strUserID As String = objUser.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", User.Identity.Name)
        Dim ds As DataSet
        'If Application("App_Type").ToString().ToUpper() = "CLAIM" Then
        '    g_fAllowUserSelect = False
        'End If
        If Not g_fAllowUserSelect Then

            ' If Application("App_Type").ToString().ToUpper() = "CLAIM" Then
            ' ds = objReportsList.GetDistributionStatisticsForPermit("7CAE24F0-08B5-47D2-AD9D-4276BDB066EB", strUserID)
            '   Else
            ds = objReportsList.GetDistributionStatistics("7CAE24F0-08B5-47D2-AD9D-4276BDB066EB", strUserID)
            '  End If

        Else
        Dim strSubUserID As String
        If lstUsers.Items.Count > 0 Then
            strSubUserID = lstUsers.SelectedItem.Value
        Else
            strSubUserID = "-1"
        End If
            If LCase(Application("App_Type").ToString) = "doar" Then
                If strSubUserID = "0" Then
                    ds = objReportsList.GetDoarStatistics("053FB10A-5ABB-4BFB-A3A8-F30DFEA68964", strUserID)
                Else
                    ds = objReportsList.GetReportsStatistics("28B2AB64-641B-4F09-969F-B4DD6B250009", strUserID, strSubUserID, 0)
                End If

            Else
                If Application("App_Type").ToString().ToUpper() = "CLAIM" Or Application("App_Type").ToString().ToUpper() = "SUPP" Then
#If NewDesign And Not EngDesign Then
                    If Application("HasCB") = "1" Then
                        ds = objReportsList.GetReportsStatistics("28B2AB64-641B-4F09-969F-B4DD6B250009", strUserID, strSubUserID, 0)
                    ElseIf Application("IsDorAlon") = "1" Then
                        ds = objReportsList.GetReportsStatisticsForPermRepTypes("4FD9D5B3-7543-4759-8DCB-6C5DC4D20DE4", strUserID, strSubUserID)
                    Else
                        ds = objReportsList.GetReportsStatisticsForPermit("28B2AB64-641B-4F09-969F-B4DD6B250009", strUserID, strSubUserID)
                    End If
#Else
#If NewDesign Then
				    ds = objReportsList.GetReportsStatisticsForPermit("28B2AB64-641B-4F09-969F-B4DD6B250009", strUserID, strSubUserID)
#Else
                    ds = objReportsList.GetReportsStatistics("28B2AB64-641B-4F09-969F-B4DD6B250009", strUserID, strSubUserID, 0)
#End If
#End If
                Else
                    ds = objReportsList.GetReportsStatistics("28B2AB64-641B-4F09-969F-B4DD6B250009", strUserID, strSubUserID, 0)
                End If
            End If
        End If
        Dim iCount As Integer = ds.Tables(0).Rows.Count
        Dim iPageCount As Integer = (iCount - 1) \ grdList.PageSize
        'If iPageCount < 0 Then
        '    iPageCount = 0
        'End If
        grdList.DataSource = ds
        If iPageCount > -1 Then
            If grdList.CurrentPageIndex > iPageCount Then
                grdList.CurrentPageIndex = iPageCount
            End If
        Else
            grdList.CurrentPageIndex = 0
        End If
        grdList.DataBind()
        If iPageCount > 0 Then
            grdList.PagerStyle.Visible = True
        Else
            grdList.PagerStyle.Visible = False
        End If
        If iCount = 0 Then
            chkFilter.Disabled = True
            chkFilter.Style.Remove("Cursor")
            chkFilter.Style.Add("Cursor", "default")
        Else
            chkFilter.Disabled = False
            chkFilter.Style.Remove("Cursor")
            chkFilter.Style.Add("Cursor", "hand")
        End If
    End Sub

    Private Sub BindUsers()

        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim strCurrentUser As String = Session("Report_List_Current_User")
        Dim strUserID As String
        If Len(strCurrentUser) > 0 Then
            strUserID = strCurrentUser
        Else
            strUserID = objUser.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", User.Identity.Name)
        End If

        Dim ds As Data.DataSet = objUser.GetSubUsers("6A2B8CB2-B464-4C16-A415-933DABD1FD10", User.Identity.Name)
        If String.Compare(Application("App_Type").ToString, "doar", True) = 0 Then
            lstUsers.Items.Add(New ListItem("����", 0))
            Dim currRow As DataRow
            Dim txtValue As String, User1stLetter As String
            Dim oRegEx As Regex
            For Each currRow In ds.Tables(0).Rows
                txtValue = String.Concat(currRow("FullName").ToString(), " ( ", currRow("UserName").ToString(), " ) ")
                lstUsers.Items.Add(New ListItem(txtValue, currRow("SysUserID").ToString()))
            Next
        Else 'for all others
            lstUsers.DataTextField = "FullName"
            lstUsers.DataValueField = "SysUserID"
            lstUsers.DataSource = ds
            lstUsers.DataBind()
        End If

        Dim li As ListItem = lstUsers.Items.FindByValue(strUserID)
        If Not li Is Nothing Then
            li.Selected = True
        Else
            Try
                li = lstUsers.Items(0)
                li.Selected = True
            Catch ex As Exception
            End Try
        End If

        lblBOUserID.ForeColor = Color.Black
        Dim strClinicName As String = ""
        Dim strClinicId As String = ""

        If strUserID = "0" Then
            lblBOUserID.Text = ""
            If lstUsers.SelectedItem.Text = "����" Then
                lblBOUserID.Text = "(����� �����)"
            End If
        Else
            If Not li Is Nothing Then
                Dim strSelectedUserID As String = li.Value
                If Application("App_Type").ToString().ToLower() = "divur" Then
					Dim strCrntUser As String = objUser.GetUserNameByID("C5C4C694-E524-41D3-8ECD-38CE8434FE4B", Val(strSelectedUserID))

                    If strCrntUser <> "" Then

                        objUser.GetClinicAndDoctor("F2D2C32E-6BA0-42C0-BD3C-1E16726B709D", strCrntUser, strClinicId, strClinicName)
                    End If
					If strClinicName <> "" Then
                        '	lblBOUserID.Text = ""
                        'Else
                        'lblBOUserID.Text = " �����: " & strClinicName
                        lblBOUserID.Text = strClinicName
#If Not EngDesign Then
#If Not NewDesign Then

                        If LCase(Application("App_Type").ToString) = "divur" Then
                            tdTitleClinic2.InnerText = strClinicName
                        End If
#End If
#End If
					End If
				Else
					Dim stBoUserID As String = objUser.GetBOUserID("EA533B72-A5A0-453E-94C9-FE210305AFA6", strSelectedUserID)
					If Len(stBoUserID) > 0 Then
#If EngDesign Then
						lblBOUserID.Text = " Back Office User ID: " & stBoUserID
#Else
						lblBOUserID.Text = " ����� ����� ������ ������� : " & stBoUserID
#End If
					Else
#If EngDesign Then
						lblBOUserID.Text = "(Local User)"
#Else
						lblBOUserID.Text = "(����� �����)"
#End If
					End If
                End If
            Else

#If Not EngDesign Then
#If Not NewDesign Then
                objUser.GetClinicAndDoctor("F2D2C32E-6BA0-42C0-BD3C-1E16726B709D", User.Identity.Name, strClinicId, strClinicName)
                If LCase(Application("App_Type").ToString) = "divur" Then
                    tdTitleClinic2.InnerText = strClinicName
                End If

#End If
#End If
            End If


        End If


#If Not NewDesign And Not EngDesign Then
        If LCase(Application("App_Type").ToString) = "divur" Then
            If lstUsers.Items.Count < 2 Then
                tdUsers.Style("display") = "none"
                trTitleRow1.Style("display") = "none"
                trTitleRow2.Style("display") = "block"

            End If
        End If
#End If
        '#If Not NewDesign And Not EngDesign Then
        '		If LCase(Application("App_Type").ToString) = "divur" Then
        '			If lstUsers.Items.Count < 2 Then
        '				tdUsers.Style("display") = "none"
        '			End If
        '		End If
        '#End If
    End Sub

    Private Sub lstUsers_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstUsers.SelectedIndexChanged
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim strUserID As String = lstUsers.SelectedItem.Value
        Session("Report_List_Current_User") = strUserID
        Dim strUserName As String
		If Application("App_Type").ToString().ToLower() = "divur" Then
			strUserName = objUser.GetUserNameByID("C5C4C694-E524-41D3-8ECD-38CE8434FE4B", Val(strUserID))
			Dim strClinicName As String = ""
			If strUserName <> "" Then
				Dim strClinicId As String = ""
				objUser.GetClinicAndDoctor("F2D2C32E-6BA0-42C0-BD3C-1E16726B709D", strUserName, strClinicId, strClinicName)
			End If
			If strClinicName <> "" Then
                '	lblBOUserID.Text = ""
                'Else
                'lblBOUserID.Text = " �����: " & strClinicName
                lblBOUserID.Text = strClinicName
#If Not EngDesign Then
#If Not NewDesign Then
                If LCase(Application("App_Type").ToString) = "divur" Then
                    tdTitleClinic2.InnerText = strClinicName
                End If
#End If
#End If
			End If
		Else
			Dim stBoUserID As String = objUser.GetBOUserID("EA533B72-A5A0-453E-94C9-FE210305AFA6", strUserID)

			If Len(stBoUserID) > 0 Then
				lblBOUserID.ForeColor = Color.Black
#If EngDesign Then
				lblBOUserID.Text = " Back Office User ID: " & stBoUserID
#Else
				lblBOUserID.Text = " ����� ����� ������ ������� : " & stBoUserID
#End If
			Else
				lblBOUserID.ForeColor = Color.Black
#If EngDesign Then
				lblBOUserID.Text = "(Local User)"
#Else
				lblBOUserID.Text = "(����� �����)"
#End If
			End If
        End If
        grdList.CurrentPageIndex = 0
        BindGrid()
        If Application("App_Type").ToString().ToUpper() = "CLAIM" Or Application("App_Type").ToString().ToUpper() = "SUPP" Then
            lstReportType.Items.Clear()
            BindCombo()
        End If


#If NewDesign And Not EngDesign Then
        If Application("HasHani").ToString() = "1" Then
            strUserName = objUser.GetUserNameByID("C5C4C694-E524-41D3-8ECD-38CE8434FE4B", Val(strUserID))
            Session("CompanyLogo") = "pics/" & objUser.GetLogoName("17060B94-065E-4DB4-975D-A3988FFD63CC", strUserName)
            imgLeftPic.Src = Session("CompanyLogo")
        End If
#End If
    End Sub


    Private Sub cboGridRowCount_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboGridRowCount.SelectedIndexChanged
        Dim iGridRowCount As Integer

        If cboGridRowCount.SelectedItem.Value <> "" Then
            iGridRowCount = CInt(cboGridRowCount.SelectedItem.Value)

            Dim objUser As New UserConnect.UserService()
            objUser.Url = Application("UserWebService").ToString()
            ' Session("GridRowCount") = iGridRowCount
            objUser.UpdateGridRowCount("5561A874-D4D7-4E5C-AA3D-4EC0EBAA8B7F", User.Identity.Name, iGridRowCount, User.Identity.Name)

            If iGridRowCount > 0 Then
                grdList.PageSize = iGridRowCount
            End If
            grdList.CurrentPageIndex = 0
            BindGrid()
        End If
    End Sub

    Private Sub grdList_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdList.ItemDataBound
        Dim dgItem As DataGridItem = e.Item
        Dim htmCtrl As System.Web.UI.HtmlControls.HtmlGenericControl
        Dim CtrlAtt As String, tmp1 As String
        Dim tblCell As TableCell
        Select Case (dgItem.ItemType)
            Case ListItemType.Item, ListItemType.AlternatingItem
                tblCell = dgItem.Cells(0)
                'Michal
                If Val(dgItem.Cells(1).Text) < 0 Then
                    dgItem.Cells(1).Text = "0"
                    dgItem.Cells(0).Text = dgItem.Cells(2).Text
                End If
              
                Dim l As Label = tblCell.FindControl("lblSign")
                tmp1 = l.ClientID
                tblCell = dgItem.Cells(1)
                htmCtrl = tblCell.FindControl("keyvalue")
                CtrlAtt = htmCtrl.Attributes("key")
                dgItem.Attributes.Add("onclick", "SelectMe('" + CtrlAtt + "', this, '" + tmp1 + "');")
#If NewDesign And Not EngDesign Then
                dgItem.Attributes.Add("ondblclick", "rowDblClick();")
                dgItem.Attributes.Add("onmouseover", "rowMouseOver(this);")
                tblCell = dgItem.Cells(4)
                tblCell.Attributes.Add("title", "��� ��� ������ ��� ������� �������")
#Else
                dgItem.Attributes.Add("ondblclick", "__doPostBack('cmdReports', '');")
                If Application("App_Type").ToString().ToLower() = "divur" Then
					htmCtrl = tblCell.FindControl("spnLastReport")
					htmCtrl.InnerText = FormatDateTime(dgItem.DataItem("LastReport"))
                End If
#End If

        End Select
    End Sub
	
    Private Function FormatDateTime(ByRef dtDate As Object) As String
        If IsDBNull(dtDate) Then
            Return ""
        Else
            Return Format(dtDate, "dd/MM/yyyy")
        End If
    End Function

    Private Sub grdList_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles grdList.PageIndexChanged
        grdList.CurrentPageIndex = e.NewPageIndex
        BindGrid()
    End Sub

    Private Sub cmdUserProp_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUserProp.ServerClick
        Session("User_Prop_Caller") = "frmRepStat.aspx"
#If NewDesign And Not EngDesign Then
        If Application("HasCB") = "1" Or Application("HasHani").ToString() = "1" Then
            'Response.Redirect("frmUserInfo.aspx")
            Response.Redirect((New Utils).GetLinkForNextForm("frmUserInfo.aspx"))
        Else
            'Response.Redirect("frmUserProp.aspx")
            Response.Redirect((New Utils).GetLinkForNextForm("frmUserProp.aspx"))
        End If
#Else
        'Response.Redirect("frmUserProp.aspx")
        Response.Redirect((New Utils).GetLinkForNextForm("frmUserProp.aspx"))
#End If
    End Sub

    Private Sub cmdReports_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReports.ServerClick
        Session("Report_List_ReportType") = txtReportType.Value
        If Application("App_Type").ToString <> "dist" Then
            Session("Report_List_Current_User") = lstUsers.SelectedItem.Value
        End If
        'Response.Redirect(Application("FORMRepList"))
        Response.Redirect((New Utils).GetLinkForNextForm(Application("FORMRepList")))
    End Sub

    Private Sub cmdLogout_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdLogout.ServerClick
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        objUser.UpdateLastLogout("DD947C22-CFCA-4BD4-A2CD-B9C916B39B28", Session.SessionID, Val(Application("SiteType")))

        FormsAuthentication.SignOut()
        If Application("HKLLDP") <> "" Then
            Response.Redirect("LoginHKL.aspx?out=1")
        Else
            Response.Redirect(Application("FORMLogin"))
        End If
    End Sub

    Private Sub cmdReturn_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.ServerClick
        Dim sURL As String = Session("RepStat_FromPageName") & ""
        If sURL <> "" Then
            Session("RepStat_FromPageName") = ""
            Response.Redirect(sURL)
        Else
            Select Case Application("App_Type").ToString().ToUpper()
                Case "KUPA_INFO"
                    Response.Redirect("KupaInfoMenu.aspx")
                Case "SUPP"                    
                    Response.Redirect(Application("FORMClaimMenu").ToString)
                Case "CLAIM", "ENG"
                    If Application("HKLLDP") <> "" Then
                        Response.Redirect("LoginHKL.aspx?out=1")
                    End If
                    'mesh
                    If Application("HasCB") = "1" Then
                        'Response.Redirect("frmCBMenu.aspx")
                        Response.Redirect((New Utils).GetLinkForNextForm("frmCBMenu.aspx"))
                    ElseIf Application("HasHKL") = "1" Then
                        Response.Redirect("frmHKLMenu.aspx")
                    ElseIf Application("IsDorAlon") = "1" Then
                        If (Session("PrevForm") <> "") Then
                            Response.Redirect(Session("PrevForm"))
                        ElseIf (Session("MainMenu") <> "") Then
                            Response.Redirect(Session("MainMenu"))
                        Else
                            Response.Redirect("frmAlonMenu.aspx")
                        End If
                    Else
                        'Michal
#If EngDesign Then
                    Response.Redirect(Application("FORMLogin"))
#End If
                        If Session("Allow_Action_Type_Upload") = "1" Or Session("Dispatch_Ability") = "1" Or Session("Allow_ForeignWorkers_Claims") = "1" Then
                            Response.Redirect("frmStart.aspx")
                        Else
                            Response.Redirect(Application("FORMLogin"))
                        End If
                    End If

                    'meshend

                Case "DIVUR"
#If EngDesign Then
                    Response.Redirect(Application("FORMLogin"))
#End If
                    Response.Redirect(Application("FORMStart"))

                Case Else
#If EngDesign Then
                Response.Redirect(Application("FORMLogin"))
#Else
                    If Session("Allow_Action_Type_Upload") = "1" Or Session("Dispatch_Ability") = "1" Then
                        Response.Redirect("frmStart.aspx")
                    Else
                        Response.Redirect(Application("FORMLogin"))
                    End If
#End If


            End Select
        End If


    End Sub


    Private Sub SetComboValue(ByRef cbo As DropDownList, ByVal strValue As String)
        Dim li As ListItem = cbo.Items.FindByValue(strValue)
        If Not li Is Nothing Then
            li.Selected = True
        End If
    End Sub

    Private Sub cmdApplyFilter_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdApplyFilter.ServerClick
        If chkFilter.Checked Then
            Session("Filter_On") = "1"
			Dim strDateFrom As String = txtDateFrom.Value
			If Len(strDateFrom) = 0 Then
				strDateFrom = "00000000"
			End If
			Dim strDateTo As String = txtDateTo.Value
			If Len(strDateTo) = 0 Then
				strDateTo = "00000000"
			End If
            Session("Filter_From_Date") = strDateFrom.Replace("/", "")
            Session("Filter_To_Date") = strDateTo.Replace("/", "")
            Dim li As ListItem = lstReportType.SelectedItem
            Dim iReportType As String = 0
            If Not li Is Nothing Then
                iReportType = li.Value
            End If
            Session("Filter_Report_Type") = iReportType
            Session("Report_List_ReportType") = Session("Filter_Report_Type")
            If Application("App_Type").ToString <> "dist" Then
                Session("Report_List_Current_User") = lstUsers.SelectedItem.Value
            End If
            If chkViewed.Checked Then
                Session("Filter_Viewed") = "1"
            Else
                Session("Filter_Viewed") = ""
            End If
            If chkNotViewed.Checked Then
                Session("Filter_NotViewed") = "1"
            Else
                Session("Filter_NotViewed") = ""
            End If
#If NewDesign Then
#If Not EngDesign Then
            Session("Filter_InsuredID") = Trim(txtInshuredID.Value)
            Session("Filter_InsuredName") = Trim(txtName.Value)
#End If
#End If
            'Response.Redirect(Application("FORMRepList"))
            Response.Redirect((New Utils).GetLinkForNextForm(Application("FORMRepList")))
        Else
            Session("Filter_From_Date") = ""
            Session("Filter_To_Date") = ""
            Session("Filter_Report_Type") = ""
            Session("Filter_On") = ""
            Session("Filter_Viewed") = ""
            Session("Filter_NotViewed") = ""
            Session("Filter_InsuredID") = ""
            Session("Filter_InsuredName") = ""
            grdList.CurrentPageIndex = 0
            BindGrid()
        End If
    End Sub

    Private Function XSSCheck(ByVal regExpr As String, ByVal inputValue As String) As Boolean
        Dim result As Boolean = True
        If InStr(1, inputValue, "--") > 0 Then
            Return False
        End If
        If Trim(regExpr) <> "" And Trim(inputValue) <> "" Then
            result = System.Text.RegularExpressions.Regex.IsMatch(inputValue, regExpr)
        End If
        Return result
    End Function

    Private Function CrossCheck() As Boolean
        Dim regExpr As String = Application("RegExpr")
        Dim element As String

        Dim intElement As Integer
        Dim strKey As String
        Dim flag As Boolean = True

        For Each element In Request.Form

            If Left(element, 2) <> "__" Then
                If Not XSSCheck(regExpr, Request.Form(element)) Then
                    flag = False
                    Return flag
                End If
            End If

        Next

        For Each element In Request.QueryString

            If Left(element, 2) <> "__" Then

                If Not XSSCheck(regExpr, Request.QueryString(element)) Then
                    flag = False
                    Return flag
                End If

            End If

        Next
        Return flag
    End Function

    'Protected Overrides Sub OnError(ByVal e As System.EventArgs)
    '    Response.Clear()
    '    Dim strResult As String = "<html><head><meta http-equiv='Content-Type' content='text/html; charset=windows-1255'/></head><body dir=rtl>"
    '    strResult += "<DIV style='font-family:Arial;font-size:16pt;font-weight:bold;width:100%;text-align:center'>����� ��� ����� ������, ��� ��� ����� ����</DIV><BR><DIV style='font-family:Arial;font-size:9pt'>" & txtFormIdentity.Value & "</DIV></body></html>"
    '    Response.Write(strResult)
    '    'Dim ex As Exception = Server.GetLastError
    '    'Response.Write(ex.Message)
    '    Response.End()
    'End Sub

#If NewDesign Then
    Private Sub cmdMenu_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdMenu.ServerClick
        Dim iScreenNum = CInt("0" + hidMenuPar.Value)
        Dim sUrl As String = ""
        Dim sSessionParametrs As String
        Dim sUrlParameters As String
        Dim bOk As Boolean
#If Not EngDesign Then
        Dim menuBuilder As New MenuBuilder()
        bOk = menuBuilder.GetActionParameters(iScreenNum, sUrl, sUrlParameters, sSessionParametrs)
#End If
        If bOk Then
            If (sUrl = "") Then ' do nothing
            Else
                If (sSessionParametrs <> "") Then
                    Dim i As Integer
                    Dim aPairs As String() = sSessionParametrs.Split(";")
                    For i = 0 To aPairs.Length / 2 Step 2
                        Session(aPairs(i).Trim) = aPairs(i + 1).Trim
                    Next

                    If (sUrlParameters <> "") Then
                        sUrl += sUrlParameters
                    End If


                End If
                'Response.Redirect(sUrl)
                Response.Redirect((New Utils).GetLinkForNextForm(sUrl))
            End If
        End If
    End Sub
#End If

End Class
