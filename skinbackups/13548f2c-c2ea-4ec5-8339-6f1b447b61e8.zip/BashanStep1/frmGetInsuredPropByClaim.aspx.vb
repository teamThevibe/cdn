Imports System.Text.RegularExpressions
Public Class frmGetInsuredPropByClaim
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim strRefID As String = Request.Form("hidClaimID")
        Dim strInsuredID As String = ""
        Dim strFirstName As String = "", tmpFirstName As String = ""
        Dim strLastName As String = "", tmpLastName As String = ""
        Dim strPolicyNo As String = ""
        Dim strEmployeeNo As String = ""
        Dim strEmpCD As String = ""
        Dim strTreatment As String = ""
        Dim strCause As String = ""
        Dim strFTooth As String = ""
        Dim strToTooth As String = ""
        Dim strSurface As String = ""
        Dim strInvoice As String = ""
        Dim strAmount As String = ""
        Dim strEntryDate As String = ""
        Dim strRequestType As String = ""
        Dim strClinic As String = ""
        Dim strDocNo As String = ""
        Dim iPolicyNo As Integer = 0
        Dim iGuf As Integer = 0
        Dim strPolGovTreatment As String = ""
        Dim iRetValue As Integer = 0
        Dim bGovermentTreatmnts As Boolean = False
        Dim dt As DateTime
        Dim dsAnswers As DataSet
        Dim currRow As DataRow
        Dim objBoLink As New TreatmentConnect.TreatmentService()
        Dim ds As Data.DataSet
        Dim strTreatmentTypeID As String, strTreatmentDesc As String, strPhotoUnits As String, strXrayB As String, strXrayA As String
        Dim strSmileCode As String = ""
        Dim objTreatmentService As New TreatmentConnect.TreatmentService(), objXML As New System.Text.StringBuilder()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        objBoLink.Url = Application("TreatmentWebService").ToString()
        dsAnswers = objBoLink.GetInsuredPropByReference("C202994D-651F-4D03-8917-C59B30D590A7", strRefID, strFirstName, strLastName, strPolicyNo, strEmployeeNo, strInsuredID)


        Dim strCancelled As String = ""

        'If dsAnswers.Tables("Requests").Rows.Count > 0 Then
        If Utils.Values.GetFirstTableRowsCount(dsAnswers) > 0 Then
            currRow = dsAnswers.Tables("Requests").Rows(0)
            If CType(currRow("RequestID"), Integer) < 1000000000 Then
                If currRow("InsuredID").ToString() <> "1000000000" Then
                    Dim bUserOK As Boolean = True
                    'If Application("CompanyID").ToString = "1" Then
                    '    If UCase(currRow("UserName").ToString()) <> UCase(User.Identity.Name) Then
                    '        bUserOK = False
                    '    End If
                    'End If
                    If bUserOK Then
                        strInsuredID = currRow("InsuredID").ToString()
                        Try
                            iRetValue = objBoLink.GetInsuredPropExt("2C331B73-13D1-4D07-B669-F409BE3CFB58", strInsuredID, tmpFirstName, tmpLastName, iPolicyNo, iGuf, strPolGovTreatment)
                        Catch ex As Exception
                            '
                        End Try

                        If strPolGovTreatment.Trim() = "�" Then
                            bGovermentTreatmnts = True
                        End If

                        strFirstName = NoGeresh(currRow("InsuredFir").ToString())
                        strLastName = NoGeresh(currRow("InsuredFan").ToString())
                        strPolicyNo = currRow("PolicyNo").ToString()
                        strEmployeeNo = currRow("EmployeeNo").ToString()
                        strTreatment = currRow("Treatment").ToString()
                        If Application("Smile") = "1" Then
                            ds = objTreatmentService.GetSingleTreatmentByID("86E85219-7BF1-4FEC-AA5B-43C05F9E3424", CInt(strTreatment))
                            If (ds.Tables(0).Rows.Count > 0) Then
                                strSmileCode = ds.Tables(0).Rows(0).Item("SmileTreatmentID").ToString()
                            End If
                        ElseIf bGovermentTreatmnts Then
                            ds = objTreatmentService.GetSingleTreatmentByID("86E85219-7BF1-4FEC-AA5B-43C05F9E3424", CInt(strTreatment))
                            If (ds.Tables(0).Rows.Count > 0) Then
                                strSmileCode = ds.Tables(0).Rows(0).Item("GovTreatmentID").ToString()
                            End If
                            If strSmileCode = "" Then
                                strSmileCode = strTreatment
                            End If
                        Else
                            strSmileCode = strTreatment
                        End If
                        strCause = currRow("Cause").ToString()
                        strFTooth = currRow("FTooth").ToString()
                        strToTooth = currRow("ToTooth").ToString()
                        strSurface = currRow("Surface").ToString()
                        strInvoice = currRow("Invoice").ToString()
                        strAmount = currRow("Amount").ToString()
                        If IsDBNull(currRow("FinishDate")) Then
                            strEntryDate = "00000000"
                        Else
                            dt = Convert.ToDateTime(currRow("FinishDate"))
                            strEntryDate = dt.ToString("ddMMyyyy")
                        End If
                        strRequestType = currRow("RequestTyp").ToString()
                        strClinic = currRow("ClinicNo").ToString()
                        strDocNo = currRow("DocNo").ToString()
                    End If
                Else
                    strCancelled = "����� �����, �� ����� ����� �����"
                End If
            End If
        End If
        Dim objResult As New System.Text.StringBuilder()
        objResult.Append("<HTML><HEAD><TITLE></TITLE>")
        objResult.Append("<meta http-equiv='Cache-Control' content='no-cache'>" & vbCrLf)
        objResult.Append("<meta http-equiv='Pragma' content='no-cache'>" & vbCrLf)
        objResult.Append("<meta http-equiv='Expires' content='0'>" & vbCrLf)
        objResult.Append("<META http-equiv='Content-Type' content='text/html; charset=windows-1255'>")
        objResult.Append("</HEAD>")
        objResult.Append("<BODY>")
        objXML.Append("<?xml version=" & Chr(34) & "1.0" & Chr(34) & " encoding=" & Chr(34) & "Windows-1255" & Chr(34) & "?><recordset>")
        objResult.Append("<INPUT type='hidden' id='txtInsuredID' value='" & strInsuredID & "'>")
        objResult.Append("<INPUT type='hidden' id='txtFirstName' value='" & strFirstName & "'>")
        objResult.Append("<INPUT type='hidden' id='txtLastName' value='" & strLastName & "'>")
        objResult.Append("<INPUT type='hidden' id='txtPolicyNo' value='" & strPolicyNo & "'>")
        objResult.Append("<INPUT type='hidden' id='txtEmployeeNo' value='" & strEmployeeNo & "'>")
        objResult.Append("<INPUT type='hidden' id='txtTreatment' value='" & strTreatment & "'>")
        objResult.Append("<INPUT type='hidden' id='txtSmileCode' value='" & strSmileCode & "'>")
        objResult.Append("<INPUT type='hidden' id='txtCause' value='" & strCause & "'>")
        objResult.Append("<INPUT type='hidden' id='txtFTooth' value='" & strFTooth & "'>")
        objResult.Append("<INPUT type='hidden' id='txtToTooth' value='" & strToTooth & "'>")
        objResult.Append("<INPUT type='hidden' id='txtSurface' value='" & strSurface & "'>")
        objResult.Append("<INPUT type='hidden' id='txtInvoice' value='" & strInvoice & "'>")
        objResult.Append("<INPUT type='hidden' id='txtAmount' value='" & strAmount & "'>")
        objResult.Append("<INPUT type='hidden' id='txtEntryDate' value='" & strEntryDate & "'>")
        objResult.Append("<INPUT type='hidden' id='txtRequestType' value='" & strRequestType & "'>")
        objResult.Append("<INPUT type='hidden' id='txtClinic' value='" & strClinic & "'>")
        objResult.Append("<INPUT type='hidden' id='ctlDocNo' value='" & strDocNo & "'>")
        objResult.Append("<INPUT type='hidden' id='txtCancelled' value='" & strCancelled & "'>")
        objResult.Append("<INPUT type='hidden' id='txtComboType' value='3'>")
        Dim strTreatmentValue As String = ""
        objResult.Append("<SELECT id='oSelect'>")
        If Trim(strTreatment) <> "" Then

            ds = objTreatmentService.GetTreatmentsByIDWithOrder("A7BEA283-6FFB-4D53-9598-CBB1745CA20A", CInt(strTreatment), 0)

            If (ds.Tables(0).Rows.Count > 0) Then
                strTreatmentValue = ds.Tables(0).Rows(0).Item("TreatmentTypeID").ToString()
            End If
            If bGovermentTreatmnts Then
                FillComboboxTreatmentGov("TreatmentID", "GovTreatmentDescription", ds, objResult, strTreatment)
            Else
                FillComboboxTreatment("TreatmentID", "Treatment", ds, objResult)
            End If
            objResult.Append("</SELECT>")
            objResult.Append("<SELECT id='oAttachSelect'>")
            If strTreatmentValue <> "" Then
                ds = objTreatmentService.GetAttachTypes("34E108A0-761B-4AD9-B226-61227A144F2F", CInt(strTreatmentValue))
                FillCombobox("AttachID", "AttachName", ds, objResult)
            End If
        End If
        objResult.Append("</SELECT>")
        objResult.Append("<SELECT id='oSelect1'>")
        If Trim(strTreatment) <> "" Then
            ds = objTreatmentService.GetCauses("CD6AEA9F-C78F-4942-A749-38C16DE0AA62", CInt(strTreatment))
            FillCombobox("CauseID", "Cause", ds, objResult)
            ds = objTreatmentService.GetTeethRange("DAD91AA1-DE6F-4C28-8A11-CB0FF79BD302", CInt(strTreatment))
            'FillXML(ds, objXML)
            'objTreatmentService.GetTreatmentTypeByID("7FC19103-F277-4D28-B445-60C4999DB7E5", CInt(strTreatment), strTreatmentTypeID, strTreatmentDesc, strPhotoUnits, strXrayB, strXrayA)
            'ds = objTreatmentService.GetTeethRange("DAD91AA1-DE6F-4C28-8A11-CB0FF79BD302", CInt(strTreatment))
            FillXML(ds, objXML)
        End If
        objXML.Append("</recordset>")
        objResult.Append("</SELECT>")
        objResult.Append("<INPUT type='hidden' id='txtTreatmentValue' value='" & strTreatmentValue & "'>")
        objResult.Append("<INPUT type='hidden' id='txtTeethRange' value='" & objXML.ToString() & "'>")
        objResult.Append("<INPUT type='hidden' id='hidGovTreatments' value='" & IIf(bGovermentTreatmnts, "1", "") & "'>")

        objResult.Append("<SCRIPT>")
        objResult.Append("	window.parent.document.all.oNotificationClaim.value = 'OK';")
        objResult.Append("</SCRIPT>")
        objResult.Append("</BODY>")
        objResult.Append("</HTML>")
        Response.Write(objResult.ToString())
    End Sub

    Private Sub FillCombobox(ByVal strValueField As String, ByVal strDescField As String, ByRef ds As Data.DataSet, ByRef objResult As System.Text.StringBuilder)
        Dim currRow As Data.DataRow
        objResult.Append("<OPTION value='0'>���...</OPTION>")
        For Each currRow In ds.Tables(0).Rows
            objResult.Append("<OPTION value='" & currRow(strValueField).ToString() & "'>" & currRow(strDescField).ToString() & "</OPTION>")
        Next
    End Sub

    Private Sub FillComboboxTreatment(ByVal strValueField As String, ByVal strDescField As String, ByRef ds As Data.DataSet, ByRef objResult As System.Text.StringBuilder)
        Dim currRow As Data.DataRow
        Dim strSmileTreatmentID As String = ""
        Dim bSmile As Boolean = CBool(Application("Smile") = "1")
        Dim bGovTreatments As Boolean = CBool(Application("GovernmentTreatments") = "1")
        objResult.Append("<OPTION value='0' DefaultRange='0' DefaultFromTooth='0' DefaultToTooth='0' SmileCode='0'>���...</OPTION>")
        For Each currRow In ds.Tables(0).Rows
            If bSmile Then
                strSmileTreatmentID = currRow("SmileTreatmentID").ToString()
            ElseIf bGovTreatments Then
                strSmileTreatmentID = currRow("GovTreatmentID").ToString()
            Else
                strSmileTreatmentID = currRow(strValueField).ToString()
            End If

            If (Not bGovTreatments) Or (bGovTreatments And strSmileTreatmentID <> "") Then
                objResult.Append("<OPTION value='" & currRow(strValueField).ToString() & "' DefaultRange='" & currRow("DefaultTeethRange").ToString() & "' DefaultFromTooth='" & currRow("DefaultFromTooth").ToString() & "' DefaultToTooth='" & currRow("DefaultToTooth").ToString() & "' SmileCode='" & strSmileTreatmentID & "'>" & currRow(strDescField).ToString() & "</OPTION>")
            End If
        Next
    End Sub

    Private Sub FillComboboxTreatmentGov(ByVal strValueField As String, ByVal strDescField As String, ByRef ds As Data.DataSet, ByRef objResult As System.Text.StringBuilder, ByVal strRequestTreatmentID As String)
        Dim currRow As Data.DataRow
        Dim strGovTreatmentID As String = ""
        Dim strTreatmentID As String
        Dim bGovTreatments As Boolean = CBool(Application("GovernmentTreatments") = "1")
        objResult.Append("<OPTION value='0' DefaultRange='0' DefaultFromTooth='0' DefaultToTooth='0' SmileCode='0'>���...</OPTION>")
        For Each currRow In ds.Tables(0).Rows
            strGovTreatmentID = currRow("GovTreatmentID").ToString().Trim()
            strTreatmentID = currRow("TreatmentID").ToString()

            If (strGovTreatmentID <> "") Then
                objResult.Append("<OPTION value='" & currRow(strValueField).ToString() & "' DefaultRange='" & currRow("DefaultTeethRange").ToString() & "' DefaultFromTooth='" & currRow("DefaultFromTooth").ToString() & "' DefaultToTooth='" & currRow("DefaultToTooth").ToString() & "' SmileCode='" & strGovTreatmentID & "'>" & currRow(strDescField).ToString() & "</OPTION>")
            ElseIf (strGovTreatmentID = "" And strRequestTreatmentID = strTreatmentID) Then
                objResult.Append("<OPTION value='" & currRow(strValueField).ToString() & "' DefaultRange='" & currRow("DefaultTeethRange").ToString() & "' DefaultFromTooth='" & currRow("DefaultFromTooth").ToString() & "' DefaultToTooth='" & currRow("DefaultToTooth").ToString() & "' SmileCode='" & strTreatmentID & "'>" & currRow("Treatment").ToString() & "</OPTION>")
            End If
        Next
    End Sub

    Private Sub FillXML(ByRef ds As Data.DataSet, ByRef objResult As System.Text.StringBuilder)
        Dim currRow As Data.DataRow
        For Each currRow In ds.Tables(0).Rows
            objResult.Append("<range from=" & Chr(34) & currRow("FromTooth").ToString() & Chr(34) & " to=" & Chr(34) & currRow("ToTooth").ToString() & Chr(34) & " allow=" & Chr(34) & currRow("AllowTeethRange").ToString() & Chr(34) & "/>")
        Next
    End Sub

    Function NoGeresh(ByVal sStr As String) As String
        Dim sRes As String = sStr
        'sRes = Replace(sRes, "'", "&acute;")
        sRes = Replace(sRes, "'", "&apos;")
        sRes = Replace(sRes, """", "&quot;")

        Return sRes
    End Function


End Class
