Imports System.Web.Security
Public Class frmUpdateDoctor
    Inherits System.Web.UI.Page
    Protected WithEvents tdPageMsg As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents txtDoctorID As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtDoctorLName As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtDoctorFName As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents cmdLogout As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdUpdate As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdNext As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents aIconlink As System.Web.UI.HtmlControls.HtmlAnchor
    Protected WithEvents cmdHelp As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents aIconlink2 As System.Web.UI.HtmlControls.HtmlAnchor
    Protected WithEvents divRIcon As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents txtError As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidDataChecked As System.Web.UI.HtmlControls.HtmlInputHidden

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim iType As Integer = Request.QueryString("Type")
        If Not IsPostBack Then
            If Application("RightLogo") = "1" Then
#If NewDesign Then
                tdRightPic.Attributes("background") = "pics/BannerTopRightTransp.gif"
                imgRightPic.Attributes("src") = "pics/BannerTopRightTransp.gif"
#End If
                divRIcon.Visible = True
            Else
#If NewDesign Then
                tdRightPic.Attributes("background") = "pics/BannerTopRightPic.gif"
                imgRightPic.Attributes("src") = "pics/BannerTopRightPic.gif"
#End If
                divRIcon.Visible = False
            End If
#If Not NewDesign Then
            divRIcon.Visible = False
#End If
            cmdHelp.Visible = False

            If iType = "1" Then
                'cmdNext.Disabled = True
                hidDataChecked.Value = "0"
                tdPageMsg.InnerHtml = "�� ����� ���� �����. ����� �� ����� �� ������ ����."
            Else
                tdPageMsg.InnerHtml = "�� ��� ������� ���� ������ �&quot;� ���� �� ������ ����." & "<BR>" & "�� ������ ���� ������ �� ��� ����� ����� ���� �� ������ ����."
                hidDataChecked.Value = "1"
            End If

            FillDoctorDetails()

        End If
    End Sub

    Private Sub FillDoctorDetails()
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim strDoctorCareName As String
        Dim strDoctorLName As String
        Dim strDoctorFName As String
        Dim strDoctorCareNumber As String
        Dim strClinicNumber As String
        Dim strClinicName As String
        Dim strUserType As String
        Dim strFName As String
        Dim strLName As String
        Dim strStreet As String
        Dim strHouse As String
        Dim strCity As String
        Dim strZIP As String
        Dim strPhone As String
        Dim strMobile As String
        Dim strFax As String
        Dim strEMail As String
        Dim strCFName As String
        Dim strCLName As String
        Dim strCStreet As String
        Dim strCHouse As String
        Dim strCCity As String
        Dim strCZIP As String
        Dim strCPhone As String
        Dim strCMobile As String
        Dim strCFax As String
        Dim strCEMail As String
        Dim strBank As String
        Dim strBranch As String
        Dim strAccount As String
        Dim strMailStreet As String
        Dim strMailPhone As String
        Dim strMailHouse As String
        Dim strMailEMail As String
        Dim strMailCity As String
        Dim strMailZIP As String
        Dim strService1 As String
        Dim strService2 As String
        Dim strService3 As String
        Dim strService4 As String
        Dim strService5 As String
        Dim strService6 As String
        Dim strProf1 As String
        Dim strProf2 As String
        Dim strProf3 As String
        Dim strProf4 As String
        Dim strProf5 As String
        Dim strClinicID As String
        Dim strDoctorID As String
        Dim strSupplierID As String
        Dim strSection As String
        Dim strCare As String
        Dim strGridRowCount As String
        Dim iSection As Integer = -1
        Dim iSupplierID As Integer

        objUser.GetProperties("305A57FB-F38A-4592-AA8E-882D66B1DEFC", User.Identity.Name, strUserType, strFName, strLName, strStreet, strHouse, strCity, strZIP, strPhone, strMobile, strFax, strEMail, _
                              strCFName, strCLName, strCStreet, strCHouse, strCCity, strCZIP, strCPhone, strCMobile, strCFax, strCEMail, _
                              strBank, strBranch, strAccount, strMailStreet, strMailPhone, strMailHouse, strMailEMail, strMailCity, strMailZIP, _
                              strService1, strService2, strService3, strService4, strService5, strService6, strProf1, strProf2, strProf3, strProf4, _
                              strProf5, strClinicID, strClinicName, strDoctorID, strSupplierID, strSection, strCare, strGridRowCount, "", "")

        If strDoctorID Is DBNull.Value Then
            txtDoctorID.Value = ""
        Else
            If Val(strDoctorID) = 0 Then
                txtDoctorID.Value = ""
            Else
                txtDoctorID.Value = strDoctorID
            End If
        End If


        txtDoctorFName.Value = strFName
        txtDoctorLName.Value = strLName

    End Sub

    Private Sub cmdLogout_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdLogout.ServerClick
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        objUser.UpdateLastLogout("DD947C22-CFCA-4BD4-A2CD-B9C916B39B28", Session.SessionID, Val(Application("SiteType")))

        FormsAuthentication.SignOut()
        Response.Redirect("Login.aspx")
    End Sub

    Private Sub cmdUpdate_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUpdate.ServerClick
        'Dim fResult As Boolean
        'Dim objUser As New UserConnect.UserService()
        'objUser.Url = Application("UserWebService").ToString()

        'fResult = objUser.UpdateDoctorDetails("BCB5534F-357A-414B-972C-B2CD84FFBCE5", User.Identity.Name, Val(txtDoctorID.Value), txtDoctorFName.Value.Trim(), txtDoctorLName.Value.Trim())
        'If fResult Then
        '    txtError.Value = "���� ����� ������ ������"
        '    cmdNext.Disabled = False
        'Else
        '    txtError.Value = "����� ���� ����� ����"
        'End If
    End Sub

    Function UpdateData() As Boolean
        Dim fResult As Boolean
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

        fResult = objUser.UpdateDoctorDetails("BCB5534F-357A-414B-972C-B2CD84FFBCE5", User.Identity.Name, Val(txtDoctorID.Value), txtDoctorFName.Value.Trim(), txtDoctorLName.Value.Trim())
        If fResult Then
            'txtError.Value = "���� ����� ������ ������"
            Return True
        Else
            'txtError.Value = "����� ���� ����� ����"
            Return False
        End If
    End Function

    Private Sub cmdNext_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdNext.ServerClick
        If Not UpdateData() Then
            txtError.Value = "���� ����� ������ ������"
            Return
        End If

        Dim fResult As Boolean
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

        fResult = objUser.UpdateDoctorCheckDate("461FD5B6-9A6D-42CD-90A3-AB7753107E01", User.Identity.Name)
        Dim bIndependent As Boolean
        Dim bAllowClaims As Boolean
        Dim bWebInterfaceAllow As Boolean
        Dim bWebServiceAllow As Boolean
        objUser.GetBashanUserPermitions("83EC08DB-E750-45BA-8F6D-B4B6BF76D018", User.Identity.Name, bIndependent, bAllowClaims, bWebInterfaceAllow, bWebServiceAllow)
        If bIndependent Then
            Session("BSHN_Independed") = "1"
        Else
            Session("BSHN_Independed") = ""
        End If
        If Session("User_Login_First_Time") = "1" Then
            Response.Redirect("frmUserProp.aspx")
        Else
            Response.Redirect("frmStart.aspx")
        End If
    End Sub


End Class
