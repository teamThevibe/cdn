﻿Imports System.Web.Security
Imports System.Drawing
Imports System.Text.RegularExpressions


Public Class frmHDRepList
    Inherits System.Web.UI.Page


    Protected WithEvents gridOccasional As System.Web.UI.WebControls.DataGrid
    Protected WithEvents cmdExit As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents hidAfterShowReport As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents chkIfPrint As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents txtOccasionalID As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFNameOccasional As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtLNameOccasional As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtPhoneOccasional As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtMailOccasional As System.Web.UI.HtmlControls.HtmlInputText
    Protected igRepIDSupportRequests As Integer

    Dim g_fAllowUserSelect As Boolean
    Dim arrChksSize As Integer = 300
    Dim arrChksValues(299) As String
    Dim filterFlag As Boolean = False

    Protected WithEvents sp1 As System.Web.UI.HtmlControls.HtmlGenericControl

    Dim bShowFilterMessage As Boolean = False

    Private Const col_grdList_ReferenceNo As Integer = 18
    Private Const col_grdList_Icons As Integer = 17
    Private Const col_grdList_Bruto As Integer = 16
    Private Const col_grdList_ValidDate As Integer = 15
    Private Const col_grdList_ViewDate As Integer = 14
    Private Const col_grdList_EntryDate As Integer = 13
    Private Const col_grdList_FinishDate As Integer = 12
    Private Const col_grdList_ToTooth As Integer = 11
    Private Const col_grdList_FTooth As Integer = 10
    Private Const col_grdList_TreatmentDesc As Integer = 9
    Private Const col_grdList_Treatment As Integer = 8
    Private Const col_grdList_RequestTyp As Integer = 7
    Private Const col_grdList_Reference As Integer = 6
    Private Const col_grdList_CheckType As Integer = 5
    Private Const col_grdList_LName As Integer = 4
    Private Const col_grdList_FName As Integer = 3
    Private Const col_grdList_InsuredID As Integer = 2
    Private Const col_grdList_RepName As Integer = 1
    Private Const col_grdList_Select As Integer = 0

    Dim showDateRange As Boolean = True


#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.

        InitializeComponent()

    End Sub

#End Region



    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


        Dim iSugDivuach As Integer = 0

        DirectCast(Me.Master, HDMasterPage).SetInterActive(iSugDivuach)

        Session.Remove("GetDataForHDReportDailyRequests")

        Session("ExternalLink") = ""

        Dim bAllowUserMultyReportsPermition As Boolean

        ReDim arrChksValues(arrChksSize - 1)

        If Application("App_Type").ToString().ToLower() = "doar" Then

            cmdPrint.Visible = True

        Else

        End If

        If Application("IsPool") & "" = "1" Then
            cmdUserProp.Visible = False
        End If

        If Application("ShowInterActiveReport").ToString = "1" Then
            Me.hidShowInterActiveReport.Value = "1"
        Else
            Me.hidShowInterActiveReport.Value = "0"
        End If

        If Application("SearchByRepName").ToString = "1" Then
            Me.SearchByRepName.Value = "1"
        Else
            Me.SearchByRepName.Value = "0"
        End If


        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()


        Dim iGridRowCount As Integer
        Dim strAllowUserSelect As String
        'Chk Prm
        If Application("App_Type").ToString.ToUpper() = "SUPP" Then
            If Session("SUPP_AllowClaims") <> "1" And Session("SUPP_AllowClaims") <> "1" And Session("SUPP_HospitalClaim") <> "1" And Session("SUPP_ReportGeneration") <> "1" Then
                objUser.AddUserIllegalAction("24304391-6FDE-4237-A9B6-49630958EB26", User.Identity.Name, "frmRepList")
                Response.Redirect(Application("FORMLogin"))
            End If
        Else
            If Session("WebInterfaceAllow") <> "1" Then
                objUser.AddUserIllegalAction("24304391-6FDE-4237-A9B6-49630958EB26", User.Identity.Name, "frmRepList")
                Response.Redirect(Application("FORMLogin"))
            End If
        End If


        'Get Clinic
        iGridRowCount = objUser.GetGridRowCount("9CDE451A-D418-40EC-9588-64CA4592AC55", User.Identity.Name)

        tdGridRowCount.Visible = False


        Select Case Application("App_Type").ToString().ToLower()
            Case "dist", "claim", "supp", "eng", "doar"

            Case "divur"
                grdListNew.PagerStyle.HorizontalAlign = HorizontalAlign.Right
                tdGridRowCount.Visible = True
                If Not IsPostBack Then
                    Dim arrValues() As Integer = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15}
                    cboGridRowCount.DataSource = arrValues
                    cboGridRowCount.DataBind()
                    cboGridRowCount.SelectedIndex = iGridRowCount - 1


                End If

        End Select

        If Application("App_Type").ToString = "dist" Then
            g_fAllowUserSelect = False
        Else
            strAllowUserSelect = objUser.GetUserSelectPermition("5CF99E07-9412-400C-89C9-6391758C6098", User.Identity.Name)

            If strAllowUserSelect <> "" Then
                If strAllowUserSelect = "1" Then
                    g_fAllowUserSelect = True
                Else
                    g_fAllowUserSelect = False
                End If
            Else
                g_fAllowUserSelect = True

            End If
        End If

        If Not g_fAllowUserSelect Then
            lstUsers.Visible = False
        Else
            lstUsers.Visible = True
        End If

        If Not IsPostBack Then

            Dim strUserName As String = objUser.GetUserFullName("3371F4F5-F671-4B9D-A054-A4232D3D2177", User.Identity.Name)
            Session("Message_Text") = "שם משתמש: " & strUserName


            txtServerDate.Value = Format(DateTime.Today, "dd/MM/yyyy")
            If Session("User_Login_First_Time") = "1" Then

                Response.Redirect("frmUserProp.aspx")

            End If

            lblMessage.Text = CEncode.StringEncode(Session("Message_Text"))

            If Session("Filter_On") = "1" Then

                If Session("Filter_InsuredID") <> "" Then
                    txtInshuredID.Value = Session("Filter_InsuredID")
                End If

                If Session("Filter_From_Date") <> "" Then
                    txtFromDate.Value = Session("Filter_From_Date")

                Else
                    txtFromDate.Value = "00000000"

                End If
                If Session("Filter_To_Date") <> "" Then
                    txtToDate.Value = Session("Filter_To_Date")

                Else
                    txtToDate.Value = "00000000"

                End If
                chkFilter.Checked = True
                If Session("Filter_Viewed") <> "" Then
                    chkViewed.Checked = True

                Else
                    chkViewed.Checked = False

                End If
                If Session("Filter_NotViewed") <> "" Then
                    chkNotViewed.Checked = True

                Else
                    chkNotViewed.Checked = False

                End If

            Else

                If Application("SearchByRepName").ToString = "1" Then
                    txtKoteret.Value = ""
                End If

                chkViewed.Checked = True
                chkNotViewed.Checked = True

                txtFromDate.Value = "00000000"
                txtToDate.Value = "00000000"
            End If
            Dim col As BoundColumn
            Dim colExcel As BoundColumn


            If LCase(Application("App_Type").ToString) = "supp" Then
                col.DataField = "ClaimNumber"

            End If


            If Application("App_Type").ToString = "dist" Then

                If Session("Allow_Action_Type_Upload") = "1" Then
                    cmdReturnMenu.Visible = True
                Else
                    cmdReturnMenu.Visible = False
                End If

                ctlTitle.InnerText = "רשימת קבצי מידע"

                lstUsers.Visible = False
                lblBOUserID.Visible = False
                lblClinic.Visible = False

                tdDistTitle.InnerText = "רשימת קבצי מידע"

                tdDistTitle.Width = "100%"
                tdDistTitle.Style("text-align") = "center"

            Else

                ctlTitle.InnerText = "רשימת דוחות"

                If LCase(Application("App_Type").ToString) = "divur" Then


                    tdDistTitle.InnerText = ""
                Else
                    tdDistTitle.Style("text-align") = "left"
                End If


                If Application("App_Type").ToString().ToLower() = "doar" Then

                    cmdReturnMenu.Value = "יציאה"
                    cmdReturnMenu.Attributes("onclick") = "window.close();return;"

                End If

                If Application("App_Type").ToString().ToLower() = "claim" Then
                    If Session("Allow_Action_Type_Upload") = "1" Then
                        cmdReturnMenu.Visible = True
                    Else
                        cmdReturnMenu.Visible = False
                    End If
                End If

                BindUsers()

            End If

            Dim strClinicId As String = ""
            Dim strClinicName As String = ""
            Dim strCrntUser = CEncode.StringEncode(objUser.GetUserNameByID("C5C4C694-E524-41D3-8ECD-38CE8434FE4B", Val(lstUsers.SelectedItem.Value)))
            If strCrntUser = "" Then
                strCrntUser = User.Identity.Name
            End If
            Session("CrntUser") = strCrntUser
            objUser.GetClinicAndDoctor("F2D2C32E-6BA0-42C0-BD3C-1E16726B709D", strCrntUser, strClinicId, strClinicName)
            ''''''''''''''''''''''objUser.GetHDClinicIdAndClinicName("BE25C36A-51E8-11E4-B3E7-C79B1D5D46B0", strCrntUser, strClinicId, strClinicName)

            lblClinic.Text = strClinicName

            tdTitleClinic2.InnerText = strClinicName


            Dim objSysTables As New ReportConnect.ReportService()
            objSysTables.Url = Application("ReportWebService").ToString()
            Dim iTableType As Integer
            Dim iReportType As Integer
            Dim iDrawerUsage As Integer

            If IsNumeric(Session("Report_List_ReportType")) Then

                iReportType = CInt(Session("Report_List_ReportType"))

                If iReportType > 0 Then

                    txtReportType.Value = iReportType.ToString().Trim

                    If LCase(Application("App_Type").ToString) = "divur" Then
                        lblReportType.Text = objSysTables.GetReportTypeName("56697E9B-C6F6-45A5-9BFA-AA3647AB62F0", iReportType)
                    Else
                        lblReportType.Text = "מסוג:" & " " & objSysTables.GetReportTypeName("56697E9B-C6F6-45A5-9BFA-AA3647AB62F0", iReportType)
                    End If


                    Dim sMainTitle As String = "מערכת הוד - " & lblReportType.Text
                    CType(Master.FindControl("MainTitle"), Literal).Text = sMainTitle
                    Page.Title = sMainTitle


                    iTableType = objSysTables.GetReportTableType("936C27EF-1292-4EE3-9A38-5FD2F124FC14", iReportType)

                    iDrawerUsage = objSysTables.GetReportDrawerUsage("2C0B75D2-5826-108E-9D19-5654572E1C86", iReportType)

                    If LCase(Application("App_Type").ToString) = "supp" Or LCase(Application("App_Type").ToString) = "divur" Then
                        Dim MaxRequestRepDays As Integer = objSysTables.GetMaxRequestRepDays("142D997D-42C5-4BC8-ADA4-4D9A95A94F0A")
                        If MaxRequestRepDays > 0 And MaxRequestRepDays < 366 Then
                            hidMaxRequestRepDays.Value = MaxRequestRepDays
                        Else
                            hidMaxRequestRepDays.Value = 30
                        End If
                    End If

                    If LCase(Application("App_Type").ToString) = "supp" Then


                    End If
                Else
                    lblReportType.Text = ""
                    iTableType = 0
                End If
            Else
                lblReportType.Text = ""
                iTableType = 0
            End If

            cmdHdReportDailyConsultations.Visible = False
            cmdHdReportDailyRequests.Visible = False
            cmdHdReportDailyAccount.Visible = False

            If Application("App_Type").ToString = "divur" And ((iReportType = 500) Or (iReportType = 510)) Then
                cmdReportClaims.Visible = True

            ElseIf Application("App_Type").ToString = "divur" And iReportType = 41 Then


                If Application("ShowInterActiveReport").ToString = "1" Then

                    cmdHdReportDailyConsultations.Visible = True

                End If



            ElseIf Application("App_Type").ToString = "divur" And iReportType = 11 Then


                If Application("ShowInterActiveReport").ToString = "1" Then


                    cmdHdReportDailyRequests.Visible = True

                End If


            ElseIf Application("App_Type").ToString = "divur" And iReportType = 10 Then


                If Application("ShowInterActiveReport").ToString = "1" Then


                    cmdHdReportDailyAccount.Visible = True

                End If


            ElseIf Application("App_Type").ToString = "supp" And iReportType = 90001 Then
                cmdReportClaims.Visible = False

            ElseIf Application("App_Type").ToString = "supp" And iReportType = 90000 Then
                cmdReportClaims.Visible = False


            ElseIf Application("App_Type").ToString = "supp" And iReportType = 90013 Then

                cmdReportClaims.Visible = False

            Else
                cmdReportClaims.Visible = False
 
            End If


            txtTableType.Value = iTableType.ToString()


            If iGridRowCount > 0 Then

                If Application("App_Type").ToString = "divur" Then
                    grdListNew.PageSize = iGridRowCount
                Else
                End If


            End If

            If Application("Paging") = "1" Then

                If Application("App_Type").ToString = "divur" Then
                    grdListNew.AllowCustomPaging = True
                Else
                End If

            End If


            If Application("App_Type").ToString = "divur" Then
                grdListNew.Visible = True
            Else
                grdListNew.Visible = False
            End If

            '*******************
            '*******************
            BindGrid()
            '*******************
            '*******************

        End If


        If IsPostBack Then

            If hidAfterShowReport.Value = "1" Then
                hidAfterShowReport.Value = ""

                '*******************
                '*******************
                BindGrid()
                '*******************
                '*******************


            End If
        Else
            hidAfterShowReport.Value = ""
        End If


        If Not IsPostBack Then

            cmdReturnConsultation.Visible = False

            If Session("From_Consultation") = "1" Or Session("From_Consultation") = "2" Or Session("From_Consultation") = "3" Then
                If Session("From_Consultation") = "1" Then
                    Session("BackUrl") = Utils.Navigation.GetURL("frmRequestt.aspx")
                End If

                If Session("From_Consultation") = "2" Then
                    Session("BackUrl") = "frmHDTRequestt.aspx"
                End If
                Session("From_Consultation") = ""
                cmdReturnConsultation.Visible = True
                cmdReturnMenu.Disabled = True
                cmdReturn.Disabled = True
                cmdUserProp.Disabled = True

            End If

        End If



        lstUsers.Style("display") = "none"

    End Sub

    Private Sub cboGridRowCount_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboGridRowCount.SelectedIndexChanged
        Dim iGridRowCount As Integer

        If cboGridRowCount.SelectedItem.Value <> "" Then
            iGridRowCount = CInt(cboGridRowCount.SelectedItem.Value)

            Dim objUser As New UserConnect.UserService()
            objUser.Url = Application("UserWebService").ToString()
            objUser.UpdateGridRowCount("5561A874-D4D7-4E5C-AA3D-4EC0EBAA8B7F", User.Identity.Name, iGridRowCount, User.Identity.Name)

            If Val(txtTableType.Value) <> 13 Then
                If iGridRowCount > 0 Then
                    Me.grdListNew.PageSize = iGridRowCount
                End If
                grdListNew.CurrentPageIndex = 0
            Else
                If iGridRowCount > 0 Then
                    gridOccasional.PageSize = iGridRowCount
                End If
                gridOccasional.CurrentPageIndex = 0
            End If

            '*******************
            '*******************
            BindGrid()
            '*******************
            '*******************



        End If
    End Sub

    Private Sub BindGridExcel()
        Dim objReportsList As New ReportConnect.ReportService()
        objReportsList.Url = Application("ReportWebService").ToString()
        Dim iReportType As Integer
        Dim strFromDate As String
        Dim strToDate As String
        Dim bViewed As Boolean
        Dim bNotViewed As Boolean
        Dim strInsuredID As String, strName As String
        Dim iTableType As Integer

        Dim dsAdd As DataSet
        Dim iCountMore As Integer = 0
        Dim MaxRecNo As Integer = 200
        Dim bPaging As Boolean = IIf(Application("Paging") = "1", True, False)
        Dim strKoteret As String


        If IsNumeric(Session("Report_List_ReportType")) Then
            iReportType = CInt(Session("Report_List_ReportType"))
            iTableType = CInt(txtTableType.Value)
        Else
            iReportType = 0
            iTableType = 0
        End If

        If chkFilter.Checked Then
            strFromDate = Trim(Utils.GetYYYYMMDDString(txtFromDate.Value.Replace("/", "")))
            strToDate = Trim(Utils.GetYYYYMMDDString(txtToDate.Value.Replace("/", "")))
            bViewed = chkViewed.Checked
            bNotViewed = chkNotViewed.Checked

            If Application("SearchByRepName").ToString = "1" Then
                strKoteret = Me.txtKoteret.Value
            End If

            If iTableType > 0 Then
                strInsuredID = txtInshuredID.Value
                strName = txtName.Value
            Else
                If Application("App_Type").ToString = "supp" Then
                    strInsuredID = Session("Filter_InsuredID")
                    strName = Session("Filter_InsuredName")
                Else
                    strInsuredID = ""
                    strName = ""
                End If
            End If

        Else

            strFromDate = "00000000"
            strToDate = "00000000"


            bViewed = True
            bNotViewed = True
            strInsuredID = ""
            strName = ""
        End If

        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim strUserID As String = objUser.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", User.Identity.Name)
        Dim ds As DataSet
        Dim dsExcel As DataSet

        If Not g_fAllowUserSelect Then
            dsExcel = objReportsList.GetDistributionList("5D1B3748-06E2-4DF8-AA9A-E1E94ED19B98", strUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
        Else
            Dim strSubUserID As String = lstUsers.SelectedItem.Value

            Session("SubUserIDForRepList") = strSubUserID


            If Application("App_Type").ToString().ToLower() = "divur" Or Application("App_Type").ToString().ToLower() = "kupa_info" Then
                If iTableType = 2 Then
                    dsExcel = objReportsList.GetReportsListExt("B23B098A-BFEB-47E3-98FF-70C23D884F1A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                ElseIf iTableType = 11 Then
                    dsExcel = objReportsList.GetReportsList11Type("A201017E-2BC3-4376-A110-8B1B9183C2A2", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, -1, strKoteret)
                Else
                    dsExcel = objReportsList.GetReportsList("7A9C96B4-DB38-4780-AA37-CA714783D55A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                End If
            ElseIf Application("App_Type").ToString().ToLower() = "doar" Then
                dsExcel = objReportsList.GetReportsList("7A9C96B4-DB38-4780-AA37-CA714783D55A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
            Else
                Select Case iTableType
                    Case 2
                        dsExcel = objReportsList.GetReportsListExtMushlam("B23B098A-BFEB-47E3-98FF-70C23D884F1A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                    Case 3
                        dsExcel = objReportsList.GetReportsListExtMushlam("B23B098A-BFEB-47E3-98FF-70C23D884F1A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                    Case 4
                        dsExcel = objReportsList.GetReportsListCB("EEF4EE5A-69C2-4EDA-9D5D-8FA3055DA777", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                    Case 11
                        Dim DoctorID As Integer = -1

                        If Application("App_Type").ToString().ToUpper() = "SUPP" Then
                            dsExcel = objReportsList.GetReportsList11TypeMushlam("BEB34FC7-0FCE-40DF-9546-DF903B284FFE", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, DoctorID, strKoteret)
                        Else
                            dsExcel = objReportsList.GetReportsList11Type("A201017E-2BC3-4376-A110-8B1B9183C2A2", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, DoctorID, strKoteret)
                        End If

                    Case 12

                    Case Else
                        Dim col As BoundColumn
                        Dim colExcel As BoundColumn

                        col.DataField = ""

                        If Session("Filter_InsuredID") <> "" Or Session("Filter_InsuredName") <> "" Then
                            dsExcel = objReportsList.GetReportsListExtMushlam("B23B098A-BFEB-47E3-98FF-70C23D884F1A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)

                        Else
                            If Application("App_Type").ToString.ToUpper = "CLAIM" Or Application("App_Type").ToString.ToUpper = "SUPP" Then

                                dsExcel = objReportsList.GetReportsList("7A9C96B4-DB38-4780-AA37-CA714783D55A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)

                            Else

                                dsExcel = objReportsList.GetReportsList("7A9C96B4-DB38-4780-AA37-CA714783D55A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)

                            End If


                        End If
                End Select
            End If

        End If

        txtAppType.Value = Application("App_Type").ToString


    End Sub

    Private Sub BindGrid()

        If Application("App_Type").ToString().ToLower() = "divur" Then

            ShowNewGridByReportType()

            '*******************
            '*******************
            BindGridNew()
            '*******************
            '*******************

        Else
            If Val(txtTableType.Value) <> 13 Then

                BindGridMain()
            Else
            End If
        End If

    End Sub

    Private Sub ShowNewGridByReportType()
        Dim iReportType As Integer = Val(txtReportType.Value)
        Dim i As Integer
        Dim iSearchByRepNameValue As Integer = 0
        Dim iSearchByInsuredID As Integer = 0

        For i = 2 To 18
            grdListNew.Columns(i).Visible = False
        Next

        cmdReportDynamic.Visible = False

        Select Case iReportType
            Case 555, 557 ' אישור דיווח מצב פה , אישור הגשת התייעצות 
                grdListNew.Columns(col_grdList_InsuredID).Visible = True
                grdListNew.Columns(col_grdList_FName).Visible = True
                grdListNew.Columns(col_grdList_LName).Visible = True
                grdListNew.Columns(col_grdList_Reference).Visible = True
                grdListNew.Columns(col_grdList_EntryDate).Visible = True
                grdListNew.Columns(col_grdList_ViewDate).Visible = True
            Case 510 ' אישור הגשת התייעצות  בודדת
                grdListNew.Columns(col_grdList_InsuredID).Visible = True
                grdListNew.Columns(col_grdList_FName).Visible = True
                grdListNew.Columns(col_grdList_LName).Visible = True
                grdListNew.Columns(col_grdList_Reference).Visible = True
                grdListNew.Columns(col_grdList_Treatment).Visible = True
                grdListNew.Columns(col_grdList_TreatmentDesc).Visible = True
                grdListNew.Columns(col_grdList_FTooth).Visible = True
                grdListNew.Columns(col_grdList_ToTooth).Visible = True
                grdListNew.Columns(col_grdList_EntryDate).Visible = True
                grdListNew.Columns(col_grdList_ViewDate).Visible = True


            Case 500 ' אישור הגשת תביעה / ברור 
                grdListNew.Columns(col_grdList_InsuredID).Visible = True
                grdListNew.Columns(col_grdList_FName).Visible = True
                grdListNew.Columns(col_grdList_LName).Visible = True
                grdListNew.Columns(col_grdList_Reference).Visible = True
                grdListNew.Columns(col_grdList_RequestTyp).Visible = True
                grdListNew.Columns(col_grdList_Treatment).Visible = True
                grdListNew.Columns(col_grdList_TreatmentDesc).Visible = True
                grdListNew.Columns(col_grdList_FTooth).Visible = True
                grdListNew.Columns(col_grdList_ToTooth).Visible = True
                grdListNew.Columns(col_grdList_FinishDate).Visible = True
                grdListNew.Columns(col_grdList_EntryDate).Visible = True
                grdListNew.Columns(col_grdList_ViewDate).Visible = True
                grdListNew.Columns(col_grdList_ValidDate).Visible = True

                If Application("ShowInterActiveReport").ToString() = "1" Then

                    grdListNew.Columns(col_grdList_ReferenceNo).Visible = True

                End If

            Case 556 ' דיווח מצב פה פריודונטלי
                grdListNew.Columns(col_grdList_InsuredID).Visible = True
                grdListNew.Columns(col_grdList_FName).Visible = True
                grdListNew.Columns(col_grdList_LName).Visible = True
                grdListNew.Columns(col_grdList_CheckType).Visible = True
                grdListNew.Columns(col_grdList_Reference).Visible = True
                grdListNew.Columns(col_grdList_EntryDate).Visible = True
                grdListNew.Columns(col_grdList_ViewDate).Visible = True
            Case 588 'תוצאת בדיקת הזכאות המרוכזת
                grdListNew.Columns(col_grdList_InsuredID).Visible = True
                grdListNew.Columns(col_grdList_FName).Visible = True
                grdListNew.Columns(col_grdList_LName).Visible = True
                grdListNew.Columns(col_grdList_Reference).Visible = True
                grdListNew.Columns(col_grdList_EntryDate).Visible = True
                grdListNew.Columns(col_grdList_ViewDate).Visible = True
            Case 888 ' פניה שלא הושלמה
                grdListNew.Columns(col_grdList_InsuredID).Visible = True
                grdListNew.Columns(col_grdList_FName).Visible = True
                grdListNew.Columns(col_grdList_LName).Visible = True
                grdListNew.Columns(col_grdList_Reference).Visible = True
                grdListNew.Columns(col_grdList_EntryDate).Visible = True
                grdListNew.Columns(col_grdList_ViewDate).Visible = True
            Case 45, 50, 41 ' מכתב ביטול התיעצויות', שוברים, משוב התייעצויות יומי
                grdListNew.Columns(col_grdList_InsuredID).Visible = True
                grdListNew.Columns(col_grdList_FName).Visible = True
                grdListNew.Columns(col_grdList_LName).Visible = True
                grdListNew.Columns(col_grdList_EntryDate).Visible = True
                grdListNew.Columns(col_grdList_EntryDate).HeaderText = "תאריך יצירה"
                grdListNew.Columns(col_grdList_ViewDate).Visible = True
                iSearchByInsuredID = 1


                If iReportType = 41 Then
                    cmdReportProp.Value = "דו""ח סטטי"
                    cmdReportDynamic.Visible = True


                    Dim col As New BoundColumn()
                    col = grdListNew.Columns(col_grdList_EntryDate)

                    col.DataField = "ValidDate"
                    'grdListNew.Columns(col_grdList_EntryDate). = True
                    col.HeaderText = "תאריך נכונות"
                    col.Visible = True

                End If

            Case 11 ' משוב תביעות יומי 

                cmdReportProp.Value = "דו""ח סטטי"
                cmdReportDynamic.Visible = True

                'grdListNew.Columns(col_grdList_EntryDate).Visible = True
                'grdListNew.Columns(col_grdList_EntryDate).HeaderText = "תאריך יצירה"

                Dim col As New BoundColumn()
                col = grdListNew.Columns(col_grdList_EntryDate)

                col.DataField = "ValidDate"
                col.HeaderText = "תאריך נכונות"
                col.Visible = True
                grdListNew.Columns(col_grdList_ViewDate).Visible = True
            Case 10 ' סיכום חשבון לרופא 

                cmdReportProp.Value = "דו""ח סטטי"
                cmdReportDynamic.Visible = True

                grdListNew.Columns(col_grdList_Bruto).Visible = True
                'grdListNew.Columns(col_grdList_EntryDate).Visible = True
                'grdListNew.Columns(col_grdList_EntryDate).HeaderText = "תאריך יצירה"
                Dim col As New BoundColumn()
                col = grdListNew.Columns(col_grdList_EntryDate)

                col.DataField = "ValidDate"
                col.HeaderText = "תאריך נכונות"
                col.Visible = True
                grdListNew.Columns(col_grdList_ViewDate).Visible = True
            Case 70 ' סיום תוקף אחריות 			
                grdListNew.Columns(col_grdList_EntryDate).Visible = True
                grdListNew.Columns(col_grdList_EntryDate).HeaderText = "תאריך יצירה"
                grdListNew.Columns(col_grdList_ViewDate).Visible = True

            Case 900, 1011 ' מכתבים אישים, הודעה
                grdListNew.Columns(col_grdList_EntryDate).Visible = True
                grdListNew.Columns(col_grdList_EntryDate).HeaderText = "תאריך יצירה"
                grdListNew.Columns(col_grdList_ViewDate).Visible = True
                grdListNew.Columns(col_grdList_RepName).Visible = True
                iSearchByRepNameValue = 1
            Case 860 'מידע למרפאה
                grdListNew.Columns(col_grdList_Select).Visible = False
                grdListNew.Columns(col_grdList_RepName).Visible = True
                grdListNew.Columns(col_grdList_EntryDate).Visible = True
                grdListNew.Columns(col_grdList_EntryDate).HeaderText = "תאריך יצירה"
                grdListNew.Columns(col_grdList_ViewDate).Visible = True
            Case Else
                grdListNew.Columns(col_grdList_EntryDate).Visible = True
                grdListNew.Columns(col_grdList_EntryDate).HeaderText = "תאריך יצירה"
                grdListNew.Columns(col_grdList_ViewDate).Visible = True

        End Select

        If Application("SearchByRepName").ToString = "1" Then
            Me.SearchByRepName.Value = CStr(iSearchByRepNameValue)
        Else
            Me.SearchByRepName.Value = "0"
        End If

        hidInshuredIDSearch.Value = CStr(iSearchByInsuredID)

    End Sub

    Private Sub BindGridMain()

        Dim objReportsList As New ReportConnect.ReportService()
        objReportsList.Url = Application("ReportWebService").ToString()
        Dim iReportType As Integer
        Dim strFromDate As String
        Dim strToDate As String
        Dim bViewed As Boolean
        Dim bNotViewed As Boolean
        Dim strInsuredID As String, strName As String
        Dim iTableType As Integer

        Dim dsAdd As DataSet
        Dim iCountMore As Integer = 0
        Dim MaxRecNo As Integer = 200
        Dim bPaging As Boolean = IIf(Application("Paging") = "1", True, False)
        Dim strKoteret As String
        Dim iRepID As Integer = 0

        If IsNumeric(Session("Report_List_ReportType")) Then
            iReportType = CInt(Session("Report_List_ReportType"))
            iTableType = CInt(txtTableType.Value)
        Else
            iReportType = 0
            iTableType = 0
        End If

        If chkFilter.Checked Then

            If IsNumeric(Session("Filter_Report_ID")) Then
                iRepID = CInt(Session("Filter_Report_ID"))
            End If
            strFromDate = Trim(txtFromDate.Value.Replace("/", ""))
            strToDate = Trim(txtToDate.Value.Replace("/", ""))
            bViewed = chkViewed.Checked
            bNotViewed = chkNotViewed.Checked

            If Application("SearchByRepName").ToString = "1" Then
                strKoteret = Me.txtKoteret.Value
            End If

            If iTableType > 0 Then
                strInsuredID = txtInshuredID.Value
                strName = txtName.Value
            Else
                If Application("App_Type").ToString = "supp" Then
                    strInsuredID = Session("Filter_InsuredID")
                    strName = Session("Filter_InsuredName")
                Else
                    strInsuredID = ""
                    strName = ""
                End If
            End If

        Else

            Dim iFilterPeriod As Integer = 0
            Dim iFilterFromMonths As Integer = 0
            Dim iFilterToMonths As Integer = 0

            objReportsList.GetReportTypeFilterPeriod("5D23DF8A-5F5C-41ED-B525-26E22931B757", iReportType, iFilterPeriod, iFilterFromMonths, iFilterToMonths)
            If iFilterPeriod = 1 Then
                If iFilterFromMonths <> 0 Or iFilterFromMonths <> 0 Then
                    showDateRange = True
                    strFromDate = Format(DateTime.Today.AddMonths(iFilterFromMonths), "dd/MM/yyyy")
                    strToDate = Format(DateTime.Today.AddMonths(iFilterToMonths), "dd/MM/yyyy")

                    txtFromDate.Value = strFromDate
                    txtToDate.Value = strToDate

                    strFromDate = strFromDate.Replace("/", "")
                    strToDate = strToDate.Replace("/", "")

                Else
                    showDateRange = False
                End If
            Else
                showDateRange = False
            End If


            bViewed = True
            bNotViewed = True
            strInsuredID = ""
            strName = ""
        End If
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim strUserID As String = objUser.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", User.Identity.Name)
        Dim ds As DataSet

        If Not g_fAllowUserSelect Then
            '-----------------
            ds = objReportsList.GetDistributionList("5D1B3748-06E2-4DF8-AA9A-E1E94ED19B98", strUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
            '-----------------
        Else
            Dim strSubUserID As String = lstUsers.SelectedItem.Value

            Session("SubUserIDForRepList") = strSubUserID


            If Application("App_Type").ToString().ToLower() = "divur" Or Application("App_Type").ToString().ToLower() = "kupa_info" Then
                If iTableType = 2 Then
                    If bPaging Then
                    Else
                        '-----------------
                        ds = objReportsList.GetReportsListExt("B23B098A-BFEB-47E3-98FF-70C23D884F1A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                        '-----------------
                    End If

                    If ds.Tables(0).Rows.Count = MaxRecNo Then
                        '-----------------
                        iCountMore = objReportsList.GetReportsListExtCount("90ED5175-FD86-40B9-8FDD-E8483BCEA6B9", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                        '-----------------
                    End If
                ElseIf iTableType = 11 Then
                    If bPaging Then
                    Else
                        '-----------------
                        ds = objReportsList.GetReportsList11Type("A201017E-2BC3-4376-A110-8B1B9183C2A2", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, -1, strKoteret)
                        '-----------------
                    End If

                    If ds.Tables(0).Rows.Count = MaxRecNo Then
                        '-----------------
                        iCountMore = objReportsList.GetReportsList11TypeCount("17073C2D-6940-4F3B-B8CF-15D8949FCAC9", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, -1, strKoteret)
                        '-----------------
                    End If
                Else
                    If bPaging Then
                    Else
                        '-----------------
                        ds = objReportsList.GetReportsList("7A9C96B4-DB38-4780-AA37-CA714783D55A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                        '-----------------
                    End If

                    If ds.Tables(0).Rows.Count = MaxRecNo Then
                        '-----------------
                        iCountMore = objReportsList.GetReportsListCount("52EF9746-374B-404D-977F-0576E92AC4DF", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                        '-----------------
                    End If
                End If
            ElseIf Application("App_Type").ToString().ToLower() = "doar" Then
                If strSubUserID = "0" Then
                    '-----------------
                    ds = objReportsList.GetDoarReportsList("8FB372FE-D9D0-49BA-91DE-DC2610B654B2", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName)
                    '-----------------
                Else
                    '-----------------
                    ds = objReportsList.GetReportsList("7A9C96B4-DB38-4780-AA37-CA714783D55A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                    '-----------------
                End If

                bPaging = False
            Else
                Select Case iTableType
                    Case 2
                        If bPaging Then
                        Else
                            '-----------------
                            ds = objReportsList.GetReportsListExtMushlam("B23B098A-BFEB-47E3-98FF-70C23D884F1A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                            '-----------------
                        End If

                        If ds.Tables(0).Rows.Count = MaxRecNo Then
                            '-----------------
                            iCountMore = objReportsList.GetReportsListExtMushlamCount("8B555A15-B7E6-4F81-87CB-51012E323695", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                            '-----------------
                        End If
                    Case 3
                        If bPaging Then
                        Else
                            '-----------------
                            ds = objReportsList.GetReportsListExtMushlam("B23B098A-BFEB-47E3-98FF-70C23D884F1A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                            '-----------------
                        End If

                        If ds.Tables(0).Rows.Count = MaxRecNo Then
                            '-----------------
                            iCountMore = objReportsList.GetReportsListExtMushlamCount("8B555A15-B7E6-4F81-87CB-51012E323695", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                            '-----------------
                        End If
                    Case 4
                        '-----------------
                        ds = objReportsList.GetReportsListCB("EEF4EE5A-69C2-4EDA-9D5D-8FA3055DA777", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                        '-----------------
                    Case 11
                        Dim DoctorID As Integer = -1

                        If Application("App_Type").ToString().ToUpper() = "SUPP" Then
                            If bPaging Then
                            Else
                                '-----------------
                                ds = objReportsList.GetReportsList11TypeMushlam("BEB34FC7-0FCE-40DF-9546-DF903B284FFE", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, DoctorID, strKoteret)
                                '-----------------
                            End If

                            If ds.Tables(0).Rows.Count = MaxRecNo Then
                                '-----------------
                                iCountMore = objReportsList.GetReportsList11TypeMushlamCount("7020D5E2-E8E8-4BE2-BFDB-4D7844A2D81C", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, DoctorID, strKoteret)
                                '-----------------
                            End If
                        Else
                            If bPaging Then
                            Else
                                '-----------------
                                ds = objReportsList.GetReportsList11Type("A201017E-2BC3-4376-A110-8B1B9183C2A2", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, DoctorID, strKoteret)
                                '-----------------
                            End If

                            If ds.Tables(0).Rows.Count = MaxRecNo Then
                                '-----------------
                                iCountMore = objReportsList.GetReportsList11TypeCount("17073C2D-6940-4F3B-B8CF-15D8949FCAC9", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, DoctorID, strKoteret)
                                '-----------------
                            End If
                        End If

                    Case 12

                    Case Else
                        Dim col As BoundColumn

                        col.DataField = ""
                        If Session("Filter_InsuredID") <> "" Or Session("Filter_InsuredName") <> "" Then
                            If bPaging Then
                            Else
                                '-----------------
                                ds = objReportsList.GetReportsListExtMushlam("B23B098A-BFEB-47E3-98FF-70C23D884F1A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                                '-----------------
                            End If

                            If ds.Tables(0).Rows.Count = MaxRecNo Then
                                '-----------------
                                iCountMore = objReportsList.GetReportsListExtMushlamCount("8B555A15-B7E6-4F81-87CB-51012E323695", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                                '-----------------
                            End If

                            Dim iCountMoreAdd As Integer = 0
                            dsAdd = objReportsList.GetReportsList11TypeMushlam("BEB34FC7-0FCE-40DF-9546-DF903B284FFE", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, -1, strKoteret)
                            If ds.Tables(0).Rows.Count = MaxRecNo Or iCountMore > 0 Then
                                '-----------------
                                iCountMoreAdd = objReportsList.GetReportsList11TypeMushlamCount("7020D5E2-E8E8-4BE2-BFDB-4D7844A2D81C", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, -1, strKoteret)
                                '-----------------
                                iCountMore = iCountMore + iCountMoreAdd
                            End If


                        Else
                            If iRepID > 0 Then
                                '-----------------
                                ds = objReportsList.GetReportListItem("D4D69A20-7F17-4DE0-824C-A416F67E06E8", strUserID, strSubUserID, iRepID)
                                '-----------------
                                bPaging = False
                            Else
                                If Application("App_Type").ToString.ToUpper = "CLAIM" Or Application("App_Type").ToString.ToUpper = "SUPP" Then

                                    If bPaging Then
                                    Else
                                        '-----------------
                                        ds = objReportsList.GetReportsList("7A9C96B4-DB38-4780-AA37-CA714783D55A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                                        '-----------------
                                    End If

                                    If ds.Tables(0).Rows.Count = MaxRecNo Then
                                        '-----------------
                                        iCountMore = objReportsList.GetReportsListCount("52EF9746-374B-404D-977F-0576E92AC4DF", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                                        '-----------------
                                    End If


                                Else
                                    If bPaging Then
                                    Else
                                        '-----------------
                                        ds = objReportsList.GetReportsList("7A9C96B4-DB38-4780-AA37-CA714783D55A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                                        '-----------------
                                    End If

                                    If ds.Tables(0).Rows.Count = MaxRecNo Then
                                        '-----------------
                                        iCountMore = objReportsList.GetReportsListCount("52EF9746-374B-404D-977F-0576E92AC4DF", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                                        '-----------------
                                    End If
                                End If
                            End If
                        End If
                End Select
                'End If
            End If



        End If

        txtAppType.Value = Application("App_Type").ToString

        Dim iCount As Integer = 0

        If bPaging Then
            If ds.Tables.Count > 0 AndAlso ds.Tables(0).Rows.Count > 0 Then
                iCount = Val(ds.Tables(0).Rows(0)("TotalRows").ToString())
            Else
                iCount = 0
            End If
        Else
            iCount = ds.Tables(0).Rows.Count
        End If


        If Application("App_Type").ToString.ToUpper() = "SUPP" Or Application("App_Type").ToString.ToUpper = "DIVUR" Then
            Dim sCountMore As String
            If iCountMore > MaxRecNo Then
                sCountMore = "&nbsp;" & "סה" & "&quot;" & "כ " & iCountMore

                If chkFilter.Checked Then
                    sCountMore += " שורות עונות לתנאי החיתוך  "
                ElseIf showDateRange Then
                    sCountMore = GetDateRangeDescription(strFromDate, strToDate)
                End If
                tdResultRowCount.InnerHtml = "נמצאו " & iCount & " שורות" & "; " & sCountMore
            ElseIf iCount = 1 Then
                tdResultRowCount.InnerHtml = "נמצאה שורה " & iCount
                If chkFilter.Checked Then
                    tdResultRowCount.InnerHtml += " העונה לתנאי החיתוך "
                ElseIf showDateRange Then
                    tdResultRowCount.InnerHtml += GetDateRangeDescription(strFromDate, strToDate)
                End If
            Else
                tdResultRowCount.InnerHtml = "נמצאו " & iCount & " שורות "
                If chkFilter.Checked Then
                    tdResultRowCount.InnerHtml += "  העונות לתנאי החיתוך "
                ElseIf showDateRange Then
                    tdResultRowCount.InnerHtml += GetDateRangeDescription(strFromDate, strToDate)
                End If

            End If


        End If


        If iCount = 0 And Not chkFilter.Checked Then
            chkFilter.Disabled = False
            chkFilter.Style.Remove("Cursor")
            chkFilter.Style.Add("Cursor", "default")

        Else

            chkFilter.Disabled = False
            chkFilter.Style.Remove("Cursor")
            chkFilter.Style.Add("Cursor", "hand")


        End If

    End Sub

    Private Function GetDateRangeDescription(ByVal strFromDate As String, ByVal strToDate As String) As String

        If (strFromDate.Length = 10 And strToDate.Length = 10) Then
            Return " בטווח תאריכים מ-" & strFromDate & " עד-" & strToDate
        End If
        If (strFromDate.Length = 8 And strToDate.Length = 8) Then
            Return " בטווח תאריכים מ-" & Left(strFromDate, 2) & "/" & Mid(strFromDate, 3, 2) & "/" & Mid(strFromDate, 5, 4) & " עד-" & Left(strToDate, 2) & "/" & Mid(strToDate, 3, 2) & "/" & Mid(strToDate, 5, 4)
        End If
        Return String.Empty

    End Function

    Private Sub BindGridNew()

        Dim objReportsList As New ReportConnect.ReportService()
        objReportsList.Url = Application("ReportWebService").ToString()
        Dim iReportType As Integer
        Dim strFromDate As String
        Dim strToDate As String
        Dim bViewed As Boolean
        Dim bNotViewed As Boolean
        Dim strInsuredID As String, strName As String
        Dim iTableType As Integer

        Dim dsAdd As DataSet
        Dim iCountMore As Integer = 0
        Dim MaxRecNo As Integer = 200
        Dim bPaging As Boolean = IIf(Application("Paging") = "1", True, False)
        Dim strKoteret As String
        Dim iRepID As Integer = 0

        If IsNumeric(Session("Report_List_ReportType")) Then
            iReportType = CInt(Session("Report_List_ReportType"))
            iTableType = CInt(txtTableType.Value)
        Else
            iReportType = 0
            iTableType = 0
        End If
        If chkFilter.Checked Then
            If IsNumeric(Session("Filter_Report_ID")) Then
                iRepID = CInt(Session("Filter_Report_ID"))
            End If

            Dim strFromDateLocal As String = Trim(txtFromDate.Value)
            strFromDate = strFromDateLocal.Replace("/", "")

            Dim strToDateLocal As String = Trim(txtToDate.Value)
            strToDate = strToDateLocal.Replace("/", "")


            bViewed = chkViewed.Checked
            bNotViewed = chkNotViewed.Checked

            If Application("SearchByRepName").ToString = "1" Then
                strKoteret = Me.txtKoteret.Value
            End If


            strInsuredID = txtInshuredID.Value
            strName = txtName.Value
        Else


            Dim iFilterPeriod As Integer = 0
            Dim iFilterFromMonths As Integer = 0
            Dim iFilterToMonths As Integer = 0

            objReportsList.GetReportTypeFilterPeriod("5D23DF8A-5F5C-41ED-B525-26E22931B757", iReportType, iFilterPeriod, iFilterFromMonths, iFilterToMonths)

            If iFilterPeriod = 1 Then
                If iFilterFromMonths <> 0 Or iFilterFromMonths <> 0 Then
                    showDateRange = True
                    strFromDate = Format(DateTime.Today.AddMonths(iFilterFromMonths), "dd/MM/yyyy")
                    strToDate = Format(DateTime.Today.AddMonths(iFilterToMonths), "dd/MM/yyyy")

                    txtFromDate.Value = strFromDate
                    txtToDate.Value = strToDate

                    strFromDate = strFromDate.Replace("/", "")
                    strToDate = strToDate.Replace("/", "")

                Else
                    showDateRange = False
                End If
            Else
                showDateRange = False
            End If


            bViewed = True
            bNotViewed = True
            strInsuredID = ""
            strName = ""
        End If

        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim strUserID As String = objUser.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", User.Identity.Name)
        Dim ds As DataSet


        Dim strSubUserID As String = lstUsers.SelectedItem.Value
        Session("SubUserIDForRepList") = strSubUserID


        If Application("App_Type").ToString().ToLower() = "divur" Then
            If iTableType = 2 Then
                If bPaging Then
                    '-----------------
                    ds = objReportsList.GetReportsListExtPaging("9E265C99-FC7E-45BA-B758-DB4711CBA5B8", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, grdListNew.PageSize, grdListNew.CurrentPageIndex, strKoteret)
                    '-----------------
                Else
                    '-----------------
                    ds = objReportsList.GetReportsListExt("B23B098A-BFEB-47E3-98FF-70C23D884F1A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                    '-----------------
                End If

                If ds.Tables(0).Rows.Count = MaxRecNo Then
                    '-----------------
                    iCountMore = objReportsList.GetReportsListExtCount("90ED5175-FD86-40B9-8FDD-E8483BCEA6B9", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                    '-----------------
                End If
            ElseIf iTableType = 11 Then
                If bPaging Then
                    '-----------------
                    ds = objReportsList.GetReportsList11TypePaging("2E11F64D-0F19-4C23-967F-464A0E8D9872", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, -1, grdListNew.PageSize, grdListNew.CurrentPageIndex, strKoteret)
                    '-----------------
                Else
                    '-----------------
                    ds = objReportsList.GetReportsList11Type("A201017E-2BC3-4376-A110-8B1B9183C2A2", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, -1, strKoteret)
                    '-----------------
                End If

                If ds.Tables(0).Rows.Count = MaxRecNo Then
                    '-----------------
                    iCountMore = objReportsList.GetReportsList11TypeCount("17073C2D-6940-4F3B-B8CF-15D8949FCAC9", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, -1, strKoteret)
                    '-----------------
                End If
            Else
                If bPaging Then
                    '-----------------
                    ds = objReportsList.GetReportsListPaging("642BC9D6-70D6-436A-81DE-883CDC6E1295", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, grdListNew.PageSize, grdListNew.CurrentPageIndex, strKoteret)
                    '-----------------
                Else
                    '-----------------
                    ds = objReportsList.GetReportsList("7A9C96B4-DB38-4780-AA37-CA714783D55A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                    '-----------------
                End If

                If ds.Tables(0).Rows.Count = MaxRecNo Then
                    '-----------------
                    iCountMore = objReportsList.GetReportsListCount("52EF9746-374B-404D-977F-0576E92AC4DF", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                    '-----------------
                End If
            End If
        End If

        If Not ds Is Nothing Then
            If ds.Tables.Count = 0 Then
                Return
            End If

        Else
            Return
        End If

        txtAppType.Value = Application("App_Type").ToString

        Dim iCount As Integer = 0

        If bPaging Then
            If ds.Tables.Count > 0 AndAlso ds.Tables(0).Rows.Count > 0 Then
                iCount = Val(ds.Tables(0).Rows(0)("TotalRows").ToString())
            Else
                iCount = 0
            End If
            grdListNew.VirtualItemCount = iCount
        Else
            iCount = ds.Tables(0).Rows.Count
        End If

        Dim iPageCount As Integer = (iCount - 1) \ grdListNew.PageSize



        If Not ds.Tables(0).Columns.Contains("FinishDate") Then
            ds.Tables(0).Columns.Add("FinishDate")
        End If

        If Not ds.Tables(0).Columns.Contains("GrossAmount") Then
            ds.Tables(0).Columns.Add("GrossAmount")
        End If
        If Not ds.Tables(0).Columns.Contains("ToTooth") Then
            ds.Tables(0).Columns.Add("ToTooth")
        End If
        If Not ds.Tables(0).Columns.Contains("FTooth") Then
            ds.Tables(0).Columns.Add("FTooth")
        End If
        If Not ds.Tables(0).Columns.Contains("TreatmentDesc") Then
            ds.Tables(0).Columns.Add("TreatmentDesc")
        End If
        If Not ds.Tables(0).Columns.Contains("Treatment") Then
            ds.Tables(0).Columns.Add("Treatment")
        End If
        If Not ds.Tables(0).Columns.Contains("RealDescription") Then
            ds.Tables(0).Columns.Add("RealDescription")
        End If

        grdListNew.DataSource = ds

        Dim bNewPageIndexForMoveFromPage As Boolean = False
        If Not Session("BackNewPageIndexForMoveFromPage") Is Nothing Then
            Session.Remove("BackNewPageIndexForMoveFromPage")
            If Not Session("NewPageIndexForMoveFromPage") Is Nothing Then
                grdListNew.CurrentPageIndex = CInt(Session("NewPageIndexForMoveFromPage"))
                bNewPageIndexForMoveFromPage = True
            Else
                Session("NewPageIndexForMoveFromPage") = 0
                grdListNew.CurrentPageIndex = CInt(Session("NewPageIndexForMoveFromPage"))
                bNewPageIndexForMoveFromPage = True
            End If
        End If

        If Not bNewPageIndexForMoveFromPage Then

            If iPageCount > -1 Then
                If grdListNew.CurrentPageIndex > iPageCount Then
                    grdListNew.CurrentPageIndex = iPageCount
                End If
            Else
                grdListNew.CurrentPageIndex = 0
            End If

        End If


        Try
            grdListNew.DataBind()
        Catch ex As Exception
            grdListNew.CurrentPageIndex = 0
            grdListNew.DataBind()
        End Try



        If Application("App_Type").ToString.ToUpper = "DIVUR" Then
            Dim sCountMore As String
            If iCountMore > MaxRecNo Then
                sCountMore = "&nbsp;" & "סה" & "&quot;" & "כ " & iCountMore
                If chkFilter.Checked Then
                    sCountMore += " שורות עונות לתנאי החיתוך  "
                ElseIf showDateRange Then
                    sCountMore = GetDateRangeDescription(strFromDate, strToDate)
                End If
                tdResultRowCount.InnerHtml = "נמצאו " & iCount & " שורות" & "; " & sCountMore
            ElseIf iCount = 1 Then
                tdResultRowCount.InnerHtml = "נמצאה שורה " & iCount
                If chkFilter.Checked Then
                    tdResultRowCount.InnerHtml += " העונה לתנאי החיתוך "
                ElseIf showDateRange Then
                    tdResultRowCount.InnerHtml += GetDateRangeDescription(strFromDate, strToDate)
                End If
            Else
                tdResultRowCount.InnerHtml = "נמצאו " & iCount & " שורות "
                If chkFilter.Checked Then
                    tdResultRowCount.InnerHtml += "  העונות לתנאי החיתוך "
                ElseIf showDateRange Then
                    tdResultRowCount.InnerHtml += GetDateRangeDescription(strFromDate, strToDate)
                End If

            End If



        End If


        If iPageCount > 0 Then

            grdListNew.PagerStyle.Visible = True
        Else
            grdListNew.PagerStyle.Visible = False
        End If

        If iCount = 0 And Not chkFilter.Checked Then
            chkFilter.Disabled = False
            chkFilter.Style.Remove("Cursor")
            chkFilter.Style.Add("Cursor", "default")



        Else
            chkFilter.Disabled = False
            chkFilter.Style.Remove("Cursor")
            chkFilter.Style.Add("Cursor", "hand")


        End If


    End Sub

    Private Sub BindGridOccasional()
        Dim objReportsList As New ReportConnect.ReportService()
        objReportsList.Url = Application("ReportWebService").ToString()
        Dim iReportType As Integer
        Dim strFromDate As String
        Dim strToDate As String
        Dim bViewed As Boolean
        Dim bNotViewed As Boolean
        Dim strInsuredID As String, strName As String
        Dim strPhone As String, strMail As String
        Dim iTableType As Integer

        Dim dsAdd As DataSet
        Dim iCountMore As Integer = 0
        Dim MaxRecNo As Integer = 200
        Dim bPaging As Boolean = IIf(Application("Paging") = "1", True, False)
        Dim strKoteret As String


        If IsNumeric(Session("Report_List_ReportType")) Then
            iReportType = CInt(Session("Report_List_ReportType"))
            iTableType = CInt(txtTableType.Value)
        Else
            iReportType = 0
            iTableType = 0
        End If
        If chkFilter.Checked Then

            strInsuredID = txtOccasionalID.Value
            strName = txtFNameOccasional.Value.Trim & " " & txtLNameOccasional.Value.Trim
            strPhone = txtPhoneOccasional.Value
            strMail = txtMailOccasional.Value


        Else


            strFromDate = "00000000"
            strToDate = "00000000"


            bViewed = True
            bNotViewed = True
            strInsuredID = ""
            strName = ""
            strPhone = ""
            strMail = ""
        End If
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim strUserID As String = objUser.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", User.Identity.Name)
        Dim ds As DataSet
        Dim strSubUserID As String = lstUsers.SelectedItem.Value
        Session("SubUserIDForRepList") = strSubUserID
        ds = objReportsList.GetReportsListOccasionalPaging("B6279A79-BBEF-4791-9AFB-0E716FC3F156", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName.Trim, strPhone, strMail, gridOccasional.PageSize, gridOccasional.CurrentPageIndex, strKoteret)


        txtAppType.Value = Application("App_Type").ToString

        Dim iCount As Integer = 0

        If bPaging Then
            If ds.Tables.Count > 0 AndAlso ds.Tables(0).Rows.Count > 0 Then
                iCount = Val(ds.Tables(0).Rows(0)("TotalRows").ToString())
            Else
                iCount = 0
            End If
            gridOccasional.VirtualItemCount = iCount
        Else
            iCount = ds.Tables(0).Rows.Count
        End If

        Dim iPageCount As Integer = (iCount - 1) \ gridOccasional.PageSize

        If bPaging Then
            If ds.Tables.Count > 0 AndAlso ds.Tables(0).Rows.Count > 0 Then
                iCount = Val(ds.Tables(0).Rows(0)("TotalRows").ToString())
            Else
                iCount = 0
            End If

        Else
            iCount = ds.Tables(0).Rows.Count
        End If

        iPageCount = (iCount - 1) \ gridOccasional.PageSize

        gridOccasional.DataSource = ds


        If iPageCount > -1 Then
            If gridOccasional.CurrentPageIndex > iPageCount Then
                gridOccasional.CurrentPageIndex = iPageCount
            End If
        Else
            gridOccasional.CurrentPageIndex = 0
        End If


        gridOccasional.DataBind()

        If Application("App_Type").ToString.ToUpper() = "SUPP" Or Application("App_Type").ToString.ToUpper = "DIVUR" Then
            Dim sCountMore As String
            If iCountMore > MaxRecNo Then
                sCountMore = "&nbsp;" & "סה" & "&quot;" & "כ " & iCountMore
                If chkFilter.Checked Then
                    sCountMore += " שורות עונות לתנאי החיתוך  "
                End If
                tdResultRowCount.InnerHtml = "נמצאו " & iCount & " שורות" & "; " & sCountMore
            ElseIf iCount = 1 Then
                tdResultRowCount.InnerHtml = "נמצאה שורה " & iCount
                If chkFilter.Checked Then
                    tdResultRowCount.InnerHtml += " העונה לתנאי החיתוך "
                End If
            Else
                tdResultRowCount.InnerHtml = "נמצאו " & iCount & " שורות "
                If chkFilter.Checked Then
                    tdResultRowCount.InnerHtml += "  העונות לתנאי החיתוך "
                End If

            End If

        End If


        If iPageCount > 0 Then

            gridOccasional.PagerStyle.Visible = True
        Else
            gridOccasional.PagerStyle.Visible = False
        End If

        If iCount = 0 And Not chkFilter.Checked Then
            chkFilter.Disabled = False
            chkFilter.Style.Remove("Cursor")
            chkFilter.Style.Add("Cursor", "default")

        Else

            chkFilter.Disabled = False
            chkFilter.Style.Remove("Cursor")
            chkFilter.Style.Add("Cursor", "hand")


        End If


    End Sub

    Sub FillArrayChecks(ByVal ds As DataSet)

        Dim dr As DataRow
        Dim i As Integer = 0
        Dim k As Integer

        If Not IsPostBack Or filterFlag = True Then

            For Each dr In ds.Tables(0).Rows
                If i < arrChksSize Then
                    arrChksValues(i) = dr("RepID").ToString() + ";" + "1"
                End If
                i = i + 1
            Next
            If i < arrChksSize Then
                For k = i To arrChksSize - 1
                    arrChksValues(k) = "0"
                Next
            End If


        End If

        filterFlag = False


    End Sub

    Private Sub BindUsers()

        Dim strCurrentUser As String = Session("Report_List_Current_User")
        Dim strUserID As String
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        If Len(strCurrentUser) > 0 Then
            strUserID = strCurrentUser
        Else
            strUserID = objUser.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", User.Identity.Name)
        End If

        Dim ds As Data.DataSet = objUser.GetSubUsers("6A2B8CB2-B464-4C16-A415-933DABD1FD10", User.Identity.Name)
        If String.Compare(Application("App_Type").ToString, "doar", True) = 0 Then
            lstUsers.Items.Add(New ListItem("כולם", "0"))
            Dim currRow As DataRow
            Dim txtValue As String, User1stLetter As String
            Dim oRegEx As Regex
            For Each currRow In ds.Tables(0).Rows
                If oRegEx.IsMatch(Trim(currRow("FullName").ToString()), "^[a-z]", RegexOptions.IgnoreCase) _
                  Or oRegEx.IsMatch(Trim(currRow("FullName").ToString()), "[a-z]$", RegexOptions.IgnoreCase) Then
                    txtValue = String.Concat(currRow("UserName").ToString(), " ) ", currRow("FullName").ToString(), " ) ")
                Else
                    txtValue = String.Concat(currRow("FullName").ToString(), " ( ", currRow("UserName").ToString(), " ) ")
                End If
                lstUsers.Items.Add(New ListItem(txtValue, currRow("SysUserID").ToString()))
            Next
        Else 'for all others
            lstUsers.DataTextField = "FullName"
            lstUsers.DataValueField = "SysUserID"
            lstUsers.DataSource = ds
            lstUsers.DataBind()
        End If
        Dim li As ListItem

        If Not Session("SubUserIDForRepList") Is Nothing Then
            If Session("SubUserIDForRepList").ToString <> "" Then
                li = lstUsers.Items.FindByValue(Session("SubUserIDForRepList").ToString)
            Else
                li = lstUsers.Items.FindByValue(strUserID)
            End If
        Else
            li = lstUsers.Items.FindByValue(strUserID)
        End If


        If Not li Is Nothing Then
            li.Selected = True
        Else
            Try
                li = lstUsers.Items(0)
                li.Selected = True
            Catch ex As Exception
            End Try
        End If

        If Not li Is Nothing Then
            Dim strSelectedUserID As String = li.Value
            Dim stBoUserID As String = ""

            If strSelectedUserID <> "0" Then
                stBoUserID = objUser.GetBOUserID("EA533B72-A5A0-453E-94C9-FE210305AFA6", strSelectedUserID)
            End If

            If Len(stBoUserID) > 0 Then
                lblBOUserID.ForeColor = Color.Black

                lblBOUserID.Text = " זיהוי משתמש במערכת תפעולית: " & stBoUserID

            Else
                lblBOUserID.ForeColor = Color.Black

                lblBOUserID.Text = "(משתמש מקומי)"

            End If
        End If

        If LCase(Application("App_Type").ToString) = "divur" Then
            If lstUsers.Items.Count < 2 Then
                tdUsers.Style("display") = "none"
                trTitleRow1.Style("display") = "none"
                trTitleRow2.Style("display") = "block"
            End If
        End If

    End Sub

    Private Function XSSCheck(ByVal regExpr As String, ByVal inputValue As String) As Boolean
        Dim result As Boolean = True
        If InStr(1, inputValue, "--") > 0 Then
            Return False
        End If
        If Trim(regExpr) <> "" And Trim(inputValue) <> "" Then
            result = System.Text.RegularExpressions.Regex.IsMatch(inputValue, regExpr)
        End If
        Return result
    End Function

    Private Function CrossCheck() As Boolean
        Dim regExpr As String = Application("RegExpr")
        Dim element As String

        Dim intElement As Integer
        Dim strKey As String
        Dim flag As Boolean = True

        For Each element In Request.Form

            If Left(element, 2) <> "__" Then
                If Not XSSCheck(regExpr, Request.Form(element)) Then
                    flag = False
                    Return flag
                End If
            End If

        Next

        For Each element In Request.QueryString

            If Left(element, 2) <> "__" Then

                If Not XSSCheck(regExpr, Request.QueryString(element)) Then
                    flag = False
                    Return flag
                End If

            End If

        Next
        Return flag
    End Function

    Private Sub lstUsers_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstUsers.SelectedIndexChanged

        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim strUserID As String = lstUsers.SelectedItem.Value
        Session("Report_List_Current_User") = strUserID

        If strUserID = "0" Then
            lblBOUserID.Text = ""
            lblClinic.Text = ""
        Else
            Dim stBoUserID As String = objUser.GetBOUserID("EA533B72-A5A0-453E-94C9-FE210305AFA6", strUserID)
            If Len(stBoUserID) > 0 Then
                lblBOUserID.ForeColor = Color.Black

                lblBOUserID.Text = " זיהוי משתמש במערכת תפעולית: " & stBoUserID

            Else
                lblBOUserID.ForeColor = Color.Black

                lblBOUserID.Text = "(משתמש מקומי)"

            End If
        End If

        Dim strClinicId As String
        Dim strClinicName As String

        Dim strCrntUser = objUser.GetUserNameByID("C5C4C694-E524-41D3-8ECD-38CE8434FE4B", Val(lstUsers.SelectedItem.Value))
        Session("CrntUser") = strCrntUser
        objUser.GetClinicAndDoctor("F2D2C32E-6BA0-42C0-BD3C-1E16726B709D", strCrntUser, strClinicId, strClinicName)
        ''''''''''''''''''''objUser.GetHDClinicIdAndClinicName("BE25C36A-51E8-11E4-B3E7-C79B1D5D46B0", strCrntUser, strClinicId, strClinicName)


        lblClinic.Text = strClinicName

        tdTitleClinic2.InnerText = strClinicName

        If LCase(Application("App_Type").ToString) = "divur" Then
            grdListNew.CurrentPageIndex = 0
        Else
            If Val(txtTableType.Value) <> 13 Then
            Else
                gridOccasional.CurrentPageIndex = 0
            End If

        End If

        '*******************
        '*******************
        BindGrid()
        '*******************
        '*******************


    End Sub

    Private Sub grdListNew_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdListNew.ItemDataBound
        Dim dgItem As DataGridItem = e.Item
        Dim htmCtrl As System.Web.UI.HtmlControls.HtmlGenericControl
        Dim htmCtrlChk As System.Web.UI.HtmlControls.HtmlInputCheckBox
        Dim CtrlAtt As String, tmp1 As String, strRepSrc As String, strReference As String, strBundle As String
        Dim tblCell As TableCell
        Dim index As Integer
        Dim BundleDisplayOriginal As String = String.Empty
        Dim RepIDSupportRequests As String = String.Empty

        Select Case (dgItem.ItemType)
            Case ListItemType.Item, ListItemType.AlternatingItem

                tblCell = dgItem.Cells(0)
                Dim l As Label = tblCell.FindControl("lblSign")
                tmp1 = l.ClientID
                htmCtrlChk = tblCell.FindControl("chkIfPrint")

                tblCell = dgItem.Cells(1)
                htmCtrl = tblCell.FindControl("keyvalue")
                CtrlAtt = htmCtrl.Attributes("key")
                strRepSrc = htmCtrl.Attributes("repsrc")
                strReference = htmCtrl.Attributes("ref1")
                strBundle = htmCtrl.Attributes("bundle")

                If (Application("GovernmentTreatments").ToString() = "1") Then
                    If dgItem.Cells(col_grdList_Treatment).Visible = True And Not IsDBNull(dgItem.DataItem("GovTreatment")) AndAlso dgItem.DataItem("GovTreatment") <> String.Empty Then
                        dgItem.Cells(col_grdList_Treatment).Text = dgItem.DataItem("GovTreatment")
                        If dgItem.Cells(col_grdList_Treatment).Text().Length > 4 Then
                            dgItem.Cells(col_grdList_Treatment).Text = "..." & dgItem.Cells(col_grdList_Treatment).Text.Substring(0, 4)
                            dgItem.Cells(col_grdList_Treatment).ToolTip = dgItem.DataItem("GovTreatment")
                        End If
                    End If
                    'If dgItem.Cells(col_grdList_TreatmentDesc).Visible = True And Not IsDBNull(dgItem.DataItem("GovTreatmentDesc")) AndAlso dgItem.DataItem("GovTreatmentDesc") <> String.Empty Then
                    '    dgItem.Cells(col_grdList_TreatmentDesc).Text = SetTextTreatmentDesctData(dgItem.DataItem("GovTreatmentDesc"))
                    '    dgItem.Cells(col_grdList_TreatmentDesc).ToolTip = SetTextTreatmentDescTitle(dgItem.DataItem("GovTreatmentDesc"))
                    'End If
                End If
                Dim iReportTypeInner As Integer
                If Not Session("Report_List_ReportType") Is Nothing Then
                    If Session("Report_List_ReportType").ToString <> "" Then

                        iReportTypeInner = CInt(Session("Report_List_ReportType"))

                    End If
                End If

                If iReportTypeInner = 500 Or iReportTypeInner = 510 Then

                    If Application("ShowInterActiveReport").ToString() = "1" Then
                        Dim iRequestType As Integer = 0
                        If Not dgItem.DataItem("RequestTyp") Is Nothing Then
                            If Not dgItem.DataItem("RequestTyp") Is System.DBNull.Value Then
                                iRequestType = CInt(dgItem.DataItem("RequestTyp"))
                            End If
                        End If


                        If iRequestType = 9 Then
                            dgItem.Cells(col_grdList_ReferenceNo).Visible = False
                        End If

                    End If
                End If

                Try
                    If Application("Paging").ToString = "1" Then
                        index = dgItem.ItemIndex()
                    Else
                    End If
                Catch ex As Exception
                End Try


                Dim bIsTechSupport As Boolean = False

                If Application("Paging").ToString = "1" Then
                    index = dgItem.ItemIndex()
                Else
                End If

                Dim strRepID As String = "", strRepIDOrg As String = "", strUpdatedByUser As String = ""

                Dim sInsuredID As String = "0"
                If Not e.Item.DataItem("InsuredID") Is Nothing Then
                    If Not e.Item.DataItem("InsuredID") Is System.DBNull.Value Then
                        sInsuredID = e.Item.DataItem("InsuredID")
                    End If
                End If

                Dim sValidDate As String = ""
                If Not e.Item.DataItem("ValidDate") Is Nothing Then
                    If Not e.Item.DataItem("ValidDate") Is System.DBNull.Value Then
                        sValidDate = CType(e.Item.DataItem("ValidDate"), Date).ToString("dd/MM/yyyy")
                    End If
                End If


                dgItem.Attributes.Add("onclick", "SelectMe('" + CtrlAtt + "','" + strRepSrc + "', this, '" + tmp1 + "'" + ",'" + strReference + "','" + strBundle + "'" + ");" + "  setInsuredID('" + sInsuredID + "','" + sValidDate + "');")
                dgItem.Attributes.Add("ondblclick", "ShowReport('0');")

        End Select

    End Sub

    Private Sub gridOccasional_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles gridOccasional.ItemDataBound
        Dim dgItem As DataGridItem = e.Item
        Dim htmCtrl As System.Web.UI.HtmlControls.HtmlGenericControl
        Dim htmCtrlChk As System.Web.UI.HtmlControls.HtmlInputCheckBox
        Dim CtrlAtt As String, tmp1 As String, strRepSrc As String, strReference As String, strBundle As String
        Dim tblCell As TableCell
        Dim index As Integer

        Select Case (dgItem.ItemType)
            Case ListItemType.Item, ListItemType.AlternatingItem
                tblCell = dgItem.Cells(0)
                Dim l As Label = tblCell.FindControl("lblSign")
                tmp1 = l.ClientID
                htmCtrlChk = tblCell.FindControl("chkIfPrint")

                tblCell = dgItem.Cells(1)
                htmCtrl = tblCell.FindControl("keyvalue")
                CtrlAtt = htmCtrl.Attributes("key")
                strRepSrc = htmCtrl.Attributes("repsrc")
                strReference = htmCtrl.Attributes("ref1")
                strBundle = htmCtrl.Attributes("bundle")

                Try
                    If Application("Paging").ToString = "1" Then
                        index = dgItem.ItemIndex()
                    Else
                        index = gridOccasional.PageSize * gridOccasional.CurrentPageIndex + dgItem.ItemIndex()
                    End If
                Catch ex As Exception
                    index = gridOccasional.PageSize * gridOccasional.CurrentPageIndex + dgItem.ItemIndex()
                End Try


                If Application("Paging").ToString = "1" Then
                    index = dgItem.ItemIndex()
                Else
                    index = gridOccasional.PageSize * gridOccasional.CurrentPageIndex + dgItem.ItemIndex()
                End If


                Dim ds As DataSet = gridOccasional.DataSource
                Dim strRepID As String = "", strRepIDOrg As String = ""


                dgItem.Attributes.Add("onclick", "SelectMe('" + CtrlAtt + "','" + strRepSrc + "', this, '" + tmp1 + "'" + ",'" + strReference + "','" + strBundle + "'" + ");")
                dgItem.Attributes.Add("ondblclick", "ShowReport('0');")

                dgItem.Attributes.Add("onmouseover", "rowMouseOver(this);")


        End Select
    End Sub

    Private Sub grdListNew_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles grdListNew.PageIndexChanged
        grdListNew.CurrentPageIndex = e.NewPageIndex

        Session("NewPageIndexForMoveFromPage") = e.NewPageIndex

        BindGridNew()
    End Sub

    Private Sub gridOccasional_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles gridOccasional.PageIndexChanged
        gridOccasional.CurrentPageIndex = e.NewPageIndex

        '*******************
        '*******************
        BindGrid()
        '*******************
        '*******************
    End Sub

    Private Sub cmdUserProp_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUserProp.ServerClick
        Session("User_Prop_Caller") = "frmRepList.aspx"

        Response.Redirect("frmUserProp.aspx")

    End Sub

    Private Sub cmdLogout_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdLogout.ServerClick
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        objUser.UpdateLastLogout("DD947C22-CFCA-4BD4-A2CD-B9C916B39B28", Session.SessionID, Val(Application("SiteType")))

        FormsAuthentication.SignOut()
        If Application("HKLLDP") <> "" Then
            Response.Redirect("LoginHKL.aspx?out=1")
        Else
            Response.Redirect(Application("FORMLogin"))
        End If
    End Sub

    Protected Function BindImageisCopy(ByRef ObjIsCopy As Object) As String

        Dim iIsCopy As Integer = 0

        If IsNumeric(ObjIsCopy.ToString()) Then

            iIsCopy = CInt(ObjIsCopy)

        End If

        If iIsCopy = 1 Then
            Return "pics/admin_settings_content-types.png"
        End If

        Return "pics/Transparentb.gif"

    End Function

    Protected Function BindImage(ByRef dtViewDate As Object, ByRef objShared As Object, ByRef objSigned As Object) As String
        Dim iShared As Integer = 0
        Dim iSigned As Integer = 0
        If IsNumeric(objShared.ToString()) Then
            iShared = CInt(objShared)
        End If
        If IsNumeric(objSigned.ToString()) Then
            iSigned = CInt(objSigned)
        End If
        If IsDBNull(dtViewDate) Then
            If iShared = 1 Then
                Return "pics/envelope_people_close.gif"
            Else
                If iSigned = 1 Then
                    Return "pics/envelope_close_signed.gif"
                Else
                    Return "pics/envelope_close.gif"
                End If
            End If
        Else
            If iShared = 1 Then
                Return "pics/envelope_people_open.gif"
            Else
                If iSigned = 1 Then
                    Return "pics/envelope_open_signed.gif"
                Else
                    Return "pics/envelope_open.gif"
                End If
            End If
        End If
    End Function

    Protected Function BindImageBundle(ByRef dtViewDate As Object, ByRef objShared As Object, ByRef objSigned As Object, ByRef objBundle As Object) As String
        Dim iShared As Integer = 0
        Dim iSigned As Integer = 0
        Dim iBundle As Integer = 1
        If IsNumeric(objShared.ToString()) Then
            iShared = CInt(objShared)
        End If
        If IsNumeric(objSigned.ToString()) Then
            iSigned = CInt(objSigned)
        End If
        If IsNumeric(objBundle.ToString()) Then
            iBundle = CInt(objBundle)
        End If
        If IsDBNull(dtViewDate) Then
            If iShared = 1 Then
                If iBundle > 1 Then
                    Return "pics/bundle_people_close.gif"
                Else
                    Return "pics/envelope_people_close.gif"
                End If
            Else
                If iSigned = 1 Then
                    If iBundle > 1 Then
                        Return "pics/bundle_close_signed.gif"
                    Else
                        Return "pics/envelope_close_signed.gif"
                    End If
                Else
                    If iBundle > 1 Then
                        Return "pics/bundle_close.gif"
                    Else
                        Return "pics/envelope_close.gif"
                    End If
                End If
            End If
        Else
            If iShared = 1 Then
                Return "pics/envelope_people_open.gif"
            Else
                If iSigned = 1 Then
                    Return "pics/envelope_open_signed.gif"
                Else
                    Return "pics/envelope_open.gif"
                End If
            End If
        End If
    End Function

    Protected Function BindImageFileDownload(ByRef objEncrypted As Object) As String

        Dim iEncrypted As Integer = 0

        If IsNumeric(objEncrypted.ToString()) Then
            iEncrypted = CInt(objEncrypted)
        End If

        If iEncrypted = 1 Then
            Return "pics/manul.gif"
        Else
            Return "pics/Transparentb.gif"
        End If


    End Function

    Protected Function BindImageExclamation(ByRef dtViewDate As Object, ByRef objNotice As Object) As String
        Dim iNotice As Integer = 0
        If IsDBNull(dtViewDate) Then
            If IsNumeric(objNotice.ToString()) Then
                iNotice = CInt(objNotice)
            End If
        End If
        If iNotice = 1 Then
            Return "pics/Exclamation.gif"
        Else
            Return "pics/Transparentb.gif"
        End If
    End Function

    Protected Function FormatDateTime2(ByRef dtViewDate As Object) As String
        If IsDBNull(dtViewDate) Then
            Return ""
        Else
            Return Format(dtViewDate, "dd/MM/yyyy")
        End If
    End Function

    Protected Function FormatDateTime(ByRef dtViewDate As Object) As String
        If IsDBNull(dtViewDate) Then
            Return ""
        Else
            Return Format(dtViewDate, "dd/MM/yyyy")
        End If
    End Function

    Protected Function GetRepSrc(ByVal strDefaultAction As String, ByVal strActionType As String) As String
        If LCase(Application("App_Type").ToString()) = "divur" Or LCase(Application("App_Type").ToString()) = "supp" Or LCase(Application("App_Type").ToString()) = "doar" Then
            Return strActionType
        Else
            Return strDefaultAction
        End If
    End Function

    Private Sub cmdReturn_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.ServerClick
        Session("Filter_On") = ""

        Session("Filter_To_Date") = ""
        Session("Filter_From_Date") = ""
        Session("MRequest_Source") = "1"
        Session("Filter_InsuredID") = ""
        Session("Report_List_ReportType") = ""

        Session("MRequest_DoctorCare") = ""
        Session("MRequest_DoctorCareName") = ""

        Session("MRequest_InsuredID") = ""
        Session("MRequest_InsuredName") = ""
        Session("MRequest_InsuredFamily") = ""
        Session("MRequest_LName") = ""
        Session("MRequest_FName") = ""
        Session("MRequest_RequestType") = ""

        Session("From_Consultation") = ""

        Response.Redirect((New Utils).GetLinkForNextForm(Application("FORMRepStat")))
    End Sub

    Private Sub cmdApplyFilter_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdApplyFilter.ServerClick
        Session("Filter_Report_ID") = ""

        If Val(txtTableType.Value) <> 13 Then
        Else
            gridOccasional.CurrentPageIndex = 0
        End If

        filterFlag = True

        Session("Filter_On") = ""
        Session("Filter_From_Date") = ""
        Session("Filter_To_Date") = ""
        Session("Filter_Viewed") = ""
        Session("Filter_NotViewed") = ""
        Session("Filter_ReportType") = ""
        Session("Filter_FromUserName") = ""
        Session("Filter_LastUpdateUserName") = ""
        Session("Filter_SupplierID") = ""
        Session("Filter_StatusCode") = ""

        '*******************
        '*******************
        BindGrid()
        '*******************
        '*******************

    End Sub

    Private Sub cmdReportProp_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReportProp.ServerClick
        Dim bIsTechSupport As Boolean = False



        If IsNumeric(txtReportID.Value) Then
            Dim iReportID As Integer = txtReportID.Value
            Dim objUser As New UserConnect.UserService()
            objUser.Url = Application("UserWebService").ToString()
            Dim strUserID As String = objUser.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", User.Identity.Name)
            Dim objReportsList As New ReportConnect.ReportService()
            objReportsList.Url = Application("ReportWebService").ToString()
            If Application("App_Type").ToString = "dist" Then
                BindGrid()
            Else

                If bIsTechSupport And Trim(lstUsers.SelectedItem.Text.ToUpper) = "INFOBAY" Then
                    Dim sLockedByUser As String = objReportsList.GetSupportRequestLockUser("SC0B75D2-5826-108E-9D19-5654572E1C86", CInt(txtReportID.Value))
                    If sLockedByUser <> "" And sLockedByUser.ToLower() <> User.Identity.Name.ToLower() Then

                        txtError.Value = sLockedByUser.ToLower() & " פניה " & txtReportID.Value.ToString & " כרגע בשימוש ע''י משתמש "

                        '*******************
                        '*******************
                        BindGrid()
                        '*******************
                        '*******************

                    Else
                        Session("TechSupport_RepID") = txtReportID.Value
                        Session("TechSupport_SubUserID") = lstUsers.SelectedItem.Value
                        Session("HdclicksForGoBack") = "2"
                        Response.Redirect(Application("FORMfrmTechSupportRequest"))
                    End If

                Else
                    '*******************
                    '*******************
                    BindGrid()
                    '*******************
                    '*******************

                End If
            End If
        End If
    End Sub

    Private Sub cmdReturnMenu_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturnMenu.ServerClick
        Session("Filter_On") = ""
        Session("Filter_On") = ""

        Session("Filter_To_Date") = ""
        Session("Filter_From_Date") = ""
        Session("MRequest_Source") = "1"
        Session("Filter_InsuredID") = ""
        Session("Report_List_ReportType") = ""

        Session("MRequest_DoctorCare") = ""
        Session("MRequest_DoctorCareName") = ""

        Session("MRequest_InsuredID") = ""
        Session("MRequest_InsuredName") = ""
        Session("MRequest_InsuredFamily") = ""
        Session("MRequest_LName") = ""
        Session("MRequest_FName") = ""
        Session("MRequest_RequestType") = ""

        Session("From_Consultation") = ""
        Select Case Application("App_Type").ToString().ToUpper()
            Case "KUPA_INFO"
                Response.Redirect("KupaInfoMenu.aspx")
            Case "SUPP"
                Response.Redirect(Application("FORMClaimMenu").ToString)
            Case "DIVUR"
                Response.Redirect("frmStart.aspx")
            Case Else
                If Application("HasCB") = "1" Then
                    Response.Redirect((New Utils).GetLinkForNextForm("frmCBMenu.aspx"))
                Else
                    Response.Redirect("frmStart.aspx")
                End If
        End Select
    End Sub

    Protected Function FormatTreatmentId(ByRef iTreatmentId As Object) As String
        Dim strTreatmentId As String
        If IsDBNull(iTreatmentId) Then
            Return ""
        Else
            strTreatmentId = iTreatmentId.ToString()
            If Len(strTreatmentId) > 4 Then
                strTreatmentId = Mid$(strTreatmentId, 1, 4) & ".."
            End If
            Return strTreatmentId

        End If
    End Function

    Protected Function FormatRequestTyp(ByRef iRequestTyp As Object) As String
        If IsDBNull(iRequestTyp) Then
            Return ""
        Else
            Dim iReportType As Integer = 0
            If IsNumeric(Session("Report_List_ReportType")) Then
                iReportType = CInt(Session("Report_List_ReportType"))
            End If
            Select Case CType(iRequestTyp, Integer)
                Case 0
                    If iReportType = 556 Then
                        Return "בדיקה ראשונית"
                    Else
                        Return "תביעה"
                    End If
                Case 1
                    If iReportType = 556 Then
                        Return "הערכה מחדש"
                    Else
                        Return ""
                    End If
                Case 4
                    Return "התייעצות"
                Case 9
                    Return "בירור"
                Case Else
                    Return ""
            End Select
        End If
    End Function

    Private Sub cmdReportClaims_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReportClaims.ServerClick
        Session("Request_Report_From_Date") = txtFromDate.Value.Replace("/", "")
        Session("Request_Report_To_Date") = txtToDate.Value.Replace("/", "")
        If chkViewed.Checked Then
            Session("Request_Report_Viewed") = "1"
        Else
            Session("Request_Report_Viewed") = ""
        End If
        If chkNotViewed.Checked Then
            Session("Request_Report_NotViewed") = "1"
        Else
            Session("Request_Report_NotViewed") = ""
        End If
        Session("Request_Report_InsuredID") = Trim(txtInshuredID.Value)
        Session("Request_Report_Name") = Trim(txtName.Value)
        Response.Redirect("frmRequestReport.aspx?StartDate=" + txtFromDate.Value.Replace("/", "") + "&EndDate=" + txtToDate.Value.Replace("/", ""))


    End Sub

    Function UnionDistinct(ByVal dt1 As DataTable, ByVal dt2 As DataTable, ByVal sPKName As String) As DataTable
        Dim dc1 As DataColumn
        Dim dc2 As DataColumn
        Dim rw1 As DataRow
        Dim rw2 As DataRow
        Dim rwRes As DataRow
        Dim dtRes As DataTable



        'create dtRes, add columns to dtRes from dt1 
        dtRes = New DataTable("RepRows")
        For Each dc1 In dt1.Columns
            Dim dc As New DataColumn()
            'dc.DataType = dc1.DataType.GetType
            dc.DataType = dc1.DataType.GetType(dc1.DataType.FullName)
            dc.ColumnName = dc1.ColumnName
            dtRes.Columns.Add(dc)
        Next


        'Add all rows from dt1 to dtRes
        For Each rw1 In dt1.Rows
            dtRes.ImportRow(rw1)
        Next

        'Add missing rows (with other PK) from dt2 to dtRes
        For Each rw2 In dt2.Rows
            Dim bRowFound As Boolean = False
            For Each rwRes In dtRes.Rows
                If rwRes(sPKName) = rw2(sPKName) Then
                    bRowFound = True
                    Exit For
                End If
            Next
            If Not bRowFound Then
                dtRes.ImportRow(rw2)
            End If
        Next

        Return dtRes
    End Function

    Protected Function FormatRemarks(ByRef objCode As Object) As String
        Dim strReturn As String = ""
        Try
            If Not IsDBNull(objCode) Then
                strReturn = objCode.ToString()
            End If
        Catch ex As Exception
        End Try

        Return strReturn
    End Function

    Protected Function FormatStatus(ByRef objCode As Object) As String
        Dim strReturn As String = ""
        Try
            If Not IsDBNull(objCode) Then
                strReturn = objCode.ToString()
            End If
        Catch ex As Exception
        End Try

        Return strReturn
    End Function

    Protected Function FormatPDF(ByRef objRepID As Object) As String
        If IsDBNull(objRepID) Then
            Return ""
        Else
            If CType(objRepID, Integer) > 0 Then
                Dim str34 As String = Chr(34).ToString()
                Return "<INPUT class='ButtonPDF' onclick='ShowPDF(" & str34 & objRepID.ToString() & str34 & ");' type='button' title='pdf-הורדה כ'>"
            Else
                Return ""
            End If
        End If
    End Function

    Protected Function EncodeField(ByRef objCode As Object) As String
        Dim strReturn As String = ""
        If Not IsDBNull(objCode) Then
            strReturn = CEncode.StringEncode(objCode.ToString())
        End If

        Return strReturn

    End Function

    Function CreateBoundColumn(ByVal sHeaderText As String, ByVal sDataField As String, ByVal sDataFormatString As String) As BoundColumn
        Dim col As New BoundColumn()
        col.HeaderText = sHeaderText
        col.DataField = sDataField
        col.SortExpression = sDataField
        If sDataFormatString <> "" Then
            col.DataFormatString = sDataFormatString
        End If
        col.Visible = True

        Return col
    End Function

    Sub ClearAllGridColumns(ByRef grd As DataGrid)
        Dim col As Object
        Dim i As Integer

        For i = 2 To grd.Columns.Count - 2
            Try
                col = grd.Columns(i)
                col.HeaderText = ""
                col.Visible = False
            Catch ex As Exception

            End Try
        Next
    End Sub


    Private Sub gridOccasional_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles gridOccasional.PreRender
        Dim dgItem As DataGridItem
        Dim dgCell As TableCell
        dgItem = New DataGridItem(0, 0, ListItemType.Header)
        dgCell = New TableCell()
        dgCell.ColumnSpan = 1
        dgCell.Text = "משתמש רשום"
        dgItem.Cells.Add(dgCell)

        dgCell = New TableCell()
        dgCell.ColumnSpan = 7
        dgCell.Text = "משתמש מזדמן"
        dgItem.Cells.Add(dgCell)

        dgCell = New TableCell()
        dgCell.ColumnSpan = 3
        dgCell.Text = "פרטי השליחה"
        dgItem.Cells.Add(dgCell)

        gridOccasional.Controls(0).Controls.AddAt(0, dgItem)
        If gridOccasional.PagerStyle.Visible Then
            gridOccasional.Controls(0).Controls(1).Visible = False
        End If
    End Sub

    Protected Function setLongFileName(ByRef objFileName As Object, ByRef objLongFileName As Object) As String
        Dim strReturn As String = ""
        Try
            If Not IsDBNull(objLongFileName) Then
                strReturn = objLongFileName.ToString()
            Else
                strReturn = objFileName.ToString()
            End If
        Catch ex As Exception
            '
        End Try

        Return strReturn

    End Function

    Private Sub cmdReturnConsultaion_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturnConsultation.ServerClick
        Session("Back_Consultation") = "1"
        Response.Redirect(Session("BackUrl"))
    End Sub

    Protected Function SetTextTreatmentDesctData(ByRef objCode As Object) As String

        Dim sTextHospitalDept As String
        Dim sTextHospitalDeptReturn As String
        sTextHospitalDept = objCode.ToString()

        If sTextHospitalDept.Length < 5 Then
            sTextHospitalDeptReturn = sTextHospitalDept
        Else
            sTextHospitalDeptReturn = sTextHospitalDept.Substring(0, 4) + "..."
        End If

        Return sTextHospitalDeptReturn


    End Function

    Protected Function SetTextTreatmentDescTitle(ByRef objCode As Object) As String

        Dim sTextHospitalDeptData As String
        Dim sTextHospitalDeptDataForReturn As String
        sTextHospitalDeptData = objCode.ToString()
        sTextHospitalDeptDataForReturn = sTextHospitalDeptData.Replace("'", "&quot;")

        Return sTextHospitalDeptDataForReturn

    End Function


End Class