Imports System.Text.RegularExpressions

Public Class frmHDGetTeethRequestProp
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim strRefID As String = Request.Form("hidClaimID")
        Dim strInsuredID As String = ""
        Dim strFirstName As String = ""
        Dim strLastName As String = ""
        Dim strPolicyNo As String = ""
        Dim strEmployeeNo As String = ""
        Dim strEmpCD As String = ""
        Dim strInvoice As String = ""
        Dim strAmount As String = ""
        Dim strClaimDate As String = ""
        Dim strHigyena As String = ""
        Dim strSmoke As String = ""
        Dim strAvnit As String = ""
        Dim strClinicNo As String = ""
        Dim strDocNo As String = ""
        Dim strClaimType As String = ""
        Dim strUserName As String = ""
        Dim strEmptyTooth As String = "0;0;0;0;0;0;0;0;0;0;0;0;0;0;"
        Dim strTooth11 As String = strEmptyTooth
        Dim strTooth12 As String = strEmptyTooth
        Dim strTooth13 As String = strEmptyTooth
        Dim strTooth14 As String = strEmptyTooth
        Dim strTooth15 As String = strEmptyTooth
        Dim strTooth16 As String = strEmptyTooth
        Dim strTooth17 As String = strEmptyTooth
        Dim strTooth18 As String = strEmptyTooth
        Dim strTooth21 As String = strEmptyTooth
        Dim strTooth22 As String = strEmptyTooth
        Dim strTooth23 As String = strEmptyTooth
        Dim strTooth24 As String = strEmptyTooth
        Dim strTooth25 As String = strEmptyTooth
        Dim strTooth26 As String = strEmptyTooth
        Dim strTooth27 As String = strEmptyTooth
        Dim strTooth28 As String = strEmptyTooth
        Dim strTooth31 As String = strEmptyTooth
        Dim strTooth32 As String = strEmptyTooth
        Dim strTooth33 As String = strEmptyTooth
        Dim strTooth34 As String = strEmptyTooth
        Dim strTooth35 As String = strEmptyTooth
        Dim strTooth36 As String = strEmptyTooth
        Dim strTooth37 As String = strEmptyTooth
        Dim strTooth38 As String = strEmptyTooth
        Dim strTooth41 As String = strEmptyTooth
        Dim strTooth42 As String = strEmptyTooth
        Dim strTooth43 As String = strEmptyTooth
        Dim strTooth44 As String = strEmptyTooth
        Dim strTooth45 As String = strEmptyTooth
        Dim strTooth46 As String = strEmptyTooth
        Dim strTooth47 As String = strEmptyTooth
        Dim strTooth48 As String = strEmptyTooth
        Dim strResult As String = ""
        Dim dt As DateTime
        Dim ds As Data.DataSet
        Dim currRow As DataRow
        Dim strTreatmentTypeID As String, strTreatmentDesc As String, strPhotoUnits As String, strXrayB As String, strXrayA As String
        Dim objTreatmentService As New TreatmentConnect.TreatmentService(), objXML As New System.Text.StringBuilder()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim iCheckResult As Integer = objTreatmentService.CheckRequestTeethForUpdate("6CFB8358-6942-4A2C-81ED-5B1493A048F8", strRefID)
        If iCheckResult = 1 Or iCheckResult = -1 Then
            ds = objTreatmentService.GetRequestTeeth("F5CB50CA-C777-40CB-99D6-E5A90CDB849A", strRefID)
            If ds.Tables("Requests").Rows.Count > 0 Then
                currRow = ds.Tables(0).Rows(0)
                strUserName = currRow("UserName").ToString()
                If LCase(strUserName) = LCase(User.Identity.Name) And currRow("RequestType").ToString() = "0" Then
                    strInsuredID = currRow("InsuredID").ToString()
                    strFirstName = currRow("FName").ToString()
                    strLastName = currRow("LName").ToString()
                    strPolicyNo = currRow("PolicyNo").ToString()
                    strEmployeeNo = currRow("EmployeeNo").ToString()
                    strInvoice = currRow("Invoice").ToString()
                    strAmount = currRow("Amount").ToString()
                    dt = Convert.ToDateTime(currRow("ClaimDate"))
                    strClaimDate = dt.ToString("ddMMyyyy")
                    strAvnit = currRow("Avnit").ToString()
                    strHigyena = currRow("Higyena").ToString()
                    strSmoke = currRow("Smoke").ToString()
                    strClinicNo = currRow("ClinicNo").ToString()
                    strDocNo = currRow("DocNo").ToString()
                    strTooth11 = ConvertTooth(currRow("ToothVector11").ToString())
                    strTooth12 = ConvertTooth(currRow("ToothVector12").ToString())
                    strTooth13 = ConvertTooth(currRow("ToothVector13").ToString())
                    strTooth14 = ConvertTooth(currRow("ToothVector14").ToString())
                    strTooth15 = ConvertTooth(currRow("ToothVector15").ToString())
                    strTooth16 = ConvertTooth(currRow("ToothVector16").ToString())
                    strTooth17 = ConvertTooth(currRow("ToothVector17").ToString())
                    strTooth18 = ConvertTooth(currRow("ToothVector18").ToString())
                    strTooth21 = ConvertTooth(currRow("ToothVector21").ToString())
                    strTooth22 = ConvertTooth(currRow("ToothVector22").ToString())
                    strTooth23 = ConvertTooth(currRow("ToothVector23").ToString())
                    strTooth24 = ConvertTooth(currRow("ToothVector24").ToString())
                    strTooth25 = ConvertTooth(currRow("ToothVector25").ToString())
                    strTooth26 = ConvertTooth(currRow("ToothVector26").ToString())
                    strTooth27 = ConvertTooth(currRow("ToothVector27").ToString())
                    strTooth28 = ConvertTooth(currRow("ToothVector28").ToString())
                    strTooth31 = ConvertTooth(currRow("ToothVector31").ToString())
                    strTooth32 = ConvertTooth(currRow("ToothVector32").ToString())
                    strTooth33 = ConvertTooth(currRow("ToothVector33").ToString())
                    strTooth34 = ConvertTooth(currRow("ToothVector34").ToString())
                    strTooth35 = ConvertTooth(currRow("ToothVector35").ToString())
                    strTooth36 = ConvertTooth(currRow("ToothVector36").ToString())
                    strTooth37 = ConvertTooth(currRow("ToothVector37").ToString())
                    strTooth38 = ConvertTooth(currRow("ToothVector38").ToString())
                    strTooth41 = ConvertTooth(currRow("ToothVector41").ToString())
                    strTooth42 = ConvertTooth(currRow("ToothVector42").ToString())
                    strTooth43 = ConvertTooth(currRow("ToothVector43").ToString())
                    strTooth44 = ConvertTooth(currRow("ToothVector44").ToString())
                    strTooth45 = ConvertTooth(currRow("ToothVector45").ToString())
                    strTooth46 = ConvertTooth(currRow("ToothVector46").ToString())
                    strTooth47 = ConvertTooth(currRow("ToothVector47").ToString())
                    strTooth48 = ConvertTooth(currRow("ToothVector48").ToString())
                    strClaimType = currRow("ClaimType").ToString()
                    strResult = CStr(iCheckResult)
                Else
                    strResult = "0"
                End If
            End If
        Else
            strResult = CStr(iCheckResult)
        End If
        Dim objResult As New System.Text.StringBuilder()
        objResult.Append("<HTML><HEAD><TITLE></TITLE>")
        objResult.Append("<meta http-equiv='Cache-Control' content='no-cache'>" & vbCrLf)
        objResult.Append("<meta http-equiv='Pragma' content='no-cache'>" & vbCrLf)
        objResult.Append("<meta http-equiv='Expires' content='0'>" & vbCrLf)
        objResult.Append("<META http-equiv='Content-Type' content='text/html; charset=windows-1255'>")
        objResult.Append("</HEAD>")
        objResult.Append("<BODY>")
        objResult.Append("<INPUT type='hidden' id='ctlInsuredID' value='" & strInsuredID & "'>")
        objResult.Append("<INPUT type='hidden' id='ctlFirstName' value='" & strFirstName & "'>")
        objResult.Append("<INPUT type='hidden' id='ctlLastName' value='" & strLastName & "'>")
        objResult.Append("<INPUT type='hidden' id='ctlPolicyNo' value='" & strPolicyNo & "'>")
        objResult.Append("<INPUT type='hidden' id='ctlEmployeeNo' value='" & strEmployeeNo & "'>")
        objResult.Append("<INPUT type='hidden' id='ctlInvoice' value='" & strInvoice & "'>")
        objResult.Append("<INPUT type='hidden' id='ctlAmount' value='" & strAmount & "'>")
        objResult.Append("<INPUT type='hidden' id='ctlClaimDate' value='" & strClaimDate & "'>")
        objResult.Append("<INPUT type='hidden' id='ctlSmoke' value='" & strSmoke & "'>")
        objResult.Append("<INPUT type='hidden' id='ctlAvnit' value='" & strAvnit & "'>")
        objResult.Append("<INPUT type='hidden' id='ctlHigyena' value='" & strHigyena & "'>")
        objResult.Append("<INPUT type='hidden' id='ctlClinicNo' value='" & strClinicNo & "'>")
        objResult.Append("<INPUT type='hidden' id='ctlDocNo' value='" & strDocNo & "'>")
        objResult.Append("<INPUT type='hidden' id='ctlClaimType' value='" & strClaimType & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth11' value='" & strTooth11 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth12' value='" & strTooth12 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth13' value='" & strTooth13 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth14' value='" & strTooth14 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth15' value='" & strTooth15 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth16' value='" & strTooth16 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth17' value='" & strTooth17 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth18' value='" & strTooth18 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth21' value='" & strTooth21 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth22' value='" & strTooth22 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth23' value='" & strTooth23 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth24' value='" & strTooth24 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth25' value='" & strTooth25 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth26' value='" & strTooth26 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth27' value='" & strTooth27 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth28' value='" & strTooth28 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth31' value='" & strTooth31 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth32' value='" & strTooth32 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth33' value='" & strTooth33 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth34' value='" & strTooth34 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth35' value='" & strTooth35 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth36' value='" & strTooth36 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth37' value='" & strTooth37 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth38' value='" & strTooth38 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth41' value='" & strTooth41 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth42' value='" & strTooth42 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth43' value='" & strTooth43 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth44' value='" & strTooth44 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth45' value='" & strTooth45 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth46' value='" & strTooth46 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth47' value='" & strTooth47 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlTooth48' value='" & strTooth48 & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlResult' value='" & strResult & "'>")
        objResult.Append("<SCRIPT>")
        objResult.Append("window.parent.FillInsuredByClaim();")
        objResult.Append("</SCRIPT>")
        objResult.Append("</BODY>")
        objResult.Append("</HTML>")
        Response.Write(objResult.ToString())
    End Sub

    Private Function ConvertTooth(ByVal strValue As String) As String
        Dim i As Integer, strReturn As String = ""
        For i = 1 To 14
            strReturn += Mid(strValue, i, 1) & ";"
        Next
        Return strReturn
    End Function
End Class
