Imports System.Text.RegularExpressions

Public Class frmPStatus
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim objResult As New System.Text.StringBuilder()

        objResult.Append("<HTML><HEAD><TITLE></TITLE>")
        objResult.Append("<meta http-equiv='Cache-Control' content='no-cache'>" & vbCrLf)
        objResult.Append("<meta http-equiv='Pragma' content='no-cache'>" & vbCrLf)
        objResult.Append("<meta http-equiv='Expires' content='0'>" & vbCrLf)
        objResult.Append("<META http-equiv='Content-Type' content='text/html; charset=windows-1255'>")
        objResult.Append("</HEAD>")
        objResult.Append("<BODY>")

        Dim strFirstName As String = ""
        Dim strLastName As String = ""
        Dim strPolicyNo As String = ""
        Dim strEmployeeNo As String = ""
        Dim strEmpCD As String = ""
        Dim strInsuredID As String = Request.Form("hidCheckInsuredID")
        Dim strInsuredFamily As String = Request.Form("hidCheckInsuredName")
        Dim strInsuredFirstName As String = Request.Form("hidCheckInsuredFirstName")
        Dim strCareDate As String = Request.Form("hidCareDate")
        Dim iRetValue As Integer = 1
        If IsNumeric(strInsuredID) Then
            If Application("CompanyID").ToString <> "3" Then
                If Application("Smile") = "1" Then
                    If Session("Smile_Porshei_Personel") = "1" Then
                        objTreatmentService.GetInsuredProp("5E25C46A-EADC-4C27-8A5A-DB8B13E129D3", strInsuredID, strFirstName, strLastName, strPolicyNo, strEmployeeNo, strEmpCD)
                        If strPolicyNo = "1015" Then
                            If strFirstName = "" Then
                                strFirstName = "�"
                            End If
                        Else
                            strFirstName = ""
                            strLastName = ""
                        End If
                    Else
                        Dim objRequest As New SmileConnector.SmileConnector
                        objRequest.Url = Application("SmileWebService")
                        Dim ds As DataSet = objRequest.GetLastAnswer("FF971BAA-4E34-4DCE-ABEF-27191AAF2C79", User.Identity.Name, Session("User_Password"), Val(strInsuredID))
                        If Not ds Is Nothing Then
                            If ds.Tables(0).Rows.Count > 0 Then
                                Dim objRow As DataRow = ds.Tables(0).Rows(0)
                                strFirstName = objRow("InsuredFName").ToString()
                                strLastName = objRow("InsuredLName").ToString()
                            End If
                        End If
                    End If
                Else
                    objTreatmentService.GetInsuredProp("5E25C46A-EADC-4C27-8A5A-DB8B13E129D3", strInsuredID, strFirstName, strLastName, strPolicyNo, strEmployeeNo, strEmpCD)
                    If UCase(Trim(strLastName)) = "ERROR" Then
                        objTreatmentService.GetSQLInsuredProp("6C865031-52E9-4422-950B-615B8F84600C", strInsuredID, strFirstName, strLastName)
                    End If

                End If
                Dim str2Chars As String = Left(strLastName, 2)
                If str2Chars = "" Then
                    iRetValue = 0
                Else
                    If Regex.IsMatch(Mid(str2Chars, 2, 1), "[�-�a-zA-Z]") Then
                        If str2Chars <> Left(strInsuredFamily, 2) Then
                            iRetValue = 0
                        End If
                    Else
                        If Left(str2Chars, 1) <> Left(strInsuredFamily, 1) Then
                            iRetValue = 0
                        End If
                    End If
                End If
                str2Chars = Left(strFirstName, 2)
                If str2Chars = "" Then
                    iRetValue = 0
                Else
                    If Regex.IsMatch(Mid(str2Chars, 2, 1), "[�-�a-zA-Z]") Then
                        If str2Chars <> Left(strInsuredFirstName, 2) Then
                            iRetValue = 0
                        End If
                    Else
                        If Left(str2Chars, 1) <> Left(strInsuredFirstName, 1) Then
                            iRetValue = 0
                        End If
                    End If
                End If
            End If
        Else
            iRetValue = 0
        End If

        objResult.Append("<INPUT TYPE='hidden' ID='InsuredAnswer' value='" & CStr(iRetValue) & "'>")
        objResult.Append("<INPUT TYPE='hidden' ID='CheckAnswer' value=''>")
        'objResult.Append("<INPUT TYPE='hidden' id='ctlLastRequest' value='" & strLastRequest & "'>")
        objResult.Append("<SCRIPT>")
        objResult.Append("	window.parent.document.all.hidNotificationStattus.value = 'OK';")
        objResult.Append("</SCRIPT>")
        objResult.Append("</BODY>")
        objResult.Append("</HTML>")
        Response.Write(objResult.ToString())
    End Sub

End Class
