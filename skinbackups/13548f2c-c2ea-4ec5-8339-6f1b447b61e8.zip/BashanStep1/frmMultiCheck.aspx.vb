﻿Public Partial Class frmMultiCheck
    Inherits System.Web.UI.Page
	
    Protected WithEvents lstDoctorCare As System.Web.UI.WebControls.DropDownList

    Protected WithEvents cmdExit As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdSend As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdNewReq As System.Web.UI.HtmlControls.HtmlInputButton

    Protected WithEvents txtDoctorCareName As System.Web.UI.WebControls.Label
    Protected WithEvents txtDoctorCareNumber As System.Web.UI.WebControls.Label
    Protected WithEvents txtClinicName As System.Web.UI.WebControls.Label
    Protected WithEvents txtClinicNumber As System.Web.UI.WebControls.Label
    Protected WithEvents txtInsuredID As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtInsuredName As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtInsuredFamily As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtAnswer As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents txtError As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtLName As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtFName As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtData As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtDoctorType As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtSkipCheck As System.Web.UI.HtmlControls.HtmlInputHidden

    Protected WithEvents lstCareType As System.Web.UI.HtmlControls.HtmlSelect
    Protected WithEvents lstOccasion As System.Web.UI.HtmlControls.HtmlSelect
    Protected WithEvents lstToothRange As System.Web.UI.HtmlControls.HtmlSelect

    Protected WithEvents lstCareGroup0 As System.Web.UI.HtmlControls.HtmlSelect
    Protected WithEvents lstCareGroup1 As System.Web.UI.HtmlControls.HtmlSelect
    Protected WithEvents lstCareGroup2 As System.Web.UI.HtmlControls.HtmlSelect
    Protected WithEvents lstCareGroup3 As System.Web.UI.HtmlControls.HtmlSelect
    Protected WithEvents lstCareGroup4 As System.Web.UI.HtmlControls.HtmlSelect
    Protected WithEvents cmdShowOldTreatments0 As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdShowOldTreatments1 As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdShowOldTreatments2 As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdShowOldTreatments3 As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdShowOldTreatments4 As System.Web.UI.HtmlControls.HtmlInputButton


    Protected WithEvents cmdClean As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdCopy As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents hidGovernmentTreatments As System.Web.UI.HtmlControls.HtmlInputHidden



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        If Not objUser.GetMultiCheckZakautPermition("4B29B2CF-68DB-4748-8725-0DBE5F74F371", User.Identity.Name) Then
            objUser.AddUserIllegalAction("24304391-6FDE-4237-A9B6-49630958EB26", User.Identity.Name, "frmMultiCheck")
            Response.Redirect("Login.aspx")
        End If
        If IsNothing(Session("Login_User")) OrElse Len(Session("Login_User")) = 0 Then
            Response.Redirect("Login.aspx")
        End If
        Session("HOD_MultiCheck_Reference") = ""
		Dim iFromCmdClean As Integer = 0
        If Not Request.QueryString("c") Is Nothing Then
            If Val(Request.QueryString("c").ToString) = 1 Then
                iFromCmdClean = 1
            End If
        End If

        hidHaveGovernmentTreatments.Value = Application("GovernmentTreatments").ToString()
        hidShowOldTreatments.Value = Application("ShowOldTreatments").ToString()

        If Application("GovernmentTreatments").ToString() = "1" And Application("ShowOldTreatments").ToString() = "1" Then
            cmdShowOldTreatments0.Visible = True
            cmdShowOldTreatments1.Visible = True
            cmdShowOldTreatments2.Visible = True
            cmdShowOldTreatments3.Visible = True
            cmdShowOldTreatments4.Visible = True
        Else
            cmdShowOldTreatments0.Visible = False
            cmdShowOldTreatments1.Visible = False
            cmdShowOldTreatments2.Visible = False
            cmdShowOldTreatments3.Visible = False
            cmdShowOldTreatments4.Visible = False
        End If

        If Not IsPostBack Then
            If Session("User_Login_First_Time") = "1" Then
                Response.Redirect("frmUserProp.aspx")
            End If
            If Application("Smile") = "1" Or Application("CompanyID").ToString = "3" Then
                'cmdCopy.Visible = False
                cmdNewReq.Visible = False
                cmdClean.Visible = False
                txtSkipCheck.Value = "1"
            End If
            If Session("BSHN_Independed") = "1" Then
                lstDoctorCare.Visible = False
                txtDoctorCareName.Visible = True
            Else
                lstDoctorCare.Visible = True
                txtDoctorCareName.Visible = False
            End If
            txtDoctorType.Value = CStr(objUser.GetUserDoctorType("C049B33B-243D-43C1-B2F5-AB4859F9EBD1", User.Identity.Name))
            '''''''''''''''''''''''''''''''txtDoctorType.Value = CStr(objUser.GetHDUserDoctorType("0B776BB2-51E1-11E4-8E10-7F911D5D46B0", User.Identity.Name))
            FillDefaults(iFromCmdClean)
            FillNameAndId()
        End If
    End Sub
	
    Private Sub FillDefaults(ByVal iFromCmdClean As Integer)
        txtData.Value = ""
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

        Dim strDoctorCareName As String
        Dim strDoctorCareNumber As String
        Dim strClinicName As String
        Dim strClinicNumber As String
        If objTreatmentService.GetDoctorProperties("7EC6114A-62CD-4DC4-A940-1416BFB136D8", User.Identity.Name, strDoctorCareName, strDoctorCareNumber, strClinicName, strClinicNumber) Then
            '''''''''''''''''''''If objTreatmentService.GetHdDoctorProperties("C4AEB905-6C91-4FC8-93BE-1486B99518E57", User.Identity.Name, strDoctorCareName, strDoctorCareNumber, strClinicName, strClinicNumber) Then

            If Session("BSHN_Independed") = "1" Then
                txtDoctorCareName.Text = strDoctorCareName
                txtDoctorCareNumber.Text = strDoctorCareNumber
            Else
                lstDoctorCare.DataSource = objUser.GetDoctorList("03407803-DE6A-41AA-87DC-60D1D0329753", User.Identity.Name)
                lstDoctorCare.DataBind()
                If lstDoctorCare.Items.Count > 1 Then
                    lstDoctorCare.Items.Insert(0, New ListItem("בחר...", "0"))
                Else
                    txtDoctorCareNumber.Text = strDoctorCareNumber
                End If
                If iFromCmdClean = 1 Then
                    Try
                        If IsNumeric(Session("MRequest_DoctorCare")) Then
                            lstDoctorCare.SelectedIndex = Val(Session("MRequest_DoctorCare"))
                            txtDoctorCareNumber.Text = Session("MRequest_DoctorCareName").ToString
                        End If
                    Catch e As Exception
                        '
                    End Try
                End If
            End If
            txtClinicName.Text = strClinicName
            txtClinicNumber.Text = strClinicNumber
        End If
        Dim isSmileAgrementClinic As Boolean = False
        Dim iSmileAgrementClinicPlus As Integer = 0
        If Application("Smile") = "1" Then
            iSmileAgrementClinicPlus = objUser.CheckIfAgrementClinicPlus("2AFAE3F5-79B5-459E-B1F9-C460BD34672A", User.Identity.Name)
            If iSmileAgrementClinicPlus > 0 Then
                isSmileAgrementClinic = True
            End If
        End If
        Dim ds As DataSet
        If Session("Leumit_OnlyServiceBasket") = "1" Or isSmileAgrementClinic Then
            If iSmileAgrementClinicPlus = 2 Then
                ds = objTreatmentService.GetTreatmentTypesForServiceBasketPlus("9E01224E-7A57-4E50-A64F-857E4DB868CC")
            Else
                ds = objTreatmentService.GetTreatmentTypesForServiceBasket("3E1378D4-4A76-4F92-B0AF-CB3AFBA60DA4")
            End If
        ElseIf Session("Smile_OnlyServiceBasketNet") = "1" Then
            ds = objTreatmentService.GetTreatmentTypesForServiceBasketNet("2DABD6CC-E754-44EF-8EAD-2044986E91E0")
        Else
            ds = objTreatmentService.GetTreatmentTypes("1C39E920-093F-46B2-BEE7-A4D459A3F1CC")
        End If
        FillCareGroup(lstCareGroup0, ds, isSmileAgrementClinic, objUser)
        FillCareGroup(lstCareGroup1, ds, isSmileAgrementClinic, objUser)
        FillCareGroup(lstCareGroup2, ds, isSmileAgrementClinic, objUser)
        FillCareGroup(lstCareGroup3, ds, isSmileAgrementClinic, objUser)
        FillCareGroup(lstCareGroup4, ds, isSmileAgrementClinic, objUser)
        FillCareType()
        FillOccasion()
        FillToothRange()
    End Sub

    Private Sub FillCareGroup(ByRef cbo As HtmlSelect, ByRef ds As DataSet, ByVal isSmileAgrementClinic As Boolean, ByVal objUser As UserConnect.UserService)
        cbo.Items.Clear()
        cbo.Items.Add(New ListItem(" ", 0))
        If Application("Smile") = "1" And Application("Smile_Platinum_18_Supported") = "1" And Session("Smile_Platinum_18") = "1" And Not isSmileAgrementClinic Then
            Dim PhotosTreatmentTypeID As Integer = Val(objUser.GetGeneralParameter("3FCAAB6E-4AAD-4231-A9F2-B9CCA67EE079", "PhotosTreatmentTypeID"))
            Dim PreservativesTreatmentTypeID As Integer = Val(objUser.GetGeneralParameter("3FCAAB6E-4AAD-4231-A9F2-B9CCA67EE079", "PreservativesTreatmentTypeID"))
            cbo.Items.Add(New ListItem("משמר", PreservativesTreatmentTypeID))
            cbo.Items.Add(New ListItem("צילומים", PhotosTreatmentTypeID))
        Else
            If Not ds Is Nothing Then
                Dim currRow As DataRow
                For Each currRow In ds.Tables(0).Rows
                    cbo.Items.Add(New ListItem(Trim(currRow("TreatmentType").ToString()), currRow("TreatmenTypetID").ToString()))
                Next
            End If
        End If
        cbo.SelectedIndex = 0
    End Sub

    Private Sub FillCareType()
        Dim bGovernmentTreatments As Boolean = CBool(Application("GovernmentTreatments").ToString())

        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim ds As DataSet, dsGov As DataSet
        Dim isSmileAgrementClinic As Boolean = False
        Dim iSmileAgrementClinicPlus As Integer = 0
        If Application("Smile") = "1" Then
            iSmileAgrementClinicPlus = objUser.CheckIfAgrementClinicPlus("2AFAE3F5-79B5-459E-B1F9-C460BD34672A", User.Identity.Name)
            If iSmileAgrementClinicPlus > 0 Then
                isSmileAgrementClinic = True
            End If
        End If
        If Session("Leumit_OnlyServiceBasket") = "1" Or isSmileAgrementClinic Then
            If iSmileAgrementClinicPlus = 2 Then
                ds = objTreatmentService.GetAllTreatmentTypesForServiceBasketPlus("D121D046-A065-4019-B2C7-02FB9B30CBCC")
            Else
                ds = objTreatmentService.GetAllTreatmentTypesForServiceBasket("47759429-F84B-4A22-B3C0-5287F4925220")
            End If
        ElseIf Session("Smile_OnlyServiceBasketNet") = "1" Then
            ds = objTreatmentService.GetAllTreatmentTypesForServiceBasketNet("DF3AC6C7-7339-49AC-86C5-0598A341F908")
            'ElseIf bGovernmentTreatments Then
            '    ds = objTreatmentService.GetAllTreatmentTypesMultiCheckGov("0D28AC92-0CA6-4ED5-8ECF-8C5E72025CEA")
        Else
            ds = objTreatmentService.GetAllTreatmentTypesMultiCheck("139AA870-2579-4f80-B875-FF909A50F55F")
        End If

        If bGovernmentTreatments Then
            dsGov = objTreatmentService.GetAllTreatmentTypesMultiCheckGov("0D28AC92-0CA6-4ED5-8ECF-8C5E72025CEA")
        End If


        Dim currRow As DataRow, objItem As ListItem
        lstCareType.Items.Clear()
        Dim bCheckType2 As Boolean = False
        If Application("Smile") = "1" And Application("Smile_Platinum_18_Supported") = "1" And Session("Smile_Platinum_18") = "1" And Not isSmileAgrementClinic Then
            bCheckType2 = True
        End If
        Dim bSmile As Boolean = CBool(Application("Smile") = "1")
        For Each currRow In ds.Tables(0).Rows
            If bCheckType2 And CType(currRow("TreatmentTypeID"), Integer) <> 1 Then
                '
            Else

                objItem = New ListItem(Trim(currRow("Treatment").ToString()), currRow("TreatmentID").ToString())

                objItem.Attributes.Add("CareGroup", currRow("TreatmentTypeID").ToString())
                objItem.Attributes.Add("AllowRange", currRow("AllowRange").ToString())
                If bSmile Then
                    objItem.Attributes.Add("SmileCode", currRow("SmileTreatmentID").ToString())
                Else
                    objItem.Attributes.Add("SmileCode", currRow("TreatmentID").ToString())
                End If
                lstCareType.Items.Add(objItem)
            End If
        Next

        If bGovernmentTreatments Then
            For Each currRow In dsGov.Tables(0).Rows
                If bCheckType2 And CType(currRow("TreatmentTypeID"), Integer) <> 1 Then
                    '
                Else
                    objItem = New ListItem(Trim(currRow("GovTreatmentDescription").ToString()), currRow("TreatmentID").ToString())

                    objItem.Attributes.Add("CareGroup", currRow("TreatmentTypeID").ToString())
                    objItem.Attributes.Add("AllowRange", currRow("AllowRange").ToString())

                    objItem.Attributes.Add("SmileCode", currRow("GovTreatmentID").ToString())
                    lstCareTypeGov.Items.Add(objItem)
                End If
            Next
        End If

    End Sub

    Private Sub FillOccasion()
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim ds As DataSet = objTreatmentService.GetCauses("CD6AEA9F-C78F-4942-A749-38C16DE0AA62", -1)
        Dim currRow As DataRow, objItem As ListItem
        lstOccasion.Items.Clear()
        For Each currRow In ds.Tables(0).Rows
            objItem = New ListItem(Trim(currRow("Cause").ToString()), currRow("CauseID").ToString())
            objItem.Attributes.Add("Treatment", currRow("TreatmentID").ToString())
            lstOccasion.Items.Add(objItem)
        Next
    End Sub

    Private Sub FillToothRange()
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim ds As DataSet = objTreatmentService.GetTeethRange("DAD91AA1-DE6F-4C28-8A11-CB0FF79BD302", -1)
        Dim currRow As DataRow, objItem As ListItem
        lstToothRange.Items.Clear()
        For Each currRow In ds.Tables(0).Rows
            objItem = New ListItem(Trim(currRow("ToTooth").ToString()), currRow("FromTooth").ToString())
            objItem.Attributes.Add("Treatment", currRow("TreatmentID").ToString())
            lstToothRange.Items.Add(objItem)
        Next
    End Sub

    Private Sub cmdExit_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdExit.ServerClick
        If Application("CompanyID") & "" = "3" Then
            Response.Redirect("frmLMCheck.aspx")
        ElseIf Application("Smile") = "1" Then
            Response.Redirect("frmCheckSM.aspx")
        Else
            Response.Redirect(Application("FORMStart"))
        End If
    End Sub

    Private Sub FillNameAndId()
        txtInsuredID.Value = Session("TRequest_InsuredID")
        txtInsuredName.Value = Session("TRequest_InsuredName")
        txtInsuredFamily.Value = Session("TRequest_InsuredFamily")
        If Application("Smile") = "1" Or Application("CompanyID").ToString = "3" Then
            ' Smile or Leumit
            txtInsuredID.Attributes.Remove("onblur")
            txtFName.Value = Session("TRequest_InsuredName")
            txtLName.Value = Session("TRequest_InsuredFamily")
            SetReadOnly(txtInsuredID)
            SetReadOnly(txtInsuredName)
            SetReadOnly(txtInsuredFamily)
        Else
            Session("TRequest_InsuredID") = ""
            Session("TRequest_InsuredName") = ""
            Session("TRequest_InsuredFamily") = ""
        End If
    End Sub

    Private Sub SetReadOnly(ByVal txtField As HtmlInputText)
        txtField.Attributes.Add("readonly", "true")
        txtField.Style.Add("background-Color", "#D6D3CE")
    End Sub

    Private Sub cmdClean_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClean.ServerClick
        If Session("BSHN_Independed") <> "1" Then
            Session("MRequest_DoctorCare") = CStr(lstDoctorCare.SelectedIndex)
            Session("MRequest_DoctorCareName") = CStr(lstDoctorCare.SelectedValue)
        Else
            Session("MRequest_DoctorCare") = "0"
            Session("MRequest_DoctorCareName") = txtDoctorCareNumber.Text
        End If
        Response.Redirect("frmMultiCheck.aspx?c=1")
    End Sub

    Private Sub cmdCopy_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCopy.ServerClick
        Session("MRequest_Source") = "1"
        If Session("BSHN_Independed") <> "1" Then
            Session("MRequest_DoctorCare") = CStr(lstDoctorCare.SelectedIndex)
            Session("MRequest_DoctorCareName") = CStr(lstDoctorCare.SelectedValue)
        Else
            Session("MRequest_DoctorCare") = "0"
            Session("MRequest_DoctorCareName") = txtDoctorCareNumber.Text
        End If
        Session("MRequest_InsuredID") = txtInsuredID.Value
        Session("MRequest_InsuredName") = txtInsuredName.Value
        Session("MRequest_InsuredFamily") = txtInsuredFamily.Value
        If Application("Smile") = "1" Or Application("CompanyID").ToString = "3" Then
            Session("MRequest_RequestType") = "1"
        End If
        Response.Redirect(Utils.Navigation.GetURL("frmRequestt.aspx"))
    End Sub

    Private Sub cmdNewReq_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdNewReq.ServerClick
        Response.Redirect(Utils.Navigation.GetURL("frmRequestt.aspx"))
    End Sub
End Class