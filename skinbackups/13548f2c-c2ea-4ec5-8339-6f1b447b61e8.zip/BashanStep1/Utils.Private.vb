Imports System.Text
Imports System.Text.RegularExpressions
Imports Microsoft.Security.Application.AntiXSSLibrary
Imports System.Web.Security
Imports Microsoft.Security.Application
Imports System.Xml

Partial Public Class Utils




    Public Class Teeth

        Public Shared Function GetIndexRange(ByVal f As Integer, ByVal t As Integer, ByRef fI As Integer, ByRef tI As Integer) As Integer

            fI = 32
            tI = -1

            For i As Integer = Math.Min(f, t) To Math.Max(f, t)
                Select Case i
                    Case 91
                        fI = Math.Min(fI, 11)
                        tI = Math.Max(tI, 15)
                    Case 92
                        fI = Math.Min(fI, 5)
                        tI = Math.Max(tI, 10)
                    Case 93
                        fI = Math.Min(fI, 0)
                        tI = Math.Max(tI, 4)
                    Case 94
                        fI = Math.Min(fI, 27)
                        tI = Math.Max(tI, 31)
                    Case 95
                        fI = Math.Min(fI, 21)
                        tI = Math.Max(tI, 26)
                    Case 96
                        fI = Math.Min(fI, 16)
                        tI = Math.Max(tI, 20)
                    Case 97
                        fI = Math.Min(fI, 0)
                        tI = Math.Max(tI, 15)
                    Case 98
                        fI = Math.Min(fI, 16)
                        tI = Math.Max(tI, 31)
                    Case Else
                        fI = 0
                        tI = 31
                End Select
            Next

            Return 0

        End Function



    End Class







#Region " Email "

#If EngDesign Then
    Public Const msgEmailNotExists As String = "Email address doesn't exist"
    Public Const msgEmailIsWrong As String = "Wrong Email address"
#Else
    Public Const msgEmailNotExists As String = "�� ������ ����� ���''� �����, �� ���� ����� �� ����� ������� ���� �� ���� ������ ��"
    Public Const msgEmailIsWrong As String = "����� ����''� �� ����� �� �����, �� ���� ����� �� ����� ������� ���� �� ���� ������ ��"
#End If

    Shared Function LogOut() As Boolean
        FormsAuthentication.SignOut()
        Dim context As HttpContext = HttpContext.Current
        context.Session.Clear()
        context.Session.Abandon()
        context.Response.Redirect("Login.aspx")
    End Function

    Shared Sub AddSystemLog(ByVal ShortDescription As String, ByVal LongDescription As String, Optional ByVal Level As Integer = 3)

        Dim context As HttpContext = HttpContext.Current
        Dim User As New UserConnect.UserService()
        User.Url = context.Application("UserWebService").ToString()
        ' 0:DebugInfo, 1:UserAction, 2:Information/Timing, 3:Warning, 4:AppError, 5:Exceptions
        User.AddSystemLog("8D414092-9FA5-4F0E-B782-00AF4C2AA4B0", Level, context.Request.UserHostAddress, "Utils.Private", "AddSystemLog", ShortDescription, LongDescription, 0)

    End Sub

    Shared Function CheckUserEmailAddress(ByVal sUserName As String, ByVal sUserWebServiceURL As String, ByRef sErrorMsg As String) As Boolean
        Dim objUser As New UserConnect.UserService()
        objUser.Url = sUserWebServiceURL
        Dim sEmail As String = String.Empty
        sErrorMsg = String.Empty

        Dim ds As DataSet
        Dim dr As DataRow
        Try
            ds = objUser.GetUser("784C13D4-4DA2-49FC-9CDD-1BB6B0E869CB", sUserName)
            If ds.Tables(0).Rows.Count > 0 Then
                dr = ds.Tables(0).Rows(0)
                If Not IsDBNull(dr("BoID")) Then
                    sEmail = dr("Email").ToString
                End If
            End If
        Catch ex As Exception
            'UserName not founed
        End Try


        Return CheckEmailAddress(sEmail, sUserWebServiceURL, sErrorMsg)
    End Function

    Shared Function CheckEmailAddress(ByVal sEmail As String, ByVal sUserWebServiceURL As String, ByRef sErrorMsg As String) As Boolean
        Dim bOK As Boolean = True
        sEmail = sEmail & String.Empty
        sErrorMsg = String.Empty

        Try
            If sEmail.Trim.Length = 0 Then
                bOK = True
                sErrorMsg = msgEmailNotExists
            Else
                Dim objUser As New UserConnect.UserService()
                objUser.Url = sUserWebServiceURL

                Dim sRegExpr As String = objUser.GetEmailValidation("E600F1B9-D4C7-4FC4-B1B6-922F3967456E") & ""
                If sRegExpr.Trim.Length > 0 Then
                    If Not Regex.IsMatch(sEmail, sRegExpr) Then
                        sErrorMsg = msgEmailIsWrong
                        bOK = False
                    End If
                End If
            End If

        Catch ex As Exception
            '
        End Try

        Return bOK
    End Function

#End Region


#Region " HD Navigation "

    Public Class Navigation

        Shared Function GetURL(ByVal Key As String, Optional ByVal ReportType As String = "", Optional ByVal WithHD As Boolean = True) As String

            If HttpContext.Current.Application("HDnavigation") Is Nothing Then
                Return Key
            End If
            Dim Document As XmlDocument = CType(HttpContext.Current.Application("HDnavigation"), XmlDocument)
            Dim Node As XmlNode
            If (ReportType = "") Then
                Node = Document.SelectSingleNode(String.Format("//Screen[@key='{0}']", Key))
            Else
                Node = Document.SelectSingleNode(String.Format("//Screen[@key='{0}' and @ReportType='{1}']", Key, ReportType))
            End If

            If Node Is Nothing Then
                Return Key
            End If

            Return Node.Attributes("URL").Value() + IIf(WithHD, "?HD=true", String.Empty)

        End Function

    End Class

#End Region

#Region " token care "

    Public Enum LoginMessageType
        NoMessage = 0
        CorruptedToken = 1
        TimeOut = 2
    End Enum

    Dim gCurrentFormName As String

    Function GetLinkForNextForm(ByVal nextFormName As String) As String

        Dim context As HttpContext = HttpContext.Current

        Dim userName As String = MakeUserName(context)
        If context.User.Identity.Name <> "" Then
            userName = context.User.Identity.Name
        End If

        Return GetLinkForNextForm(nextFormName, userName, False)

    End Function


    Function GetLinkForNextForm(ByVal nextFormName As String, ByVal bUpper As Boolean) As String

        Dim context As HttpContext = HttpContext.Current

        Dim userName As String = MakeUserName(context)
        If context.User.Identity.Name <> "" Then
            userName = context.User.Identity.Name
        End If

        Return GetLinkForNextForm(nextFormName, userName, bUpper)

    End Function



    Function GetLinkForNextForm(ByVal nextFormName As String, ByVal userName As String, Optional ByVal bUpper As Boolean = False) As String

        Dim context As HttpContext = HttpContext.Current
        Dim shortFormName As String
        Dim separator As String
        Dim sLink As String
        Dim index As Integer = nextFormName.IndexOf("?")

        If index > 0 Then
            separator = "&"
            shortFormName = nextFormName.Substring(0, index)
        Else
            separator = "?"
            shortFormName = nextFormName
        End If
        Dim currentFormName As String = context.Request.Url.Segments(context.Request.Url.Segments.Length - 1)

        Dim sGUID As String = GetFormGuid(context.Session.SessionID, userName, shortFormName, currentFormName)
        context.Session("Form_GUID") = sGUID

        sLink = DateTime.Now.Ticks.ToString() & "$" & context.Session.SessionID & "$" & userName & "$" & sGUID & "$" & shortFormName & "$" & currentFormName
        sLink = cryptComtec.RijndaelSimple.EncryptSimple(sLink)

        If bUpper Then

            nextFormName = "../" + nextFormName
            sLink = nextFormName & separator & "key=" & Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(sLink))

        Else
            sLink = nextFormName & separator & "key=" & Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(sLink))

        End If

        Return sLink

    End Function

    Private Function GetFormGuid(ByVal SessionID As String, ByVal userName As String, ByVal toFormName As String, ByVal fromFormName As String) As String

        Dim context As HttpContext = HttpContext.Current

        If (context.Session("NavigationKey") Is Nothing) Then
            context.Session("NavigationKey") = SessionID & "$" & userName & "$" & toFormName & "$" & fromFormName
            Return Guid.NewGuid().ToString("N")
        End If

        Dim Parts As String() = Split(context.Session("NavigationKey").ToString(), "$")

        If (Parts(0) <> SessionID) Or _
            (Parts(1) <> userName) Or _
            (Parts(2) <> toFormName) Or _
            (Parts(3) <> fromFormName) Then
            context.Session("NavigationKey") = SessionID & "$" & userName & "$" & toFormName & "$" & fromFormName
            Return Guid.NewGuid().ToString("N")
        End If

        If (context.Session("Form_GUID") Is Nothing) Or (context.Session("Form_GUID") = "") Then
            Return Guid.NewGuid().ToString("N")
        End If

        Return context.Session("Form_GUID").ToString()

    End Function

    Function CheckKey(ByVal CurrentFormName As String, ByVal bCach As Boolean, Optional ByVal bUpper As Boolean = False) As Boolean

        Dim context As HttpContext = HttpContext.Current

        If (context.Session("UserRegLevel") <> "1") Then
            context.Response.Redirect(context.Application("FORMLogin"))
        End If

        If bCach Then
            context.Response.AddHeader("X-FRAME-OPTIONS", "DENY")
            context.Response.Cache.SetCacheability(HttpCacheability.NoCache)
        End If

        gCurrentFormName = CurrentFormName
        Dim Parts As String()
        Dim Ticks, SessionID, UserName, GUID, FormName, FromForm As String

        Dim sShortDescription As String
        Dim sTempShortDescription As String
        Dim report As New StringBuilder
        Dim QueryString As String = "" & context.Request.QueryString("key")
        Try
            QueryString = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(QueryString))
            QueryString = cryptComtec.RijndaelSimple.DencryptSimple(QueryString)
            Parts = Split(QueryString, "$")
            Ticks = Parts(0)
            SessionID = Parts(1)
            UserName = Parts(2)
            GUID = Parts(3)
            FormName = Parts(4)
            FromForm = Parts(5)

            If (GUID = "") Or _
                (GUID <> context.Session("Form_GUID")) Or _
                (UserName <> context.User.Identity.Name) Or _
                (SessionID <> context.Session.SessionID) Or _
                (LCase(FormName) <> LCase(CurrentFormName)) Then

                sTempShortDescription = "Reasons:"

                If GUID = "" Then
                    sTempShortDescription = sTempShortDescription + " GUID='' &"
                End If

                If GUID <> context.Session("Form_GUID") Then
                    sTempShortDescription = sTempShortDescription + " GUID<>Form_GUID &"
                End If

                If UserName <> context.User.Identity.Name Then
                    sTempShortDescription = sTempShortDescription + " UserName<>Identity.Name &"
                End If

                If SessionID <> context.Session.SessionID Then
                    sTempShortDescription = sTempShortDescription + " SessionID<>SessionID &"
                End If

                If LCase(FormName) <> LCase(CurrentFormName) Then
                    sTempShortDescription = sTempShortDescription + " FormName<>CurrentFormName &"
                End If

                sShortDescription = sTempShortDescription.Substring(0, sTempShortDescription.Length - 2)

                report.Append("<span style='display:none'>").Append(vbNewLine)
                report.Append("Server Variables:").Append(vbNewLine)
                report.Append("LOCAL_ADDR:" & context.Request.ServerVariables("LOCAL_ADDR")).Append(vbNewLine)
                report.Append("REMOTE_ADDR:" & context.Request.ServerVariables("REMOTE_ADDR")).Append(vbNewLine)
                report.Append("QUERY_STRING:" & context.Request.ServerVariables("QUERY_STRING")).Append(vbNewLine)
                report.Append("SERVER_NAME:" & context.Request.ServerVariables("SERVER_NAME")).Append(vbNewLine)
                report.Append("REMOTE_USER:" & context.Request.ServerVariables("REMOTE_USER")).Append(vbNewLine)
                report.Append("URL:" & context.Request.ServerVariables("URL")).Append(vbNewLine)
                report.Append("Compare Parameters:").Append(vbNewLine)
                report.Append("GUID:" & GUID).Append(vbNewLine)
                report.Append(GUID & "<>" & context.Session("Form_GUID")).Append(vbNewLine)
                report.Append(UserName & "<>" & context.User.Identity.Name).Append(vbNewLine)
                report.Append(SessionID & "<>" & context.Session.SessionID).Append(vbNewLine)
                report.Append(LCase(FormName) & "<>" & CurrentFormName).Append(vbNewLine)
                report.Append("FromForm:" & FromForm).Append(vbNewLine)
                report.Append("</span>").Append(vbNewLine)
            End If
        Catch ex As Exception

            sShortDescription = "Exception : " + ex.Message

            report.Append("<span exception='true' style='display:none'>").Append(vbNewLine)
            report.Append("Server Variables:").Append(vbNewLine)
            report.Append("LOCAL_ADDR:" & context.Request.ServerVariables("LOCAL_ADDR")).Append(vbNewLine)
            report.Append("REMOTE_ADDR:" & context.Request.ServerVariables("REMOTE_ADDR")).Append(vbNewLine)
            report.Append("QUERY_STRING:" & context.Request.ServerVariables("QUERY_STRING")).Append(vbNewLine)
            report.Append("SERVER_NAME:" & context.Request.ServerVariables("SERVER_NAME")).Append(vbNewLine)
            report.Append("REMOTE_USER:" & context.Request.ServerVariables("REMOTE_USER")).Append(vbNewLine)
            report.Append("URL:" & context.Request.ServerVariables("URL")).Append(vbNewLine)
            report.Append("Exception:" & ex.Message).Append(vbNewLine)
            report.Append("StackTrace:" & ex.StackTrace).Append(vbNewLine)
            report.Append("</span>").Append(vbNewLine)
        End Try

        If (report.Length > 0) Then
            Dim sClassName As String
            sClassName = "from: " + FromForm + " to: " + CurrentFormName

            WriteMessToTable(context, sClassName, sShortDescription, report.ToString)
            SendIllegalKeyMessage(context, report.ToString(), String.Format("{0}->{1}", FromForm, CurrentFormName))

            With context
                Dim objUser As New UserConnect.UserService()
                objUser.Url = .Application("UserWebService").ToString()
                objUser.UpdateLastLogout("DD947C22-CFCA-4BD4-A2CD-B9C916B39B28", .Session.SessionID, Val(.Application("SiteType")))
                FormsAuthentication.SignOut()
                context.Session("LoginMessageType") = LoginMessageType.CorruptedToken

                If bUpper Then
                    Dim sWinName As String
                    sWinName = "../" & context.Application("FORMLogin")
                    context.Response.Redirect(sWinName)
                Else
                    context.Response.Redirect(context.Application("FORMLogin"))
                End If



            End With
        End If

    End Function

    Function CheckKey(ByVal CurrentFormName As String) As Boolean
        Return CheckKey(CurrentFormName, True)
    End Function

    Private Sub SendIllegalKeyMessage(ByVal context As HttpContext, ByVal report As String, ByVal FormName As String)

        Dim objUser As New UserConnect.UserService()
        objUser.Url = context.Application("UserWebService").ToString()
        objUser.AddUserIllegalAction("24304391-6FDE-4237-A9B6-49630958EB26", context.User.Identity.Name, FormName)
        Dim objReportService As New ReportConnect.ReportService()
        objReportService.Url = context.Application("ReportWebService").ToString()
        Dim flag_Success As Integer
        Dim strFileContent As String
#If EngDesign Then
        strFileContent = "<html><body><p align='left' dir='ltr'>" & "Date: " & DateTime.Now.ToString("dd/MM/yyy HH:mm") & "<br>" & " User " & context.User.Identity.Name & " performed an illegal operation " & "</p>"  &  report & "</body></html>"
#Else
        strFileContent = "<html><body><p align='right' dir='rtl'>" & "���� ����: " & DateTime.Now.ToString("dd/MM/yyy HH:mm") & "<br>" & " ������ " & context.User.Identity.Name & " ���� ������ ����� ������ " & " ���� ���� -   " & gCurrentFormName & "</p>" & report & "</body></html>"
#End If
        Dim subject As String = context.User.Identity.Name & " ���� ����� ���� " & gCurrentFormName.Split(".")(0) ' & gCurrentFormName '  " ������ ����� �� " + context.User.Identity.Name & " ���� ���� -   " & gCurrentFormName
        Dim iRepId As Integer = objReportService.AddNewFileReport2User("CD48CB4B-CF9A-4E8E-98D2-D35E42DE9F8C", context.User.Identity.Name, "Infobay", subject, 996, 0, strFileContent, 0, False, False, True, flag_Success, "I", context.User.Identity.Name)

    End Sub

    Private Sub WriteMessToTable(ByVal context As HttpContext, ByVal _sClassName As String, _
                                 ByVal _sShortDescription As String, ByVal LongDescription As String)
        Dim UserService As New UserConnect.UserService()
        UserService.Url = context.Application("UserWebService").ToString()
        UserService.AddSystemLog("8D414092-9FA5-4F0E-B782-00AF4C2AA4B0", _
                                 2, _
                                 context.Request.UserHostAddress, _
                                 _sClassName, _
                                 "Utils.private : CheckKey", _
                                 _sShortDescription, _
                                 LongDescription, _
                                 0)

    End Sub

#End Region

    Public Function SignOut(ByVal ExitURL As String) As Boolean

        Dim context As HttpContext = HttpContext.Current
        Dim objUser As New UserConnect.UserService()
        objUser.Url = context.Application("UserWebService").ToString()
        objUser.UpdateLastLogout("DD947C22-CFCA-4BD4-A2CD-B9C916B39B28", context.Session.SessionID, Val(context.Application("SiteType")))

        FormsAuthentication.SignOut()

        context.Response.Redirect(ExitURL)

    End Function

    Public Function CheckSessionEnd() As Boolean

        Dim Context As HttpContext = HttpContext.Current
        If Not Context.Session Is Nothing Then
            If Context.Session.IsNewSession Then
                SignOut(Context.Application("FORMLogin").ToString)
            End If
        End If

        Return True

    End Function

#Region " AntiXSS care "

    Shared Function AntiXSSJavaScript(ByRef objCode As Object) As String
        Dim strReturn As String = ""
        If Not IsDBNull(objCode) Then
            strReturn = JavaScriptEncode(objCode.ToString())
        End If
        Return strReturn
    End Function

    Shared Function AntiXSSHtml(ByRef objCode As Object) As String
        Dim strReturn As String = ""
        If Not IsDBNull(objCode) Then
            strReturn = HtmlEncode(objCode.ToString())
        End If
        Return strReturn
    End Function

    Shared Function GetSafeHtmlFragment(ByRef objCode As Object) As String
        Dim strReturn As String = ""
        If Not IsDBNull(objCode) Then
#If EngDesign Or Not NewDesign Then
            strReturn = objCode.ToString()
#Else
            strReturn = Sanitizer.GetSafeHtmlFragment(objCode.ToString())
#End If
        End If
        Return strReturn
    End Function

    Shared Function AntiXSS(ByRef objCode As Object) As String
        Dim strReturn As String = ""
        If Not IsDBNull(objCode) Then
            strReturn = Microsoft.Security.Application.AntiXSSLibrary.HtmlAttributeEncode(objCode.ToString())
            strReturn = Microsoft.Security.Application.AntiXSSLibrary.HtmlEncode(objCode.ToString())
            strReturn = Microsoft.Security.Application.AntiXSSLibrary.JavaScriptEncode(objCode.ToString())
            strReturn = Microsoft.Security.Application.AntiXSSLibrary.UrlEncode(objCode.ToString())
            strReturn = Microsoft.Security.Application.AntiXSSLibrary.VisualBasicScriptEncode(objCode.ToString())
            strReturn = Microsoft.Security.Application.AntiXSSLibrary.XmlAttributeEncode(objCode.ToString())
            strReturn = Microsoft.Security.Application.AntiXSSLibrary.XmlEncode(objCode.ToString())
        End If
        Return strReturn
    End Function

    Public Shared Function GetUTF8Code(ByVal crntChar As String) As String
        Select Case crntChar
            Case "�"
                Return "%D7%90"
            Case "�"
                Return "%D7%91"
            Case "�"
                Return "%D7%92"
            Case "�"
                Return "%D7%93"
            Case "�"
                Return "%D7%94"
            Case "�"
                Return "%D7%95"
            Case "�"
                Return "%D7%96"
            Case "�"
                Return "%D7%97"
            Case "�"
                Return "%D7%98"
            Case "�"
                Return "%D7%99"
            Case "�"
                Return "%D7%9A"
            Case "�"
                Return "%D7%9B"
            Case "�"
                Return "%D7%9C"
            Case "�"
                Return "%D7%9D"
            Case "�"
                Return "%D7%9E"
            Case "�"
                Return "%D7%9F"
            Case "�"
                Return "%D7%A0"
            Case "�"
                Return "%D7%A1"
            Case "�"
                Return "%D7%A2"
            Case "�"
                Return "%D7%A3"
            Case "�"
                Return "%D7%A4"
            Case "�"
                Return "%D7%A5"
            Case "�"
                Return "%D7%A6"
            Case "�"
                Return "%D7%A7"
            Case "�"
                Return "%D7%A8"
            Case "�"
                Return "%D7%A9"
            Case "�"
                Return "%D7%AA"
            Case Else
                Return crntChar
        End Select

    End Function

#End Region

#Region "WhiteList"

    Shared Function ValidateInput(ByRef objCode As Object, ByVal regexWhiteList As String, ByVal maxLength As Integer, ByRef errNo As Integer) As Boolean

        If Not IsDBNull(objCode) Then
            Dim s As String = objCode.ToString().ToLower()

            If maxLength > 0 And s.Length > maxLength Then
                errNo = 541 '"Length Exception"
                Return False
            End If

            If regexWhiteList.Length > 0 Then
                Dim r As Regex
                If Not r.IsMatch(s, regexWhiteList) Then
                    errNo = 542 '"Invalid Chars Exception" 
                    Return False
                ElseIf Not CheckString(s) Then
                    errNo = 543 '"Length Exception"
                    Return False
                End If
            End If
        End If

        Return True

    End Function

    Shared Function CheckString(ByVal str As String) As Boolean

        Dim bRet As Boolean = True
        Dim val As String = str.ToLower()
        Dim sInvalidExpressions() As String = {"--", "alert", "expression", "script", "object", "applet", "embed", "input"}

        For Each sExpression As String In sInvalidExpressions

            If val.IndexOf(sExpression) > -1 Then
                bRet = False
                Exit For
            End If
        Next
        Return bRet

    End Function

#End Region

    Public Function SendEMailWithError(ByVal Subject As String, ByVal Message As String) As Boolean

        Dim context As HttpContext = HttpContext.Current
        Dim objErrorReportConnect As New ErrorReportConnect.ErrorReportConnector()
        objErrorReportConnect.Url = "" + context.Application("ErrorReportConnectorService").ToString()

        Try
            objErrorReportConnect.SendErrorWithSubject("9F8D01F4-6CBF-4852-B5E0-1FD2A3AB7F60", Message, Subject, False)
        Catch ex1 As Exception
        End Try

        Return True

    End Function

    Public Function CheckUser(ByVal ConnectionString As String, ByVal UserHostAddress As String, ByVal UserName As String, ByVal Password As String, ByVal UpdateUserName As String) As Integer
        Dim context As HttpContext = HttpContext.Current
        Dim objUser As New UserConnect.UserService()
        objUser.Url = context.Application("UserWebService").ToString()
        Return objUser.CheckUserEx("79D565C1-784C-4606-935B-68BA32141600", UserName, Password, 0, -1, context.Request.UserHostAddress, UpdateUserName, String.Empty, "", "", "")
    End Function

    '   iErrorType = 1 - Exception,
    '                2 - WhiteList
    Public Shared Function SendErrorMessage(ByVal strUrl As String, ByVal sMessage As String, ByVal sSubject As String) As Boolean
        Dim context As HttpContext = HttpContext.Current

        Dim bConnectionError As Boolean = False
        Dim objUser As New UserConnect.UserService()
        objUser.Url = context.Application("UserWebService").ToString()
        Dim objErrorReportConnect As New ErrorReportConnect.ErrorReportConnector()
        objErrorReportConnect.Url = strUrl
        Try
            Dim iTestValue As Integer = objUser.CheckWS()
            If iTestValue < 3 Then
                bConnectionError = True
            End If
        Catch ex As Exception
            sMessage = context.Request.Url.AbsoluteUri & "; " & ex.Message
            bConnectionError = True
        End Try
        Try
            objErrorReportConnect.SendErrorWithSubject("9F8D01F4-6CBF-4852-B5E0-1FD2A3AB7F60", sMessage, sSubject, bConnectionError)
            If bConnectionError Then
                Dim strBatch As String = Trim(context.Application("ErrorBatchFile").ToString())
                If Len(strBatch) > 0 Then
                    System.Threading.Thread.Sleep(1000)
                    Dim startInfo As System.Diagnostics.ProcessStartInfo
                    Dim pStart As New System.Diagnostics.Process()
                    startInfo = New System.Diagnostics.ProcessStartInfo(strBatch)
                    pStart.StartInfo = startInfo
                    pStart.Start()
                End If
            End If
            Return True
        Catch ex1 As Exception
            Return False
        End Try


        'Return False
    End Function


#Region " Get Value Care "

    Public Function GetQueryString(ByVal name As String) As String

        Dim context As HttpContext = HttpContext.Current
        If (context.Request.QueryString(name) Is Nothing) Then
            Return String.Empty
        End If
        Return context.Request.QueryString(name)

    End Function

    Public Function GetApplicationString(ByVal name As String) As String

        Dim context As HttpContext = HttpContext.Current
        If (context.Application(name) Is Nothing) Then
            Return String.Empty
        End If
        Return context.Application(name).ToString()

    End Function

    Public Function GetSessionString(ByVal name As String) As String

        Dim context As HttpContext = HttpContext.Current
        If (context.Session(name) Is Nothing) Then
            Return String.Empty
        End If
        Return context.Session(name).ToString()

    End Function

    Public Function GetSessionInteger(ByVal name As String) As Integer

        Dim context As HttpContext = HttpContext.Current
        If (context.Session(name) Is Nothing) Then
            Return 0
        End If

        If (TypeOf (context.Session(name)) Is Integer) Then
            Return context.Session(name)
        Else
            Return Val(context.Session(name).ToString())
        End If

    End Function

    Public Function GetFirstTableRowsCount(ByVal ds As DataSet) As Integer

        If ds Is Nothing Then
            Return 0
        End If
        If ds.Tables Is Nothing Then
            Return 0
        End If
        If ds.Tables.Count < 1 Then
            Return 0
        End If
        Return ds.Tables(0).Rows.Count

    End Function

    Public Function GetFirstTableFirstRowString(ByVal ds As DataSet, ByVal name As String, Optional ByVal FormatString As String = "") As String

        If ds Is Nothing Then
            Return String.Empty
        End If
        If ds.Tables Is Nothing Then
            Return String.Empty
        End If
        If ds.Tables.Count < 1 Then
            Return String.Empty
        End If
        If ds.Tables(0).Rows.Count < 1 Then
            Return String.Empty
        End If
        If Not ds.Tables(0).Columns.Contains(name) Then
            Return String.Empty
        End If
        Return GetDataRowString(ds.Tables(0).Rows(0), name, FormatString)

    End Function

    Public Function GetDataRowString(ByVal dr As DataRow, ByVal name As String, Optional ByVal FormatString As String = "") As String

        If dr Is Nothing Then
            Return String.Empty
        End If
        If Not dr.Table.Columns.Contains(name) Then
            Return String.Empty
        End If
        If IsDBNull(dr(name)) Then
            Return String.Empty
        End If

        If FormatString = "" Then
            Return dr(name).ToString()
        Else
            Return String.Format(FormatString, dr(name))
        End If

    End Function

    Public Function GetDataRowString(ByVal dr As DataRowView, ByVal name As String, Optional ByVal FormatString As String = "") As String

        If Not dr.Row.Table.Columns.Contains(name) Then
            Return String.Empty
        End If
        If IsDBNull(dr.Row(name)) Then
            Return String.Empty
        End If

        If FormatString = "" Then
            Return dr.Row(name).ToString()
        Else
            Return String.Format(FormatString, dr.Row(name))
        End If

    End Function

    Public Function GetFirstTableFirstRowInteger(ByVal ds As DataSet, ByVal name As String) As Integer

        Dim value As Integer = 0
        Integer.TryParse(GetFirstTableFirstRowString(ds, name), value)
        Return value

    End Function

    Public Function GetFirstTableLastRowString(ByVal ds As DataSet, ByVal name As String) As String

        If ds Is Nothing Then
            Return String.Empty
        End If
        If ds.Tables Is Nothing Then
            Return String.Empty
        End If
        If ds.Tables.Count < 1 Then
            Return String.Empty
        End If
        If ds.Tables(0).Rows.Count < 1 Then
            Return String.Empty
        End If
        If Not ds.Tables(0).Columns.Contains(name) Then
            Return String.Empty
        End If
        Return GetDataRowString(ds.Tables(0).Rows(ds.Tables(0).Rows.Count - 1), name)

    End Function

    Public Function GetFirstTableLastRowInteger(ByVal ds As DataSet, ByVal name As String) As Integer

        Dim value As Integer = 0
        Integer.TryParse(GetFirstTableLastRowString(ds, name), value)
        Return value

    End Function

#End Region


#Region "Version Detection"

    Protected Shared BrowserObjects As Dictionary(Of String, BrowserData) = New Dictionary(Of String, BrowserData)
    Protected Shared DataOS As Dictionary(Of String, OSData) = New Dictionary(Of String, OSData)


    Public Shared Sub FillBrowserObjects()
        Dim context As HttpContext = HttpContext.Current

        Dim objSec As New SecurityService.SecurityService()
        objSec.Url = context.Application("SecurityService")

        Dim ds As DataSet = objSec.GetOperationSystems("A93B92E4-CC64-4AF4-89B8-15328BD8BD84")

        For Each dr As DataRow In ds.Tables(0).Rows
            DataOS.Add(dr("SearchKey").ToString(), New OSData(dr("SearchKey").ToString(), dr("Name").ToString(), dr("SaveUserAgent")))
            'DataOS.Add(dr("SearchKey").ToString(), dr("Name").ToString())
        Next


        ds = objSec.GetBrowsers("9C168AD7-E846-4CD0-8DE8-3F5C0BD5863B", 0)
        ' RecId, SearchKey, SubString, [Identity], VersionSearch, EndDelimeter, CompVersionSource, CompVersionValue, SaveUserAgent

        For Each dr As DataRow In ds.Tables(0).Rows
            If (dr("SearchKey").ToString() = "Trident") Then
                BrowserObjects.Add(dr("SearchKey").ToString(), New InternetExplorer(dr("SubString").ToString(), dr("Identity").ToString(), dr("VersionSearch").ToString(), dr("EndDelimeter").ToString(), dr("SaveUserAgent")))
            Else
                BrowserObjects.Add(dr("SearchKey").ToString(), New BrowserData(dr("SubString").ToString(), dr("Identity").ToString(), dr("VersionSearch").ToString(), dr("EndDelimeter").ToString(), dr("SaveUserAgent")))
            End If
        Next

        'MSIE Compatible 
        ds = objSec.GetBrowsers("9C168AD7-E846-4CD0-8DE8-3F5C0BD5863B", 1)

        If BrowserObjects.ContainsKey("Trident") Then
            Dim ie As InternetExplorer = DirectCast(BrowserObjects("Trident"), InternetExplorer)
            If (Not IsNothing(ie)) Then
                For Each dr As DataRow In ds.Tables(0).Rows
                    ie.AddCompatibleItem(dr("CompVersionSource").ToString(), dr("CompVersionValue").ToString())
                Next
            End If
        End If

        'BrowserObjects.Add("Chrome", New BrowserData("Chrome", "Chrome", "", " "))
        'BrowserObjects.Add("CriOS", New BrowserData("CriOS", "Chrome-IOS", "CriOS", " "))
        'BrowserObjects.Add("Dolfin", New BrowserData("Dolfin", "Dolfin", "Dolfin", " "))
        'BrowserObjects.Add("OmniWeb", New BrowserData("OmniWeb", "OmniWeb", "OmniWeb", " "))
        'BrowserObjects.Add("NokiaBrowser", New BrowserData("NokiaBrowser", "Nokia Browser", "NokiaBrowser", " "))
        'BrowserObjects.Add("Apple", New BrowserData("Apple", "Safari", "Version", " "))	' may be the same for Apple and Android
        'BrowserObjects.Add("Opera", New BrowserData("Opera", "Opera", "Version", " ")) ' window.opera
        'BrowserObjects.Add("iCab", New BrowserData("iCab", "iCab", "iCab", "|"))
        'BrowserObjects.Add("KDE", New BrowserData("KDE", "Konqueror", "", ";"))
        'BrowserObjects.Add("Firefox", New BrowserData("Firefox", "Firefox", "", "|"))
        'BrowserObjects.Add("Camino", New BrowserData("Camino", "Camino", "", " "))
        'BrowserObjects.Add("Netscape", New BrowserData("Netscape", "Netscape", "", " "))
        'BrowserObjects.Add("Trident", New InternetExplorer("MSIE", "Explorer", "Trident", ";"))

        'BrowserObjects.Add("MSIE", New BrowserData("MSIE", "Explorer", "MSIE", ";"))
        'BrowserObjects.Add("Gecko", New BrowserData("Gecko", "Mozilla", "rv", ")"))

        '{ 		// for older Netscapes (4-)
        '    string: navigator.userAgent,
        '    subString: "Mozilla",
        '    identity: "Netscape",
        '    versionSearch: "Mozilla",
        '    endDelimeter: " "
        '}        
        'DataOS.Add("Win16", "Windows 3.11")
        'DataOS.Add("Win95", "Windows 95")
        'DataOS.Add("Windows_95", "Windows 95")
        'DataOS.Add("Windows 95", "Windows 95")
        'DataOS.Add("Win98", "Windows 98")
        'DataOS.Add("Windows 98", "Windows 98")
        'DataOS.Add("Windows ME", "Windows ME")
        'DataOS.Add("Windows NT 5.0", "Windows 2000")
        'DataOS.Add("Windows 2000", "Windows 2000")
        'DataOS.Add("WinNT4.0", "Windows NT 4.0")
        'DataOS.Add("Windows NT 4.0", "Windows NT 4.0")
        'DataOS.Add("Windows XP", "Windows XP")
        'DataOS.Add("Windows NT 5.1", "Windows XP")
        'DataOS.Add("Windows NT 5.2", "Windows Server 2003")
        'DataOS.Add("Windows NT 6.0", "Windows Vista")
        'DataOS.Add("Windows NT 6.1", "Windows 7")
        'DataOS.Add("Windows NT 6.2", "Windows 8")
        'DataOS.Add("Windows NT 6.3", "Windows 8.1")
        'DataOS.Add("Windows NT 7.0", "Windows 7")
        'DataOS.Add("Windows NT", "Windows NT 4.0")
        'DataOS.Add("Win32", "Windows XP")
        'DataOS.Add("WinNT", "Windows NT 4.0")
        'DataOS.Add("Windows Phone OS", "Windows Phone OS")
        'DataOS.Add("Windows Phone ", "Windows Phone")
        'DataOS.Add("Win;", "Windows")
        'DataOS.Add("OpenBSD", "Open BSD")
        'DataOS.Add("SunOS", "Sun OS")
        'DataOS.Add("Android", "Android")
        'DataOS.Add("Linux", "Linux")
        'DataOS.Add("X11", "Linux")
        'DataOS.Add("iPod", "iPod")
        'DataOS.Add("iPhone", "iPhone")
        'DataOS.Add("iPad", "iPad")
        'DataOS.Add("Mac", "Mac")
        'DataOS.Add("OS/2", "OS/2")
        'DataOS.Add("Bada", "Bada")
        'DataOS.Add("SymbOS", "Symbian OS")
        'DataOS.Add("SymbianOS", "Symbian OS")
        'DataOS.Add("BlackBerry", "BlackBerry")

    End Sub


    Public Sub CheckBrowser(ByVal sUserAgent As String, ByRef sBrowserName As String, ByRef sBrowserVersion As String, ByRef sOperationSyst As String, ByRef bSaveUserAgent As Boolean)
        Const cUnknown As String = "Unknown"
        Const cEmpty As String = "Empty"

        sBrowserName = cUnknown
        sBrowserVersion = cUnknown
        sOperationSyst = cUnknown

        Dim resultObj As BrowserData = Nothing
        Dim resultOSData As OSData = Nothing
        'Dim bSaveUserAgent As Boolean = False

        Try

			For Each sKey As String In BrowserObjects.Keys
				If (sUserAgent.IndexOf(sKey) > -1) Then
					resultObj = BrowserObjects(sKey)
					Exit For
				End If
			Next

            If (Not IsNothing(resultObj)) Then
                sBrowserName = resultObj.Identity.Trim()
                sBrowserVersion = resultObj.GetBrowserVersion(sUserAgent)
                bSaveUserAgent = (resultObj.SaveUserAgent > 0)
            End If

            For Each sKey As String In DataOS.Keys
                If (sUserAgent.IndexOf(sKey) > -1) Then
                    resultOSData = DataOS(sKey)
                    Exit For
                End If
            Next

            If (Not IsNothing(resultOSData)) Then
                sOperationSyst = resultOSData.Name
                bSaveUserAgent = bSaveUserAgent OrElse (resultOSData.SaveUserAgent > 0)
            End If

			If (sOperationSyst.ToLower().IndexOf("windows") > -1) Then
				If (sUserAgent.IndexOf("WOW64") > -1) Then
					sOperationSyst += " 64-bit"
				Else
					sOperationSyst += " 32-bit"
				End If
			End If

			If ((sOperationSyst = "iPhone") Or (sOperationSyst = "iPad") Or (sOperationSyst = "Mac")) Then
				If (sBrowserName = cUnknown) Then
					sBrowserName = "Safari"
				End If

				If (sBrowserVersion = cUnknown) Then
					sBrowserVersion = "5.1"
				End If

			End If

			If (sBrowserName.Trim() = "") Then
				sBrowserName = cEmpty
			End If

			If (sBrowserVersion.Trim() = "") Then
				sBrowserVersion = cEmpty
			End If

			If (sOperationSyst.Trim() = "") Then
				sOperationSyst = cEmpty
			End If
		Catch ex As Exception

			If (sBrowserName = cUnknown) Then
				sBrowserName = cEmpty
			End If
			If (sBrowserVersion = cUnknown) Then
				sBrowserVersion = cEmpty
			End If
			If (sOperationSyst = cUnknown) Then
				sOperationSyst = cEmpty
			End If


		End Try
    End Sub

#End Region



    Public Class UrgentReport
        Public RepID As String
        Public SysUserID As String
        Public PageName As String

        Public Sub New(ByVal RepID As String, ByVal SysUserID As String, ByVal PageName As String)
            Me.RepID = RepID
            Me.SysUserID = SysUserID
            Me.PageName = PageName
        End Sub
    End Class


    Public Shared Sub HideButtonForSupp(ByVal cmdHelp As HtmlInputButton)

        Dim app As HttpApplicationState = HttpContext.Current.Application

        If app("App_Type").ToString().ToUpper() = "SUPP" Then
            cmdHelp.Visible = False
        End If

    End Sub

End Class

Public Class BrowserData
    Public SubString As String = ""
    Public Identity As String = ""
    Public VersionSearch As String = ""
    Public EndDelimeter As String = ""
    Public SaveUserAgent As Integer = 0

    Public Sub New(ByVal sSubString As String, ByVal sIdentity As String, ByVal sVersionSearch As String, ByVal sEndDelimeter As String, ByVal iSaveUserAgent As Integer)
        MyBase.New()
        SubString = sSubString
        Identity = sIdentity
        VersionSearch = sVersionSearch
        EndDelimeter = sEndDelimeter
        SaveUserAgent = iSaveUserAgent
    End Sub

    Public Overridable Function GetBrowserVersion(ByVal sUserAgent As String) As String
        Dim sBrowserVersion As String = ""
        Dim sVersionSearch As String = ""
        If (VersionSearch = "") Then
            sVersionSearch = Identity
        Else
            sVersionSearch = VersionSearch
        End If

        Dim iVersionIndex As Integer = sUserAgent.IndexOf(sVersionSearch)

        Dim sVersionStart As String = sUserAgent.Substring(iVersionIndex + sVersionSearch.Length + 1)

        If (EndDelimeter <> "") Then
            Dim iLen As Integer = sVersionStart.IndexOf(EndDelimeter)
            If (iLen > 0) Then
                sBrowserVersion = sVersionStart.Substring(0, iLen)
            Else
                sBrowserVersion = sVersionStart
            End If
        Else
            sBrowserVersion = Val(sVersionStart).ToString()
        End If
        Return sBrowserVersion
    End Function

End Class

Public Class InternetExplorer
    Inherits BrowserData

    Private compatibilityList As Dictionary(Of String, String)

    Public Sub New(ByVal sSubString As String, ByVal sIdentity As String, ByVal sVersionSearch As String, ByVal sEndDelimeter As String, ByVal iSaveUserAgent As Integer)
        MyBase.New(sSubString, sIdentity, sVersionSearch, sEndDelimeter, iSaveUserAgent)
        compatibilityList = New Dictionary(Of String, String)

    End Sub

    Public Sub AddCompatibleItem(ByVal sSource As String, ByVal sValue As String)
        compatibilityList.Add(sSource, sValue)
    End Sub

    Public Overrides Function GetBrowserVersion(ByVal sUserAgent As String) As String
        Dim sVersion As String = MyBase.GetBrowserVersion(sUserAgent)
        If (sVersion.EndsWith(")")) Then
            sVersion = sVersion.Substring(0, sVersion.Length - 1)
        End If

        If (compatibilityList.ContainsKey(sVersion)) Then
            sVersion = "" + compatibilityList(sVersion).ToString()
        Else
            Dim dVersion As Double = Val(sUserAgent)
            If (dVersion > 0) Then
                sVersion = (dVersion + 4D).ToString()
            End If

        End If


        'Select Case sVersion
        '    Case "4.0"
        '        sVersion = "8.0"
        '    Case "5.0"
        '        sVersion = "9.0"
        '    Case "6.0"
        '        sVersion = "10.0"
        '    Case "7.0"
        '        sVersion = "11.0"
        'End Select

        Dim iIndex As Integer = sUserAgent.IndexOf("MSIE ")
        If (iIndex > 0) Then
            Dim sComVersion As String = sUserAgent.Substring(iIndex + 5)
            iIndex = sComVersion.IndexOf(";")
            sComVersion = sComVersion.Substring(0, iIndex)

            If (sVersion <> sComVersion) Then
                sVersion += " comp " + sComVersion
            End If
        End If

        Return sVersion
    End Function

End Class

Public Class OSData
    Public SubString As String = ""
    Public Name As String = ""
    Public SaveUserAgent As Integer = 0

    Public Sub New(ByVal sSubString As String, ByVal sName As String, ByVal iSaveUserAgent As Integer)
        MyBase.New()
        SubString = sSubString
        Name = sName
        SaveUserAgent = iSaveUserAgent
    End Sub

End Class



