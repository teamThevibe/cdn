Imports System.IO

Public Class frmRequestt
    Inherits System.Web.UI.Page
    Protected WithEvents lstRequestType As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstCareGroup As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstCareType As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstOccasion As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstDoctorCare As System.Web.UI.WebControls.DropDownList

    Protected WithEvents cmdExit As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdHelp As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdUserProp As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdCopy As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdNew As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdSend As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdMRequest As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdAddAttachForLastRequest As System.Web.UI.HtmlControls.HtmlInputButton

    Protected WithEvents chkCLV As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents chkB As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents chkLP As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents chkD As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents chkO As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents chkM As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents chkPan As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents chkStatus As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents chkFace As System.Web.UI.HtmlControls.HtmlInputCheckBox

    Protected WithEvents HidCountRequestPerUserPerDay As System.Web.UI.HtmlControls.HtmlInputHidden

    Protected WithEvents txtDate As System.Web.UI.HtmlControls.HtmlInputHidden

    Protected WithEvents HidDayForReport As System.Web.UI.HtmlControls.HtmlInputHidden


    Protected WithEvents HidCurrentAsmacta As System.Web.UI.HtmlControls.HtmlInputHidden


    Protected WithEvents txtCareType As System.Web.UI.HtmlControls.HtmlInputHidden


    Protected WithEvents HidSourchWin As System.Web.UI.HtmlControls.HtmlInputHidden

    Protected WithEvents HidOrgSourchWin As System.Web.UI.HtmlControls.HtmlInputHidden

    Protected WithEvents txtOccasion As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtToday As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtError As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtLName As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtFName As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtMaxClaimSum As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtTeethMode As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtCompany As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtDoctorType As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtSkipCheck As System.Web.UI.HtmlControls.HtmlInputHidden

    Protected WithEvents HidLeumit_Infant As System.Web.UI.HtmlControls.HtmlInputHidden

    Protected WithEvents txtDoctorCareName As System.Web.UI.WebControls.Label
    Protected WithEvents txtDoctorCareNumber As System.Web.UI.WebControls.Label
    Protected WithEvents txtClinicName As System.Web.UI.WebControls.Label
    Protected WithEvents txtClinicNumber As System.Web.UI.WebControls.Label
    Protected WithEvents txtInsuredID As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtInsuredName As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtInsuredFamily As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtPolicy As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtWorkerID As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFromTooth As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtToTooth As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtClaimID As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtInvoiceID As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtSum As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents lstSum As System.Web.UI.HtmlControls.HtmlSelect
    Protected WithEvents txtAnswer As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents txtNote As System.Web.UI.HtmlControls.HtmlTextArea
    Protected WithEvents txtCareTypeCombo As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtOccasionCombo As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAppType As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidGovernmentTreatments As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidHaveGovernmentTreatments As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidShowOldTreatments As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidSalParticipation As System.Web.UI.HtmlControls.HtmlInputHidden

    Protected WithEvents txtXrayA As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtXrayB As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtRangeTeeth As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents trPolicy As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents txtPriodontRequestMode As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents cmdConsultationReq As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdConsultationNew As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents txtFillingString As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtSmileAgrementClinic As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidInsuredBirthDate As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents WLType As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidHasReportConsultation As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents cmdShowConsultations As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents txtFocusFlag As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidWinName As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents cmdShowOldTreatments As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents hidPolGovTreatment As System.Web.UI.HtmlControls.HtmlInputHidden

    Protected WithEvents HidClaimID As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents HidFromHodReportDailyRequests As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents verofbrowser As Global.System.Web.UI.HtmlControls.HtmlInputHidden


    'Protected WithEvents txtServiceBasket As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected Const cEmptyCareCode As String = "��� �����..."

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If Utils.Values.GetConfigurationInteger("ForcedNewDesign") = 1 Then
            Response.Redirect(Utils.Navigation.GetURL("frmRequestt.aspx", String.Empty, False) + Request.Url.Query)
        End If

        'Chk Prm
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()



        'Page.ClientScript.RegisterArrayDeclaration("Skills", "'C#'")
        'Page.ClientScript.RegisterArrayDeclaration("Skills", "'VB.NET'")
        'Page.ClientScript.RegisterArrayDeclaration("Skills", "'C'")
        'Page.ClientScript.RegisterArrayDeclaration("Skills", "'C++'")


        Dim s As String = ""
        With Request.Browser
            s &= "Browser Capabilities" & vbCrLf
            s &= "Type = " & .Type & vbCrLf
            s &= "Name = " & .Browser & vbCrLf
            s &= "Version = " & .Version & vbCrLf
            s &= "Major Version = " & .MajorVersion & vbCrLf
            s &= "Minor Version = " & .MinorVersion & vbCrLf
            s &= "Platform = " & .Platform & vbCrLf
            s &= "Is Beta = " & .Beta & vbCrLf
            s &= "Is Crawler = " & .Crawler & vbCrLf
            s &= "Is AOL = " & .AOL & vbCrLf
            s &= "Is Win16 = " & .Win16 & vbCrLf
            s &= "Is Win32 = " & .Win32 & vbCrLf
            s &= "Supports Frames = " & .Frames & vbCrLf
            s &= "Supports Tables = " & .Tables & vbCrLf
            ' ''s &= "Supports Cookies = " & .Cookies & vbCrLf
            ' ''s &= "Supports VBScript = " & .VBScript & vbCrLf
            's &= "Supports JavaScript = " & _
            '    .EcmaScriptVersion.ToString() & vbCrLf
            ' s &= "Supports Java Applets = " & .JavaApplets & vbCrLf
            's &= "Supports ActiveX Controls = " & .ActiveXControls & _
            'vbCrLf
            's &= "Supports JavaScript Version = " & _
            'Request.Browser("JavaScriptVersion") & vbCrLf
        End With
        verofbrowser.Value = s

        If Not Request.QueryString("sourchWin") Is Nothing Then
            If Request.QueryString("sourchWin").ToString <> "" Then
                HidOrgSourchWin.Value = Request.QueryString("sourchWin").ToString
            End If

        End If

        If Not Request.QueryString("Makor") Is Nothing Then
            If Request.QueryString("Makor").ToString <> "" Then
                HidSourchWin.Value = CInt(Request.QueryString("Makor").ToString)
            End If

        End If

        If Not Request.QueryString("DayForReport") Is Nothing Then
            If Request.QueryString("DayForReport").ToString <> "" Then
                HidDayForReport.Value = Request.QueryString("DayForReport").ToString
            End If

        End If

        If Request.QueryString("CurrentAsmacta") Is Nothing Then



            If Session("BSHN_AllowClaims") <> "1" Then
                objUser.AddUserIllegalAction("24304391-6FDE-4237-A9B6-49630958EB26", User.Identity.Name, "frmRequestt")
                Response.Redirect("Login.aspx")
            End If
            If IsNothing(Session("Login_User")) OrElse Len(Session("Login_User")) = 0 Then
                Response.Redirect("Login.aspx")
            End If

        Else

            If Not Request.QueryString("CurrentAsmacta").ToString Is Nothing Then
                If Request.QueryString("CurrentAsmacta").ToString <> "" Then
                    HidCurrentAsmacta.Value = Request.QueryString("CurrentAsmacta").ToString
                Else
                    txtError.Value = "��� ������"
                    Return
                End If
            Else
                txtError.Value = "��� ������"
                Return
            End If




        End If

        If Not IsPostBack Then
            If Session("User_Login_First_Time") = "1" Then
                Response.Redirect("frmUserProp.aspx")
            End If
            HidLeumit_Infant.Value = "0"
            If Not Session("Leumit_Infant") Is Nothing Then
                HidLeumit_Infant.Value = Session("Leumit_Infant").ToString
            End If


            hidSalParticipation.Value = objUser.GetGeneralParameter("3FCAAB6E-4AAD-4231-A9F2-B9CCA67EE079", "SalParticipation").ToString()

            txtCompany.Value = Application("CompanyID").ToString
            If Session("BSHN_Independed") = "1" Then
                lstDoctorCare.Visible = False
                txtDoctorCareName.Visible = True
            Else
                lstDoctorCare.Visible = True
                txtDoctorCareName.Visible = False
            End If
            txtToday.Value = Format(DateTime.Today, "ddMMyyyy")
            FillDefaults()
            BindCareGroupCombo()
            lstCareGroup.SelectedIndex = 0
            txtAppType.Value = Application("App_Type").ToString
            hidHaveGovernmentTreatments.Value = Application("GovernmentTreatments").ToString()
            hidShowOldTreatments.Value = Application("ShowOldTreatments").ToString()
            txtSmileAgrementClinic.Value = ""
            ' ''If Application("GovernmentTreatments").ToString() = "1" And Application("ShowOldTreatments").ToString() = "1" Then
            ' ''    cmdShowOldTreatments.Visible = True
            ' ''Else
            ' ''    cmdShowOldTreatments.Visible = False
            ' ''End If
            'hidHasReportConsultation.Value = objUser.CheckUserHaveReportConsultation("801B330D-716F-4844-9F1A-A3628B03A7C3", User.Identity.Name)

            If Session("MRequest_Source") = "1" Then
                If Session("BSHN_Independed") <> "1" Then
                    Try
                        If IsNumeric(Session("MRequest_DoctorCare")) Then
                            lstDoctorCare.SelectedIndex = CInt(Session("MRequest_DoctorCare"))
                            txtDoctorCareNumber.Text = Session("MRequest_DoctorCareName").ToString
                        End If
                    Finally
                        '
                    End Try
                End If
                txtInsuredID.Value = Session("MRequest_InsuredID")
                txtInsuredName.Value = Session("MRequest_InsuredName")
                txtInsuredFamily.Value = Session("MRequest_InsuredFamily")
                txtLName.Value = Session("MRequest_LName")
                txtFName.Value = Session("MRequest_FName")
                hidPolGovTreatment.Value = Session("MRequest_PolGovTreatment")

                If IsNumeric(Session("MRequest_RequestType")) Then
                    lstRequestType.SelectedIndex = Val(Session("MRequest_RequestType"))
                End If
                Session("MRequest_Source") = ""
            End If

            If Session("Back_Consultation") = "1" Then
                Session("Back_Consultation") = ""
                txtFocusFlag.Value = "3"
            End If

            If Application("TeethMode").ToString() = "1" Then
                txtTeethMode.Value = "1"
            End If
            Dim bAllowMouthRequest As Boolean = objUser.GetMouthRequestPermitions("AC616A4E-9E4B-4B27-BB73-B4A8AC31A63E", User.Identity.Name)
            If Not bAllowMouthRequest Then
                cmdMRequest.Visible = False
                txtTeethMode.Value = "1"
            End If
            Dim iDoctorType As Integer = objUser.GetUserDoctorType("C049B33B-243D-43C1-B2F5-AB4859F9EBD1", User.Identity.Name)
            If iDoctorType <> 3 Then
                cmdAddAttachForLastRequest.Style.Add("display", "none")
            End If
            txtDoctorType.Value = CStr(iDoctorType)
            If objUser.GetPriodontRequestPermitions("1DDDF20C-5DC6-4656-A2CB-2D83B7CC13D9", User.Identity.Name) Then
                txtPriodontRequestMode.Value = "1"
            Else
                txtPriodontRequestMode.Value = "0"
            End If
            If Not objUser.GetConsultationPermitions("AB699114-1C1D-4EB7-8186-033B5306E799", User.Identity.Name) Then
                cmdConsultationReq.Visible = False
                cmdConsultationNew.Visible = False
            End If


            If Application("Smile") = "1" Or Application("CompanyID").ToString = "3" Then
                ' Smile or Leumit
                If Application("Smile") = "1" Then
                    txtSkipCheck.Value = "1"
                Else
                    txtSkipCheck.Value = "2"
                End If

                hidInsuredBirthDate.Value = Session("Smile_InsuredBirthDate")

                SetReadOnly(txtInsuredID)
                SetReadOnly(txtInsuredName)
                SetReadOnly(txtInsuredFamily)

                If Application("CompanyID").ToString <> "3" Then
                    cmdMRequest.Style.Add("display", "none")
                End If
                cmdConsultationNew.Style.Add("display", "none")
                'cmdConsultationReq.Style.Add("display", "none")
                cmdNew.Style.Add("display", "none")
                'cmdCopy.Style.Add("display", "none")
                txtSmileAgrementClinic.Value = objUser.CheckIfAgrementClinic("4C29075C-B17E-4EB5-A302-5EB9D5930E99", User.Identity.Name)
                If txtSmileAgrementClinic.Value = "1" Then
                    txtSum.Style.Add("display", "none")
                    lstSum.Style.Add("display", "block")
                    BindAmountCombo()
                Else
                    txtSum.Style.Add("display", "block")
                    lstSum.Style.Add("display", "none")
                End If

                If Session("MRequest_RequestType") = "1" Then
                    txtInsuredID.Value = Session("MRequest_InsuredID")
                    txtInsuredName.Value = Session("MRequest_InsuredName")
                    txtInsuredFamily.Value = Session("MRequest_InsuredFamily")
                    txtLName.Value = txtInsuredFamily.Value
                    txtFName.Value = txtInsuredName.Value
                    'txtInsuredID.Disabled = True
                    'txtInsuredName.Disabled = True
                    'txtInsuredFamily.Disabled = True
                    lstRequestType.SelectedIndex = 0
                Else
                    lstRequestType.SelectedIndex = 2
                    lstRequestType.Enabled = False
                End If
                txtInsuredID.Attributes.Remove("onblur")
                If Application("CompanyID").ToString <> "3" Then
                    Session("MRequest_InsuredID") = ""
                    Session("MRequest_InsuredName") = ""
                    Session("MRequest_InsuredFamily") = ""
                End If
            End If


            If Not Request.QueryString("CurrentAsmacta") Is Nothing Then

                HidFromHodReportDailyRequests.Value = "1"
                lstRequestType.SelectedValue = 9

                HidClaimID.Value = Request.QueryString("CurrentAsmacta").ToString
                Session("MRequest_Source") = ""



            End If







            Dim objTreatmentService As New TreatmentConnect.TreatmentService()
            objTreatmentService.Url = Application("TreatmentWebService").ToString()
            txtFillingString.Value = objTreatmentService.GetFillingTreatmentsString("7E9CBF59-C684-4EAD-8C6E-13B56E303FB2")


            'If Application("CompanyID").ToString = "3" Then

            '    Dim ds As DataSet = objTreatmentService.GetCountRequestPerUserPerDay("0555E25A-DCDE-11E2-8D81-F2CE6088709B", CInt(txtInsuredID.Value), User.Identity.Name)
            '    If ds.Tables.Count > 0 Then
            '        If ds.Tables(0).Rows.Count > 0 Then
            '            Session("dsCountRequestPerUserPerDay") = ds
            '        End If
            '    End If



            'End If


        End If
    End Sub

    Sub SetReadOnly(ByVal txtField As HtmlInputText)
        txtField.Attributes.Add("readonly", "true")
        txtField.Style.Add("background-Color", "#D6D3CE")
    End Sub

    Private Sub FillDefaults()
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        txtMaxClaimSum.Value = objTreatmentService.GetMaxClaimSum("D2D2CC74-A3CE-4420-B6CE-073F25E8E70A")
        Dim strDoctorCareName As String
        Dim strDoctorCareNumber As String
        Dim strClinicName As String
        Dim strClinicNumber As String
        If objTreatmentService.GetDoctorProperties("7EC6114A-62CD-4DC4-A940-1416BFB136D8", User.Identity.Name, strDoctorCareName, strDoctorCareNumber, strClinicName, strClinicNumber) Then
            If Session("BSHN_Independed") = "1" Then
                txtDoctorCareName.Text = strDoctorCareName
                txtDoctorCareNumber.Text = strDoctorCareNumber
            Else
                Dim objUser As New UserConnect.UserService()
                objUser.Url = Application("UserWebService").ToString()
                lstDoctorCare.DataSource = objUser.GetDoctorList("03407803-DE6A-41AA-87DC-60D1D0329753", User.Identity.Name)
                lstDoctorCare.DataBind()
                If lstDoctorCare.Items.Count > 1 Then
                    lstDoctorCare.Items.Insert(0, New ListItem("���...", "0"))
                Else
                    txtDoctorCareNumber.Text = strDoctorCareNumber
                End If

                'SetComboValue(lstDoctorCare, strDoctorCareNumber)
            End If
            txtClinicName.Text = CEncode.StringEncode(strClinicName)
            txtClinicNumber.Text = strClinicNumber
        End If
        If Application("BSHN_WorkerIDRequired").ToString() = "1" Then
            txtWorkerID.Attributes.Add("required", "1")
            txtPolicy.Attributes.Add("required", "1")
        Else
            txtWorkerID.Value = "9999999"
            trPolicy.Style("display") = "none"
            'txtWorkerCID.Value = "9"
        End If
        lstRequestType.SelectedIndex = 0
    End Sub

    Private Sub BindCareGroupCombo()
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

        Dim ds As Data.DataSet
        Dim isSmileAgrementClinic As Boolean = False
        Dim iSmileAgrementClinicPlus As Integer = 0
        If Application("Smile") = "1" Then
            iSmileAgrementClinicPlus = objUser.CheckIfAgrementClinicPlus("2AFAE3F5-79B5-459E-B1F9-C460BD34672A", User.Identity.Name)
            If iSmileAgrementClinicPlus > 0 Then
                isSmileAgrementClinic = True
            End If
        End If
        If Session("Leumit_OnlyServiceBasket") = "1" Or isSmileAgrementClinic Then
            If iSmileAgrementClinicPlus = 2 Then
                ds = objTreatmentService.GetTreatmentTypesForServiceBasketPlus("9E01224E-7A57-4E50-A64F-857E4DB868CC")
            Else
                ds = objTreatmentService.GetTreatmentTypesForServiceBasket("3E1378D4-4A76-4F92-B0AF-CB3AFBA60DA4")
            End If
        ElseIf Session("Smile_OnlyServiceBasketNet") = "1" Then
            ds = objTreatmentService.GetTreatmentTypesForServiceBasketNet("2DABD6CC-E754-44EF-8EAD-2044986E91E0")
        Else
            ds = objTreatmentService.GetTreatmentTypes("1C39E920-093F-46B2-BEE7-A4D459A3F1CC")
        End If
        If Application("Smile") = "1" And Application("Smile_Platinum_18_Supported") = "1" And Session("Smile_Platinum_18") = "1" And Not isSmileAgrementClinic Then
            lstCareGroup.Items.Add(New ListItem("���...", 0))
            lstCareGroup.Items.Add(New ListItem("����", 1))
        Else
            BindCombo("TreatmentType", "TreatmenTypetID", lstCareGroup, ds)
        End If
    End Sub

    Private Sub BindAmountCombo()
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim currRow As DataRow
        Dim ds As DataSet = objTreatmentService.GetClinicAmounts("7FC988DD-BAA2-4EBB-8D20-7AC1F67CA423")

        lstSum.Items.Add(New ListItem("���...", -1))
        For Each currRow In ds.Tables(0).Rows
            lstSum.Items.Add(New ListItem(currRow("Amount").ToString(), currRow("Amount").ToString()))
        Next

    End Sub

    Private Sub BindCombo(ByVal strTextField As String, ByVal strValueField As String, ByRef cbo As DropDownList, ByRef ds As Data.DataSet)
        Dim currRow As DataRow
        cbo.Items.Add(New ListItem("���...", 0))
        For Each currRow In ds.Tables(0).Rows
            cbo.Items.Add(New ListItem(currRow(strTextField).ToString(), currRow(strValueField).ToString()))
        Next
    End Sub

    Private Sub cmdExit_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdExit.ServerClick
		CheckWindowName()
        Session("Filter_On") = ""

        Session("Filter_To_Date") = ""
        Session("Filter_From_Date") = ""
        Session("MRequest_Source") = "1"
        Session("Filter_InsuredID") = ""
        ''''''''''''''''''''''''''''''Session("Report_List_ReportType") = ""

        Session("MRequest_DoctorCare") = ""
        Session("MRequest_DoctorCareName") = ""

        Session("MRequest_InsuredID") = ""
        Session("MRequest_InsuredName") = ""
        Session("MRequest_InsuredFamily") = ""
        Session("MRequest_LName") = ""
        Session("MRequest_FName") = ""
        Session("MRequest_PolGovTreatment") = ""

        Session("MRequest_RequestType") = ""

        Session("From_Consultation") = ""


        If Not Session("SugDivuachBack") Is Nothing Then
            If Not Session("SugDivuachBack").ToString Is System.DBNull.Value And Not Session("SugDivuachBack").ToString = "" Then
                Response.Redirect(Session("SugDivuachBack"))
            End If
        End If

        If Application("CompanyID") & "" = "3" Then
            Response.Redirect("frmLMCheck.aspx")
        ElseIf Application("Smile") = "1" Then
            Response.Redirect("frmCheckSM.aspx")
        Else
            Dim sCurrentAsmacta As String = HidCurrentAsmacta.Value
            Dim stz As String = txtInsuredID.Value
            Dim sDayForReport As String = HidDayForReport.Value

            If stz = "" Then
                If Not Session("TzForfrmHDReportDailyRequests") Is Nothing Then
                    stz = Session("TzForfrmHDReportDailyRequests")
                End If
            End If

            If HidSourchWin.Value = "" Then
                Response.Redirect(Application("FORMStart"))
            End If


            If HidSourchWin.Value = eHidSourchWin.eRequests Then
                Response.Redirect("frmHDReportDailyRequests.aspx?SugDivuach=11&Asmaxta=" + sCurrentAsmacta + "&DayForReport=" + sDayForReport + "&tz=" + stz + "&SourchWin=" + HidOrgSourchWin.Value)
            End If

            If HidSourchWin.Value = eHidSourchWin.eConsultations Then
                Response.Redirect("frmHDReportDailyRequests.aspx?SugDivuach=41&Asmaxta=" + sCurrentAsmacta + "&DayForReport=" + sDayForReport + "&tz=" + stz + "&SourchWin=" + HidOrgSourchWin.Value)
            End If

            If HidSourchWin.Value = eHidSourchWin.eAccount Then
                Response.Redirect("frmHDReportDailyRequests.aspx?SugDivuach=10&Asmaxta=" + sCurrentAsmacta + "&DayForReport=" + sDayForReport + "&tz=" + stz + "&SourchWin=" + HidOrgSourchWin.Value)
            End If

            If HidSourchWin.Value = eHidSourchWin.eHDRepList Then
                Session("Report_List_ReportType") = "500"
                Response.Redirect("frmHDRepList.aspx?SugDivuach=500")
            End If




            End If
    End Sub

    Private Sub cmdUserProp_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUserProp.ServerClick
		CheckWindowName()
        Session("User_Prop_Caller") = "frmRequestt.aspx"
        Response.Redirect("frmUserProp.aspx")
    End Sub

    Private Sub cmdNew_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdNew.ServerClick
		CheckWindowName()
        Dim iIndex As Integer
        If Session("BSHN_Independed") <> "1" Then
			Try
				iIndex = lstDoctorCare.SelectedIndex
			Finally
				'
			End Try
        End If
        MyBase.ViewState.Clear()
        lstCareType.Items.Clear()
        lstOccasion.Items.Clear()
        FillDefaults()
        If Session("BSHN_Independed") <> "1" Then
			Try
				lstDoctorCare.SelectedIndex = iIndex
			Finally
				'
			End Try
        End If
        lstCareGroup.SelectedIndex = 0
        txtAnswer.InnerText = ""
        txtCareTypeCombo.Value = ""
        txtOccasionCombo.Value = ""
        txtDate.Value = "00000000"
        cmdSend.Disabled = False
        txtLName.Value = ""
        txtFName.Value = ""
    End Sub

    Private Sub cmdCopy_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCopy.ServerClick
        CheckWindowName()
        Dim strInsuredID As String = txtInsuredID.Value
        Dim strInsuredName As String = txtInsuredName.Value
        Dim strInsuredFamily As String = txtInsuredFamily.Value
        Dim strPolicy As String = txtPolicy.Value
        Dim strWorkerID As String = txtWorkerID.Value
        Dim strLName As String = txtLName.Value
        Dim strFName As String = txtFName.Value
        Dim strPolGovTreatment As String = hidPolGovTreatment.Value
        Dim iIndex As Integer, iIndex1 As Integer
        iIndex1 = lstRequestType.SelectedIndex
        If Session("BSHN_Independed") <> "1" Then
			Try
				iIndex = lstDoctorCare.SelectedIndex
			Finally
				'
			End Try
        End If
        MyBase.ViewState.Clear()
        lstCareType.Items.Clear()
        lstOccasion.Items.Clear()
        FillDefaults()
        If Session("BSHN_Independed") <> "1" Then
			Try
				lstDoctorCare.SelectedIndex = iIndex
				txtDoctorCareNumber.Text = lstDoctorCare.SelectedItem.Value
			Finally
				'
			End Try
        End If
        lstRequestType.SelectedIndex = iIndex1
        lstCareGroup.SelectedIndex = 0
        txtInsuredID.Value = strInsuredID
        txtInsuredName.Value = strInsuredName
        txtInsuredFamily.Value = strInsuredFamily
        txtPolicy.Value = strPolicy
        txtWorkerID.Value = strWorkerID
        txtLName.Value = strLName
        txtFName.Value = strFName
        txtAnswer.InnerText = ""
        txtCareTypeCombo.Value = ""
        txtOccasionCombo.Value = ""
        txtDate.Value = "00000000"
        cmdSend.Disabled = False
        hidPolGovTreatment.Value = strPolGovTreatment
    End Sub

    Private Sub SetComboValue(ByRef cbo As DropDownList, ByVal strValue As String)
        Dim li As ListItem = cbo.Items.FindByValue(strValue)
        If Not li Is Nothing Then
            li.Selected = True
        End If
    End Sub

    Private Sub cmdMRequest_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdMRequest.ServerClick
		CheckWindowName()
        Session("MRequest_InsuredID") = txtInsuredID.Value
        Session("MRequest_InsuredName") = txtInsuredName.Value
        Session("MRequest_InsuredFamily") = txtInsuredFamily.Value
        Session("MRequest_LName") = txtLName.Value
        Session("MRequest_FName") = txtFName.Value
        If Session("BSHN_Independed") <> "1" Then
            Session("MRequest_DoctorCare") = CStr(lstDoctorCare.SelectedIndex)
            Session("MRequest_DoctorCareName") = CStr(lstDoctorCare.SelectedValue)
        Else
            Session("MRequest_DoctorCare") = "0"
            Session("MRequest_DoctorCareName") = txtDoctorCareNumber.Text
        End If
        Session("MRequest_Source") = "2"
        Response.Redirect("frmHDMRequestt.aspx")
    End Sub

    Private Sub cmdConsultationReq_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdConsultationReq.ServerClick
		CheckWindowName()
        Session("TRequest_InsuredID") = txtInsuredID.Value
        Session("TRequest_InsuredName") = txtInsuredName.Value
        Session("TRequest_InsuredFamily") = txtInsuredFamily.Value
        Session("TRequest_LName") = txtLName.Value
        Session("TRequest_FName") = txtFName.Value

        Session("TRequest_PolGovTreatment") = hidPolGovTreatment.Value
        If Session("BSHN_Independed") <> "1" Then
            Session("MRequest_DoctorCare") = CStr(lstDoctorCare.SelectedIndex)
            Session("MRequest_DoctorCareName") = CStr(lstDoctorCare.SelectedValue)
        Else
            Session("MRequest_DoctorCare") = "0"
            Session("MRequest_DoctorCareName") = txtDoctorCareNumber.Text
        End If

        If (Application("MilkTeeth") = "1") Then
            Response.Redirect("frmTRequesttExt.aspx?fromCmdClean=1")
        Else
            Response.Redirect("frmHDTRequestt.aspx?fromCmdClean=1")
        End If

    End Sub

    Private Sub cmdShowConsultations_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdShowConsultations.ServerClick
		CheckWindowName()
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

        Dim iShowReportConsultationPerion As Integer

        iShowReportConsultationPerion = Val(objUser.GetGeneralParameter("3FCAAB6E-4AAD-4231-A9F2-B9CCA67EE079", "ConsultationShowPeriod"))

        If iShowReportConsultationPerion = 0 Then
            iShowReportConsultationPerion = 6
        End If


        Session("Filter_On") = "1"

        Session("Filter_To_Date") = DateTime.Now.ToString("ddMMyyyy")
        Session("Filter_From_Date") = DateAdd(DateInterval.Month, -iShowReportConsultationPerion, DateTime.Now).ToString("ddMMyyyy")
        Session("MRequest_Source") = "1"
        Session("Filter_InsuredID") = txtInsuredID.Value
        Session("Report_List_ReportType") = "41"
        Session("Filter_Viewed") = "1"
        Session("Filter_NotViewed") = "1"

        If Session("BSHN_Independed") <> "1" Then
            Session("MRequest_DoctorCare") = CStr(lstDoctorCare.SelectedIndex)
            Session("MRequest_DoctorCareName") = CStr(lstDoctorCare.SelectedValue)
        Else
            Session("MRequest_DoctorCare") = "0"
            Session("MRequest_DoctorCareName") = txtDoctorCareNumber.Text
        End If

        Session("MRequest_InsuredID") = txtInsuredID.Value
        Session("MRequest_InsuredName") = txtInsuredName.Value
        Session("MRequest_InsuredFamily") = txtInsuredFamily.Value
        Session("MRequest_LName") = txtLName.Value
        Session("MRequest_FName") = txtFName.Value
        Session("MRequest_RequestType") = lstRequestType.SelectedIndex
        Session("MRequest_PolGovTreatment") = hidPolGovTreatment.Value


        Session("From_Consultation") = "1"

        Response.Redirect("frmRepList.aspx")
    End Sub
	
    Private Sub CheckWindowName()
        If Session("winname") = "" Then
            If (hidWinName.Value <> "") Then
                Session("winname") = hidWinName.Value
			End If
        Else
            If hidWinName.Value <> Session("winname") Then
				Response.Redirect("frmInvalidOperation.aspx")
			End If
        End If
    End Sub

    Protected Sub lstCareGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles lstCareGroup.SelectedIndexChanged

    End Sub


    Enum eHidSourchWin As Integer
        eRequests = 1
        eConsultations = 2
        eAccount = 3
        eHDRepList = 4
    End Enum


End Class
