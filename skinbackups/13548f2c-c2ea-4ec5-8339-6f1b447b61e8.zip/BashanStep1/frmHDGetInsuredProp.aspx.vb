Imports System.Text.RegularExpressions
Public Class frmHDGetInsuredProp
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim strID As String = Request.Form("hidInsuredID")
        Dim strSearchType As String
        Try
            strSearchType = Request.Form("hidSearchType")
        Catch ex As Exception
            strSearchType = ""
        End Try

        Dim strFirstName As String = ""
        Dim strLastName As String = ""
        Dim strPolicyNo As String = ""
        Dim iPolicyNo As Integer = 0
        Dim iGuf As String = 0
        Dim strEmployeeNo As String = ""
        Dim strEmpCD As String = ""
        Dim strPolGovTreatment As String = ""

        Dim iCheckPolicy As Integer = 0
        Dim iRetValue As Integer = 0
        Dim objBoLink As New TreatmentConnect.TreatmentService()
        objBoLink.Url = Application("TreatmentWebService").ToString()
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

        Session.Remove("HDInsuredID")
        Session.Remove("HDSHEM")
        Session.Remove("HDMISP")

        If strSearchType = "1" Then
            iRetValue = objBoLink.GetSQLInsuredProp("6C865031-52E9-4422-950B-615B8F84600C", strID, strFirstName, strLastName)
        Else
            Try
                Select Case strSearchType
                    Case "2"
                        iRetValue = objBoLink.GetInsuredPropExt("2C331B73-13D1-4D07-B669-F409BE3CFB58", strID, strFirstName, strLastName, iPolicyNo, iGuf, strPolGovTreatment)
                        If iPolicyNo > 0 Then
                            iCheckPolicy = objBoLink.CheckZakautPolicy("BDF9BCE6-8DB9-4199-A70D-0D8DF3091978", iPolicyNo)
                            strPolicyNo = CStr(iPolicyNo)
                        End If
                    Case "3"
                        iRetValue = objBoLink.GetInsuredPropExt("2C331B73-13D1-4D07-B669-F409BE3CFB58", strID, strFirstName, strLastName, iPolicyNo, iGuf, strPolGovTreatment)
                        iCheckPolicy = objBoLink.CheckMultiCheckPolicy("9001C9EA-9ED8-4EC0-917D-843946ECE907", iPolicyNo)
                        strPolicyNo = CStr(iPolicyNo)
                    Case Else
                        iRetValue = objBoLink.GetInsuredPropExt("2C331B73-13D1-4D07-B669-F409BE3CFB58", strID, strFirstName, strLastName, iPolicyNo, iGuf, strPolGovTreatment)
                End Select
			Catch ex As Exception
				Const cSoShortMessage = "Server was unable to process request."
				Const cUnaleToCastMessage = "Unable to cast object of type "

				Dim strSubject As String
				Dim strMessage As String
				Dim sStackTrace As String

				iRetValue = 0
				Dim strUrl As String = "" + Application("ErrorReportConnectorService").ToString()
				If strUrl <> "" Then
					Dim sErrMessage As String = ex.Message
					If Not IsNothing(ex.InnerException) Then
						sErrMessage = ex.InnerException.Message
					End If

					Dim sErrStack As String = ex.StackTrace
					If Not IsNothing(ex.InnerException) Then
						sErrStack = ex.InnerException.StackTrace
					End If

					sErrMessage = RemoveSpecialCharacters(sErrMessage).Replace(">", "").Replace("<", "")
					Dim nPoint As Integer = 0
					Dim nStartPoint As Integer = 0
					If (sErrMessage.IndexOf(": ") > 0) Then
						nStartPoint = sErrMessage.LastIndexOf(": ") + 2
					End If

					Dim sSubjMessage As String = sErrMessage.Substring(nStartPoint)

					If (sSubjMessage.IndexOf(cSoShortMessage) > -1) Then
						Dim sDescription = sSubjMessage.Substring(cSoShortMessage.Length + 1)
						nPoint = sDescription.IndexOf(".")
						If (nPoint < 0) Then
							nPoint = sDescription.IndexOf(":")
						End If
						If (nPoint < 0) Then
							nPoint = Math.Min(40, sDescription.Length - 1)
						End If
						nPoint += cSoShortMessage.Length + 1
					ElseIf (sSubjMessage.IndexOf(cUnaleToCastMessage) > -1) Then
						nPoint = sSubjMessage.Length() - 1
					Else
						nPoint = sSubjMessage.IndexOf(".")
						If nPoint = -1 Then
							nPoint = sSubjMessage.Length - 1
						End If
					End If

					Dim sApplicationName = Application("ErrorApplicationName").ToString()
					If (String.IsNullOrEmpty(sApplicationName)) Then
						sApplicationName = "Undefined"
					End If

					strSubject = sSubjMessage.Substring(0, nPoint + 1)
					strMessage = "System:" & sApplicationName & "; User:" & User.Identity.Name & "; UserAddress:" & Request.UserHostAddress & "; URL:" & Request.Url.AbsoluteUri & "; Message:" & sErrMessage & "; StackTrace:" & sStackTrace


					Dim bConnectionError As Boolean = False
					Dim objErrorReportConnect As New ErrorReportConnect.ErrorReportConnector()
					objErrorReportConnect.Url = strUrl
					Try
						Dim iTestValue As Integer = objUser.CheckWS()
					Catch exErr As Exception
						strMessage = Request.Url.AbsoluteUri & "; " & exErr.Message
						bConnectionError = True
					End Try

					Try
						objErrorReportConnect.SendErrorWithSubject("9F8D01F4-6CBF-4852-B5E0-1FD2A3AB7F60", strMessage, strSubject, bConnectionError)
					Catch ex1 As Exception
						'
					End Try
				End If
			End Try
        End If

        Dim strHasReportConsultation As String = ""

#If Not NewDesign Then
        strHasReportConsultation = objUser.CheckUserHaveReportConsultation("801B330D-716F-4844-9F1A-A3628B03A7C3", User.Identity.Name, strID)
#End If

        Dim objResult As New System.Text.StringBuilder()
        objResult.Append("<HTML><HEAD><TITLE></TITLE>")
        objResult.Append("<meta http-equiv='Cache-Control' content='no-cache'>" & vbCrLf)
        objResult.Append("<meta http-equiv='Pragma' content='no-cache'>" & vbCrLf)
        objResult.Append("<meta http-equiv='Expires' content='0'>" & vbCrLf)
        objResult.Append("<META http-equiv='Content-Type' content='text/html; charset=windows-1255'>")
        objResult.Append("</HEAD>")
        objResult.Append("<BODY onload='if(window.parent.FillInsured==undefined){window.opener.FillInsured()}else{window.parent.FillInsured()};'>")
        objResult.Append("<INPUT type='hidden' id='txtFirstName' value='" & strFirstName & "'>")
        objResult.Append("<INPUT type='hidden' id='txtLastName' value='" & strLastName & "'>")

        Session("HDInsuredID") = strID
        Session("HDSHEM") = strFirstName
        Session("HDMISP") = strLastName

        objResult.Append("<INPUT type='hidden' id='txtInsuredID' value='" & strID & "'>")
        objResult.Append("<INPUT type='hidden' id='txtPolicyNo' value='" & strPolicyNo & "'>")
        objResult.Append("<INPUT type='hidden' id='txtCheckPolicy' value='" & CStr(iCheckPolicy) & "'>")
        objResult.Append("<INPUT type='hidden' id='txtHasReportConsultation' value='" & strHasReportConsultation & "'>")
        objResult.Append("<INPUT type='hidden' id='txtPolGovTreatment' value='" & strPolGovTreatment & "'>")
        'objResult.Append("<SCRIPT>")
        'objResult.Append("if(window.parent.FillInsured==undefined){window.opener.FillInsured()}else{window.parent.FillInsured()};")
        'objResult.Append("</SCRIPT>")
        objResult.Append("</BODY>")
        objResult.Append("</HTML>")
        Response.Write(objResult.ToString())
	End Sub

	Private Function RemoveSpecialCharacters(ByVal inputStr As String) As String
		Dim sb = New System.Text.StringBuilder(inputStr.Length)
		For i As Integer = 0 To inputStr.Length - 1
			If ((inputStr(i) >= " ") OrElse (inputStr(i) = Chr(10)) OrElse (inputStr(i) = Chr(13)) OrElse (inputStr(i) = Chr(9))) Then
				sb.Append(inputStr(i))
			End If
		Next

		Return sb.ToString()
	End Function
End Class
