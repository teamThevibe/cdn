﻿Imports System.Text.RegularExpressions

Public Class frmHDUserPass
    Inherits System.Web.UI.Page

    Protected WithEvents trAllowChangePassword As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents LExtraQuestion As System.Web.UI.WebControls.Literal
    Protected WithEvents LExtraAnswer As System.Web.UI.WebControls.Literal
    Protected WithEvents txtErrorEMail As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents cmdBack As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents tdRightPic As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents imgRightPic As System.Web.UI.HtmlControls.HtmlImage
    Protected WithEvents imgLeftPic As System.Web.UI.HtmlControls.HtmlImage
    Protected WithEvents txtHasCB As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents divUserName As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents chkExtra As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents trchkExtra As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents imgPwdToolTip As System.Web.UI.HtmlControls.HtmlImage
    Protected WithEvents QuestionMark1 As System.Web.UI.HtmlControls.HtmlAnchor
    Protected WithEvents divPromtTitle As System.Web.UI.HtmlControls.HtmlGenericControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        DirectCast(Me.Master, HDMasterPage).SetDisableMenu("1")
        InitializeComponent()
    End Sub

#End Region

    Private Class Messages
#If EngDesign Then ' YT:
        Public Const YouMustChangePassword As String = "You must change password"
        Public Const MissingPassword As String = "Missing Password"
        Public Const IncorrectPassword As String = "Incorrect password"
        Public Const PasswordConfirmationNotIdentical As String = "Password confirmation not identical to the new password."
        Public Const PasswordMustBeDifferent As String = "Password must be different from the user name."
        Public Const TheNewPasswordMustBeDifferent As String = "The new password must be different from the old."
        Public Const PasswordLengthMustBeBetween As String = "Password length must be between 6 and 10 signs"
        Public Const UseOnlyLettersAndNumbers As String = "Use only letters and numbers"
        Public Const DoNotRepeatLetterOrNumber As String = "Do not repeat letter or number more then twice."
        Public Const YouAlreadyUsedThisPassword As String = "You already used this Password"
        Public Const LoginQuestionMissing As String = "Login question missing"
        Public Const LoginResponseMissing As String = "Login Response missing"
        Public Const InvalidLoginDetail As String = "Invalid login detail. Please type letters and digits only"
        Public Const InvalidEMailAddress As String = "Invalid eMail address"
        Public Const DataUpdatedSuccessfully As String = "Data Updated Successfully"
        Public Const WrongUserName As String = "Wrong User Name"
        Public Const MissingUserName As String = "Missing User Name"
        Public Const UserIdentificationFailed As String = "User identification failed"
        Public Const MissingNewPassword As String = "Missing New Password"
#Else
        Public Const YouMustChangePassword As String = "יש לשנות סיסמה"
        Public Const MissingPassword As String = "חסרה סיסמה"
        Public Const IncorrectPassword As String = "הסיסמה הנוכחית שגויה"
        Public Const PasswordConfirmationNotIdentical As String = "אישור סיסמה לא זהה לסיסמה החדשה"
        Public Const PasswordMustBeDifferent As String = "אסור שהסיסמה תהיה זהה לשם המשתמש"
        Public Const TheNewPasswordMustBeDifferent As String = "אסור שהסיסמה החדשה תהיה זהה לסיסמה הנוכחית"
        Public Const PasswordLengthMustBeBetween As String = "אורך הסיסמה צריך להיות בין 6 ל 10 תווים"
        Public Const UseOnlyLettersAndNumbers As String = "יש להשתמש באותיות ומספרים בלבד"
        Public Const DoNotRepeatLetterOrNumber As String = "אין לחזור על אותה האות או המספר יותר מפעמיים"
        Public Const YouAlreadyUsedThisPassword As String = "הסיסמה החדשה היתה כבר בשימוש"
        Public Const LoginQuestionMissing As String = "חסרה שאלת זיהוי"
        Public Const LoginResponseMissing As String = "חסרה תשובת זיהוי"
        Public Const InvalidLoginDetail As String = "פרט זיהוי נוסף לא תקין - ניתן להקליד רק אותיות ומספרים"
        Public Const InvalidEMailAddress As String = "כתובת הדוא''ל לא תקינה"
        Public Const DataUpdatedSuccessfully As String = "הנתונים עודכנו בהצלחה"
        Public Const WrongUserName As String = "שם משתמש שגוי"
        Public Const MissingUserName As String = "שם משתמש חסר"
        Public Const UserIdentificationFailed As String = "זיהוי משתמש נכשל"
        Public Const MissingNewPassword As String = "חסרה סיסמה חדשה"
#End If
    End Class

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not IsPostBack Then
            Dim objUser As New UserConnect.UserService()
            objUser.Url = Application("UserWebService").ToString()

            If Application("RightLogo") = "1" Then
                divRIcon.Visible = True
            Else
                divRIcon.Visible = False
            End If

            Dim sMainTitle As String = "מערכת הוד - " & Page.Title
            CType(Master.FindControl("MainTitle"), Literal).Text = sMainTitle
            Page.Title = sMainTitle

            divRIcon.Visible = False

            Dim strUserName As String = User.Identity.Name
            Dim strUserType As String
            Dim strFName As String
            Dim strLName As String
            Dim strStreet As String
            Dim strHouse As String
            Dim strCity As String
            Dim strZIP As String
            Dim strPhone As String
            Dim strMobile As String
            Dim strFax As String
            Dim strEMail As String
            Dim strCFName As String
            Dim strCLName As String
            Dim strCStreet As String
            Dim strCHouse As String
            Dim strCCity As String
            Dim strCZIP As String
            Dim strCPhone As String
            Dim strCMobile As String
            Dim strCFax As String
            Dim strCEMail As String
            Dim strBank As String
            Dim strBranch As String
            Dim strAccount As String
            Dim strMailStreet As String
            Dim strMailPhone As String
            Dim strMailHouse As String
            Dim strMailEMail As String
            Dim strMailCity As String
            Dim strMailZIP As String
            Dim strService1 As String
            Dim strService2 As String
            Dim strService3 As String
            Dim strService4 As String
            Dim strService5 As String
            Dim strService6 As String
            Dim strProf1 As String
            Dim strProf2 As String
            Dim strProf3 As String
            Dim strProf4 As String
            Dim strProf5 As String
            Dim strClinicID As String
            Dim strClinicName As String
            Dim strDoctorID As String
            Dim strSupplierID As String
            Dim strSection As String
            Dim strCare As String
            Dim strGridRowCount As String

            Dim ExtraIdQuestionFromTable As String = ""
            Dim ExtraIdAnswerFromTable As String = ""

            objUser.GetProperties("305A57FB-F38A-4592-AA8E-882D66B1DEFC", strUserName, strUserType, strFName, strLName, strStreet, strHouse, strCity, strZIP, strPhone, strMobile, strFax, strEMail, _
                                  strCFName, strCLName, strCStreet, strCHouse, strCCity, strCZIP, strCPhone, strCMobile, strCFax, strCEMail, _
                                  strBank, strBranch, strAccount, strMailStreet, strMailPhone, strMailHouse, strMailEMail, strMailCity, strMailZIP, _
                                  strService1, strService2, strService3, strService4, strService5, strService6, strProf1, strProf2, strProf3, strProf4, _
                                  strProf5, strClinicID, strClinicName, strDoctorID, strSupplierID, strSection, strCare, strGridRowCount, "", "")

            'Select Case Application("App_Type").ToString.ToUpper()
            '    Case "DIST"
            '        If Session("AS400_User") = "1" Then
            '            txtUserType.Value = "4"
            '        Else
            '            txtUserType.Value = "3"
            '        End If
            '        If Session("Allow_Action_Type_Upload") = "1" Then
            '            cmdReturn.Visible = True
            '        Else
            '            cmdReturn.Visible = False
            '        End If
            '    Case "DIVUR"
            cmdHelp.Disabled = False
            txtUserType.Value = strUserType
            '    Case "CLAIM", "ENG"
            '        cmdHelp.Disabled = False
            '        txtUserType.Value = strUserType
            '        If Session("Allow_Action_Type_Upload") = "1" Then
            '            cmdReturn.Visible = True
            '        Else
            '            If Not cmdBack Is Nothing Then
            '                cmdBack.Visible = False
            '            End If
            '            cmdReturn.Visible = False
            '        End If
            '    Case "DOAR"
            '        cmdHelp.Disabled = False
            '        txtUserType.Value = "30"
            '        cmdReturn.Value = "יציאה"
            '        cmdReturn.Attributes("onclick") = "window.close();return;"
            '    Case "SUPP"
            '        cmdOK.Attributes.Remove("onclick")
            '        cmdHelp.Disabled = False
            '        txtUserType.Value = "40"
            'End Select

            txtAppType.Value = Application("App_Type").ToString

            Dim bShowExtra As Boolean = (Application("AllowExtraID") = "1")
            'If Application("App_Type").ToString.ToUpper() = "SUPP" Then
            '    bShowExtra = True
            'End If

            If bShowExtra Then
                trExtraQuestion.Visible = True
                Tr3.Visible = True
                objUser.GetExtraId("204A61C3-ACD7-4719-88B8-1B13313E9844", strUserName, ExtraIdQuestionFromTable, ExtraIdAnswerFromTable)
                If Len(ExtraIdAnswerFromTable) = 0 Then
                    txtQuestion.Attributes("class") = "InputStyle"
                    ExtraIdAnswer.Attributes("class") = "InputStyle"
                    If Session("User_Login_First_Time") = "1" Then
                    End If
                Else
                    txtQuestion.Attributes("class") = "InputDis"
                    ExtraIdAnswer.Attributes("class") = "InputDis"
                End If
            Else
                trExtraQuestion.Style.Add("display", "none")
                trExtraAnswer.Style.Add("display", "none")
            End If

            lblMessage.Text = Session("Message_Text")

            If Session("User_Login_First_Time") = "1" Then
                txtError.Value = Messages.YouMustChangePassword
                txtExpired.Value = "1"
                txtNewEMail.Value = Trim(strEMail)
            Else
                trEmail.Visible = False
                txtExpired.Value = ""
            End If
        Else
            divPasswordError.Visible = False
        End If

    End Sub

    Private Sub Page_PreRender(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.PreRender

        If Not IsPostBack Then
            ' Cancel using Mobile & Email (always)
            trEmail.Visible = False
        End If

        LPass2.Visible = (chkPassword.Disabled And chkPassword.Checked)
        LConfirmPass.Visible = (chkPassword.Disabled And chkPassword.Checked)

    End Sub

    Private Sub cmdOK_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdOK.ServerClick

        If (txtErrorType.Value = "3") Then
            Response.Redirect(Session("User_Prop_Caller"))
        End If

        Dim strUserName As String = User.Identity.Name
        Dim strPassword As String
        Dim emailvalue As String

        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

        If chkPassword.Disabled Then
            chkPassword.Checked = True
        End If

        If Trim(txtUserName.Value) = "" Then
            ShowError(Messages.MissingUserName)
            Return
        End If

        If strUserName.ToLower() <> Trim(txtUserName.Value.ToLower()) Then
            ShowError(Messages.UserIdentificationFailed)
            Return
        End If

        strPassword = Trim(txtPassword.Value)
        If (Not trPassword.Visible) And (Not Session("PassLoginFromEmail") Is Nothing) Then
            strPassword = Session("PassLoginFromEmail").ToString
        End If

        If Len(strPassword) = 0 Then
            ShowError(Messages.MissingPassword)
            Return
        End If

        Dim iResult As Integer = objUser.CheckUser("79D565C1-784C-4606-935B-68BA32141600", strUserName, strPassword, "0", -1, Request.UserHostAddress, User.Identity.Name)
        If iResult <> 0 And iResult <> 10 Then
            ShowError(Messages.UserIdentificationFailed)
            Return
        End If

        If chkPassword.Checked = True Then
            strPassword = Trim(txtNewPassword.Value)
            If strPassword.Length < 1 Then
                ShowError(Messages.MissingNewPassword)
                Return
            End If
            If Trim(txtNewPassword.Value) <> Trim(txtConfirmPassword.Value) Then
                ShowError(Messages.PasswordConfirmationNotIdentical)
                Return
            End If
            If LCase(Trim(txtNewPassword.Value)) = LCase(Trim(strUserName)) Then
                ShowError(Messages.PasswordMustBeDifferent)
                Return
            End If
            If Trim(txtPassword.Value) = strPassword Then
                ShowError(Messages.TheNewPasswordMustBeDifferent)
                Return
            End If

            If (CBool(Application("PasswordVerification"))) Then
                Dim strRegEx As String = Application("PasswordRegEx").ToString() & ""
                Dim nCheck As Integer = objUser.CheckNewPasswordEx("2DDEF6A6-4053-491A-8642-CF441B81BA46", strPassword, strRegEx)
                If nCheck > 0 Then
                    divPasswordError.InnerHtml = objUser.GetPassInstruction("B8CD9DE5-95C1-466d-AC29-E8170E3BCA2E")
                    txtErrorType.Value = "2"
                    divPasswordError.Visible = True
                    Return
                End If
            Else
                Select Case objUser.CheckNewPassword("2A8A46F2-A060-4FD9-B74E-3784FEC1C0EF", strPassword)
                    Case 1
                        'too short or too long
                        ShowError(Messages.PasswordLengthMustBeBetween)
                        Return
                    Case 2
                        'invalid char
                        ShowError(Messages.UseOnlyLettersAndNumbers)
                        Return
                    Case 3
                        'one char
                        ShowError(Messages.DoNotRepeatLetterOrNumber)
                        Return
                End Select
            End If
            If objUser.CheckPasswordHistory("6BC8399D-247C-48E4-8312-7FC05ECA207E", strUserName, strPassword) Then
                'one char
                ShowError(Messages.YouAlreadyUsedThisPassword)
                Return
            End If
        End If

        If Application("App_Type").ToString.ToUpper() = "SUPP" Or Application("App_Type").ToString.ToUpper() = "CLAIM" Or Application("App_Type").ToString.ToUpper() = "ENG" Or Application("App_Type").ToString.ToUpper() = "DIVUR" Then
            If Application("AllowExtraID") = "1" Then
                If Session("User_Login_First_Time") = "1" Then
                    If Trim(txtQuestion.Value) = "" Then
                        ShowError(Messages.LoginQuestionMissing)
                        Return
                    End If

                    If Trim(ExtraIdAnswer.Value) = "" Then
                        ShowError(Messages.LoginResponseMissing)
                        Return
                    End If

                    If Regex.IsMatch(ExtraIdAnswer.Value, "[^0-9א-תa-zA-Z]") Then
                        ShowError(Messages.InvalidLoginDetail)
                        Return
                    End If
                    Dim sTxtQuestion As String = ""
                    If Not txtQuestion.Value Is Nothing And txtQuestion.Value.Length >= 24 Then
                        sTxtQuestion = txtQuestion.Value.Substring(0, 24)
                    Else
                        sTxtQuestion = txtQuestion.Value.ToString
                    End If
                    objUser.UpdateExstraId("7C2895C8-6FFC-4999-B6EF-A5CB7E522EC6", strUserName, sTxtQuestion, ExtraIdAnswer.Value, User.Identity.Name)
                End If
            End If
            '' '' ''If Session("User_Login_First_Time") = "1" Then
            '' '' ''    Dim sRegExpr As String
            '' '' ''    emailvalue = txtNewEMail.Value
            '' '' ''    If (emailvalue.Trim().Length() > 0) Then
            '' '' ''        sRegExpr = objUser.GetEmailValidation("E600F1B9-D4C7-4FC4-B1B6-922F3967456E")
            '' '' ''        If Not Regex.IsMatch(emailvalue, sRegExpr) Then
            '' '' ''            ShowError(Messages.InvalidEMailAddress)
            '' '' ''            Return
            '' '' ''        End If
            '' '' ''    End If
            '' '' ''    objUser.UpdateUserEMail("9848A9BA-DCE8-467C-9F80-5C17864F3FC3", strUserName, Trim(txtNewEMail.Value))
            '' '' ''End If

            If objUser.UpdatePassword("5561A874-D4D7-4E5C-AA3D-4EC0EBAA8B7F", strUserName, strPassword, 1, User.Identity.Name) Then
                If Session("User_Login_First_Time") = "1" Then
                    Session("User_Login_First_Time") = ""
                    'Select Case Application("App_Type").ToString().ToUpper()
                    '    Case "INPOST"
                    '        Session("User_Prop_Caller") = "frmPostEntry.aspx"
                    '    Case "SUPP"
                    '        Session("User_Prop_Caller") = Application("FORMClaimMenu").ToString
                    '        Session("User_Password") = strPassword
                    '    Case "DIVUR"
                    Session("User_Prop_Caller") = Application("FORMStart") '"frmStart.aspx"
                    '    Case Else
                    '        'Session("User_Prop_Caller") = "frmRepStat.aspx" YT:
                    '        If Session("Allow_Action_Type_Upload") = "1" Or Session("Allow_Download_Files") = "1" Or Session("Allow_ForeignWorkers_Claims") = "1" Then
                    '            Session("User_Prop_Caller") = "frmStart.aspx"
                    '        Else
                    '            Session("User_Prop_Caller") = Application("FORMRepStat")
                    '        End If
                    'End Select
                End If
                chkPassword.Checked = False
                txtError.Value = Messages.DataUpdatedSuccessfully
                trPassword.Visible = True
                txtErrorType.Value = ""
                txtExpired.Value = ""
                'Response.Redirect(Application("FORMStart"))

                Dim iCheckDoctorResult As Integer = objUser.CheckDoctorID("EB2F60ED-E277-42EA-9310-EDBB15B97445", User.Identity.Name)
                Session("CheckDoctorResult") = iCheckDoctorResult

                Select Case iCheckDoctorResult
                    Case 0
                        'If (Application("AllowUrgentMessage") AndAlso "1".Equals(Application("InsuredStatusAsMainScreen"))) Then
                        '    Response.Redirect("frmHDUrgentMessage.aspx")
                        'Else
                        'Response.Redirect(Application("FORMStart"))
                        Session("User_Prop_Caller") = Application("FORMStart")
                        'End If
                    Case 1, 2, 6
                        'If Session("User_Login_First_Time") = "1" Then
                        '    Response.Redirect(Application("FORMStart"))
                        'End If
                        'If Application("InsuredStatusAsMainScreen") = "1" Then
                        'Response.Redirect("frmHDUpdateDoctor.aspx?Type=" & CStr(iCheckDoctorResult))
                        'Session("User_Prop_Caller") = "frmHDUpdateDoctor.aspx?Type=" & CStr(iCheckDoctorResult)
                        'Else
                        '    Response.Redirect("frmUpdateDoctorList.aspx?Type=" & CStr(iCheckDoctorResult))
                        'End If

                        Session("User_Prop_Caller") = "frmHDUserProp.aspx"
                    Case Else
                        'Response.Redirect("frmUpdateDoctorList.aspx?Type=" & iCheckDoctorResult.ToString())
                        'Response.Redirect(Application("FORMStart"))
                        'Session("User_Prop_Caller") = Application("FORMStart")
                        Session("User_Prop_Caller") = "frmHDUserProp.aspx"
                End Select
                ShowError("הסיסמה הוחלפה בהצלחה", 3)
            Else
                txtError.Value = "Error!"
            End If

        End If
    End Sub

    Private Sub ShowError(ByVal strMessage As String, Optional ByVal ErrorType As Integer = 1)
        txtError.Value = strMessage
        txtErrorType.Value = ErrorType.ToString() ' "1"
    End Sub

    Private Sub setAllowChangePassword(ByVal isAllowChangePassword As Boolean)
        If isAllowChangePassword Then
            txtUserName.Disabled = False
            txtPassword.Disabled = False
            txtNewPassword.Disabled = False
            txtConfirmPassword.Disabled = False
            chkPassword.Checked = True
        Else
            trAllowChangePassword.Visible = True
            txtErrorType.Value = ""
            txtExpired.Value = ""
            txtUserName.Disabled = True
            txtPassword.Disabled = True
            txtNewPassword.Disabled = True
            txtConfirmPassword.Disabled = True
            chkPassword.Checked = False
        End If
    End Sub

    Private Sub cmdReturn_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.ServerClick
        Response.Redirect(Application("FORMStart"))
    End Sub

End Class