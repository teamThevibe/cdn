Imports System.Text.RegularExpressions

Public Class frmHDCheckRequestFields
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


        Dim strWhiteListResult As String = "1"
        Dim sCheckKind As String = "1"
        Try
            If (Not IsNothing(Request.Form("hidCheckKind"))) Then
                sCheckKind = Request.Form("hidCheckKind")
            End If
        Catch
        End Try

        Dim objResult As New System.Text.StringBuilder()
        objResult.Append("<HTML><HEAD><TITLE></TITLE>")
        objResult.Append("<meta http-equiv='Cache-Control' content='no-cache'>" & vbCrLf)
        objResult.Append("<meta http-equiv='Pragma' content='no-cache'>" & vbCrLf)
        objResult.Append("<meta http-equiv='Expires' content='0'>" & vbCrLf)
        objResult.Append("<META http-equiv='Content-Type' content='text/html; charset=windows-1255'>")
        objResult.Append("</HEAD>")
        objResult.Append("<BODY>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlWhiteListResult' value='" & strWhiteListResult & "'>")
        objResult.Append("<INPUT TYPE='hidden' id='ctlCheckKind' value='" & sCheckKind & "'>")
        objResult.Append("<SCRIPT>")
        objResult.Append("	window.parent.document.all.oWLNotification.value = 'OK';")
        objResult.Append("</SCRIPT>")
        objResult.Append("</BODY>")
        objResult.Append("</HTML>")
        Response.Write(objResult.ToString())

    End Sub
End Class
