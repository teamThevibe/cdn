﻿Public Partial Class frmHDAttachments
    Inherits System.Web.UI.Page

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not IsPostBack Then
            Response.Expires = -1
            'Response.Cache.SetNoServerCaching()
            Dim strInsuredID As String = Request.QueryString("ID")
            Dim strRequestType As String = Request.QueryString("RequestType")
            txtValues.Value = Request.QueryString("Values")
            txtLocalFilesCount.Value = Request.QueryString("LocalFilesCount")
            Dim objTreatmentService As New TreatmentConnect.TreatmentService()
            objTreatmentService.Url = Application("TreatmentWebService").ToString()
            Dim ds As DataSet
            If strRequestType = "Teeth" Then
                ds = objTreatmentService.GetAttachmentsTeeth("5BC09888-FA5D-4FDF-8F7E-7BDC19287C0A", User.Identity.Name, strInsuredID)
            Else
                ds = objTreatmentService.GetAllAttachments("4918A773-90F8-4F16-AF4A-0A54FC2A5C97", User.Identity.Name, strInsuredID)
            End If

            Dim iCount As Integer = ds.Tables(0).Rows.Count
            Dim iPageCount As Integer = (iCount - 1) \ grdList.PageSize

            grdList.DataSource = ds
            If grdList.CurrentPageIndex > iPageCount Then
                grdList.CurrentPageIndex = iPageCount
            End If
            grdList.DataBind()
            If iPageCount > 0 Then
                grdList.PagerStyle.Visible = True
            Else
                grdList.PagerStyle.Visible = False
            End If
            txtAppType.Value = Application("App_Type").ToString
            txtGridRowsCount.Value = iCount
        End If
    End Sub

    Protected Function FormatRequestType(ByRef objCode As Object) As String
        Dim strReturn As String = ""
        If Not IsDBNull(objCode) Then
            Dim iType As Integer = CType(objCode, Integer)
            Select Case iType
                Case 0
                    strReturn = "תביעה"
                Case 4
                    strReturn = "התייעצות"
                Case 9
                    strReturn = "בירור"
            End Select
        End If
        Return strReturn
    End Function
End Class