﻿Imports System.Text.RegularExpressions

Partial Public Class frmMultiCheckRequest
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Session("HOD_MultiCheck_Reference") = ""
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim strReference As String = ""
        Dim iRetValue As Integer = 0
        Dim iPolicyNo As Integer = 0
        Dim iInsuredID As Integer = 0
        Dim strAnswer As String = ""
        If objUser.GetMultiCheckZakautPermition("4B29B2CF-68DB-4748-8725-0DBE5F74F371", User.Identity.Name) Then
            iRetValue = 1
        Else
            strAnswer = "אין הרשאות"
        End If
        Dim strTreatmentsValue As String = Trim("" & Request.Form("hidRValue"))
        Dim arrTreatmentsRows() As String
        Dim strInsuredID As String = Trim("" & Request.Form("hidRInsuredID"))
        Dim strDoctorCareName As String
        Dim strDoctorCareNumber As String
        Dim strClinicName As String
        Dim strClinicNumber As String
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        objTreatmentService.GetDoctorProperties("7EC6114A-62CD-4DC4-A940-1416BFB136D8", User.Identity.Name, strDoctorCareName, strDoctorCareNumber, strClinicName, strClinicNumber)
        Dim strDocNo As String = Trim("" & Request.Form("hidRDoctorCareNumber"))
        Dim strInsuredLName As String = Trim("" & Request.Form("hidRInsuredFamily"))
        Dim strInsuredFName As String = Trim("" & Request.Form("hidRInsuredName"))
        Dim iGovTreatments As Integer = Val(Request.Form("hidRGovTreatments"))
        If iRetValue > 0 Then
            iRetValue = 0
            If strTreatmentsValue <> "" Then
                arrTreatmentsRows = Split(strTreatmentsValue, ";")
                If arrTreatmentsRows.Length > 0 Then
                    If Len(arrTreatmentsRows(0)) > 0 Then
                        iRetValue = 1
                    End If
                End If
            End If
            If iRetValue = 0 Then
                strAnswer = "לא ניתן להעביר דיווח ריק"
            End If
        End If
        If iRetValue > 0 Then
            If IsNumeric(strInsuredID) Then
                iInsuredID = Val(strInsuredID)
            Else
                iRetValue = 0
                strAnswer = "מספר ת.ז. לא קיים בחברת הביטוח"
            End If
        End If
        If iRetValue > 0 Then
            Dim strFirstName As String = ""
            Dim strLastName As String = ""
            Dim str2Chars As String
            Dim str2FNChars As String
            Dim strPolicyNo As String = ""
            Dim strEmployeeNo As String = ""
            Dim strEmpCD As String = ""
            If Application("Smile") = "1" Then
                If Session("Smile_Porshei_Personel") = "1" Then
                    objTreatmentService.GetInsuredProp("5E25C46A-EADC-4C27-8A5A-DB8B13E129D3", CStr(iInsuredID), strFirstName, strLastName, strPolicyNo, strEmployeeNo, strEmpCD)
                    If strPolicyNo = "1015" Then
                        If strFirstName = "" Then
                            strFirstName = "א"
                        End If
                        iPolicyNo = 1015
                    Else
                        strFirstName = ""
                        strLastName = ""
                    End If
                Else
                    Dim objRequest As New SmileConnector.SmileConnector
                    objRequest.Url = Application("SmileWebService")
                    Dim ds As DataSet
                    If Session("Smile_ShilaWorker") = "1" Then
                        ds = objRequest.GetShilaEmployeeProp("60DED06E-37E5-45DE-9857-F61842C9CBC4", iInsuredID)
                        strPolicyNo = Session("Smile_Policy")
                        iPolicyNo = Val(strPolicyNo)
                    Else
                        ds = objRequest.GetLastAnswer("FF971BAA-4E34-4DCE-ABEF-27191AAF2C79", User.Identity.Name, Session("User_Password"), iInsuredID)
                    End If
                    If Not ds Is Nothing Then
                        If ds.Tables(0).Rows.Count > 0 Then
                            Dim objRow As DataRow = ds.Tables(0).Rows(0)
                            strFirstName = Trim(objRow("InsuredFName").ToString())
                            strLastName = Trim(objRow("InsuredLName").ToString())
                            If strFirstName = "" Then
                                strFirstName = "א"
                            End If
                        End If
                    End If
                End If
            Else
                If Application("CompanyID").ToString = "3" Then
                    strFirstName = Session("TRequest_InsuredName")
                    strLastName = Session("TRequest_InsuredFamily")
                    strInsuredID = Session("Leumit_CrntInsuredID")
                Else
                    Dim iGuf As Integer = 0
                    Dim strPolGovTreatment As String = ""
                    objTreatmentService.GetInsuredPropExt("2C331B73-13D1-4D07-B669-F409BE3CFB58", CStr(iInsuredID), strFirstName, strLastName, iPolicyNo, iGuf, strPolGovTreatment)
					'objTreatmentService.GetInsuredProp("5E25C46A-EADC-4C27-8A5A-DB8B13E129D3", CStr(iInsuredID), strFirstName, strLastName, strPolicyNo, strEmployeeNo, strEmpCD)
                    If UCase(Trim(strLastName)) = "ERROR" Then
                        objTreatmentService.GetSQLInsuredProp("6C865031-52E9-4422-950B-615B8F84600C", CStr(iInsuredID), strFirstName, strLastName)
                    End If
                End If
            End If
            str2Chars = Left(strLastName, 2)
            str2FNChars = Left(strFirstName, 2)
            iRetValue = 1
            If str2Chars = "" Or str2FNChars = "" Then
                strAnswer = "בחברת הביטוח לא נמצא מבוטח פעיל המתאים לפרטים שהוזנו"
                iRetValue = 0
            Else
                If Regex.IsMatch(Mid(str2Chars, 2, 1), "[א-תa-zA-Z]") Then
                    If str2Chars <> Left(strInsuredLName, 2) Then
                        strAnswer = "בחברת הביטוח לא נמצא מבוטח פעיל המתאים לפרטים שהוזנו"
                        iRetValue = 0
                    End If
                Else
                    If Left(str2Chars, 1) <> Left(strInsuredLName, 1) Then
                        strAnswer = "בחברת הביטוח לא נמצא מבוטח פעיל המתאים לפרטים שהוזנו"
                        iRetValue = 0
                    End If
                End If
                If Regex.IsMatch(Mid(str2FNChars, 2, 1), "[א-תa-zA-Z]") Then
                    If str2FNChars <> Left(strInsuredFName, 2) Then
                        strAnswer = "בחברת הביטוח לא נמצא מבוטח פעיל המתאים לפרטים שהוזנו"
                        iRetValue = 0
                    End If
                Else
                    If Left(str2FNChars, 1) <> Left(strInsuredFName, 1) Then
                        strAnswer = "בחברת הביטוח לא נמצא מבוטח פעיל המתאים לפרטים שהוזנו"
                        iRetValue = 0
                    End If
                End If
            End If
            Dim iDoctorType As Integer = objUser.GetUserDoctorType("C049B33B-243D-43C1-B2F5-AB4859F9EBD1", User.Identity.Name)
            If iDoctorType <> 3 Then
                If strDocNo = "" Or strDocNo = "0" Then
                    strAnswer = "חובה לבחור רופא מטפל עם מספר רשיון במשרד הבריאות"
                    iRetValue = 0
                End If
            End If
        End If
        Dim objTreatmentsBuilder As New System.Text.StringBuilder
        If iRetValue > 0 Then
            Dim strTreatmentRow As String, arrOneRow() As String, strTreatmentValue As String, strCauseValue As String, strFromTooth As String, strToTooth As String
            Dim i As Integer, iArrIndex1 As Integer, iArrIndex2 As Integer, iFromTooth As Integer, iToTooth As Integer, iTreatmentValue As Integer, iCauseValue As Integer
            Dim arrToothCheck(64) As ArrayList
            For i = 0 To 63
                arrToothCheck(i) = New ArrayList()
            Next
            Dim dsTreatmentTypes As DataSet = objTreatmentService.GetAllTreatmentTypes("E1AA7659-0ADB-4AAB-9014-7EB2FD5BA451")
            Dim dsToothRange As DataSet = objTreatmentService.GetTeethRange("DAD91AA1-DE6F-4C28-8A11-CB0FF79BD302", -1)
            Dim arrIndexTranslate As Integer() = {7, 6, 5, 4, 3, 2, 1, 0, 8, 9, 10, 11, 12, 13, 14, 15, 23, 22, 21, 20, 19, 18, 17, 16, 24, 25, 26, 27, 28, 29, 30, 31, 39, 38, 37, 36, 35, 34, 33, 32, 40, 41, 42, 43, 44, 45, 46, 47, 55, 54, 53, 52, 51, 50, 49, 48, 56, 57, 58, 59, 60, 61, 62, 63}
            Dim arrToothTranslate As Integer() = {18, 17, 16, 15, 14, 13, 12, 11, 21, 22, 23, 24, 25, 26, 27, 28, 38, 37, 36, 35, 34, 33, 32, 31, 41, 42, 43, 44, 45, 46, 47, 48, 58, 57, 56, 55, 54, 53, 52, 51, 61, 62, 63, 64, 65, 66, 67, 68, 78, 77, 76, 75, 74, 73, 72, 71, 81, 82, 83, 84, 85, 86, 87, 88}
            For Each strTreatmentRow In arrTreatmentsRows
                arrOneRow = Split(strTreatmentRow, ".")
                If arrOneRow.Length = 4 Then
                    strTreatmentValue = arrOneRow(0)
                    strCauseValue = arrOneRow(1)
                    strFromTooth = arrOneRow(2)
                    strToTooth = arrOneRow(3)
                    If IsNumeric(strTreatmentValue) Then
                        iTreatmentValue = CInt(strTreatmentValue)
                    Else
                        iTreatmentValue = 0
                    End If
                    If IsNumeric(strCauseValue) Then
                        iCauseValue = CInt(strCauseValue)
                    Else
                        iCauseValue = 0
                    End If
                    If IsNumeric(strFromTooth) Then
                        iFromTooth = CInt(strFromTooth)
                    Else
                        iFromTooth = 0
                    End If
                    If IsNumeric(strToTooth) Then
                        iToTooth = CInt(strToTooth)
                    Else
                        iToTooth = iFromTooth
                    End If
                    If iTreatmentValue > 0 And iFromTooth > 0 Then
                        Select Case CheckTreatment(CStr(iTreatmentValue), Not (iToTooth = iFromTooth), dsTreatmentTypes)
                            Case 0
                                strAnswer = "ערך בשדה טיפול לא תקין"
                                iRetValue = 0
                            Case -1
                                strAnswer = "לא ניתן לדווח טווח שיניים לטיפול זה"
                                iRetValue = 0
                        End Select
                        Select Case CheckTooth(CStr(iTreatmentValue), CStr(iFromTooth), CStr(iToTooth), dsToothRange)
                            Case 0
                                strAnswer = "ערך בשדה טיפול לא תקין"
                                iRetValue = 0
                            Case -1
                                strAnswer = "ערך בשדה 'משן' לא חוקי"
                                iRetValue = 0
                            Case -2
                                strAnswer = "ערך בשדה 'עד שן' לא חוקי"
                                iRetValue = 0
                            Case -3
                                strAnswer = "ערכים בשדות 'משן' ו- 'עד שן' לא חוקים"
                                iRetValue = 0
                        End Select
                        If iFromTooth = 88 Or iFromTooth = 0 Then
                            iArrIndex1 = 0
                            iArrIndex2 = 63
                            objTreatmentsBuilder.Append(CStr(iTreatmentValue)).Append(".").Append(CStr(iCauseValue)).Append(".88.0;")
                        Else
                            iArrIndex1 = arrIndexTranslate(Convert.ToInt16(CStr(iFromTooth - 11), 8))
                            iArrIndex2 = arrIndexTranslate(Convert.ToInt16(CStr(iToTooth - 11), 8))
                            i = iArrIndex1
                            iArrIndex1 = Math.Min(iArrIndex1, iArrIndex2)
                            iArrIndex2 = Math.Max(i, iArrIndex2)
                        End If
                        For i = iArrIndex1 To iArrIndex2
                            If arrToothCheck(i).Contains(iTreatmentValue) Then
                                strAnswer = "לא ניתן לדווח על טיפול יותר מפעם אחת לשן"
                                iRetValue = 0
                            End If
                            arrToothCheck(i).Add(iTreatmentValue)
                            If iFromTooth <> 88 And iFromTooth <> 0 Then
                                objTreatmentsBuilder.Append(CStr(iTreatmentValue)).Append(".").Append(CStr(iCauseValue)).Append(".").Append(CStr(arrToothTranslate(i))).Append(".0;")
                            End If
                        Next
                        If Session("Leumit_CollectionProblem") = "1" Then
                            Dim iResult As Integer
                            iResult = CheckTreatmentForServiceBasket(iTreatmentValue)
                            If iResult = 0 Then
                                strAnswer = "אין אפשרות להעניק טיפול שאינו בסל הטיפולים.<BR>נא לפנות לקופת חולים לאומית על מנת להסדיר חוב כספי לקופה."
                                iRetValue = 0
                            End If
                        End If
                    Else
                        strAnswer = "ערכים לא נכונים"
                        iRetValue = 0
                    End If
                End If
                If iRetValue = 0 Then
                    Exit For
                End If
            Next
            If iRetValue > 0 Then
                For i = 0 To 63
                    If arrToothCheck(i).Count > 7 Then
                        strAnswer = "לא ניתן לדווח על יותר משבעה טיפולים לשן"
                        iRetValue = 0
                    End If
                    If iRetValue = 0 Then
                        Exit For
                    End If
                Next
            End If
        End If
        If iRetValue > 0 Then
            Dim objZakautService As New ZakautConnect.ZakautService()
            objZakautService.Url = Application("ZakautConnectorService").ToString()
            iRetValue = objZakautService.PutMultiCheckRequest("88207D80-93C8-4F09-84DB-36622AA07D4C", User.Identity.Name, strClinicNumber, strDocNo, iInsuredID, iPolicyNo, strInsuredLName, strInsuredFName, objTreatmentsBuilder.ToString(), strReference, iGovTreatments)
            If iRetValue > 0 Then
                Session("HOD_MultiCheck_Reference") = strReference
            End If
        End If
        Dim objResult As New System.Text.StringBuilder()
        objResult.Append("<HTML><HEAD><TITLE></TITLE>").Append(vbCrLf)
        objResult.Append("<meta http-equiv='Cache-Control' content='no-cache'>").Append(vbCrLf)
        objResult.Append("<meta http-equiv='Pragma' content='no-cache'>").Append(vbCrLf)
        objResult.Append("<meta http-equiv='Expires' content='0'>").Append(vbCrLf)
        objResult.Append("<META http-equiv='Content-Type' content='text/html; charset=windows-1255'>").Append(vbCrLf)
        objResult.Append("</HEAD>").Append(vbCrLf)
        objResult.Append("<BODY>").Append(vbCrLf)
        objResult.Append("<INPUT TYPE='hidden' ID='RequestResult' value='").Append(CStr(iRetValue)).Append("'>").Append(vbCrLf)
        objResult.Append("<INPUT TYPE='hidden' ID='RequestAnswer' value='").Append(strAnswer).Append("'>").Append(vbCrLf)
        objResult.Append("<INPUT TYPE='hidden' ID='RequestReference' value='").Append(strReference).Append("'>").Append(vbCrLf)
        objResult.Append("<SCRIPT>").Append(vbCrLf)
        objResult.Append("	window.parent.document.all.oRequestNotificationCheck.value = 'OK';").Append(vbCrLf)
        objResult.Append("</SCRIPT>").Append(vbCrLf)
        objResult.Append("</BODY></HTML>")
        Response.Write(objResult.ToString())
    End Sub

    Private Function CheckTreatmentForServiceBasket(ByVal iTreatmentValue As Integer) As Integer
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim dsTreatment As DataSet = objTreatmentService.GetTreatmentByTreatmentID("CA459EC9-0EC6-42AD-AA10-72A5E50FEDB4", iTreatmentValue)
        Dim iServiceBasket As Integer = Val(dsTreatment.Tables(0).Rows(0)("ServiceBasket").ToString())
        If iServiceBasket <> 1 Then
            Return 0
        Else
            Return 1
        End If
    End Function

    Private Function CheckTreatment(ByVal strTreatmentValue As String, ByVal bRange As Boolean, ByRef ds As DataSet) As Integer
        Dim foundRows() As DataRow
        Dim retValue As Integer = 0
        foundRows = ds.Tables(0).Select("TreatmentID=" & strTreatmentValue)
        If foundRows.Length > 0 Then
            If foundRows(0).Item("AllowRange").ToString() = "1" Then
                retValue = 1
            Else
                If bRange Then
                    retValue = -1
                Else
                    retValue = 1
                End If
            End If
        End If
        Return retValue
    End Function

    Private Function CheckTooth(ByVal strTreatmentValue As String, ByVal strFromTooth As String, ByVal strToTooth As String, ByRef ds As DataSet) As Integer
        Dim foundRows() As DataRow
        Dim currRow As Data.DataRow
        Dim retValue As Integer = 0
        Dim bResultFrom As Boolean = False
        Dim bResultTo As Boolean = False
        Dim iTempFrom As Integer, iTempTo As Integer
        foundRows = ds.Tables(0).Select("TreatmentID=" & strTreatmentValue)
        If foundRows.Length > 0 Then
            For Each currRow In foundRows
                iTempFrom = CInt(currRow("FromTooth").ToString())
                iTempTo = CInt(currRow("ToTooth").ToString())
                If ValidateTooth(CInt(strFromTooth), iTempFrom, iTempTo) Then
                    bResultFrom = True
                End If
                If ValidateTooth(CInt(strToTooth), iTempFrom, iTempTo) Then
                    bResultTo = True
                End If
                If bResultFrom And bResultTo Then
                    retValue = 1
                    Exit For
                End If
            Next
            If retValue = 0 Then
                If Not bResultFrom Then
                    retValue = -1
                End If
                If Not bResultTo Then
                    retValue += -2
                End If
            End If
        End If
        Return retValue
    End Function

    Private Function ValidateTooth(ByVal iTooth As Integer, ByVal iFromTooth As Integer, ByVal iToTooth As Integer) As Boolean
        If (iTooth >= iFromTooth) And (iTooth <= iToTooth) Then
            Return True
        Else
            Return False
        End If
    End Function
End Class