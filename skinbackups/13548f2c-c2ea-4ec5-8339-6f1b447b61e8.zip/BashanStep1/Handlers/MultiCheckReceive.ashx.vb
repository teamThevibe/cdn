﻿Imports System.Web
Imports System.Web.Services
Imports System.Web.Script.Serialization

Public Class MultiCheckReceive
    Implements System.Web.IHttpHandler
    Implements SessionState.IRequiresSessionState

    <Serializable()> Private Class ActionResult
        Public ResultCode As Integer
        Public RestRows As Integer
        Public RequestStatus As Integer
        Public RepID As Integer
    End Class

    Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest
        context.Response.Expires = -1
        context.Response.ContentType = "text/plain"
        Dim strReference As String = Trim("" & context.Session("HOD_MultiCheck_Reference"))
        Dim iRestRows As Integer = -1, iRequestStatus As Integer = -1, iRepID As Integer = -1
        Dim Result As New ActionResult()
        Result.ResultCode = -1
        If Len(strReference) = 10 Then
            Dim objZakautService As New ZakautConnect.ZakautService()
            objZakautService.Url = HttpContext.Current.Application("ZakautConnectorService").ToString()
            Try
                Result.ResultCode = objZakautService.ReadMultiCheckRowsFromQueue("DD677B3C-2CB2-494B-9A01-1DD2C0199329", strReference, iRestRows, iRequestStatus, iRepID)
            Catch ex As Exception
                Result.ResultCode = -2
            End Try
        End If
        Result.RestRows = iRestRows
        Result.RequestStatus = iRequestStatus
        Result.RepID = iRepID
        Dim serializer As New JavaScriptSerializer()
        HttpContext.Current.Response.Write(serializer.Serialize(Result))
    End Sub

    ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property

End Class