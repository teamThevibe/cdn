﻿Imports System.Web
Imports System.Web.Services
Imports System.Web.SessionState

Public Class keepAlive
    Implements System.Web.IHttpHandler, IReadOnlySessionState

    Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest

        context.Response.ContentType = "text/plain"
        'Debug.Print(HttpContext.Current.Session.Timeout.ToString())
        context.Response.Write("session restarted")

    End Sub

    ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property

End Class