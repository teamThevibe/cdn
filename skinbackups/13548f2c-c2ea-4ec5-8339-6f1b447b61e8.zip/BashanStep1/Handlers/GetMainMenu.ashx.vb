﻿Imports System.Web
Imports System.Web.Services
Imports System.Text
Imports System.Web.SessionState

Public Class GetMainMenu
    Implements System.Web.IHttpHandler, IRequiresSessionState

    Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest

        Dim blncmdTechSupportForm_Visible As Boolean
        Dim spnMultiCheck_Visible As Boolean
        Dim spnManageUsers_Visible As Boolean
        Dim User_Identity_Name As String
        Dim sb As New StringBuilder
        Dim sDisabledMenu As String = "0"

        If Not HttpContext.Current.Request.QueryString("DisabledMenu") Is Nothing Then
            sDisabledMenu = HttpContext.Current.Request.QueryString("DisabledMenu")
        End If

        ' = צפיה במידע
        'id="spnRequest" = טיפול בפניות  = If Session("BSHN_AllowClaims") = "1" Then                                               
        'id="spnZakaut" = בדיקת זכאות = bBashanZakautPermitions
        'id="spnMRequest" = מצב פה   = bAllowMouthRequest
        'id="spnPRequest" = מצב פה פריודונטלי = f bAllowPriodontRequest Then
        'id="spnKeter" = כתר בראש שקט   =  bAllowKeter
        'id="spnConsultation" = דיווח התייעצויות = bConsultationPermitions
        'id="spnMultiCheck" = בדיקת זכאות מרוכזת במסלול מהיר = bMultiCheckPermitions

        Dim spnShaban_Visible As Boolean
        Dim spnShabanTxt_Visible As Boolean
        Dim spnZakaut_Visible As Boolean
        Dim spnMRequest_Visible As Boolean
        Dim spnPRequest_Visible As Boolean
        Dim spnKeter_Visible As Boolean
        Dim spnUpload_Visible As Boolean
        Dim spnDoctorService_Visible As Boolean
        Dim spnConsultation_Visible As Boolean
        Dim spnForiegnWorkers_Visible As Boolean
        Dim spnKeptAppeal_Visible As Boolean


        ' '' ''If sDisabledMenu = "1" Then
        ' '' ''    sb.Append("<li class=""SubMenuItem""><a style='cursor:none' href=""#""  onclick ='' >מסך ראשי</a></li> ")
        ' '' ''Else
        ' '' ''    sb.Append("<li class=""SubMenuItem""><a  href=""#""  onclick =""  if  ( SelectMasachRhashi() == '1' ) { return } else {  window.navigate('FORMStart?ScrollPosition='+GetScrollPosition()+'&FromMenu=1'); }"" >מסך ראשי</a></li> ".Replace("FORMStart", context.Application("FORMStart")))
        ' '' ''End If

        User_Identity_Name = context.User.Identity.Name '"shemesh"
        context.Response.ContentType = "text/plain"

        context.Session("FW_RequestID") = String.Empty

        If Not context.Session("PassLoginFromEmail") Is Nothing Then
            If context.Session("PassLoginFromEmail").ToString <> "" Then
                context.Session("User_Login_First_Time") = "1"
            End If
        End If

        context.Session("OnBehalfOf") = User_Identity_Name

        Dim objUser As New UserConnect.UserService()
        objUser.Url = context.Application("UserWebService").ToString()
        Dim strUserName As String = objUser.GetUserFullName("3371F4F5-F671-4B9D-A054-A4232D3D2177", User_Identity_Name)
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = context.Application("TreatmentWebService").ToString()
        Dim strDoctorCareName As String
        Dim strDoctorCareNumber As String
        Dim strClinicName As String
        Dim strClinicNumber As String
        Dim strText As String = ""

        'TechSupport
        Dim bIsTechSupportEnabled As Boolean = False
        If context.Application("WithTechSupport") & "" = "1" Then
            bIsTechSupportEnabled = True
        End If
        Dim bAllowTechSupport As Boolean = objUser.GetTechSupportPermition("S61AD468-275E-409D-B209-BE3C3A4000FF", User_Identity_Name)
        If bIsTechSupportEnabled And bAllowTechSupport Then
            blncmdTechSupportForm_Visible = True
        Else
            blncmdTechSupportForm_Visible = False
        End If
        context.Session("TechSupport_RepID") = "0"
        context.Session("TechSupport_SubUserID") = ""

        objTreatmentService.GetDoctorProperties("7EC6114A-62CD-4DC4-A940-1416BFB136D8", User_Identity_Name, strDoctorCareName, strDoctorCareNumber, strClinicName, strClinicNumber)
        ''''''''''''''''''''''''''objTreatmentService.GetHdDoctorProperties("C4AEB905-6C91-4FC8-93BE-1486B99518E57", User_Identity_Name, strDoctorCareName, strDoctorCareNumber, strClinicName, strClinicNumber)

        strClinicNumber = Trim(strClinicNumber)

        Dim bBashanZakautPermitions As Boolean = objUser.GetBashanZakautPermitions("8CE02069-9F79-4D39-A07C-5DDE5BD7C3D9", User_Identity_Name)
        If Not bBashanZakautPermitions Then
            bBashanZakautPermitions = objUser.GetCheckZakautHarelPermition("E64600AD-4946-4DFD-9CDD-032FD5B48634", User_Identity_Name)
        End If
        Dim bMultiCheckPermitions As Boolean = False
        Dim bAllowPriodontRequest As Boolean = objUser.GetPriodontRequestPermitions("1DDDF20C-5DC6-4656-A2CB-2D83B7CC13D9", User_Identity_Name)
        Dim bConsultationPermitions As Boolean = objUser.GetConsultationPermitions("AB699114-1C1D-4EB7-8186-033B5306E799", User_Identity_Name)
        spnMultiCheck_Visible = False
        spnManageUsers_Visible = False

        spnShaban_Visible = False
        spnShabanTxt_Visible = False



        '''''''''''''''''''''''''''''''''''''''
        '''''''''''    בדיקת זכאות   '''''''''' 
        '''''''''''''''''''''''''''''''''''''''
        Dim iDoctorType As Integer = objUser.GetUserDoctorType("C049B33B-243D-43C1-B2F5-AB4859F9EBD1", User_Identity_Name)
        ''''''''''''''''''Dim iDoctorType As Integer = objUser.GetHDUserDoctorType("0B776BB2-51E1-11E4-8E10-7F911D5D46B0", User_Identity_Name)

        If bBashanZakautPermitions Then
            sb.Append("<li id=""spnZakaut"" class=""SubMenuItem""><a  href=""#"" ") '>בדיקת זכאות</a></li>")
            If strClinicNumber = "" Or strClinicNumber = "0" Then
                If sDisabledMenu = "1" Then
                    sb.Append("  onclick = ''")
                Else
                    sb.Append(" onclick = ""alert('אין אפשרות להגיש פניות ללא זיהוי מרפאה. נא פנה למנהל המערכת')""")
                End If
                sb.Append("  >בדיקת זכאות </a></li>")
            Else
                If ((iDoctorType = 1) Or (iDoctorType = 2)) Then
                    If sDisabledMenu = "1" Then
                        sb.Append("    onclick = '' >בדיקת זכאות </a></li>")
                    Else
                        sb.Append("  onclick='bdikatZakhut();' >בדיקת זכאות </a></li>")
                        '''sb.Append(String.Format("onclick = ""window.navigate('{0}?ScrollPosition='+GetScrollPosition());"" >בדיקת זכאות טיפולים</a></li>", Utils.Navigation.GetURL("frmZakautExt.aspx")))
                    End If
                Else
                    If context.Application("CompanyID").ToString() = "0" Or context.Application("CompanyID").ToString() = "1" Then
                        If sDisabledMenu = "1" Then
                            sb.Append("  onclick='' >בדיקת זכאות </a></li>")
                        Else
                            sb.Append("  onclick='bdikatZakhut();' >בדיקת זכאות </a></li>")
                            ''sb.Append(String.Format(" onclick=""window.navigate('{0}?ScrollPosition='+GetScrollPosition());"" >בדיקת זכאות טיפולים</a></li>", Utils.Navigation.GetURL("frmZakautExt.aspx")))
                        End If
                    Else
                        If sDisabledMenu = "1" Then
                            sb.Append("  onclick=''>בדיקת זכאות </a></li>")
                        Else
                            sb.Append("  onclick='bdikatZakhut();'>בדיקת זכאות </a></li>")
                            ''sb.Append(String.Format(" style='cursor:none' onclick=""window.navigate('{0}?ScrollPosition='+GetScrollPosition());"" >בדיקת זכאות טיפולים</a></li>", Utils.Navigation.GetURL("frmZakautExt.aspx")))
                        End If
                    End If
                End If
            End If
            spnZakaut_Visible = True
        Else
            spnZakaut_Visible = False
        End If





        '''''''''''''''''''''''''''''''''''''''
        '''''''''''    טיפול בפניות   '''''''''' 
        '''''''''''''''''''''''''''''''''''''''


        Dim spnRequest_Visible As Boolean
        If context.Session("BSHN_AllowClaims") = "1" Then
            sb.Append("<li id=""spnRequest"" class=""SubMenuItem""><a  href=""#"" ")   '
            If strClinicNumber = "" Or strClinicNumber = "0" Then
                If sDisabledMenu = "1" Then
                    sb.Append(" style='cursor:none' onclick = ''")
                Else
                    sb.Append(" onclick = ""alert('אין אפשרות להגיש פניות ללא זיהוי מרפאה. נא פנה למנהל המערכת')""")
                End If
                sb.Append("  >טיפול בפניות</a></li>")
            Else
                If sDisabledMenu = "1" Then
                    sb.Append(" style='cursor:none' onclick ='' >טיפול בפניות</a></li> ")
                Else
                    sb.Append(String.Format(" onclick =""if(!onMenuItemClick())return;Complaints('{0}?ScrollPosition='+GetScrollPosition());"" >טיפול בפניות</a></li> ", Utils.Navigation.GetURL("frmRequestt.aspx")))
                End If
            End If
            spnRequest_Visible = True
        Else
            spnRequest_Visible = False
        End If


        '''''''''''''''''''''''''''''''''''''''
        '''''''''''  דיווח התייעצויות   '''''''''' 
        '''''''''''''''''''''''''''''''''''''''


        If context.Application("App_Type").ToString().ToUpper() = "DIVUR" Then
            If bConsultationPermitions Then




                If strClinicNumber = "" Or strClinicNumber = "0" Then

                    sb.Append("<li id=""spnConsultation"" class=""SubMenuItem""><a  href=""#"" ")   '

                    If sDisabledMenu = "1" Then
                        sb.Append(" style='cursor:none'  onclick = '')""")
                    Else
                        sb.Append("onclick = ""alert('אין אפשרות להגיש פניות ללא זיהוי מרפאה. נא פנה למנהל המערכת')""")
                    End If
                    sb.Append(" >דיווח התייעצויות</a></li>")
                Else ' If strClinicNumber = "" Or strClinicNumber = "0" Then


                    If sDisabledMenu = "1" Then
                        sb.Append("<li id=""spnConsultation"" class=""SubMenuItem""><a href=""#"" style='cursor:none'   onclick=''") ' >דיווח התייעצויות</a></li>")
                    Else
                        sb.Append(String.Format("<li id=""spnConsultation"" class=""SubMenuItem""><a href=""#""   onclick=""if(!onMenuItemClick())return;window.navigate('{0}?ScrollPosition='+GetScrollPosition())""", Utils.Navigation.GetURL("frmTRequestt.aspx")))
                    End If

                    '' ''If strClinicNumber = "" Or strClinicNumber = "0" Then
                    '' ''    If sDisabledMenu = "1" Then
                    '' ''        sb.Append(" style='cursor:none'  onclick = '')""")
                    '' ''    Else
                    '' ''        sb.Append("onclick = ""alert('אין אפשרות להגיש פניות ללא זיהוי מרפאה. נא פנה למנהל המערכת')""")
                    '' ''    End If
                    '' ''    sb.Append(" >דיווח התייעצויות</a></li>")
                    '' ''Else
                    If sDisabledMenu = "1" Then
                        sb.Append(" style='cursor:none' onclick='' >דיווח התייעצויות</a></li>")
                    Else
                        sb.Append(String.Format(" onclick=""if(!onMenuItemClick())return;window.navigate('{0}?ScrollPosition='+GetScrollPosition())"" >דיווח התייעצויות</a></li>", Utils.Navigation.GetURL("frmTRequestt.aspx")))
                    End If

                    '''''''''''''''''''End If

                End If ' If strClinicNumber = "" Or strClinicNumber = "0" Then
                spnConsultation_Visible = True


            Else
                spnConsultation_Visible = False
            End If


            Else
                spnConsultation_Visible = False
            End If





        '''''''''''''''''''''''''''''''''''''''
        '''''''''''    דיווח מצב פה   '''''''''' 
        '''''''''''''''''''''''''''''''''''''''


        Dim bAllowMouthRequest As Boolean = objUser.GetMouthRequestPermitions("AC616A4E-9E4B-4B27-BB73-B4A8AC31A63E", User_Identity_Name)

        If context.Application("App_Type").ToString().ToUpper() = "DIVUR" Then
            If bAllowMouthRequest Then
                sb.Append("<li id=""spnMRequest"" class=""SubMenuItem""><a href=""#""  ") '>דיווח מצב פה</a></li>")
                If strClinicNumber = "" Or strClinicNumber = "0" Then
                    If sDisabledMenu = "1" Then
                        sb.Append(" style='cursor:none'  onclick = ''")
                    Else
                        sb.Append("  onclick = ""alert('אין אפשרות להגיש פניות ללא זיהוי מרפאה. נא פנה למנהל המערכת')""")
                    End If
                    sb.Append("  >דיווח מצב פה</a></li>")
                Else
                    If sDisabledMenu = "1" Then
                        sb.Append(" style='cursor:none' onclick='' >דיווח מצב פה</a></li>")
                    Else
                        sb.Append(String.Format(" onclick=""if(!onMenuItemClick())return;window.navigate('{0}?ScrollPosition='+GetScrollPosition())"" >דיווח מצב פה</a></li>", Utils.Navigation.GetURL("frmMRequestt.aspx")))
                    End If

                End If
                spnMRequest_Visible = True
            Else
                spnMRequest_Visible = False
            End If
        Else
            spnMRequest_Visible = False
        End If



        '''''''''''''''''''''''''''''''''''''''
        '''''''''''  דיווח מצב פה פריודנטלי   '''''''''' 
        '''''''''''''''''''''''''''''''''''''''



        If context.Application("App_Type").ToString().ToUpper() = "DIVUR" Then
            If bAllowPriodontRequest Then
                sb.Append("<li id=""spnPRequest"" class=""SubMenuItem""><a href=""#""  ") '>דיווח מצב פה פריודונטלי</a></li>")
                If strClinicNumber = "" Or strClinicNumber = "0" Then
                    If sDisabledMenu = "1" Then
                        sb.Append(" style='cursor:none'  onclick =''")
                    Else
                        sb.Append("onclick = ""alert('אין אפשרות להגיש פניות ללא זיהוי מרפאה. נא פנה למנהל המערכת')""")
                    End If

                    sb.Append("  >דיווח מצב פה פריודונטלי</a></li>")
                Else
                    If sDisabledMenu = "1" Then
                        sb.Append(" style='cursor:none' onclick='' >דיווח מצב פה פריודונטלי</a></li>")
                    Else
                        sb.Append(String.Format(" onclick=""if(!onMenuItemClick())return;window.navigate('{0}?ScrollPosition='+GetScrollPosition())"" >דיווח מצב פה פריודונטלי</a></li>", Utils.Navigation.GetURL("frmPRequestt.aspx")))
                    End If

                End If
                spnPRequest_Visible = True
            Else
                spnPRequest_Visible = False
            End If
        Else
            spnPRequest_Visible = False
        End If


        '''''''''''''''''''''''''''''''''''''''
        '''''''''''  שליחת קבצי מידע   '''''''''' 
        '''''''''''''''''''''''''''''''''''''''



        Dim bAllowKeter As Boolean = objUser.GetKeterPermitions("8577A6A8-8AAE-402B-A928-9294C241DBCD", User_Identity_Name)

        'If bAllowKeter Then
        '    If sDisabledMenu = "1" Then
        '        sb.Append("<li id=""spnKeter"" style=""display:none;"" class=""SubMenuItem""><a href=""#""  style='cursor:none' onclick='' >כתר בראש שקט</a></li>")
        '    Else
        '        sb.Append(String.Format("<li id=""spnKeter"" style=""display:none;"" class=""SubMenuItem""><a href=""#""   onclick=""window.navigate('{0}?ScrollPosition='+GetScrollPosition())"" >כתר בראש שקט</a></li>", Utils.Navigation.GetURL("frmKeterStart.aspx")))
        '    End If
        '    spnKeter_Visible = True
        'Else
        spnKeter_Visible = False
        'End If

        If context.Session("Allow_Action_Type_Upload") = "1" Then
            If sDisabledMenu = "1" Then
                sb.Append("<li id=""spnKeter"" class=""SubMenuItem""><a href=""#"" style='cursor:none' onclick='' >שליחת קבצי מידע</a></li>")
            Else
                sb.Append(String.Format("<li id=""spnKeter"" class=""SubMenuItem""><a href=""#""  onclick=""if(!onMenuItemClick())return;window.navigate('{0}?ScrollPosition='+GetScrollPosition())"" >שליחת קבצי מידע</a></li>", Utils.Navigation.GetURL("frmUploadt.aspx")))
            End If
            spnUpload_Visible = True
        Else
            spnUpload_Visible = False
        End If




        '''''''''''''''''''''''''''''''''''''''
        '''''''''''  בדיקת זכאות מרוכזת   '''''''''' 
        '''''''''''''''''''''''''''''''''''''''



        '' '' '' ''If (context.Application("App_Type").ToString().ToUpper() = "DIVUR") And (context.Application("IfAllowMultiCheckZakaut") = "1") And ((iDoctorType = 1) Or (iDoctorType = 2)) Then
        '' '' '' ''    bMultiCheckPermitions = objUser.GetMultiCheckZakautPermition("4B29B2CF-68DB-4748-8725-0DBE5F74F371", User_Identity_Name)
        '' '' '' ''End If

        '' '' '' ''If bMultiCheckPermitions Then
        '' '' '' ''    sb.Append("<li id=""spnMultiCheck"" class=""SubMenuItem""><a href=""#""   ")
        '' '' '' ''    If strClinicNumber = "" Or strClinicNumber = "0" Then
        '' '' '' ''        If sDisabledMenu = "1" Then
        '' '' '' ''            sb.Append("  style='cursor:none' onclick = '')""")
        '' '' '' ''        Else
        '' '' '' ''            sb.Append("onclick = ""alert('אין אפשרות להגיש פניות ללא זיהוי מרפאה. נא פנה למנהל המערכת')""")
        '' '' '' ''        End If
        '' '' '' ''        sb.Append(" >בדיקת זכאות מרוכזת</a></li>")
        '' '' '' ''    Else
        '' '' '' ''        If sDisabledMenu = "1" Then
        '' '' '' ''            sb.Append(" style='cursor:none' onclick='' >בדיקת זכאות מרוכזת</a></li>")
        '' '' '' ''        Else
        '' '' '' ''            sb.Append(String.Format(" onclick=""window.navigate('{0}?ScrollPosition='+GetScrollPosition())"" >בדיקת זכאות מרוכזת</a></li>", Utils.Navigation.GetURL("frmMultiCheck.aspx")))
        '' '' '' ''        End If
        '' '' '' ''    End If
        '' '' '' ''    spnMultiCheck_Visible = True
        '' '' '' ''Else
        '' '' '' ''    spnMultiCheck_Visible = False
        '' '' '' ''End If


        '''''''''''''''''''''''''''''''''''''''
        '''''''''''  תביעות עובדים זרים   '''''''''' 
        '''''''''''''''''''''''''''''''''''''''


        If context.Application("App_Type").ToString.ToUpper = "CLAIM" Or context.Application("App_Type").ToString.ToUpper = "DIST" Then
            If context.Application("HasForigenWorkers") = "1" Then
                If context.Session("Allow_ForeignWorkers_Claims") = "1" Then
                    spnForiegnWorkers_Visible = True
                    sb.Append("<li id=""spnMultiCheck"" class=""SubMenuItem""><a href=""#""  ")
                    spnKeptAppeal_Visible = False
                    If objUser.CheckFWDeclaration("3F6DCC54-177C-424D-857A-742B4075E09A", User_Identity_Name) Then
                        If sDisabledMenu = "1" Then
                            sb.Append(" style='cursor:none' onclick = ''")
                        Else
                            sb.Append(String.Format("onclick = ""if(!onMenuItemClick())return;window.navigate('{0}?ScrollPosition='+GetScrollPosition())""", Utils.Navigation.GetURL("frmFWClaim.aspx")))
                        End If
                        sb.Append(" >תביעות עובדים זרים</a></li>")
                    Else
                        If sDisabledMenu = "1" Then
                            sb.Append(" style='cursor:none' onclick =''")
                        Else
                            sb.Append(String.Format("onclick = ""if(!onMenuItemClick())return;window.navigate('{0}?ScrollPosition='+GetScrollPosition())""", Utils.Navigation.GetURL("frmFWClaimDeclaration.aspx")))
                        End If
                        sb.Append(" >תביעות עובדים זרים</a></li>")
                    End If
                Else
                    spnForiegnWorkers_Visible = False
                    spnKeptAppeal_Visible = False
                End If
            Else
                spnForiegnWorkers_Visible = False
                spnKeptAppeal_Visible = False
            End If


            '''''''''''''''''''''''''''''''''''''''
            '''''''''''  ניהול חברי קבוצה   '''''''''' 
            '''''''''''''''''''''''''''''''''''''''


            Dim sUserID As String = objUser.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", User_Identity_Name)
            Dim bIsManagerCommunity As Boolean = objUser.IsManagerCommunity("B4900750-FD16-11DF-8CFF-0800200C9A66", CInt(sUserID))
            If bIsManagerCommunity Then
                spnManageUsers_Visible = True
                sb.Append("<li id=""spnMultiCheck"" class=""SubMenuItem""><a href=""#""  ")
                If sDisabledMenu = "1" Then
                    sb.Append("onclick = ''  style='cursor:none' ")
                Else
                    sb.Append(String.Format("onclick = ""if(!onMenuItemClick())return;window.navigate('{0}?ScrollPosition='+GetScrollPosition())""", Utils.Navigation.GetURL("frmmanageusers.aspx")))
                End If
                sb.Append(" >ניהול חברי קבוצה</a></li>")
            End If
        Else
            spnForiegnWorkers_Visible = False
            spnKeptAppeal_Visible = False
        End If

        context.Response.Write(sb)

    End Sub

    ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property

End Class