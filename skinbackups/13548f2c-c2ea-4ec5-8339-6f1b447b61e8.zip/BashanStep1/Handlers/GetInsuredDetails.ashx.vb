﻿Imports System.Web
Imports System.Web.Services
Imports System.Web.Script.Serialization
Imports System.Collections.Generic
Imports System.Text
Imports System.Text.RegularExpressions

Public Class GetInsuredDetails
    Implements System.Web.IHttpHandler
    Implements SessionState.IRequiresSessionState

    <Serializable()> Private Class SearchResult
        Public InsuredName As String
        Public InsuredFamily As String
    End Class

    Dim sResult As SearchResult

    Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest
        Dim objBO As New BOConnection.BOService
        objBO.Url = context.Application("BOWebService")
        Dim iError As Integer
        Dim ds As New DataSet
        Dim strId As String = HttpContext.Current.Request("InsuredID")


        Dim Response As String = String.Empty
        Dim SearchResultsForSelectFromList As List(Of SearchResult) = New List(Of SearchResult)
        Dim SearchResultsForAutocomplete As Dictionary(Of String, String) = New Dictionary(Of String, String)



        ds = objBO.GetInsuredDetails("BB91B46E-024D-41F0-97C0-D58FE62388E9", Val(strId))

        If ds.Tables(0).Rows.Count = 0 Then
            iError = "11"

            context.Session.Remove("HDInsuredID")

            context.Session.Remove("HDSHEM")

            context.Session.Remove("HDMISP")



            sResult = New SearchResult()
            sResult.InsuredName = ""
            sResult.InsuredFamily = ""



        Else






            For Each dr As DataRow In ds.Tables(0).Rows
                sResult = New SearchResult()
                sResult.InsuredName = Utils.Values.GetFirstTableFirstRowString(ds, "SHEM")
                sResult.InsuredFamily = Utils.Values.GetFirstTableFirstRowString(ds, "MISP")
            Next


            If iError <> 11 Then
                context.Session("HDInsuredID") = strId
                context.Session("HDSHEM") = sResult.InsuredName
                context.Session("HDMISP") = sResult.InsuredFamily
            End If

        End If

        SearchResultsForSelectFromList.Add(sResult)




        Dim serializer As JavaScriptSerializer = New JavaScriptSerializer()

        Response = serializer.Serialize(SearchResultsForSelectFromList)

        HttpContext.Current.Response.Write(Response)




    End Sub




    ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property









End Class