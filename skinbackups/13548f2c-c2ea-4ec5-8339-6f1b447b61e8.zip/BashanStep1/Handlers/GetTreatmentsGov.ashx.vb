﻿Imports System.Web
Imports System.Web.Services

Public Class GetTreatmentsGov
    Implements System.Web.IHttpHandler

    Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest

        context.Response.ContentType = "text/plain"
        Dim strID As String = context.Request("hidID")
        Dim strType As String = context.Request("hidType")
        Dim iConsultation As Integer = Val(context.Request("hidConsultation") & "")

        Dim objResult As New System.Text.StringBuilder(), objXML As New System.Text.StringBuilder()
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = context.Application("TreatmentWebService").ToString()
        Dim objUser As New UserConnect.UserService()
        objUser.Url = context.Application("UserWebService").ToString()

        Dim ds As Data.DataSet
        Dim strTreatmentTypeID As String, strTreatmentDesc As String, strPhotoUnits As String, strXrayB As String, strXrayA As String
        Dim iUnuseTreatment As Integer = 0

        objResult.Append("<?xml version=" & Chr(34) & "1.0" & Chr(34) & " encoding=" & Chr(34) & "Windows-1255" & Chr(34) & "?><recordset>")
        If strType = "3" Or strType = "5" Then
            Dim strTreatmentValue As String = ""
            objResult.Append("<oSelect>")
            If Trim(strID) <> "" Then

                If strType = "5" Then
                    ds = objTreatmentService.GetTreatmentsByIDWithOrder("A7BEA283-6FFB-4D53-9598-CBB1745CA20A", Val(strID), iConsultation)
                    iUnuseTreatment = CheckTreatment(ds, Val(strID))
                Else
                    ds = objTreatmentService.GetTreatmentsByIDWithOrderGov("9256523B-37FC-4DA4-A986-82991D5BDB51", Trim(strID), iConsultation)
                End If

                If (ds.Tables(0).Rows.Count > 0) Then
                    strTreatmentValue = ds.Tables(0).Rows(0).Item("TreatmentTypeID").ToString()
                Else
                    strTreatmentValue = "0"
                End If

                If (ds.Tables(0).Rows.Count > 0) Then
                    Dim iBashanCode As Integer = 0
                    If strType = "3" Then
                        Try
                            iBashanCode = Val(context.Request.Form("CareType"))
                        Catch ex As Exception
                            iBashanCode = 0
                        End Try
                    End If
                    If iBashanCode = 0 Then
                        strID = GetBashanTreatmentByGovTreatment(ds, Trim(strID))
                    Else
                        strID = iBashanCode.ToString()
                    End If
                Else
                    strID = 0
                End If

                If strType = "3" Then
                    FillComboboxTreatment("TreatmentID", "GovTreatmentDescription", ds, objResult)
                Else
                    FillComboboxTreatment("TreatmentID", "Treatment", ds, objResult)
                End If

                objResult.Append("</oSelect>")
                objResult.Append("<oAttachSelect>")
                ds = objTreatmentService.GetAllAttachTypes("5793D9EB-2CC1-44A3-BC46-84C21525AA07")
                FillAttachCombobox("AttachID", "AttachName", ds, objResult)
                objResult.Append("</oAttachSelect>")
            Else
                objResult.Append("</oSelect>")
            End If

            objResult.Append("<oSelect1>")
            If Not strID Is Nothing Then
                If Trim(strID) <> "" Then
                    ds = objTreatmentService.GetCauses("CD6AEA9F-C78F-4942-A749-38C16DE0AA62", Val(strID))
                    FillCombobox("CauseID", "Cause", ds, objResult)
                    ds = objTreatmentService.GetTeethRange("DAD91AA1-DE6F-4C28-8A11-CB0FF79BD302", Val(strID))
                    FillXML(ds, objXML)
                    objTreatmentService.GetTreatmentTypeByIDGov("FB56EA91-5609-44C7-B6AB-2615DDF76515", Val(strID), strTreatmentTypeID, strTreatmentDesc, strPhotoUnits, strXrayB, strXrayA)
                End If
            End If
            objResult.Append("</oSelect1>")
            objResult.Append("<txtTreatmentValue>" & strTreatmentValue & "</txtTreatmentValue>")
        Else
            objResult.Append("<oSelect>")
            If Trim(strID) <> "" Then
                If strType = "1" Or strType = "4" Then
                    Dim iTType As Integer = CInt(strID)
                    If iTType = 1 Then
                        ds = objTreatmentService.GetTreatmentsWithOrderGov("9C2DF2BD-B351-4F4F-B034-8B48870D5580", 1, iConsultation)
                    Else
                        ds = objTreatmentService.GetTreatmentsGov("6431850A-2AA4-4BB8-BE87-3A6F6FEB3C8A", iTType, iConsultation)
                    End If
                    If strType = "4" Then
                        FillComboboxTreatment("TreatmentID", "Treatment", ds, objResult)
                    Else
                        FillComboboxTreatment("TreatmentID", "GovTreatmentDescription", ds, objResult)
                    End If
                    objResult.Append("</oSelect>")
                    objResult.Append("<oAttachSelect>")
                    ds = objTreatmentService.GetAllAttachTypes("5793D9EB-2CC1-44A3-BC46-84C21525AA07")
                    FillAttachCombobox("AttachID", "AttachName", ds, objResult)
                    objResult.Append("</oAttachSelect>")
                Else
                    ds = objTreatmentService.GetCauses("CD6AEA9F-C78F-4942-A749-38C16DE0AA62", CInt(strID))
                    FillCombobox("CauseID", "Cause", ds, objResult)
                    objResult.Append("</oSelect>")
                    objTreatmentService.GetTreatmentTypeByID("7FC19103-F277-4D28-B445-60C4999DB7E5", CInt(strID), strTreatmentTypeID, strTreatmentDesc, strPhotoUnits, strXrayB, strXrayA)
                    ds = objTreatmentService.GetTeethRange("DAD91AA1-DE6F-4C28-8A11-CB0FF79BD302", CInt(strID))
                    FillXML(ds, objXML)
                End If
            Else
                objResult.Append("</oSelect>")
            End If
        End If

        objResult.Append("<txtComboType>" & strType & "</txtComboType>")
        objResult.Append("<txtXray_A>" & strXrayA & "</txtXray_A>")
        objResult.Append("<txtXray_B>" & strXrayB & "</txtXray_B>")
        'objResult.Append("<txtTeethRange>" & objXML.ToString() & "</txtTeethRange>")
        objResult.Append("<hidUnusedTreatment>" & iUnuseTreatment.ToString() & "</hidUnusedTreatment>")
        objResult.Append(objXML.ToString())
        objResult.Append("</recordset>")
        HttpContext.Current.Response.Write(objResult.ToString())

    End Sub

    Private Function CheckTreatment(ByVal dsTreatments As DataSet, ByVal iTreatmentID As Integer) As Integer
        Dim retVal As Integer
        Dim foundRow As DataRow() = dsTreatments.Tables(0).Select("TreatmentID=" & iTreatmentID.ToString())
        If foundRow.Length = 1 Then
            If foundRow(0)("GovTreatmentID").ToString() = "" Then
                retVal = 1
            Else
                retVal = 0
            End If
        End If
        Return retVal
    End Function

    Private Function GetBashanTreatmentByGovTreatment(ByVal dsTreatments As DataSet, ByVal strGovTreatment As String) As String
        Dim strTreatment As String = ""
        Dim foundRow As DataRow() = dsTreatments.Tables(0).Select("GovTreatmentID='" & strGovTreatment & "'")
        If foundRow.Length > 0 Then
            strTreatment = foundRow(0)("TreatmentID").ToString()
        End If
        Return strTreatment
    End Function

    'Private Sub FillCombobox(ByVal strValueField As String, ByVal strDescField As String, ByRef ds As Data.DataSet, ByRef objResult As System.Text.StringBuilder)
    '    Dim currRow As Data.DataRow
    '    objResult.Append("<OPTION value='0'>בחר...</OPTION>")
    '    For Each currRow In ds.Tables(0).Rows
    '        objResult.Append("<OPTION value='" & currRow(strValueField).ToString() & "'>" & currRow(strDescField).ToString() & "</OPTION>")
    '    Next
    'End Sub

    Private Sub FillCombobox(ByVal strValueField As String, ByVal strDescField As String, ByRef ds As Data.DataSet, ByRef objResult As System.Text.StringBuilder)
        Dim currRow As Data.DataRow
        AddXmlNode("OPTION", "0", "בחר...", objResult)
        For Each currRow In ds.Tables(0).Rows
            AddXmlNode("OPTION", currRow(strValueField).ToString(), currRow(strDescField).ToString(), objResult)
        Next
    End Sub
    Private Sub AddXmlNode(ByVal strNodeName As String, ByVal strValue As String, ByVal strText As String, ByRef objResult As System.Text.StringBuilder)
        objResult.Append("<").Append(strNodeName).Append("><value>").Append(strValue).Append("</value><text>").Append(strText).Append("</text></").Append(strNodeName).Append(">")
    End Sub

    Private Sub FillAttachCombobox(ByVal strValueField As String, ByVal strDescField As String, ByRef ds As Data.DataSet, ByRef objResult As System.Text.StringBuilder)
        Dim currRow As Data.DataRow
        Dim strIsConsultation As String
        objResult.Append("<OPTION value='0'>בחר...</OPTION>")
        For Each currRow In ds.Tables(0).Rows
            If currRow("ForConsultationUse").ToString() = "1" Then
                strIsConsultation = "1"
            Else
                strIsConsultation = "0"
            End If
            objResult.Append("<OPTION value='" & currRow(strValueField).ToString() & "' Prefix='" & currRow("Prefix").ToString() & "' ForConsultation='" & strIsConsultation & "' >" & currRow(strDescField).ToString() & "</OPTION>")
        Next
    End Sub

    Private Sub FillComboboxTreatment(ByVal strValueField As String, ByVal strDescField As String, ByRef ds As Data.DataSet, ByRef objResult As System.Text.StringBuilder)
        Dim currRow As Data.DataRow
        Dim strSmileTreatmentID As String = ""
        Dim strServiceBasket As String = ""
        objResult.Append("<OPTION><value>0</value><DefaultRange>0</DefaultRange><DefaultFromTooth>0</DefaultFromTooth><DefaultToTooth>0</DefaultToTooth><SmileCode>0</SmileCode><from></from><BashanCode>0</BashanCode><EarlyConsultation>0</EarlyConsultation><text>בחר...</text></OPTION>")
        For Each currRow In ds.Tables(0).Rows
            strSmileTreatmentID = currRow("GovTreatmentID").ToString().Trim()
            If strSmileTreatmentID <> "" Then
                objResult.Append("<OPTION><value>").Append(currRow(strValueField).ToString())
                objResult.Append("</value><DefaultRange>").Append(currRow("DefaultTeethRange").ToString())
                objResult.Append("</DefaultRange><DefaultFromTooth>").Append(currRow("DefaultFromTooth").ToString())
                objResult.Append("</DefaultFromTooth><DefaultToTooth>").Append(currRow("DefaultToTooth").ToString())
                objResult.Append("</DefaultToTooth><SmileCode>").Append(strSmileTreatmentID)
                objResult.Append("</SmileCode><ServiceBasket>").Append(strServiceBasket)
                objResult.Append("</ServiceBasket><from>").Append(currRow("RangeID").ToString())
                objResult.Append("</from><BashanCode>").Append(currRow("BashanCode").ToString())
                objResult.Append("</BashanCode><EarlyConsultation>").Append(currRow("EarlyConsultation").ToString())
                objResult.Append("</EarlyConsultation><text>").Append(currRow(strDescField).ToString())
                objResult.Append("</text><IsFilling>").Append(currRow("IsFilling").ToString()).Append("</IsFilling></OPTION>")
            End If
        Next
    End Sub

    'Private Sub FillXML(ByRef ds As Data.DataSet, ByRef objResult As System.Text.StringBuilder)
    '    Dim currRow As Data.DataRow
    '    For Each currRow In ds.Tables(0).Rows
    '        objResult.Append("<range from=" & Chr(34) & currRow("FromTooth").ToString() & Chr(34) & " to=" & Chr(34) & currRow("ToTooth").ToString() & Chr(34) & " allow=" & Chr(34) & currRow("AllowTeethRange").ToString() & Chr(34) & "/>")
    '    Next
    'End Sub

    Private Sub FillXML(ByRef ds As Data.DataSet, ByRef objResult As System.Text.StringBuilder)
        Dim currRow As Data.DataRow
        objResult.Append("<txtTeethRange>")
        For Each currRow In ds.Tables(0).Rows
            objResult.Append("<range><from>").Append(currRow("FromTooth").ToString()).Append("</from><to>").Append(currRow("ToTooth").ToString()).Append("</to><allow>").Append(currRow("AllowTeethRange").ToString()).Append("</allow></range>")
        Next
        objResult.Append("</txtTeethRange>")
    End Sub

    ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property

End Class