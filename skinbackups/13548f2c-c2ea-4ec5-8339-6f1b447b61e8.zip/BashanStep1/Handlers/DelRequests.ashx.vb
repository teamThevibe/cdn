﻿Imports System.Web
Imports System.Web.Services

Public Class DelRequests
    Implements System.Web.IHttpHandler

    Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest

        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = context.Application("TreatmentWebService").ToString()

        Dim InsuredID As Integer = Val(context.Request("InsuredID"))
        Dim Requests As String = HttpContext.Current.Request("Requests")
        Dim UserName As String = context.User.Identity.Name

        Dim DelRequestBashanInWork As Boolean = objTreatmentService.DelRequestBashanInWork("1BE727A9-81B3-44FF-968A-A68E73ED8B95", Requests, InsuredID, UserName)
        context.Response.ContentType = "text/plain"
        context.Response.Write(Val(DelRequestBashanInWork))
         
    End Sub

    ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property

End Class