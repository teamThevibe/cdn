﻿Imports System.IO
Imports System.Web.Script.Serialization

Public Class HandlersUtils

    ' YT:!
    Shared Function InputStreamToObject(Of T As Class)(ByVal inputStream As Stream) As T
        Dim reader As StreamReader = New StreamReader(inputStream)
        Dim inputStreamText As String = reader.ReadToEnd()
        reader.Close()
        Return InputStreamToObject(Of T)(inputStreamText)
    End Function

    Shared Function InputStreamToObject(Of T As Class)(ByVal inputStreamText As String) As T
        Dim serializer As JavaScriptSerializer = New JavaScriptSerializer()
        Dim obj As T = serializer.Deserialize(Of T)(inputStreamText)
        Return obj
    End Function

    Shared Function ClassToJSON(Of T As Class)(ByVal inputStream As T) As String
        Dim serializer As JavaScriptSerializer = New JavaScriptSerializer()
        Return serializer.Serialize(inputStream)
    End Function

End Class

<Serializable()> Public Class SupplierPayments

    Public RecID As Long
    Public SupplierID As String ' ??????????????????????
    Public BusinessNumber As Long
    Public FaxConcern As Boolean
    Public MonthYear As String
    Public Amount As String
    Public InvoiceNumber As String
    Public InvoiceDate As String
    Public InvoiceAmount As String
    Public InvoiceRemarks As String
    Public Status As Nullable(Of Integer)
    Public RejectionReason As Nullable(Of Integer)

    Public Sub New()
        Me.RecID = 0
        Me.SupplierID = ""
        Me.BusinessNumber = 0
        Me.FaxConcern = False
        Me.MonthYear = ""
        Me.Amount = ""
        Me.InvoiceNumber = ""
        Me.InvoiceDate = ""
        Me.InvoiceAmount = ""
        Me.InvoiceRemarks = ""
        'Me.Status = ""
        'Me.RejectionReason = ""
    End Sub

End Class

