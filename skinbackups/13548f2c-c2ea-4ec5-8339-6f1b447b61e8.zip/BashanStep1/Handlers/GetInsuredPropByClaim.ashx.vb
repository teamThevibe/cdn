﻿Imports System.Web
Imports System.Web.Services
Imports System.Web.Script.Serialization

Public Class GetInsuredPropByClaim
    Implements System.Web.IHttpHandler

    <Serializable()> Private Class SearchResult
        Public FirstName As String = ""
        Public LastName As String = ""
        Public PolicyNo As String = ""
        Public InsuredID As String = ""
        Public Treatment As String = ""
        Public SmileCode As String = ""
        Public Cause As String = ""
        Public FromTooth As String = ""
        Public ToTooth As String = ""
        Public Surface As String = ""
        Public Invoice As String = ""
        Public Amount As String = ""
        Public EntryDate As String = ""
        Public RequestType As String = ""
        Public Clinic As String = ""
        Public DoctorNo As String = ""
        Public Cancelled As String = ""
        Public TreatmentValue As String = ""
        Public GovTreatments As String = ""
        Public RetValue As Integer = 0
    End Class

    Dim objResult As New SearchResult

    Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest
        Dim strRefID As String = context.Request("ClaimID")
        Dim strFirstName As String = ""
        Dim strLastName As String = ""
        Dim strPolicyNo As String = ""
        Dim strEmployeeNo As String = ""
        Dim strInsuredID As String = ""
        Dim strTreatment As String = ""

        Dim strTreatmentValue As String = ""
        Dim strGovTreatments As String = ""
        Dim bGovermentTreatmnts As Boolean = False

        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = context.Application("TreatmentWebService")
        Dim dsAnswers As DataSet = objTreatmentService.GetInsuredPropByReference("C202994D-651F-4D03-8917-C59B30D590A7", strRefID, strFirstName, strLastName, strPolicyNo, strEmployeeNo, strInsuredID)
        If dsAnswers.Tables("Requests").Rows.Count > 0 Then
            Dim currRow As DataRow = dsAnswers.Tables("Requests").Rows(0)
            If CType(currRow("RequestID"), Integer) < 1000000000 Then
                If currRow("InsuredID").ToString() <> "1000000000" Then
					strInsuredID = currRow("InsuredID").ToString()
					Dim tmpFirstName As String = ""
					Dim tmpLastName As String = ""
					Dim iPolicyNo As Integer = 0
					Dim iGuf As Integer = 0
					Dim strPolGovTreatment As String = ""
                    With objResult
                        Try
                            .RetValue = objTreatmentService.GetInsuredPropExt("2C331B73-13D1-4D07-B669-F409BE3CFB58", strInsuredID, tmpFirstName, tmpLastName, iPolicyNo, iGuf, strPolGovTreatment)
                        Catch ex As Exception

                        End Try
                        If Trim(strPolGovTreatment) = "ח" Then
                            bGovermentTreatmnts = True
                        End If
                        .FirstName = NoGeresh(currRow("InsuredFir").ToString())
                        .LastName = NoGeresh(currRow("InsuredFan").ToString())
                        .PolicyNo = currRow("PolicyNo").ToString()
                        .InsuredID = strInsuredID
                        strEmployeeNo = currRow("EmployeeNo").ToString()
                        strTreatment = currRow("Treatment").ToString()
                        .Treatment = strTreatment
                        Dim ds As DataSet
                        If context.Application("Smile") = "1" Then
                            ds = objTreatmentService.GetSingleTreatmentByID("86E85219-7BF1-4FEC-AA5B-43C05F9E3424", CInt(strTreatment))
                            If (ds.Tables(0).Rows.Count > 0) Then
                                .SmileCode = ds.Tables(0).Rows(0).Item("SmileTreatmentID").ToString()
                            End If
                        ElseIf bGovermentTreatmnts Then
                            ds = objTreatmentService.GetSingleTreatmentByID("86E85219-7BF1-4FEC-AA5B-43C05F9E3424", CInt(strTreatment))
                            If (ds.Tables(0).Rows.Count > 0) Then
                                .SmileCode = ds.Tables(0).Rows(0).Item("GovTreatmentID").ToString()
                            End If
                            If .SmileCode = "" Then
                                .SmileCode = strTreatment
                            End If
                        Else
                            .SmileCode = strTreatment
                        End If
                        .Cause = currRow("Cause").ToString()
                        .FromTooth = currRow("FTooth").ToString()
                        .ToTooth = currRow("ToTooth").ToString()
                        .Surface = currRow("Surface").ToString()
                        .Invoice = currRow("Invoice").ToString()
                        .Amount = currRow("Amount").ToString()
                        If IsDBNull(currRow("FinishDate")) Then
                            .EntryDate = "00000000"
                        Else
                            Dim dt As DateTime = Convert.ToDateTime(currRow("FinishDate"))
                            .EntryDate = dt.ToString("ddMMyyyy")
                        End If
                        .RequestType = currRow("RequestTyp").ToString()
                        .Clinic = currRow("ClinicNo").ToString()
                        .DoctorNo = currRow("DocNo").ToString()
                        If Trim(strTreatment) <> "" Then
                            ds = objTreatmentService.GetTreatmentsByIDWithOrder("A7BEA283-6FFB-4D53-9598-CBB1745CA20A", CInt(strTreatment), 0)
                            If (ds.Tables(0).Rows.Count > 0) Then
                                strTreatmentValue = ds.Tables(0).Rows(0).Item("TreatmentTypeID").ToString()
                            End If
                        End If
                        .TreatmentValue = strTreatmentValue
                        .GovTreatments = IIf(bGovermentTreatmnts, "1", "")
                    End With
                Else
                    objResult.Cancelled = "הפניה בוטלה, נא לפנות למנהל מערכת"
                End If
            End If
        End If
        Dim serializer As JavaScriptSerializer = New JavaScriptSerializer()
        HttpContext.Current.Response.Write(serializer.Serialize(objResult))
    End Sub

    ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property

    Function NoGeresh(ByVal sStr As String) As String
        Dim sRes As String = sStr
        sRes = Replace(sRes, "'", "&apos;")
        sRes = Replace(sRes, """", "&quot;")
        Return sRes
    End Function
End Class