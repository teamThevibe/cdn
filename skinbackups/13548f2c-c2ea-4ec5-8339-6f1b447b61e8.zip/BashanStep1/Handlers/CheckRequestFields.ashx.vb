﻿Imports System.Web
Imports System.Web.Services

Public Class CheckRequestFields
    Implements System.Web.IHttpHandler

    Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest


        'Dim objResult As New System.Text.StringBuilder()
        'objResult.Append("<HTML><HEAD><TITLE></TITLE>")
        'objResult.Append("<meta http-equiv='Cache-Control' content='no-cache'>" & vbCrLf)
        'objResult.Append("<meta http-equiv='Pragma' content='no-cache'>" & vbCrLf)
        'objResult.Append("<meta http-equiv='Expires' content='0'>" & vbCrLf)
        'objResult.Append("<META http-equiv='Content-Type' content='text/html; charset=windows-1255'>")
        'objResult.Append("</HEAD>")
        'objResult.Append("<BODY>")
        'objResult.Append("<INPUT TYPE='hidden' id='ctlWhiteListResult' value='" & strWhiteListResult & "'>")
        'objResult.Append("<INPUT TYPE='hidden' id='ctlCheckKind' value='" & sCheckKind & "'>")
        'objResult.Append("<SCRIPT>")
        'objResult.Append("	window.opener.document.all.oWLNotification.value = 'OK';")
        'objResult.Append("</SCRIPT>")
        'objResult.Append("</BODY>")
        'objResult.Append("</HTML>")
        'Response.Write(objResult.ToString())


        context.Response.ContentType = "text/plain"
        context.Response.Write("OK")

    End Sub

    ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property

End Class