﻿Imports System.Web
Imports System.Web.Services
Imports System.Web.Script.Serialization
Imports System.Collections.Generic
Imports System.Text
Imports System.Text.RegularExpressions


Public Class GetCareCode
    Implements System.Web.IHttpHandler

    <Serializable()> Private Class SearchResult
        Public ID As String
        Public Name As String
    End Class

    Protected Enum ServiceType
        Autocomplete = 1
        SelectFromList = 2
    End Enum

    Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest


        Dim CurrentServiceType As ServiceType = ServiceType.SelectFromList

        context.Response.ContentType = "text/plain"
        Dim SearchString As String = HttpContext.Current.Request("SearchString")
        Dim strId As String = HttpContext.Current.Request("hidID")
        Dim iTType As String = 1 'Integer.Parse(HttpContext.Current.Request("hidType"))
        Dim iConsultation As String = Integer.Parse(HttpContext.Current.Request("hidConsultation"))
        Dim strHebEngSearch As String
        

        If SearchString Is Nothing Then ' call from autocomplete
            SearchString = HttpContext.Current.Request.QueryString("mask")
            CurrentServiceType = ServiceType.Autocomplete
        End If
        'SearchString = ArrangeEnHeString(SearchString)
        'strHebEngSearch = ConvertToOldEbcdic(SearchString)
        strHebEngSearch = convertHebrewToEnglish(SearchString)

        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = HttpContext.Current.Application("TreatmentWebService").ToString()

        If strHebEngSearch.Length > 0 Then
            SearchString = strHebEngSearch
        End If

        Dim ds As DataSet = objTreatmentService.GetTreatmentsGovAutoComplete("6431850A-2AA4-4BB8-BE87-3A6F6FEB3C8A", iTType, iConsultation, SearchString)
        Dim Response As String = String.Empty
        Dim SearchResultsForSelectFromList As List(Of SearchResult) = New List(Of SearchResult)
        Dim SearchResultsForAutocomplete As Dictionary(Of String, String) = New Dictionary(Of String, String)

        ' YT:
        Dim sResult As SearchResult
        For Each dr As DataRow In ds.Tables(0).Rows
            sResult = New SearchResult()
            sResult.ID = dr("GovTreatmentID")

            Dim strName As String = dr("GovTreatmentID").ToString().Trim()

            While (strName.IndexOf("  ") > -1)
                strName = strName.Replace("  ", " ")
            End While
            strName = strName.Replace("""", "'").Trim()

            'Dim strTitle As String = dr("Title").ToString()

            'strTitle = strTitle.Replace("""", "'").Trim()
            'If (strTitle <> "") Then
            '    strTitle += " "
            'End If

            'sResult.Name = strTitle & strName
            sResult.Name = strName
            SearchResultsForSelectFromList.Add(sResult)
            SearchResultsForAutocomplete.Add(sResult.ID, sResult.Name)
        Next

        Dim serializer As JavaScriptSerializer = New JavaScriptSerializer()
        If CurrentServiceType = ServiceType.SelectFromList Then
            Response = serializer.Serialize(SearchResultsForSelectFromList)
        Else
            Response = serializer.Serialize(SearchResultsForAutocomplete)
        End If
        HttpContext.Current.Response.Write(Response)



    End Sub

    ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property



    '++++++++++++++++++++++++++++
    'Fix AutoComplete to work with hebrew - change Heb to Eng

    Private Function convertHebrewToEnglish(ByVal strSearchString As String) As String
        If Regex.IsMatch(strSearchString, "([א-ת])") Then
            strSearchString = SwapBrackets(strSearchString)

            Dim matchValueTrimmed As String = strSearchString.Trim()
            Dim ebcEnc As Encoding = Encoding.GetEncoding(1255)
            Dim inBytes As Byte() = ebcEnc.GetBytes(matchValueTrimmed)
            Dim sBuilder As New StringBuilder(inBytes.Length * 2)
            Dim i As Integer
            For i = 0 To inBytes.GetUpperBound(0)
                inBytes(i) = ChangeHebCharToEngChar(inBytes(i))
            Next
            matchValueTrimmed = ebcEnc.GetString(inBytes) ' sBuilder.ToString()
            Return matchValueTrimmed.ToUpper()

        Else
            Return strSearchString
        End If
    End Function

    Private Shared Function ChangeHebCharToEngChar(ByVal oldEbcdic As Byte) As Byte
        Dim newEbcdic As Byte
        Dim dictionary As Byte(,) = GetEbcdicDictionary()
        newEbcdic = 0
        For i As Integer = 0 To 26
            If dictionary(i, 0).Equals(oldEbcdic) Then
                newEbcdic = dictionary(i, 1)
                Exit For
            End If
        Next

        If newEbcdic = 0 Then
            ' if not hebrew letter keep existing mapping 
            newEbcdic = oldEbcdic
        End If

        Return newEbcdic
    End Function

    Public Shared Function SwapBrackets(ByVal outputString As String) As String
        For i As Integer = 0 To outputString.Length - 1
            If outputString(i) = ")"c Then
                outputString = outputString.Remove(i, 1)
                outputString = outputString.Insert(i, "(")
            ElseIf outputString(i) = "("c Then
                outputString = outputString.Remove(i, 1)
                outputString = outputString.Insert(i, ")")
            ElseIf outputString(i) = "["c Then
                outputString = outputString.Remove(i, 1)
                outputString = outputString.Insert(i, "]")
            ElseIf outputString(i) = "]"c Then
                outputString = outputString.Remove(i, 1)
                outputString = outputString.Insert(i, "[")
            ElseIf outputString(i) = "}"c Then
                outputString = outputString.Remove(i, 1)
                outputString = outputString.Insert(i, "{")
            ElseIf outputString(i) = "{"c Then
                outputString = outputString.Remove(i, 1)
                outputString = outputString.Insert(i, "}")
            End If
        Next
        Return outputString
    End Function

    Private Shared Function GetEbcdicDictionary() As Byte(,)

        '65	(A)	=	249	(ש)
        '66	(B)	=	240	(נ)
        '67	(C)	=	225	(ב)
        '68	(D)	=	226	(ג)
        '69	(E)	=	247	(ק)
        '70	(F)	=	235	(כ)
        '71	(G)	=	242	(ע)
        '72	(H)	=	233	(י)
        '73	(I)	=	239	(ן)
        '74	(J)	=	231	(ח)
        '75	(K)	=	236	(ל)
        '76	(L)	=	234	(ך)
        '77	(M)	=	246	(צ)
        '78	(N)	=	238	(מ)
        '79	(O)	=	237	(ם)
        '80	(P)	=	244	(פ)
        '81	(Q)	=	92	(\)
        '82	(R)	=	248	(ר)
        '83	(S)	=	227	(ד)
        '84	(T)	=	224	(א)
        '85	(U)	=	229	(ו)
        '86	(V)	=	228	(ה)
        '87	(W)	=	146	(’)
        '88	(X)	=	241	(ס)
        '89	(Y)	=	232	(ט)
        '90	(Z)	=	230	(ז)
        '44	(,)	=	250	(ת)
        '59	(;)	=	243	(ף)
        '46	(.)	=	245	(ץ)

        Dim dictionary As Byte(,) = New Byte(,) {{249, 65}, {240, 66}, {225, 67}, {226, 68}, {247, 69}, {235, 70}, _
                {242, 71}, {233, 72}, {239, 73}, {231, 74}, {236, 75}, {234, 76}, _
                {246, 77}, {238, 78}, {237, 79}, {244, 80}, {92, 81}, {248, 82}, _
                {227, 83}, {224, 84}, {229, 85}, {228, 86}, {146, 87}, {241, 88}, _
                {232, 89}, {230, 90}, {250, 44}, {243, 59}, {245, 46}}


        Return dictionary
    End Function

    '++++++++++++++++++++++++++++++++++++++++++++++++++++++++

End Class