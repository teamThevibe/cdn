﻿Imports System.Web
Imports System.Web.Services

Public Class GetTreatments
    Implements System.Web.IHttpHandler
    Implements System.Web.SessionState.IRequiresSessionState

    Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest

        context.Response.ContentType = "text/plain"

        Dim strID As String = HttpContext.Current.Request("hidID")
        Dim strType As String = HttpContext.Current.Request("hidType")
        Dim iConsultation As Integer = Val(HttpContext.Current.Request("hidConsultation") & "")
        Dim objResult As New System.Text.StringBuilder(), objXML As New System.Text.StringBuilder()

        ' да уж... похоже, что strID иногда должно быть числом, иногда не обязательно... 
        Try
            Dim objTreatmentService As New TreatmentConnect.TreatmentService()
            objTreatmentService.Url = HttpContext.Current.Application("TreatmentWebService").ToString()
            Dim objUser As New UserConnect.UserService()
            objUser.Url = HttpContext.Current.Application("UserWebService").ToString()

            Dim ds As Data.DataSet
            Dim strTreatmentTypeID As String, strTreatmentDesc As String, strPhotoUnits As String, strXrayB As String, strXrayA As String
            Dim isSmileAgrementClinic As Boolean = False
            Dim iSmileAgrementClinicPlus As Integer = 0
            If HttpContext.Current.Application("Smile") = "1" Then
                iSmileAgrementClinicPlus = objUser.CheckIfAgrementClinicPlus("2AFAE3F5-79B5-459E-B1F9-C460BD34672A", HttpContext.Current.User.Identity.Name)
                If iSmileAgrementClinicPlus > 0 Then
                    isSmileAgrementClinic = True
                End If
            End If

            objResult.Append("<?xml version=" & Chr(34) & "1.0" & Chr(34) & " encoding=" & Chr(34) & "Windows-1255" & Chr(34) & "?><recordset>")
            If strType = "3" Then
                Dim strTreatmentValue As String = ""
                objResult.Append("<oSelect>")
                If Trim(strID) <> "" Then
                    If HttpContext.Current.Application("Smile") = "1" Then
                        Dim objSmile As New SmileConnector.SmileConnector()
                        objSmile.Url = HttpContext.Current.Application("SmileWebService").ToString()
                        If isSmileAgrementClinic Then
                            If iSmileAgrementClinicPlus = 2 Then
                                ds = objSmile.GetSmileTreatmentForServiceBasketPlus("FFCBF402-CC32-4E6D-9A7D-FBD7D6C3B39C", strID)
                            Else
                                ds = objSmile.GetSmileTreatmentForServiceBasket("17E9AF74-D4C8-432E-8249-0AD74900983B", strID)
                            End If
                        ElseIf context.Session("Smile_OnlyServiceBasketNet") = "1" Then
                            ds = objSmile.GetSmileTreatmentForServiceBasketNet("607416EF-AA1A-42B1-AAB5-44E912F20FD9", strID)
                        Else
                            ds = objSmile.GetSmileTreatment("C4675A38-17EF-4158-97A4-A32DCDB55135", strID)
                        End If
                        If (ds.Tables(0).Rows.Count > 0) Then
                            strID = ds.Tables(0).Rows(0).Item("TreatmentID").ToString()
                        End If
                    End If
                    If context.Session("Leumit_OnlyServiceBasket") = "1" Or isSmileAgrementClinic Then
                        If iSmileAgrementClinicPlus = 2 Then
                            ds = objTreatmentService.GetTreatmentsByIDWithOrderForServiceBasketPlus("DC891BD1-495E-48F6-ABDD-7FC65B070406", CInt(strID), iConsultation)
                        Else
                            ds = objTreatmentService.GetTreatmentsByIDWithOrderForServiceBasket("A7BEA283-6FFB-4D53-9598-CBB1745CA20A", CInt(strID), iConsultation)
                        End If
                    ElseIf context.Session("Smile_OnlyServiceBasketNet") = "1" Then
                        ds = objTreatmentService.GetTreatmentsByIDWithOrderForServiceBasketNet("E9BFD603-56D9-4122-9009-ECE37FC844CC", CInt(strID), iConsultation)
                    Else
                        ds = objTreatmentService.GetTreatmentsByIDWithOrder("A7BEA283-6FFB-4D53-9598-CBB1745CA20A", CInt(strID), iConsultation)
                    End If

                    If (ds.Tables(0).Rows.Count > 0) Then
                        strTreatmentValue = ds.Tables(0).Rows(0).Item("TreatmentTypeID").ToString()
                    Else
                        strTreatmentValue = "0"
                    End If
                    If HttpContext.Current.Application("Smile") = "1" And HttpContext.Current.Application("Smile_Platinum_18_Supported") = "1" And context.Session("Smile_Platinum_18") = "1" And Not isSmileAgrementClinic Then
                        If strTreatmentValue = "1" Then
                            FillComboboxTreatment("TreatmentID", "Treatment", ds, objResult)
                        Else
                            strTreatmentValue = "0"
                            strID = ""
                        End If
                    Else
                        FillComboboxTreatment("TreatmentID", "Treatment", ds, objResult)
                    End If
                    objResult.Append("</oSelect>")
                    objResult.Append("<oAttachSelect>")
                    ds = objTreatmentService.GetAllAttachTypes("5793D9EB-2CC1-44A3-BC46-84C21525AA07")

                    FillAttachCombobox("AttachID", "AttachName", ds, objResult)
                    objResult.Append("</oAttachSelect>")
                Else
                    objResult.Append("</oSelect>")
                End If
                objResult.Append("<oSelect1>")
                If Trim(strID) <> "" Then
                    ds = objTreatmentService.GetCauses("CD6AEA9F-C78F-4942-A749-38C16DE0AA62", CInt(strID))
                    FillCombobox("CauseID", "Cause", ds, objResult)
                    ds = objTreatmentService.GetTeethRange("DAD91AA1-DE6F-4C28-8A11-CB0FF79BD302", CInt(strID))
                    FillXML(ds, objXML)
                    objTreatmentService.GetTreatmentTypeByID("7FC19103-F277-4D28-B445-60C4999DB7E5", CInt(strID), strTreatmentTypeID, strTreatmentDesc, strPhotoUnits, strXrayB, strXrayA)
                End If
                objResult.Append("</oSelect1>")
                objResult.Append("<txtTreatmentValue>" & strTreatmentValue & "</txtTreatmentValue>")
            Else
                objResult.Append("<oSelect>")
                If Trim(strID) <> "" Then
                    If strType = "1" Then
                        Dim iTType As Integer = CInt(strID)
                        If iTType = 1 Then
                            If context.Session("Leumit_OnlyServiceBasket") = "1" Or isSmileAgrementClinic Then
                                If iSmileAgrementClinicPlus = 2 Then
                                    ds = objTreatmentService.GetTreatmentsWithOrderForServiceBasketPlus("BFC93185-7DBD-4077-9D4A-BB05DDF292D9", 1, iConsultation)
                                Else
                                    ds = objTreatmentService.GetTreatmentsWithOrderForServiceBasket("24396BC1-5D9C-4634-B200-E3FDE8EB7080", 1, iConsultation)
                                End If
                            ElseIf context.Session("Smile_OnlyServiceBasketNet") = "1" Then
                                ds = objTreatmentService.GetTreatmentsWithOrderForServiceBasketNet("D55B93C6-C849-4060-B535-21A2E3DE4690", 1, iConsultation)
                            Else
                                ds = objTreatmentService.GetTreatmentsWithOrder("10F8CFC2-99E1-4094-AABE-D477C8EA8BB0", 1, iConsultation)
                            End If

                        Else
                            If context.Session("Leumit_OnlyServiceBasket") = "1" Or isSmileAgrementClinic Then
                                If iSmileAgrementClinicPlus = 2 Then
                                    ds = objTreatmentService.GetTreatmentsForServiceBasketPlus("640E3791-6127-47DC-967A-B6BA62887B7B", iTType, iConsultation)
                                Else
                                    ds = objTreatmentService.GetTreatmentsForServiceBasket("94473140-9D70-437A-A130-0C0E5ACA6F5A", iTType, iConsultation)
                                End If
                            ElseIf context.Session("Smile_OnlyServiceBasketNet") = "1" Then
                                ds = objTreatmentService.GetTreatmentsForServiceBasketNet("C4D37EBD-0857-4F81-A66B-4BB1BF4AB86C", iTType, iConsultation)
                            Else
                                ds = objTreatmentService.GetTreatments("BE6B6940-6E41-4E06-8C4D-8B95E0D319E2", iTType, iConsultation)
                            End If

                        End If
                        FillComboboxTreatment("TreatmentID", "Treatment", ds, objResult)
                        objResult.Append("</oSelect>")
                        objResult.Append("<oAttachSelect>")
                        ds = objTreatmentService.GetAllAttachTypes("5793D9EB-2CC1-44A3-BC46-84C21525AA07")

                        FillAttachCombobox("AttachID", "AttachName", ds, objResult)
                        objResult.Append("</oAttachSelect>")
                    Else
                        ds = objTreatmentService.GetCauses("CD6AEA9F-C78F-4942-A749-38C16DE0AA62", CInt(strID))
                        FillCombobox("CauseID", "Cause", ds, objResult)
                        objResult.Append("</oSelect>")
                        objTreatmentService.GetTreatmentTypeByID("7FC19103-F277-4D28-B445-60C4999DB7E5", CInt(strID), strTreatmentTypeID, strTreatmentDesc, strPhotoUnits, strXrayB, strXrayA)
                        ds = objTreatmentService.GetTeethRange("DAD91AA1-DE6F-4C28-8A11-CB0FF79BD302", CInt(strID))
                        FillXML(ds, objXML)
                    End If
                Else
                    objResult.Append("</oSelect>")
                End If
            End If
            objResult.Append("<txtComboType>" & strType & "</txtComboType>")
            objResult.Append("<txtXray_A>" & strXrayA & "</txtXray_A>")
            objResult.Append("<txtXray_B>" & strXrayB & "</txtXray_B>")
            objResult.Append(objXML.ToString())
            objResult.Append("</recordset>")

        Catch ex As Exception
            ' Мне надо побольше информации!
            Utils.AddSystemLog(String.Format("GetTreatments exception: {0}${1}${2}${3}${4}${5}", strID, strType, iConsultation, HttpContext.Current.Application("Smile"), HttpContext.Current.Application("Smile_Platinum_18_Supported"), context.Session("Smile_Platinum_18")), ex.ToString(), 5)
            Throw
        End Try

        HttpContext.Current.Response.Write(objResult.ToString())
    End Sub

    Private Sub FillCombobox1(ByVal strValueField As String, ByVal strDescField As String, ByRef ds As Data.DataSet, ByRef objResult As System.Text.StringBuilder)
        Dim currRow As Data.DataRow
        objResult.Append("<OPTION value='0'>בחר...</OPTION>")
        For Each currRow In ds.Tables(0).Rows
            objResult.Append("<OPTION value='" & currRow(strValueField).ToString() & "'>" & currRow(strDescField).ToString() & "</OPTION>")
        Next
    End Sub

    Private Sub FillCombobox(ByVal strValueField As String, ByVal strDescField As String, ByRef ds As Data.DataSet, ByRef objResult As System.Text.StringBuilder)
        Dim currRow As Data.DataRow
        AddXmlNode("OPTION", "0", "בחר...", objResult)
        For Each currRow In ds.Tables(0).Rows
            AddXmlNode("OPTION", currRow(strValueField).ToString(), currRow(strDescField).ToString(), objResult)
        Next
    End Sub

    Private Sub AddXmlNode(ByVal strNodeName As String, ByVal strValue As String, ByVal strText As String, ByRef objResult As System.Text.StringBuilder)
        objResult.Append("<").Append(strNodeName).Append("><value>").Append(strValue).Append("</value><text>").Append(strText).Append("</text></").Append(strNodeName).Append(">")
    End Sub

    Private Sub FillAttachCombobox(ByVal strValueField As String, ByVal strDescField As String, ByRef ds As Data.DataSet, ByRef objResult As System.Text.StringBuilder)
        Dim currRow As Data.DataRow
        Dim strIsConsultation As String

        AddXmlNode("OPTION", "0", "בחר...", objResult)
        For Each currRow In ds.Tables(0).Rows
            If currRow("ForConsultationUse").ToString() = "1" Then
                strIsConsultation = "1"
            Else
                strIsConsultation = "0"
            End If
            objResult.Append("<OPTION><value>").Append(currRow(strValueField).ToString()).Append("</value><Prefix>").Append(currRow("Prefix").ToString()).Append("</Prefix><ForConsultation>").Append(strIsConsultation).Append("</ForConsultation><text>").Append(currRow(strDescField).ToString()).Append("</text></OPTION>")
        Next
    End Sub

    Private Sub FillComboboxTreatment(ByVal strValueField As String, ByVal strDescField As String, ByRef ds As Data.DataSet, ByRef objResult As System.Text.StringBuilder)
        Dim currRow As Data.DataRow
        Dim strSmileTreatmentID As String = ""
        Dim strServiceBasket As String = ""
        objResult.Append("<OPTION><value>0</value><DefaultRange>0</DefaultRange><DefaultFromTooth>0</DefaultFromTooth><DefaultToTooth>0</DefaultToTooth><SmileCode>0</SmileCode><from></from><BashanCode>0</BashanCode><EarlyConsultation>0</EarlyConsultation><text>בחר...</text></OPTION>")
        For Each currRow In ds.Tables(0).Rows
            strSmileTreatmentID = currRow("SmileTreatmentID").ToString()
            strServiceBasket = currRow("ServiceBasket").ToString()
            If HttpContext.Current.Application("CompanyID") & "" = "3" Then
                objResult.Append("<OPTION><value>").Append(currRow(strValueField).ToString())
                objResult.Append("</value><DefaultRange>").Append(currRow("DefaultTeethRange").ToString())
                objResult.Append("</DefaultRange><DefaultFromTooth>").Append(currRow("DefaultFromTooth").ToString())
                objResult.Append("</DefaultFromTooth><DefaultToTooth>").Append(currRow("DefaultToTooth").ToString())
                objResult.Append("</DefaultToTooth><SmileCode>").Append(strSmileTreatmentID)
                objResult.Append("</SmileCode><ServiceBasket>").Append(strServiceBasket)
                objResult.Append("</ServiceBasket><from>").Append(currRow("RangeID").ToString())
                objResult.Append("</from><BashanCode>").Append(currRow("BashanCode").ToString())
                objResult.Append("</BashanCode><EarlyConsultation>").Append(currRow("EarlyConsultation").ToString())
                objResult.Append("</EarlyConsultation><ExemptionFromDeductibles>").Append(currRow("ExemptionFromDeductibles").ToString())
                objResult.Append("</ExemptionFromDeductibles><text>").Append(currRow(strDescField).ToString())
                objResult.Append("</text><IsFilling>").Append(currRow("IsFilling").ToString()).Append("</IsFilling></OPTION>")
            Else
                objResult.Append("<OPTION><value>").Append(currRow(strValueField).ToString())
                objResult.Append("</value><DefaultRange>").Append(currRow("DefaultTeethRange").ToString())
                objResult.Append("</DefaultRange><DefaultFromTooth>").Append(currRow("DefaultFromTooth").ToString())
                objResult.Append("</DefaultFromTooth><DefaultToTooth>").Append(currRow("DefaultToTooth").ToString())
                objResult.Append("</DefaultToTooth><SmileCode>").Append(strSmileTreatmentID)
                objResult.Append("</SmileCode><ServiceBasket>").Append(strServiceBasket)
                objResult.Append("</ServiceBasket><from>").Append(currRow("RangeID").ToString())
                objResult.Append("</from><BashanCode>").Append(currRow("BashanCode").ToString())
                objResult.Append("</BashanCode><EarlyConsultation>").Append(currRow("EarlyConsultation").ToString())
                objResult.Append("</EarlyConsultation><text>").Append(currRow(strDescField).ToString())
                objResult.Append("</text><IsFilling>").Append(currRow("IsFilling").ToString()).Append("</IsFilling></OPTION>")
            End If
        Next
    End Sub

    Private Sub FillXML(ByRef ds As Data.DataSet, ByRef objResult As System.Text.StringBuilder)
        Dim currRow As Data.DataRow
        objResult.Append("<txtTeethRange>")
        For Each currRow In ds.Tables(0).Rows
            objResult.Append("<range><from>").Append(currRow("FromTooth").ToString()).Append("</from><to>").Append(currRow("ToTooth").ToString()).Append("</to><allow>").Append(currRow("AllowTeethRange").ToString()).Append("</allow></range>")
        Next
        objResult.Append("</txtTeethRange>")
    End Sub

    ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property

End Class