﻿Imports System.Web
Imports System.Web.Services
Imports System.Web.Script.Serialization

Public Class CheckRequestsJournal
    Implements System.Web.IHttpHandler

    <Serializable()> Public Class CheckItem
        Public RequestID As Integer
        Public Reference As String
        Public Status As Integer
        Public FinishDate As String
        Public EntryDate As String
    End Class

    <Serializable()> Public Class CheckResult
        Public Result As Integer = 0
        Public CheckItems As List(Of CheckItem) = New List(Of CheckItem)
    End Class

    Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = context.Application("TreatmentWebService").ToString()

        Dim iInsuredID As Integer = Val(context.Request("InsuredID"))
        Dim strUserName As String = context.User.Identity.Name
        Dim ds As DataSet = objTreatmentService.CheckRequestsJournal("83674676-3FA8-45D1-BAC1-463D2A39F2DD", strUserName, iInsuredID)

        Dim objCheckResult As New CheckResult

        If Not ds Is Nothing Then
            If ds.Tables.Count > 0 Then
                Dim objCheckItem As CheckItem
                Dim dr As DataRow
                For Each dr In ds.Tables(0).Rows
                    objCheckItem = New CheckItem()
                    With objCheckItem
                        .RequestID = Utils.Values.GetDataRowInteger(dr, "RequestID")
                        .Reference = Utils.Values.GetDataRowString(dr, "Reference")
                        .Status = Utils.Values.GetDataRowInteger(dr, "Status")
                        .FinishDate = Utils.Values.GetDataRowString(dr, "FinishDate", "{0:dd/MM/yyyy}")
                        .EntryDate = Utils.Values.GetDataRowString(dr, "EntryDate", "{0:dd/MM/yyyy}")
                    End With
                    objCheckResult.CheckItems.Add(objCheckItem)
                Next
                objCheckResult.Result = 1
            End If
        End If

        Dim serializer As JavaScriptSerializer = New JavaScriptSerializer()
        Dim Response As String = serializer.Serialize(objCheckResult)
        HttpContext.Current.Response.Write(Response)
    End Sub

    ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property
End Class