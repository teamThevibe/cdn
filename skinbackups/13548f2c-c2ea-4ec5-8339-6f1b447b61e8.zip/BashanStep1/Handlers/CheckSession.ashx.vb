﻿Imports System.Web
Imports System.Web.Services

Public Class CheckSession
    Implements System.Web.IHttpHandler, System.Web.SessionState.IRequiresSessionState

    Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest

        '****************************************************
        '********** this code is shared to all web sites ****
        '****************************************************

        context.Response.ContentType = "text/plain"
        Dim LoginURL As String = String.Empty

        If context.Session.IsNewSession Then
            LoginURL = context.Application("FORMLogin")
        End If

        context.Response.Write(LoginURL)
    End Sub

    ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property

End Class