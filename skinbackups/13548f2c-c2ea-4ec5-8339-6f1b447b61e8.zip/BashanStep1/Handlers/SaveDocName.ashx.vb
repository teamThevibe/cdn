﻿Imports System.Web
Imports System.Web.Services
Imports System.Web.Script.Serialization

Public Class SaveDocName
    Implements System.Web.IHttpHandler
    Implements SessionState.IRequiresSessionState

    <Serializable()> Private Class SearchResult
        Public RetCode As Integer

    End Class

    Dim iSaveDocName As Integer

    Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest

        context.Response.ContentType = "text/plain"


        iSaveDocName = CInt(context.Request.Params("sSaveDocNameId").ToString())
        context.Session("sSaveDocNameId") = iSaveDocName.ToString


        Dim Response As String = String.Empty
        Dim SearchResultsForSelectFromList As List(Of SearchResult) = New List(Of SearchResult)

        Dim sResult As SearchResult

        sResult = New SearchResult()
        sResult.RetCode = 1
        '

        Dim serializer As JavaScriptSerializer = New JavaScriptSerializer()

        Response = serializer.Serialize(sResult)

        HttpContext.Current.Response.Write(Response)

    End Sub

    ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property

End Class