﻿Imports System.Web
Imports System.Web.Services
Imports System.Web.Script.Serialization

Public Class GetRequests
    Implements System.Web.IHttpHandler

    <Serializable()> Public Class Attachment
        Public RequestID As Integer
        Public AttachmentNumber As Integer
        Public AttachmentName As String
        Public RecordNumber As Integer
        Public PhotoType As Integer
    End Class


    <Serializable()> Public Class SearchResult
        Public RequestID As Integer = 0
        Public Reference As String = String.Empty
        Public ReferTo As String = String.Empty
        Public RequestType As String = String.Empty
        Public RequestTypeID As String = String.Empty
        Public TreatmentID As String = String.Empty
        Public Treatment As String = String.Empty
        Public CauseID As String = String.Empty
        Public Cause As String = String.Empty
        Public FinishDate As String = String.Empty
        Public Amount As String = String.Empty
        Public Invoice As String = String.Empty
        Public Notes As String = String.Empty
        Public DoctorCareNumber As String = String.Empty
        Public InsuredID As String = String.Empty
        Public InsuredFamily As String = String.Empty
        Public InsuredName As String = String.Empty
        Public XrayExist As Integer = 0
        Public TreatmentGov As String = String.Empty
        Public FromTooth As Integer = 0
        Public ToTooth As Integer = 0
        Public Surface As String = String.Empty
        Public Attachments As List(Of Attachment) = New List(Of Attachment)
    End Class

    Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest

        Dim TreatmentService As New TreatmentConnect.TreatmentService()
        TreatmentService.Url = context.Application("TreatmentWebService").ToString()

        Dim InsuredID As Integer = Val(context.Request("InsuredID"))
        Dim UserName As String = context.User.Identity.Name
        Dim dsRequests As DataSet = TreatmentService.GetRequestBashanInWork("0B89FD35-B814-4914-95E6-113801F086BC", UserName, InsuredID)
        Dim dsAttachments As DataSet = TreatmentService.GetAllAttachments("4918A773-90F8-4F16-AF4A-0A54FC2A5C97", UserName, InsuredID)

        Dim SearchResultsForSelectFromList As List(Of SearchResult) = New List(Of SearchResult)
        Dim Result As SearchResult
        Dim Response As String
        Dim Attachment As Attachment

        If (Utils.Values.GetFirstTableRowsCount(dsRequests) > 0) Then
            For Each drRequest As DataRow In dsRequests.Tables(0).Rows
                Result = New SearchResult()
                Result.RequestID = Utils.Values.GetDataRowInteger(drRequest, "RequestID")
                Result.Reference = Utils.Values.GetDataRowString(drRequest, "Reference")
                Result.ReferTo = Utils.Values.GetDataRowString(drRequest, "ReferTo")
                Result.RequestType = Utils.Values.GetDataRowString(drRequest, "RequestType")
                Result.RequestTypeID = Utils.Values.GetDataRowString(drRequest, "RequestTypeID")
                Result.TreatmentID = Utils.Values.GetDataRowString(drRequest, "TreatmentID")
                Result.Treatment = Utils.Values.GetDataRowString(drRequest, "Treatment")
                Result.CauseID = Utils.Values.GetDataRowString(drRequest, "CauseID")
                Result.Cause = Utils.Values.GetDataRowString(drRequest, "Cause")
                Result.FinishDate = Utils.Values.GetDataRowString(drRequest, "FinishDate", "{0:dd/MM/yyyy}")
                Result.Amount = Utils.Values.GetDataRowString(drRequest, "Amount", "{0:0.##}")
                Result.Invoice = Utils.Values.GetDataRowString(drRequest, "Invoice")
                Result.Notes = Utils.Values.GetDataRowString(drRequest, "Notes")
                Result.DoctorCareNumber = Utils.Values.GetDataRowString(drRequest, "DoctorCareNumber")
                Result.InsuredID = Utils.Values.GetDataRowString(drRequest, "InsuredID")
                Result.InsuredFamily = Utils.Values.GetDataRowString(drRequest, "InsuredFamily")
                Result.InsuredName = Utils.Values.GetDataRowString(drRequest, "InsuredName")
                Result.XrayExist = Utils.Values.GetDataRowInteger(drRequest, "XrayExist")
                Result.TreatmentGov = Utils.Values.GetDataRowString(drRequest, "TreatmentGov")
                Result.FromTooth = Utils.Values.GetDataRowInteger(drRequest, "FromTooth")
                Result.ToTooth = Utils.Values.GetDataRowInteger(drRequest, "ToTooth")
                If Result.ToTooth = 0 Then
                    Result.ToTooth = Result.FromTooth
                End If
                Result.Surface = Utils.Values.GetDataRowString(drRequest, "Surface")
                For Each drAttachment As DataRow In dsAttachments.Tables(0).Rows
                    If (Result.RequestID = Utils.Values.GetDataRowInteger(drAttachment, "RequestID")) Then
                        Attachment = New Attachment()
                        Attachment.AttachmentName = Utils.Values.GetDataRowString(drAttachment, "AttachName")
                        Attachment.PhotoType = Utils.Values.GetDataRowInteger(drAttachment, "PhotoType")
                        Attachment.RecordNumber = Utils.Values.GetDataRowInteger(drAttachment, "RecordNo")
                        Attachment.AttachmentNumber = Utils.Values.GetDataRowInteger(drAttachment, "AttachNo")
                        Result.Attachments.Add(Attachment)
                    End If
                Next
                SearchResultsForSelectFromList.Add(Result)
            Next
        End If

        Dim serializer As JavaScriptSerializer = New JavaScriptSerializer()
        Response = serializer.Serialize(SearchResultsForSelectFromList)
        HttpContext.Current.Response.Write(Response)

    End Sub

    ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property

End Class