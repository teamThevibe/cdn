﻿Imports System.Web
Imports System.Web.Services
Imports System.Web.Script.Serialization

Public Class MultiCheckSend
    Implements System.Web.IHttpHandler
    Implements SessionState.IRequiresSessionState

    <Serializable()> Private Class ActionResult
        Public ResultCode As Integer
        Public RestRows As Integer
    End Class

    Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest
        context.Response.Expires = -1
        context.Response.ContentType = "text/plain"
        Dim strReference As String = Trim("" & context.Session("HOD_MultiCheck_Reference"))
        Dim iRestRows As Integer = -1
        Dim Result As New ActionResult()
        Result.ResultCode = -1
        If Len(strReference) = 10 Then
            Dim objZakautService As New ZakautConnect.ZakautService()
            objZakautService.Url = HttpContext.Current.Application("ZakautConnectorService").ToString()
            Try
                Result.ResultCode = objZakautService.SendMultiCheckRowsToQueue("DD6A07F1-B6D2-44FF-B83F-AD4FEA3B4298", strReference, iRestRows)
            Catch ex As Exception
                Result.ResultCode = -2
            End Try
        End If
        Result.RestRows = iRestRows
        Dim serializer As New JavaScriptSerializer()
        HttpContext.Current.Response.Write(serializer.Serialize(Result))
    End Sub

    ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property

End Class