Imports System.Web.Security
Public Class frmUpdateDoctorList
    Inherits System.Web.UI.Page
    Protected WithEvents grdList As System.Web.UI.WebControls.DataGrid
    Protected WithEvents txtDoctorID As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDoctorName As System.Web.UI.WebControls.TextBox
    Protected WithEvents cmdSave As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdNew As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdCancel As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents txtCurrentID As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtError As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents cmdLogout As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdNext As System.Web.UI.HtmlControls.HtmlInputButton


#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim iType As Integer = Request.QueryString("Type")
        If Not IsPostBack Then
            txtError.Attributes("ConfirmText") = "?��� ����� �� ������"
            If iType = "3" Then
                cmdNext.Disabled = True
            End If
            BindGrid()
        End If
    End Sub

    Private Sub BindGrid()
        Dim dsdoc
        Dim objList As New UserConnect.UserService()
        objList.Url = Application("UserWebService").ToString()
        grdList.DataSource = objList.GetDoctorList("03407803-DE6A-41AA-87DC-60D1D0329753", User.Identity.Name)
        grdList.DataBind()
    End Sub

    Private Sub cmdSave_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.ServerClick
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim strDoctorID As String = Trim(txtDoctorID.Text)
        Dim strDoctorName As String = Trim(txtDoctorName.Text)

        If Not Len(strDoctorID) > 0 Or Not Len(strDoctorName) > 0 Then
            txtError.Value = "�� ������ ���� ����� ��� ���� ���� ������ �����"
            Return
        End If
        If DoctorIDExist(CInt(strDoctorID)) Then
            txtError.Value = "���� ������� ������ ��� ���� ������" & vbNewLine & "�� ������ ���� ������ ������ �� ���� ���"
            txtDoctorID.Text = ""
            Return
        End If
        If Not objUser.AddNewDoctor("1F850A70-6AD6-470C-9AFF-CD9A645684C8", User.Identity.Name, strDoctorID, strDoctorName, User.Identity.Name) Then
            txtError.Value = "���� ������ ������ �����"
        Else
            Dim res = objUser.CheckDoctorID("EB2F60ED-E277-42EA-9310-EDBB15B97445", User.Identity.Name)
            Session("CheckDoctorResult") = res
            If res = 0 Or res = 4 Or res = 5 Then
                cmdNext.Disabled = False
            End If
        End If
        txtDoctorID.Text = ""
        txtDoctorName.Text = ""
        BindGrid()


    End Sub

    Private Function DoctorIDExist(ByVal iDoctorID As Integer, Optional ByVal iRowID As Long = -1) As Boolean
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Return objUser.DoctorIDExist("B4B3D83D-7B35-4FA5-8EC6-34EF15A8C3F3", User.Identity.Name, iDoctorID, iRowID)
    End Function

    Private Sub grdList_EditCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdList.EditCommand
        grdList.EditItemIndex = e.Item.ItemIndex
        BindGrid()
    End Sub

    Private Sub grdList_CancelCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdList.CancelCommand
        grdList.EditItemIndex = -1
        BindGrid()
    End Sub

    Private Sub grdList_UpdateCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdList.UpdateCommand
        Dim CurrentTextBox As TextBox
        CurrentTextBox = CType(e.Item.FindControl("txtDocName"), TextBox)

        Dim strDoctorName As String = Trim(CurrentTextBox.Text)

        CurrentTextBox = e.Item.Cells(1).Controls(0)
        Dim sDoctorID As String = Trim(CurrentTextBox.Text)

        If Len(sDoctorID) > 5 Or Len(sDoctorID) = 0 Then
            txtError.Value = "�� ������ ���� ����� ����"
            Return
        End If
        Dim iDoctorID As Integer = CInt(sDoctorID)
        If iDoctorID = 0 Then
            txtError.Value = "�� ������ ���� ����� ����"
            Return
        End If

        If Not Len(strDoctorName) > 0 Then
            txtError.Value = "���� ������ �� ���� "
            Return
        End If

        Dim iRowID As Integer = grdList.DataKeys(CInt(e.Item.ItemIndex))

        If DoctorIDExist(CInt(sDoctorID), iRowID) Then
            txtError.Value = "���� ������� ������ ��� ���� ������" & vbNewLine & "�� ������ ���� ������ ������ �� ���� ���"
            Return
        End If

        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

        If objUser.UpdateDoctorByID("18A0A647-F4A0-4CB5-A74A-4DEE0B899093", iRowID, iDoctorID, strDoctorName, User.Identity.Name) Then
            grdList.EditItemIndex = -1
            BindGrid()
            Dim res = objUser.CheckDoctorID("EB2F60ED-E277-42EA-9310-EDBB15B97445", User.Identity.Name)
            Session("CheckDoctorResult") = res
            If res = 0 Or res = 4 Or res = 5 Then
                cmdNext.Disabled = False
            End If
        End If
    End Sub

    Private Sub grdList_DeleteCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdList.DeleteCommand
        If Not IsDBNull(grdList.DataKeys(CInt(e.Item.ItemIndex))) Then
            Dim iRowID As Integer = grdList.DataKeys(CInt(e.Item.ItemIndex))
            If grdList.DataKeys.Count > 1 Or grdList.PageCount > 1 Then
                Dim objUser As New UserConnect.UserService()
                objUser.Url = Application("UserWebService").ToString()

                If objUser.DeleteDoctorByID("50824D86-4116-4883-AEEC-A850147021E0", iRowID, User.Identity.Name) Then
                    grdList.EditItemIndex = -1
                    BindGrid()
                End If
            Else
                txtError.Value = "��� ������ ����� ���� �����"
            End If
        Else
            txtError.Value = "����� �� �����"
        End If
    End Sub

    Private Sub grdList_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles grdList.PageIndexChanged
        grdList.CurrentPageIndex = e.NewPageIndex
        BindGrid()
    End Sub

    Private Sub cmdLogout_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdLogout.ServerClick
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        objUser.UpdateLastLogout("DD947C22-CFCA-4BD4-A2CD-B9C916B39B28", Session.SessionID, Val(Application("SiteType")))

        FormsAuthentication.SignOut()
        Response.Redirect("Login.aspx")
    End Sub

    Private Sub cmdNext_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdNext.ServerClick

        Dim fResult As Boolean
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

        Dim res = objUser.CheckDoctorID("EB2F60ED-E277-42EA-9310-EDBB15B97445", User.Identity.Name)
        If res = 3 Or res = 5 Then
            'txtError.Value = "�� �� ��������, ���� ������� ������ ����� ������ �� ����� ����� �� ����� ��� ������" & vbNewLine & "�� ��� �� ��, �� ����� ���� ���"
            txtError.Value = "�� �� ��������, ���� ������� ������ ����� ������ �� ����� �� ������ �� �� ������� ������" & vbNewLine & "�� ��� �� ��, �� ����� ���� ���"
            Exit Sub
        End If

        fResult = objUser.UpdateDoctorCheckDate("461FD5B6-9A6D-42CD-90A3-AB7753107E01", User.Identity.Name)
        Dim bIndependent As Boolean
        Dim bAllowClaims As Boolean
        Dim bWebInterfaceAllow As Boolean
        Dim bWebServiceAllow As Boolean
        objUser.GetBashanUserPermitions("83EC08DB-E750-45BA-8F6D-B4B6BF76D018", User.Identity.Name, bIndependent, bAllowClaims, bWebInterfaceAllow, bWebServiceAllow)
        If bIndependent Then
            Session("BSHN_Independed") = "1"
        Else
            Session("BSHN_Independed") = ""
        End If
        If Session("User_Login_First_Time") = "1" Then
            Response.Redirect("frmUserProp.aspx")
        Else
            Response.Redirect(Application("FORMStart"))
        End If

    End Sub

    Protected Function EncodeField(ByRef objCode As Object) As String
        Dim strReturn As String = ""
        If Not IsDBNull(objCode) Then
            strReturn = CEncode.StringEncode(objCode.ToString())
        End If
        Return strReturn
    End Function

End Class
