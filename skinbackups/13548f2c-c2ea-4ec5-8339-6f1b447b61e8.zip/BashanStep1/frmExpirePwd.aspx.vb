Public Class frmExpirePwd
    Inherits System.Web.UI.Page

    Protected WithEvents tdRightPic As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents imgRightPic As System.Web.UI.HtmlControls.HtmlImage
    Protected WithEvents divRIcon As System.Web.UI.HtmlControls.HtmlGenericControl

    Protected WithEvents tdAlertMsg As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents tdTitle As System.Web.UI.HtmlControls.HtmlTableCell

    Protected WithEvents cmdChangePassword As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents aIconLink As System.Web.UI.HtmlControls.HtmlAnchor
    Protected WithEvents aIconLink2 As System.Web.UI.HtmlControls.HtmlAnchor
    Protected WithEvents cmdContinue As System.Web.UI.HtmlControls.HtmlInputButton

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Session("User_Login_First_Time") = "1" Then
            Response.Redirect("frmUserProp.aspx")
        End If

        If Not IsPostBack Then


            If Application("RightLogo") = "1" Then
#If NewDesign Then
                tdRightPic.Attributes("background") = "pics/BannerTopRightTransp.gif"
                imgRightPic.Attributes("src") = "pics/BannerTopRightTransp.gif"
#End If
                divRIcon.Visible = True
            Else
#If NewDesign Then
                tdRightPic.Attributes("background") = "pics/BannerTopRightPic.gif"
                imgRightPic.Attributes("src") = "pics/BannerTopRightPic.gif"
#End If
                divRIcon.Visible = False
            End If


            Dim iExpiraionLevel As Integer = Val(Session("ExpirationLevel") & "")
            Dim iExpirationRestDays As Integer = Val(Session("ExpirationRestDays") & "")
            Dim iExpirationRestTimes As Integer = Session("ExpirationRestTimes")
            Select Case iExpiraionLevel
                Case 1
                    tdTitle.InnerText = "���� ������ ���� ����"
                    cmdContinue.Visible = True

                    If iExpirationRestDays = 1 Then
                        tdAlertMsg.InnerText = " ���� ��� ��� " & " �� ���� ���� ������"
                    Else
                        tdAlertMsg.InnerText = "����� " & iExpirationRestDays & " ���� " & " �� ���� ���� ������"
                    End If
                Case 2
                    Dim msg As String = "��� ������ �� ������ �� ����� �� �����  " & "<i>����� �����</i>"
                    tdTitle.InnerText = "���� ������ ��"
                    cmdContinue.Visible = True

                    If iExpirationRestTimes = 1 Then
                        tdAlertMsg.InnerHtml = " ����� ����� ��� " & "<br>" & msg
                    ElseIf iExpirationRestTimes = 0 Then
                        tdAlertMsg.InnerHtml = "������� ���� ������ ������ �����" & "<br>" & msg
                    Else
                        tdAlertMsg.InnerHtml = " ����� " & iExpirationRestTimes & " ������ " & "<br>" & msg
                    End If
                    '� &acute;
                Case 3
                    tdTitle.InnerText = "���� ������ ��"
                    cmdContinue.Visible = False

                    tdAlertMsg.InnerHtml = "�� ����� �� ������ ��� ����� ������"
            End Select

        End If
    End Sub

    Private Sub cmdContinue_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdContinue.ServerClick
        Dim sUrl As String = Session("Expiration_NextPage") & ""
        If sUrl <> "" Then
            Session("User_Login_First_Time") = ""
            Response.Redirect(sUrl)
        End If
    End Sub

    Private Sub cmdChangePassword_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdChangePassword.ServerClick
        Session("User_Login_First_Time") = "1"
        Response.Redirect("frmUserProp.aspx")
    End Sub
End Class
