﻿Imports System.IO
Imports System.Text
Imports System.Text.RegularExpressions

Partial Public Class frmTRequestbExt
    Inherits System.Web.UI.Page

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If IsPostBack Then
            Dim iRetValue As Integer = 0
            Dim iPolicy As Integer = 0
            Dim strTreatmentsValue = Trim(hidValue.Value)
            Dim sMilkTeeth As String = Trim(hidMilkToothList.Value)
            Dim strTreatmentsCheckedMilkTeethValue As String = ""
            Dim bMixedMilkTeeth As Boolean = CheckMixedMilkTeeth(strTreatmentsValue, sMilkTeeth, strTreatmentsCheckedMilkTeethValue)

            If (bMixedMilkTeeth) Then
                hidAnswer.Value = "לא ניתן להגדיר טווח עם שיני חלב ושיניים קבועות"
                hidReturnValue.Value = "0"
                Return
            Else
                strTreatmentsValue = strTreatmentsCheckedMilkTeethValue
            End If

            strTreatmentsValue = AddTreatmentSeries(strTreatmentsValue)
            Dim arrTreatmentsRows() As String
            Dim strInsuredID As String = hidInsuredNo.Value
            Dim bAllowSendFiles As Boolean = True
            If strTreatmentsValue <> "" Then
                arrTreatmentsRows = Split(strTreatmentsValue, ";")
                If arrTreatmentsRows.Length > 0 Then
                    If Len(arrTreatmentsRows(0)) > 0 Then
                        iRetValue = 1
                    End If
                End If
            End If
            If iRetValue = 0 Then
                hidAnswer.Value = "לא ניתן להעביר דיווח ריק"
                hidReturnValue.Value = "0"
                Return
            End If
            Dim iMaxSize As Integer
            If IsNumeric(Session("UploadFileSize").ToString()) Then
                iMaxSize = CInt(Session("UploadFileSize").ToString())
                If iMaxSize = 0 Then
                    bAllowSendFiles = False
                    'hidReturnValue.Value = "-1"
                    'Return
                End If
            Else
                bAllowSendFiles = False
                'hidReturnValue.Value = "-1"
                'Return
            End If
            iRetValue = CheckAllFiles(iMaxSize)
            If iRetValue = 2 Then
                If bAllowSendFiles Then
                    hidAnswer.Value = "ניתן לצרף קבצים עד גודל " & CStr(iMaxSize / 1024) & "K!" & "  יש לשייך הנספחים מחדש  "
                Else
                    hidAnswer.Value = "אינך מורשה לצרף קבצים. נא פנה למנהל המערכת."
                End If
                iRetValue = 0
            ElseIf iRetValue = 1 Then
                hidAnswer.Value = "קובץ לא קיים"
                iRetValue = 0
                'ElseIf iRetValue = 3 Then
                '    hidAnswer.Value = "פורמט הנספח אינו חוקי"
                '    iRetValue = 0
            ElseIf iRetValue = 3 Then
                hidAnswer.Value = "קובץ לא חוקי"
                iRetValue = 0
            Else
                Dim objTreatmentService As New TreatmentConnect.TreatmentService()
                objTreatmentService.Url = Application("TreatmentWebService").ToString()
                Dim strFirstName As String = ""
                Dim strLastName As String = ""
                Dim str2Chars As String
                Dim str2FNChars As String
                Dim strPolicyNo As String = ""
                Dim strEmployeeNo As String = ""
                Dim strEmpCD As String = ""
                If Application("Smile") = "1" Then
                    If Session("Smile_Porshei_Personel") = "1" Then
                        objTreatmentService.GetInsuredProp("5E25C46A-EADC-4C27-8A5A-DB8B13E129D3", hidInsuredNo.Value, strFirstName, strLastName, strPolicyNo, strEmployeeNo, strEmpCD)
                        If strPolicyNo = "1015" Then
                            If strFirstName = "" Then
                                strFirstName = "א"
                            End If
                            strInsuredID = hidInsuredNo.Value
                            iPolicy = 1015
                        Else
                            strFirstName = ""
                            strLastName = ""
                        End If
                    Else
                        Dim objRequest As New SmileConnector.SmileConnector
                        objRequest.Url = Application("SmileWebService")
                        Dim ds As DataSet
                        If Session("Smile_ShilaWorker") = "1" Then
                            ds = objRequest.GetShilaEmployeeProp("60DED06E-37E5-45DE-9857-F61842C9CBC4", Val(hidInsuredNo.Value))
                            strPolicyNo = Session("Smile_Policy")
                            iPolicy = Val(strPolicyNo)
                        Else
                            ds = objRequest.GetLastAnswer("FF971BAA-4E34-4DCE-ABEF-27191AAF2C79", User.Identity.Name, Session("User_Password"), Val(hidInsuredNo.Value))
                        End If
                        If Not ds Is Nothing Then
                            If ds.Tables(0).Rows.Count > 0 Then
                                Dim objRow As DataRow = ds.Tables(0).Rows(0)
                                strFirstName = Trim(objRow("InsuredFName").ToString())
                                strLastName = Trim(objRow("InsuredLName").ToString())
                                If strFirstName = "" Then
                                    strFirstName = "א"
                                End If
                            End If
                        End If
                    End If
                Else
                    If Application("CompanyID").ToString = "3" Then
                        strFirstName = Session("TRequest_InsuredName")
                        strLastName = Session("TRequest_InsuredFamily")
                        strInsuredID = Session("Leumit_CrntInsuredID")
                    Else
                        objTreatmentService.GetInsuredProp("5E25C46A-EADC-4C27-8A5A-DB8B13E129D3", hidInsuredNo.Value, strFirstName, strLastName, strPolicyNo, strEmployeeNo, strEmpCD)
                        If UCase(Trim(strLastName)) = "ERROR" Then
                            objTreatmentService.GetSQLInsuredProp("6C865031-52E9-4422-950B-615B8F84600C", hidInsuredNo.Value, strFirstName, strLastName)
                        End If
                        strInsuredID = hidInsuredNo.Value
                    End If
                End If
				If Val(strInsuredID) < 1 Then
                    hidAnswer.Value = "תקלה בקליטת פרטי פניה"
                    iRetValue = 0
				Else
					str2Chars = Left(strLastName, 2)
					str2FNChars = Left(strFirstName, 2)
					iRetValue = 1
					If str2Chars = "" Or str2FNChars = "" Then
						hidAnswer.Value = "בחברת הביטוח לא נמצא מבוטח פעיל המתאים לפרטים שהוזנו"
						iRetValue = 0
					Else
						If Regex.IsMatch(Mid(str2Chars, 2, 1), "[א-תa-zA-Z]") Then
							If str2Chars <> Left(hidInsuredFamily.Value, 2) Then
								hidAnswer.Value = "בחברת הביטוח לא נמצא מבוטח פעיל המתאים לפרטים שהוזנו"
								iRetValue = 0
							End If
						Else
							If Left(str2Chars, 1) <> Left(hidInsuredFamily.Value, 1) Then
								hidAnswer.Value = "בחברת הביטוח לא נמצא מבוטח פעיל המתאים לפרטים שהוזנו"
								iRetValue = 0
							End If
						End If
						If Regex.IsMatch(Mid(str2FNChars, 2, 1), "[א-תa-zA-Z]") Then
							If str2FNChars <> Left(hidInsuredName.Value, 2) Then
								hidAnswer.Value = "בחברת הביטוח לא נמצא מבוטח פעיל המתאים לפרטים שהוזנו"
								iRetValue = 0
							End If
						Else
							If Left(str2FNChars, 1) <> Left(hidInsuredName.Value, 1) Then
								hidAnswer.Value = "בחברת הביטוח לא נמצא מבוטח פעיל המתאים לפרטים שהוזנו"
								iRetValue = 0
							End If
						End If
					End If
					Dim objUser As New UserConnect.UserService()
					objUser.Url = Application("UserWebService").ToString()
                    Dim iDoctorType As Integer = objUser.GetUserDoctorType("C049B33B-243D-43C1-B2F5-AB4859F9EBD1", User.Identity.Name)
                    '''''''''''''''Dim iDoctorType As Integer = objUser.GetHDUserDoctorType("0B776BB2-51E1-11E4-8E10-7F911D5D46B0", User.Identity.Name)


					If iDoctorType <> 3 Then
						If hidDoctorCareNumber.Value = "" Or hidDoctorCareNumber.Value = "0" Then
							hidAnswer.Value = "חובה לבחור רופא מטפל עם מספר רשיון במשרד הבריאות"
							iRetValue = 0
						End If
					End If
				End If
                If iRetValue > 0 Then
                    Dim bNote As Boolean = False
                    Dim strNote As String = Trim(hidNote.Value)
                    If strNote <> "" Then
                        bNote = True
                    End If
                    Dim strAttach As String = CStr(GetAttachValue(bNote, 1))
                    Dim strXRayExist As String = CStr(CheckXrayExist())
                    Dim iXRayAttach As Integer
                    If CheckXrayAttach() Then
                        iXRayAttach = 1
                    Else
                        iXRayAttach = 0
                    End If
                    Dim iRequestID As Integer
                    Dim strReferenceID As String, strFirstReference = "", strConnectReference As String = ""
                    Dim iExtError As Integer = 0, iLastAttachNo As Integer = 0
                    Dim strTreatmentRow As String, arrOneRow() As String, strTreatmentValue As String, strCauseValue As String, strFromTooth As String, strToTooth As String
                    Dim iIsSeriesTreatment As Integer
                    Dim i As Integer, iArrIndex1 As Integer, iArrIndex2 As Integer, iFromTooth As Integer, iToTooth As Integer, iTreatmentValue As Integer, iCauseValue As Integer, strTestValue As String
                    Dim arrToothCheck(64) As ArrayList
                    For i = 0 To 63
                        arrToothCheck(i) = New ArrayList()
                    Next
                    Dim dsTreatmentTypes As DataSet = objTreatmentService.GetTreatmentTypesForConsultation("D7BA44CC-36D7-4755-BE56-D217C1089527")
                    Dim dsCauseList As DataSet = objTreatmentService.GetCauseListForConsultation("788DDC06-CA83-49A1-B132-40A8FAC1C905")
                    Dim dsToothRange As DataSet = objTreatmentService.GetToothRangeForConsultationExt("C25E100D-EEA0-4109-AF74-5B008D0D5775")
                    'Dim arrIndexTranslate As Integer() = {7, 6, 5, 4, 3, 2, 1, 0, 8, 9, 10, 11, 12, 13, 14, 15, 23, 22, 21, 20, 19, 18, 17, 16, 24, 25, 26, 27, 28, 29, 30, 31}
                    Dim arrIndexTranslate As Integer() = {7, 6, 5, 4, 3, 2, 1, 0, 8, 9, 10, 11, 12, 13, 14, 15, 23, 22, 21, 20, 19, 18, 17, 16, 24, 25, 26, 27, 28, 29, 30, 31, 39, 38, 37, 36, 35, 34, 33, 32, 40, 41, 42, 43, 44, 45, 46, 47, 55, 54, 53, 52, 51, 50, 49, 48, 56, 57, 58, 59, 60, 61, 62, 63}
                    For Each strTreatmentRow In arrTreatmentsRows
                        arrOneRow = Split(strTreatmentRow, ".")
                        If arrOneRow.Length >= 4 Then
                            strTreatmentValue = arrOneRow(0)
                            strCauseValue = arrOneRow(1)
                            strFromTooth = arrOneRow(2)
                            strToTooth = arrOneRow(3)
                            Try
                                iIsSeriesTreatment = CInt(arrOneRow(4))
                            Catch ex As Exception
                                iIsSeriesTreatment = 0
                            End Try
                            If IsNumeric(strTreatmentValue) Then
                                iTreatmentValue = CInt(strTreatmentValue)
                            Else
                                iTreatmentValue = 0
                            End If
                            If IsNumeric(strCauseValue) Then
                                iCauseValue = CInt(strCauseValue)
                            Else
                                iCauseValue = 0
                            End If
                            If IsNumeric(strFromTooth) Then
                                iFromTooth = CInt(strFromTooth)
                            Else
                                iFromTooth = 0
                            End If
                            If IsNumeric(strToTooth) Then
                                iToTooth = CInt(strToTooth)
                            Else
                                iToTooth = iFromTooth
                            End If
                            If iTreatmentValue > 0 And iFromTooth > 0 Then
                                Select Case CheckTreatment(CStr(iTreatmentValue), Not (iToTooth = iFromTooth), dsTreatmentTypes)
                                    Case 0
                                        hidAnswer.Value = "ערך בשדה טיפול לא תקין"
                                        hidReturnValue.Value = "0"
                                        Return
                                    Case -1
                                        hidAnswer.Value = "לא ניתן לדווח טווח שיניים לטיפול זה"
                                        hidReturnValue.Value = "0"
                                        Return
                                End Select
                                'Select Case CheckCause(CStr(iTreatmentValue), CStr(iCauseValue), dsCauseList)
                                '    Case -1
                                '        hidAnswer.Value = "לא ניתן לדווח סיבה לטיפול זה"
                                '        hidReturnValue.Value = "0"
                                '        Return
                                '    Case -2
                                '        hidAnswer.Value = "חסר ערך בשדה סיבה"
                                '        hidReturnValue.Value = "0"
                                '        Return
                                '    Case -3
                                '        hidAnswer.Value = "ערך בשדה סיבה לא תקין"
                                '        hidReturnValue.Value = "0"
                                '        Return
                                'End Select


                                'Select Case CheckTooth(CStr(iTreatmentValue), CStr(iFromTooth), CStr(iToTooth), dsToothRange)
                                '    Case 0
                                '        hidAnswer.Value = "ערך בשדה טיפול לא תקין"
                                '        hidReturnValue.Value = "0"
                                '        Return
                                '    Case -1
                                '        hidAnswer.Value = "ערך בשדה 'משן' לא חוקי"
                                '        hidReturnValue.Value = "0"
                                '        Return
                                '    Case -2
                                '        hidAnswer.Value = "ערך בשדה 'עד שן' לא חוקי"
                                '        hidReturnValue.Value = "0"
                                '        Return
                                '    Case -3
                                '        hidAnswer.Value = "ערכים בשדות 'משן' ו- 'עד שן' לא חוקים"
                                '        hidReturnValue.Value = "0"
                                '        Return
                                'End Select

                                Dim iToothOK As Integer = CheckTooth(CStr(iTreatmentValue), iFromTooth, iToTooth, sMilkTeeth, dsToothRange)
                                If (iToothOK > 0) Then
                                    hidAnswer.Value = "לא ניתן לשייך את טיפול"
                                    hidReturnValue.Value = "0"
                                    Return
                                End If


                                If iFromTooth = 88 Or iFromTooth = 0 Then
                                    iArrIndex1 = 0
                                    iArrIndex2 = 63
                                Else
                                    iArrIndex1 = arrIndexTranslate(Convert.ToInt16(CStr(iFromTooth - 11), 8))
                                    iArrIndex2 = arrIndexTranslate(Convert.ToInt16(CStr(iToTooth - 11), 8))
                                    i = iArrIndex1
                                    iArrIndex1 = Math.Min(iArrIndex1, iArrIndex2)
                                    iArrIndex2 = Math.Max(i, iArrIndex2)
                                End If
                                For i = iArrIndex1 To iArrIndex2
                                    If arrToothCheck(i).Contains(iTreatmentValue) Then
                                        hidAnswer.Value = "לא ניתן לדווח על טיפול יותר מפעם אחת לשן"
                                        hidReturnValue.Value = "0"
                                        Return
                                    End If

                                    'If iIsSeriesTreatment = 1 Then
                                    arrToothCheck(i).Add(iTreatmentValue)
                                    'End If
                                Next
                                If Session("Leumit_CollectionProblem") = "1" Then
                                    Dim iResult As Integer
                                    iResult = CheckTreatmentForServiceBasket(iTreatmentValue)
                                    If iResult = 0 Then
                                        hidAnswer.Value = "אין אפשרות להעניק טיפול שאינו בסל הטיפולים.<BR>נא לפנות לקופת חולים לאומית על מנת להסדיר חוב כספי לקופה."
                                        hidReturnValue.Value = "0"
                                    End If
                                End If
                            Else
                                hidAnswer.Value = "ערכים לא נכונים"
                                hidReturnValue.Value = "0"
                                Return
                            End If
                        End If
                    Next
                    ' ''For i = 0 To 63
                    ' ''    If arrToothCheck(i).Count > 5 Then
                    ' ''        hidAnswer.Value = "לא ניתן לדווח על יותר מחמישה טיפולים לשן"
                    ' ''        hidReturnValue.Value = "0"
                    ' ''        Return
                    ' ''    End If
                    ' ''Next
                    Dim objReport As New ReportConnect.ReportService()
                    objReport.Url = Application("ReportWebService").ToString()
                    For Each strTreatmentRow In arrTreatmentsRows
                        If iRetValue = 0 Then
                            Exit For
                        End If
                        arrOneRow = Split(strTreatmentRow, ".")
                        If arrOneRow.Length >= 4 Then
                            strTreatmentValue = arrOneRow(0)
                            strCauseValue = arrOneRow(1)
                            strFromTooth = arrOneRow(2)
                            strToTooth = arrOneRow(3)
                            iIsSeriesTreatment = Val(arrOneRow(4))
                            If IsNumeric(strTreatmentValue) Then
                                iTreatmentValue = CInt(strTreatmentValue)
                            Else
                                iTreatmentValue = 0
                            End If
                            If IsNumeric(strCauseValue) Then
                                iCauseValue = CInt(strCauseValue)
                            Else
                                iCauseValue = 0
                            End If
                            If IsNumeric(strFromTooth) Then
                                iFromTooth = CInt(strFromTooth)
                            Else
                                iFromTooth = 0
                            End If
                            If IsNumeric(strToTooth) Then
                                iToTooth = CInt(strToTooth)
                            Else
                                iToTooth = iFromTooth
                            End If




                            Dim surface As String = String.Empty
                            If arrOneRow.Length > 4 Then
                                surface = arrOneRow(4)
                            End If

                            iRequestID = objTreatmentService.PutRequestTSurface("7660A5AD-F018-44AA-AF60-3CC29549E946", _
                                            User.Identity.Name, _
                                            hidClinicNumber.Value, _
                                            hidDoctorCareNumber.Value, _
                                            Val(strInsuredID), _
                                            iPolicy, _
                                            "", _
                                            "0", _
                                            hidInsuredFamily.Value, _
                                            hidInsuredName.Value, _
                                            CStr(iFromTooth), _
                                            CStr(iToTooth), _
                                            iTreatmentValue, _
                                            surface, _
                                            CStr(iCauseValue), _
                                            "5", _
                                            "ש", _
                                            strAttach, _
                                            strXRayExist, _
                                            "", _
                                            iXRayAttach, _
                                            7, _
                                            strConnectReference, _
                                            strReferenceID, _
                                            strConnectReference)


                            'iRequestID = objTreatmentService.HDPutRequest("B9100DFF-D0D7-4BED-BC67-A0646916D149", _
                            '        User.Identity.Name, _
                            '        hidClinicNumber.Value, _
                            '        hidDoctorCareNumber.Value, _
                            '        strInsuredID, _
                            '        iPolicy, _
                            '        "", _
                            '        "0", _
                            '        hidInsuredFamily.Value, _
                            '        hidInsuredName.Value, _
                            '        CStr(iFromTooth), _
                            '        CStr(iToTooth), _
                            '        iTreatmentValue, _
                            '        surface, _
                            '        CStr(iCauseValue), _
                            '        "5", _
                            '        "ש", _
                            '        strAttach, _
                            '        strXRayExist, _
                            '        "", _
                            '        iXRayAttach, _
                            '        7, _
                            '        strConnectReference, _
                            '        strReferenceID, _
                            '        strConnectReference, _
                            '        Val(hidGovTreatments.Value), _
                            '        "")



















                            If (strReferenceID <> "") And (iRequestID > 0) Then
                                If iIsSeriesTreatment = 1 Then
                                    objTreatmentService.SetIsSeriesTreatment("501E9D27-43EF-4F5A-97DB-49FF0D0DE51E", iRequestID)
                                End If

                                If objTreatmentService.ArchiveRequest("170BA2F5-EC88-4190-A495-E97E3CB68F13", User.Identity.Name, iRequestID, CInt(strInsuredID), 0, strReferenceID, CInt(strFromTooth), strReferenceID, CInt(strXRayExist), "00000000") Then
                                    iRetValue = 1
                                    If iXRayAttach > 0 Then
                                        iRetValue = ProcessRow(strReferenceID, strFirstReference, iLastAttachNo, Request.Form.Item("lstAttachmentType1"), objTreatmentService, fileToUpload1, txtExistAttNo1, txtExistRecNo1, iExtError, iLastAttachNo)
                                        If iRetValue > 0 Then
                                            iRetValue = ProcessRow(strReferenceID, strFirstReference, iLastAttachNo, Request.Form.Item("lstAttachmentType2"), objTreatmentService, fileToUpload2, txtExistAttNo2, txtExistRecNo2, iExtError, iLastAttachNo)
                                        End If
                                        If iRetValue > 0 Then
                                            iRetValue = ProcessRow(strReferenceID, strFirstReference, iLastAttachNo, Request.Form.Item("lstAttachmentType3"), objTreatmentService, fileToUpload3, txtExistAttNo3, txtExistRecNo3, iExtError, iLastAttachNo)
                                        End If
                                        If iRetValue > 0 Then
                                            iRetValue = ProcessRow(strReferenceID, strFirstReference, iLastAttachNo, Request.Form.Item("lstAttachmentType4"), objTreatmentService, fileToUpload4, txtExistAttNo4, txtExistRecNo4, iExtError, iLastAttachNo)
                                        End If
                                        If iRetValue > 0 Then
                                            iRetValue = ProcessRow(strReferenceID, strFirstReference, iLastAttachNo, Request.Form.Item("lstAttachmentType5"), objTreatmentService, fileToUpload5, txtExistAttNo5, txtExistRecNo5, iExtError, iLastAttachNo)
                                        End If
                                        If iRetValue > 0 Then
                                            iRetValue = ProcessRow(strReferenceID, strFirstReference, iLastAttachNo, Request.Form.Item("lstAttachmentType6"), objTreatmentService, fileToUpload6, txtExistAttNo6, txtExistRecNo6, iExtError, iLastAttachNo)
                                        End If
                                        If iRetValue > 0 Then
                                            iRetValue = ProcessRow(strReferenceID, strFirstReference, iLastAttachNo, Request.Form.Item("lstAttachmentType7"), objTreatmentService, fileToUpload7, txtExistAttNo7, txtExistRecNo7, iExtError, iLastAttachNo)
                                        End If
                                        If iRetValue > 0 Then
                                            iRetValue = ProcessRow(strReferenceID, strFirstReference, iLastAttachNo, Request.Form.Item("lstAttachmentType8"), objTreatmentService, fileToUpload8, txtExistAttNo8, txtExistRecNo8, iExtError, iLastAttachNo)
                                        End If
                                        If iRetValue > 0 Then
                                            iRetValue = ProcessRow(strReferenceID, strFirstReference, iLastAttachNo, Request.Form.Item("lstAttachmentType9"), objTreatmentService, fileToUpload9, txtExistAttNo9, txtExistRecNo9, iExtError, iLastAttachNo)
                                        End If
                                        If iRetValue > 0 Then
                                            iRetValue = ProcessRow(strReferenceID, strFirstReference, iLastAttachNo, Request.Form.Item("lstAttachmentType10"), objTreatmentService, fileToUpload10, txtExistAttNo10, txtExistRecNo10, iExtError, iLastAttachNo)
                                        End If
                                        If strFirstReference = "" Then
                                            strFirstReference = strReferenceID
                                        End If
                                    Else
                                        strFirstReference = strReferenceID
                                    End If
                                Else
                                    iRetValue = 0
                                End If
                                If iRetValue > 0 Then
                                    'objTreatmentService.SetRequestComplited("1A529E7C-262A-4A6F-94D6-AA8C5AACBF8E", iRequestID)
                                Else
                                    If iExtError > 0 Then
                                        hidAnswer.Value = "פורמט הנספח אינו חוקי"
                                    Else
                                        hidAnswer.Value = "תקלה בעת העברת נתוני הפניה, אנא פנה למנהל המערכת"
                                    End If
                                End If
                            Else
                                hidAnswer.Value = "תקלה בעת העברת נתוני הפניה, אנא פנה למנהל המערכת"
                                iRetValue = 0
                            End If
                        End If
                    Next
                    If iRetValue > 0 Then
                        If strNote <> "" Then
                            If Not objReport.AddConnectNote("F06493AA-9F7C-4A6E-B6A0-15002F4379F0", strConnectReference, strFirstReference, strNote) Then
                                hidAnswer.Value = "תקלה בעת העברת נתוני הפניה, אנא פנה למנהל המערכת"
                                iRetValue = 0
                            End If
                        End If
                        If iRetValue > 0 Then
                            Dim strAnswer As String = "מספר אסמכתא: <SPAN dir='ltr'><B>" & strConnectReference & "</B></SPAN>"
                            If Not objReport.AddConnectRefReport("CE588BA3-4165-4C20-8387-60A6103C14BD", User.Identity.Name, strConnectReference, strFirstReference, strNote, "") Then
                                strAnswer = strAnswer & "<BR>עקב תקלה במערכת דוח הגשת פניה ייוצר מאוחר יותר"
                            End If
                            objTreatmentService.SetAllRequestsComplitedByConnectRef("C5514E80-299B-4197-A0AE-050262788861", strConnectReference)
                            hidAnswer.Value = strAnswer
                        End If
                    End If
                End If
            End If
            hidReturnValue.Value = iRetValue
        Else
            FillAttachmentsType(lstAttachmentType1)
            FillAttachmentsType(lstAttachmentType2)
            FillAttachmentsType(lstAttachmentType3)
            FillAttachmentsType(lstAttachmentType4)
            FillAttachmentsType(lstAttachmentType5)
            FillAttachmentsType(lstAttachmentType6)
            FillAttachmentsType(lstAttachmentType7)
            FillAttachmentsType(lstAttachmentType8)
            FillAttachmentsType(lstAttachmentType9)
            FillAttachmentsType(lstAttachmentType10)
        End If
    End Sub

    Private Function AddTreatmentSeries(ByVal strTreatmentsValue As String) As String
        Dim arrTreatmentsRows() As String
        Dim arrOneRow() As String
        Dim strTreatmentRow As String
        Dim strTreatmentValue As String
        Dim strResult As New StringBuilder
        Dim bFirstRow As Boolean = True
        Dim bFirstSeries As Boolean = True
        Dim objRows As DataRow
        Dim foundRows As DataRow()
        Dim strTreatmentNew As String

        arrTreatmentsRows = Split(strTreatmentsValue, ";")
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()

        Dim dsTreatmentsSeries As DataSet = objTreatmentService.GetTreatmentsSeries("E4B3D801-144A-4736-B44B-9A6A396B777C")

        If dsTreatmentsSeries.Tables.Count > 0 AndAlso dsTreatmentsSeries.Tables(0).Rows.Count Then
            If strTreatmentsValue <> "" Then
                arrTreatmentsRows = Split(strTreatmentsValue, ";")
                If arrTreatmentsRows.Length > 0 Then
                    If Len(arrTreatmentsRows(0)) > 0 Then
                        For Each strTreatmentRow In arrTreatmentsRows

                            If bFirstRow Then
                                bFirstRow = False
                            Else
                                strResult.Append(";")
                            End If

                            strResult.Append(strTreatmentRow).Append(".0")
                            arrOneRow = Split(strTreatmentRow, ".")

                            If arrOneRow.Length = 4 Then
                                strTreatmentValue = arrOneRow(0)
                                foundRows = dsTreatmentsSeries.Tables(0).Select("TreatmentSeriesID = " & strTreatmentValue)

                                If foundRows.Length > 0 Then
                                    strResult.Append(";")
                                    bFirstSeries = True
                                    For Each objRows In foundRows
                                        strTreatmentNew = objRows("TreatmentID").ToString()
                                        If bFirstSeries Then
                                            bFirstSeries = False
                                        Else
                                            strResult.Append(";")
                                        End If
                                        strResult.Append(strTreatmentNew).Append(".").Append(arrOneRow(1)).Append(".").Append(arrOneRow(2)).Append(".").Append(arrOneRow(3)).Append(".1")
                                    Next
                                End If

                            End If
                        Next
                    End If

                End If
            End If
		Else
			strResult.Append(strTreatmentsValue)
        End If



        Return strResult.ToString()
    End Function

    Private Sub FillAttachmentsType(ByRef cbo As DropDownList)
        cbo.Items.Add(New ListItem("בחר...", 0))
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim ds As DataSet = objTreatmentService.GetAllAttachTypes("5793D9EB-2CC1-44A3-BC46-84C21525AA07")
        Dim currRow As DataRow
        For Each currRow In ds.Tables(0).Rows
            cbo.Items.Add(New ListItem(currRow("AttachName").ToString(), currRow("AttachID").ToString()))
        Next
    End Sub

    Private Function ProcessRow(ByVal strReferenceID As String, ByVal strFirstReference As String, ByVal iLastAttachNo As Integer, ByVal strComboSelectedValue As String, ByRef objTreatmentService As TreatmentConnect.TreatmentService, ByRef ctlFile As HtmlInputFile, ByRef ctlHidden1 As HtmlInputHidden, ByRef ctlHidden2 As HtmlInputHidden, ByRef iExtError As Integer, ByRef iNewAttachNo As Integer) As Integer
        Dim iPhotoType As Integer = CInt(strComboSelectedValue)
        Dim iRetValue As Integer = 0
        iExtError = 0
        If Not ctlFile.PostedFile Is Nothing AndAlso Trim(ctlFile.PostedFile.FileName) <> "" And strFirstReference = "" Then
            Dim ioReader As New BinaryReader(ctlFile.PostedFile.InputStream)
            ioReader.BaseStream.Seek(0, SeekOrigin.Begin)
            Dim arrFileContent(ioReader.BaseStream.Length - 1) As Byte
            ioReader.Read(arrFileContent, 0, ioReader.BaseStream.Length)
            If CheckFileHeader(arrFileContent) > 0 Then
                Dim strFileName As String = ctlFile.PostedFile.FileName
                Dim iPt As Integer = InStrRev(strFileName, "\")
                If iPt > 0 Then
                    strFileName = Mid(strFileName, iPt + 1)
                End If
                If objTreatmentService.ArchiveAttachment("C7F043B7-8717-430D-A7B6-8A2EBDE30741", strReferenceID, iPhotoType, strFileName, arrFileContent) Then
                    iRetValue = 1
                    iNewAttachNo = iLastAttachNo + 1
                    ctlHidden2.Value = "0"
                    ctlHidden1.Value = CStr(iNewAttachNo)
                End If
            Else
                iExtError = 1
            End If
        ElseIf (Trim(ctlHidden1.Value) <> "" And Trim(ctlHidden2.Value) <> "") Then
            Dim iRecordNo As Integer = CInt(ctlHidden2.Value)
            Dim iAttachNo As Integer = CInt(ctlHidden1.Value)
            If iRecordNo = 0 Then
                If iAttachNo > 0 Then
                    If objTreatmentService.CopyAttachmentAndRetFilename("010CC7A5-1561-48AD-8D51-C8DE24E10807", strFirstReference, iAttachNo, strReferenceID) Then
                        iRetValue = 1
                    End If
                Else
                    iRetValue = 1
                End If
            Else
                If objTreatmentService.CopyAttachment("DCAB5DEB-D32B-4B1B-9156-2A47D9ADAC96", iRecordNo, iAttachNo, strReferenceID) Then
                    iRetValue = 1
                End If
            End If
        Else
            iRetValue = 2
        End If
        Return iRetValue
    End Function

    Private Function CheckTreatmentForServiceBasket(ByVal iTreatmentValue As Integer) As Integer
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()

        Dim dsTreatment As DataSet = objTreatmentService.GetTreatmentByTreatmentID("CA459EC9-0EC6-42AD-AA10-72A5E50FEDB4", iTreatmentValue)
        Dim iServiceBasket As Integer = Val(dsTreatment.Tables(0).Rows(0)("ServiceBasket").ToString())

        If iServiceBasket <> 1 Then
            Return 0
        Else
            Return 1
        End If

    End Function

    Private Function CheckAllFiles(ByVal iMaxSize As Integer) As Integer
        Dim iRetValue As Integer
        iRetValue = CheckFileSize(fileToUpload1, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload2, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload3, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload4, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload5, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload6, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload7, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload8, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload9, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload10, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        Return 0
    End Function

    Private Function CheckFileSize(ByRef ctlFile As HtmlInputFile, ByVal iMaxSize As Integer) As Integer
        Dim iRetValue As Integer = 0
        If Not ctlFile.PostedFile Is Nothing AndAlso Trim(ctlFile.PostedFile.FileName) <> "" Then
            'If CheckFileHeader(ctlFile) > 0 Then
            '    iRetValue = 3
            'End If
            If ctlFile.PostedFile.ContentLength > iMaxSize Then
                iRetValue = 2
            ElseIf ctlFile.PostedFile.ContentLength < 1024 Then
                iRetValue = 3
            ElseIf ctlFile.PostedFile.ContentLength = 0 Then
                iRetValue = 1
            End If
        End If
        Return iRetValue
    End Function

    Private Function CheckFileHeader(ByRef byContent As Byte()) As Integer
        Dim iRetValue As Integer = 0
        If Application("CheckJpgHeader") = "1" Then
            Dim strJPEGStart As String = "255216"
            Dim strTIFFStartIntel As String = "7373"
            Dim strTIFFStartMotorola As String = "7777"
            Try
                Dim strHeader As String = byContent(0).ToString() & byContent(1).ToString()
                If strJPEGStart = strHeader Then
                    iRetValue = 1
                ElseIf strTIFFStartIntel = strHeader Or strTIFFStartMotorola = strHeader Then
                    iRetValue = 2
                End If
            Catch ex As Exception
                iRetValue = -1
            End Try
        Else
            iRetValue = 1
        End If
        Return iRetValue
    End Function

    Private Function CheckXrayExist() As Integer
        Dim iRetValue As Integer = 0
        If hidPan.Value = "1" Then
            iRetValue = 1
        End If
        If hidStatus.Value = "1" Then
            iRetValue = iRetValue Or 2
        End If
        If hidFace.Value = "1" Then
            iRetValue = iRetValue Or 4
        End If
        Return iRetValue
    End Function

    Private Function CheckXrayExistOneRow(ByRef ctlHidden1 As HtmlInputHidden, ByRef ctlHidden2 As HtmlInputHidden) As Integer
        Dim iRetValue As Integer = 0
        If (IsNumeric(ctlHidden1.Value) And IsNumeric(ctlHidden2.Value)) Then
            Dim iRecordNo As Integer = CInt(ctlHidden2.Value)
            Dim iAttachNo As Integer = CInt(ctlHidden1.Value)
            If iRecordNo = 0 Then
                iRetValue = Math.Abs(iAttachNo)
            End If
        End If
        Return iRetValue
    End Function

    Private Function CheckXrayAttach() As Boolean
        Dim bRetValue As Boolean = False
        bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType1"), fileToUpload1, txtExistAttNo1, txtExistRecNo1)
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType2"), fileToUpload2, txtExistAttNo2, txtExistRecNo2)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType3"), fileToUpload3, txtExistAttNo3, txtExistRecNo3)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType4"), fileToUpload4, txtExistAttNo4, txtExistRecNo4)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType5"), fileToUpload5, txtExistAttNo5, txtExistRecNo5)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType6"), fileToUpload6, txtExistAttNo6, txtExistRecNo6)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType7"), fileToUpload7, txtExistAttNo7, txtExistRecNo7)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType8"), fileToUpload8, txtExistAttNo8, txtExistRecNo8)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType9"), fileToUpload9, txtExistAttNo9, txtExistRecNo9)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType10"), fileToUpload10, txtExistAttNo10, txtExistRecNo10)
        End If
        Return bRetValue
    End Function

    Private Function CheckXrayAttachOneRow(ByVal strComboSelectedValue As String, ByRef ctlFile As HtmlInputFile, ByRef ctlHidden1 As HtmlInputHidden, ByRef ctlHidden2 As HtmlInputHidden) As Boolean
        Dim bRetValue As Boolean = False
        Dim i As Integer = CInt(strComboSelectedValue)
        If i > 0 Then
            If (IsNumeric(ctlHidden1.Value) And IsNumeric(ctlHidden2.Value)) Then
                Dim iRecordNo As Integer = CInt(ctlHidden2.Value)
                If iRecordNo > 0 Then
                    bRetValue = True
                End If
            ElseIf Not ctlFile.PostedFile Is Nothing AndAlso Trim(ctlFile.PostedFile.FileName) <> "" Then
                bRetValue = True
            End If
        End If
        Return bRetValue
    End Function

    Private Function GetAttachValue(ByVal bNote As Boolean, ByVal iInitValue As Integer) As Integer
        Dim iRetValue As Integer = iInitValue
        Dim iTestValue As Integer
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType1"), txtExistAttNo1)
        iRetValue = iRetValue Or iTestValue
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType2"), txtExistAttNo2)
        iRetValue = iRetValue Or iTestValue
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType3"), txtExistAttNo3)
        iRetValue = iRetValue Or iTestValue
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType4"), txtExistAttNo4)
        iRetValue = iRetValue Or iTestValue
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType5"), txtExistAttNo5)
        iRetValue = iRetValue Or iTestValue
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType6"), txtExistAttNo6)
        iRetValue = iRetValue Or iTestValue
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType7"), txtExistAttNo7)
        iRetValue = iRetValue Or iTestValue
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType8"), txtExistAttNo8)
        iRetValue = iRetValue Or iTestValue
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType9"), txtExistAttNo9)
        iRetValue = iRetValue Or iTestValue
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType10"), txtExistAttNo10)
        iRetValue = iRetValue Or iTestValue
        If bNote Then
            iRetValue += 4
        End If
        Return iRetValue
    End Function

    Private Function GetAttachValueOneRow(ByVal strComboSelectedValue As String, ByRef ctlHidden1 As HtmlInputHidden) As Integer
        Dim i As Integer = CInt(strComboSelectedValue)
        Dim iRetValue As Integer
        If i = 0 Then
            iRetValue = 0
        ElseIf i = 10 Then
            iRetValue = 2
        Else
            If (IsNumeric(ctlHidden1.Value)) Then
                If CInt(ctlHidden1.Value) < 0 Then
                    iRetValue = 0
                Else
                    iRetValue = 1
                End If
            Else
                iRetValue = 1
            End If
        End If
        Return iRetValue
    End Function

    Private Function CheckCause(ByVal strTreatmentValue As String, ByVal strCause As String, ByRef ds As DataSet) As Integer
        Dim foundRows() As DataRow
        Dim retValue As Integer = 0
        foundRows = ds.Tables(0).Select("TreatmentID=" & strTreatmentValue)
        If foundRows.Length > 0 Then
            If strCause = "0" Then
                retValue = -2
            Else
                foundRows = ds.Tables(0).Select("TreatmentID=" & strTreatmentValue & " AND CauseID=" & strCause)
                If foundRows.Length > 0 Then
                    retValue = 1
                Else
                    retValue = -3
                End If
            End If
        Else
            If strCause = "0" Then
                retValue = 1
            Else
                retValue = -1
            End If
        End If
        Return retValue
    End Function

    Private Function CheckTreatment(ByVal strTreatmentValue As String, ByVal bRange As Boolean, ByRef ds As DataSet) As Integer
        Dim foundRows() As DataRow
        Dim retValue As Integer = 0
        foundRows = ds.Tables(0).Select("TreatmentID=" & strTreatmentValue)
        If foundRows.Length > 0 Then
            If foundRows(0).Item("AllowRange").ToString() = "1" Then
                retValue = 1
            Else
                If bRange Then
                    retValue = -1
                Else
                    retValue = 1
                End If
            End If
        End If
        Return retValue
    End Function

    'Private Function CheckTooth(ByVal strTreatmentValue As String, ByVal strFromTooth As String, ByVal strToTooth As String, ByRef ds As DataSet) As Integer
    '    Dim foundRows() As DataRow
    '    Dim currRow As Data.DataRow
    '    Dim retValue As Integer = 0
    '    Dim bResultFrom As Boolean = False
    '    Dim bResultTo As Boolean = False
    '    Dim iTempFrom As Integer, iTempTo As Integer
    '    foundRows = ds.Tables(0).Select("TreatmentID=" & strTreatmentValue)
    '    If foundRows.Length > 0 Then
    '        For Each currRow In foundRows
    '            iTempFrom = CInt(currRow("FromTooth").ToString())
    '            iTempTo = CInt(currRow("ToTooth").ToString())
    '            If ValidateTooth(CInt(strFromTooth), iTempFrom, iTempTo) Then
    '                bResultFrom = True
    '            End If
    '            If ValidateTooth(CInt(strToTooth), iTempFrom, iTempTo) Then
    '                bResultTo = True
    '            End If
    '            If bResultFrom And bResultTo Then
    '                retValue = 1
    '                Exit For
    '            End If
    '        Next
    '        If retValue = 0 Then
    '            If Not bResultFrom Then
    '                retValue = -1
    '            End If
    '            If Not bResultTo Then
    '                retValue += -2
    '            End If
    '        End If
    '    End If
    '    Return retValue
    'End Function

    Private Function CheckTooth(ByVal strTreatmentValue As String, ByVal iFromTooth As Integer, ByVal iToTooth As Integer, ByVal sMilkTeeth As String, ByRef ds As DataSet) As Integer
        Dim foundRows() As DataRow
        Dim currRow As Data.DataRow
        Dim retValue As Integer = 0
        Dim bResultFrom As Boolean = False
        Dim bResultTo As Boolean = False
        Dim iTempFrom As Integer, iTempTo As Integer
        Dim iCurrentTooth As Integer
        Dim iCheckTooth As Integer
        Dim bOk As Boolean = False
        foundRows = ds.Tables(0).Select("TreatmentID=" & strTreatmentValue)
        If foundRows.Length > 0 Then
            For iCurrentTooth = iFromTooth To iToTooth
                bOk = False
                If (sMilkTeeth.IndexOf(iCurrentTooth.ToString() + "-1") > -1) Then
                    iCheckTooth = iCurrentTooth + 40
                Else
                    iCheckTooth = iCurrentTooth
                End If


                For Each currRow In foundRows
                    iTempFrom = CInt(currRow("FromTooth").ToString())
                    iTempTo = CInt(currRow("ToTooth").ToString())

                    bOk = ValidateTooth(iCheckTooth, iTempFrom, iTempTo)

                    If (bOk) Then
                        Exit For
                    End If
                Next

                If (Not bOk) Then
                    Exit For
                End If
            Next
        End If
        If (bOk) Then
            retValue = 0
        Else
            retValue = iCheckTooth
        End If
        Return retValue
    End Function

    Private Function CheckMixedMilkTeeth(ByVal strTreatmentsValue As String, ByVal sMilkTeeth As String, ByRef sNewTreatmentsValue As String) As Boolean

        Dim bMixed As Boolean = False
        Dim bMilkTooth As Boolean

        Dim arrTreatmentsRows As String() = Split(strTreatmentsValue, ";")
        Dim arrOneRow As String()
        Dim strTreatmentValue As String
        Dim strCauseValue As String
        Dim strFromTooth As String
        Dim strToTooth As String
        Dim iFromTooth As Integer
        Dim iToTooth As Integer
        Dim surface As String

        sNewTreatmentsValue = ""
        Dim sb As New StringBuilder()

        If arrTreatmentsRows.Length > 0 Then
            If Len(arrTreatmentsRows(0)) > 0 Then
                For Each sTreatRow As String In arrTreatmentsRows
                    arrOneRow = Split(sTreatRow, ".")
                    If arrOneRow.Length >= 4 Then
                        strTreatmentValue = arrOneRow(0)
                        strCauseValue = arrOneRow(1)
                        strFromTooth = arrOneRow(2)
                        strToTooth = arrOneRow(3)
                        iFromTooth = Val(strFromTooth)
                        iToTooth = Val(strToTooth)

                        If (iFromTooth = 88) Then
                            bMixed = False
                        Else
                            bMilkTooth = (sMilkTeeth.IndexOf(";" + iFromTooth.ToString() + "-1;") > -1)

                            For i As Integer = iFromTooth + 1 To iToTooth
                                bMixed = bMilkTooth <> (sMilkTeeth.IndexOf(";" + i.ToString() + "-1;") > -1)
                                If bMixed Then
                                    Exit For
                                End If
                            Next

                            If bMixed Then
                                Exit For
                            Else
                                If (bMilkTooth) Then
                                    strFromTooth = (iFromTooth + 40).ToString()
                                    strToTooth = (iToTooth + 40).ToString()
                                End If
                            End If
                        End If

                        surface = String.Empty
                        If arrOneRow.Length >= 5 Then
                            surface = arrOneRow(4)
                        End If

                        sb.Append(strTreatmentValue).Append(".").Append(strCauseValue).Append(".").Append(strFromTooth).Append(".").Append(strToTooth).Append(".").Append(surface).Append(";")
                    End If
                Next
            End If
        End If

        sNewTreatmentsValue = sb.ToString()

        Return bMixed
    End Function

    Private Function ValidateTooth(ByVal iTooth As Integer, ByVal iFromTooth As Integer, ByVal iToTooth As Integer) As Boolean
        If (iTooth >= iFromTooth) And (iTooth <= iToTooth) Then
            Return True
        Else
            Return False
        End If
    End Function

End Class