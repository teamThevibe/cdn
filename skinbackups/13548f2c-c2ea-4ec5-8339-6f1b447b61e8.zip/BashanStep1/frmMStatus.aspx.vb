Imports System.Text.RegularExpressions

Public Class frmMStatus
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim ds As Data.DataSet
        ds = objTreatmentService.GetAllowedVectors("5A625CF8-662C-42E6-BCA1-1852B8FA76EE")
        Dim objResult As New System.Text.StringBuilder()
        Dim i As Integer, j As Integer
        Dim strCtlName As String, strValue As String
        objResult.Append("<HTML><HEAD><TITLE></TITLE>")
        objResult.Append("<meta http-equiv='Cache-Control' content='no-cache'>" & vbCrLf)
        objResult.Append("<meta http-equiv='Pragma' content='no-cache'>" & vbCrLf)
        objResult.Append("<meta http-equiv='Expires' content='0'>" & vbCrLf)
        objResult.Append("<META http-equiv='Content-Type' content='text/html; charset=windows-1255'>")
        objResult.Append("</HEAD>")
        objResult.Append("<BODY>")

        Dim strFirstName As String = ""
        Dim strLastName As String = ""
        Dim strPolicyNo As String = ""
        Dim strEmployeeNo As String = ""
        Dim strEmpCD As String = ""
        Dim strInsuredID As String = Request.Form("hidCheckInsuredID")
        Dim strInsuredFamily As String = Request.Form("hidCheckInsuredName")
        Dim strInsuredFirstName As String = Request.Form("hidCheckInsuredFirstName")
        Dim strCareDate As String = Request.Form("hidCareDate")
        Dim iRetValue As Integer = 1
        If IsNumeric(strInsuredID) Then
            If Application("CompanyID").ToString = "3" Then
                strFirstName = Session("MRequest_InsuredName")
                strLastName = Session("MRequest_InsuredFamily")
            Else
                objTreatmentService.GetInsuredProp("5E25C46A-EADC-4C27-8A5A-DB8B13E129D3", strInsuredID, strFirstName, strLastName, strPolicyNo, strEmployeeNo, strEmpCD)
                If UCase(Trim(strLastName)) = "ERROR" Then
                    objTreatmentService.GetSQLInsuredProp("6C865031-52E9-4422-950B-615B8F84600C", strInsuredID, strFirstName, strLastName)
                End If
            End If
            Dim str2Chars As String = Left(strLastName, 2)
            If str2Chars = "" Then
                iRetValue = 0
            Else
                If Regex.IsMatch(Mid(str2Chars, 2, 1), "[�-�a-zA-Z]") Then
                    If str2Chars <> Left(strInsuredFamily, 2) Then
                        iRetValue = 0
                    End If
                Else
                    If Left(str2Chars, 1) <> Left(strInsuredFamily, 1) Then
                        iRetValue = 0
                    End If
                End If
            End If
            str2Chars = Left(strFirstName, 2)
            If str2Chars = "" Then
                iRetValue = 0
            Else
                If Regex.IsMatch(Mid(str2Chars, 2, 1), "[�-�a-zA-Z]") Then
                    If str2Chars <> Left(strInsuredFirstName, 2) Then
                        iRetValue = 0
                    End If
                Else
                    If Left(str2Chars, 1) <> Left(strInsuredFirstName, 1) Then
                        iRetValue = 0
                    End If
                End If
            End If
        Else
            iRetValue = 0
        End If
        objResult.Append("<INPUT TYPE='hidden' ID='InsuredAnswer' value='" & CStr(iRetValue) & "'>")
        objResult.Append("<INPUT TYPE='hidden' ID='CheckAnswer' value='")
        For i = 1 To 4
            For j = 1 To 8
                strCtlName = "hidT" & CStr(i) & CStr(j)
                strValue = Request.Form(strCtlName)
                objResult.Append(CheckTooth(strValue, ds) & ";")
            Next
        Next
        objResult.Append("'>")
        Dim strLastRequest As String = ""
        If IsNumeric(strInsuredID) Then
            Dim iCheckTeethRequestResult As Integer = 0
            If strCareDate <> "00000000" And strCareDate <> "" Then
                Dim strTemDate As String = Mid(strCareDate, 5, 4) & "-" & Mid(strCareDate, 3, 2) & "-" & Left(strCareDate, 2)
                If IsDate(strTemDate) Then
                    iCheckTeethRequestResult = objTreatmentService.CheckTeethRequest("5D30CF5E-D59D-420A-BA7A-DEF24957B587", CInt(strInsuredID), Convert.ToDateTime(strTemDate))
                End If
            End If
            If iCheckTeethRequestResult = 0 Then
                ds = objTreatmentService.GetLastTeethRequest("CA074525-9665-41A4-802F-96183FD3E791", CInt(strInsuredID), User.Identity.Name)
                If ds.Tables(0).Rows.Count > 0 Then
                    strLastRequest = "1"
                    Dim currRow As DataRow = ds.Tables(0).Rows(0)
                    Dim strReference As String = currRow("Reference").ToString()
                    Dim dt As DateTime = Convert.ToDateTime(currRow("ClaimDate"))
                    Dim strInvoice As String = ""
                    Dim strAmount As String = ""
                    Dim strClaimDate As String = ""
                    Dim strHigyena As String = ""
                    Dim strSmoke As String = ""
                    Dim strAvnit As String = ""
                    Dim strEmptyTooth As String = "0;0;0;0;0;0;0;0;0;0;0;0;0;0;"
                    Dim strTooth11 As String = strEmptyTooth
                    Dim strTooth12 As String = strEmptyTooth
                    Dim strTooth13 As String = strEmptyTooth
                    Dim strTooth14 As String = strEmptyTooth
                    Dim strTooth15 As String = strEmptyTooth
                    Dim strTooth16 As String = strEmptyTooth
                    Dim strTooth17 As String = strEmptyTooth
                    Dim strTooth18 As String = strEmptyTooth
                    Dim strTooth21 As String = strEmptyTooth
                    Dim strTooth22 As String = strEmptyTooth
                    Dim strTooth23 As String = strEmptyTooth
                    Dim strTooth24 As String = strEmptyTooth
                    Dim strTooth25 As String = strEmptyTooth
                    Dim strTooth26 As String = strEmptyTooth
                    Dim strTooth27 As String = strEmptyTooth
                    Dim strTooth28 As String = strEmptyTooth
                    Dim strTooth31 As String = strEmptyTooth
                    Dim strTooth32 As String = strEmptyTooth
                    Dim strTooth33 As String = strEmptyTooth
                    Dim strTooth34 As String = strEmptyTooth
                    Dim strTooth35 As String = strEmptyTooth
                    Dim strTooth36 As String = strEmptyTooth
                    Dim strTooth37 As String = strEmptyTooth
                    Dim strTooth38 As String = strEmptyTooth
                    Dim strTooth41 As String = strEmptyTooth
                    Dim strTooth42 As String = strEmptyTooth
                    Dim strTooth43 As String = strEmptyTooth
                    Dim strTooth44 As String = strEmptyTooth
                    Dim strTooth45 As String = strEmptyTooth
                    Dim strTooth46 As String = strEmptyTooth
                    Dim strTooth47 As String = strEmptyTooth
                    Dim strTooth48 As String = strEmptyTooth
                    objResult.Append("<INPUT type='hidden' id='ctlReference' value='" & strReference & "'>")
                    objResult.Append("<INPUT type='hidden' id='ctlClaimDate' value='" & dt.ToString("ddMMyyyy") & "'>")
                    Dim iCheckResult As Integer = objTreatmentService.CheckRequestTeethForUpdate("6CFB8358-6942-4A2C-81ED-5B1493A048F8", strReference)
                    ds = objTreatmentService.GetRequestTeeth("F5CB50CA-C777-40CB-99D6-E5A90CDB849A", strReference)
                    If ds.Tables("Requests").Rows.Count > 0 Then
                        currRow = ds.Tables(0).Rows(0)
                        strInvoice = currRow("Invoice").ToString()
                        strAmount = currRow("Amount").ToString()
                        strAvnit = currRow("Avnit").ToString()
                        strHigyena = currRow("Higyena").ToString()
                        strSmoke = currRow("Smoke").ToString()
                        strTooth11 = ConvertTooth(currRow("ToothVector11").ToString())
                        strTooth12 = ConvertTooth(currRow("ToothVector12").ToString())
                        strTooth13 = ConvertTooth(currRow("ToothVector13").ToString())
                        strTooth14 = ConvertTooth(currRow("ToothVector14").ToString())
                        strTooth15 = ConvertTooth(currRow("ToothVector15").ToString())
                        strTooth16 = ConvertTooth(currRow("ToothVector16").ToString())
                        strTooth17 = ConvertTooth(currRow("ToothVector17").ToString())
                        strTooth18 = ConvertTooth(currRow("ToothVector18").ToString())
                        strTooth21 = ConvertTooth(currRow("ToothVector21").ToString())
                        strTooth22 = ConvertTooth(currRow("ToothVector22").ToString())
                        strTooth23 = ConvertTooth(currRow("ToothVector23").ToString())
                        strTooth24 = ConvertTooth(currRow("ToothVector24").ToString())
                        strTooth25 = ConvertTooth(currRow("ToothVector25").ToString())
                        strTooth26 = ConvertTooth(currRow("ToothVector26").ToString())
                        strTooth27 = ConvertTooth(currRow("ToothVector27").ToString())
                        strTooth28 = ConvertTooth(currRow("ToothVector28").ToString())
                        strTooth31 = ConvertTooth(currRow("ToothVector31").ToString())
                        strTooth32 = ConvertTooth(currRow("ToothVector32").ToString())
                        strTooth33 = ConvertTooth(currRow("ToothVector33").ToString())
                        strTooth34 = ConvertTooth(currRow("ToothVector34").ToString())
                        strTooth35 = ConvertTooth(currRow("ToothVector35").ToString())
                        strTooth36 = ConvertTooth(currRow("ToothVector36").ToString())
                        strTooth37 = ConvertTooth(currRow("ToothVector37").ToString())
                        strTooth38 = ConvertTooth(currRow("ToothVector38").ToString())
                        strTooth41 = ConvertTooth(currRow("ToothVector41").ToString())
                        strTooth42 = ConvertTooth(currRow("ToothVector42").ToString())
                        strTooth43 = ConvertTooth(currRow("ToothVector43").ToString())
                        strTooth44 = ConvertTooth(currRow("ToothVector44").ToString())
                        strTooth45 = ConvertTooth(currRow("ToothVector45").ToString())
                        strTooth46 = ConvertTooth(currRow("ToothVector46").ToString())
                        strTooth47 = ConvertTooth(currRow("ToothVector47").ToString())
                        strTooth48 = ConvertTooth(currRow("ToothVector48").ToString())
                    End If
                    objResult.Append("<INPUT type='hidden' id='ctxInvoice' value='" & strInvoice & "'>")
                    objResult.Append("<INPUT type='hidden' id='ctxAmount' value='" & strAmount & "'>")
                    objResult.Append("<INPUT type='hidden' id='ctxClaimDate' value='" & strClaimDate & "'>")
                    objResult.Append("<INPUT type='hidden' id='ctxSmoke' value='" & strSmoke & "'>")
                    objResult.Append("<INPUT type='hidden' id='ctxAvnit' value='" & strAvnit & "'>")
                    objResult.Append("<INPUT type='hidden' id='ctxHigyena' value='" & strHigyena & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth11' value='" & strTooth11 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth12' value='" & strTooth12 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth13' value='" & strTooth13 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth14' value='" & strTooth14 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth15' value='" & strTooth15 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth16' value='" & strTooth16 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth17' value='" & strTooth17 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth18' value='" & strTooth18 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth21' value='" & strTooth21 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth22' value='" & strTooth22 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth23' value='" & strTooth23 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth24' value='" & strTooth24 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth25' value='" & strTooth25 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth26' value='" & strTooth26 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth27' value='" & strTooth27 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth28' value='" & strTooth28 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth31' value='" & strTooth31 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth32' value='" & strTooth32 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth33' value='" & strTooth33 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth34' value='" & strTooth34 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth35' value='" & strTooth35 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth36' value='" & strTooth36 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth37' value='" & strTooth37 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth38' value='" & strTooth38 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth41' value='" & strTooth41 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth42' value='" & strTooth42 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth43' value='" & strTooth43 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth44' value='" & strTooth44 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth45' value='" & strTooth45 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth46' value='" & strTooth46 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth47' value='" & strTooth47 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxTooth48' value='" & strTooth48 & "'>")
                    objResult.Append("<INPUT TYPE='hidden' id='ctxResult' value='" & CStr(iCheckResult) & "'>")
                End If
            Else
                strLastRequest = "2"
            End If
        End If
        objResult.Append("<INPUT TYPE='hidden' id='ctlLastRequest' value='" & strLastRequest & "'>")
        objResult.Append("<SCRIPT>")
        objResult.Append("	window.parent.document.all.oNotificationCheck.value = 'OK';")
        objResult.Append("</SCRIPT>")
        objResult.Append("</BODY>")
        objResult.Append("</HTML>")
        Response.Write(objResult.ToString())
    End Sub

    Private Function CheckTooth(ByVal strValue As String, ByRef dsVectors As DataSet) As Integer
        Dim i As Integer, strTest As String = "", bHasStima As Boolean = False
        Dim iRetValue As Integer = 0
        Dim currRow As Data.DataRow, strTemplate As String
        Dim vArr As String() = Split(strValue, ";")
        For i = 0 To 7
            strTest += vArr(i) & ";"
        Next
        For i = 8 To 12
            If vArr(i) = "1" Then
                bHasStima = True
            End If
        Next
        If bHasStima Then
            strTest += "1;"
        Else
            strTest += "0;"
        End If
        strTest += vArr(13) & ";"
        For Each currRow In dsVectors.Tables(0).Rows
            strTemplate = ""
            strTemplate += currRow("SHLEMA").ToString() & ";"
            strTemplate += currRow("HELKIT").ToString() & ";"
            strTemplate += currRow("SHETEL").ToString() & ";"
            strTemplate += currRow("HASER").ToString() & ";"
            strTemplate += currRow("KETER").ToString() & ";"
            strTemplate += currRow("MIVNE").ToString() & ";"
            strTemplate += currRow("SHORESH").ToString() & ";"
            strTemplate += currRow("ASHESHET").ToString() & ";"
            strTemplate += currRow("STIMA").ToString() & ";"
            strTemplate += currRow("HALAV").ToString() & ";"
            If strTest = strTemplate Then
                iRetValue = 1
                Exit For
            End If
        Next
        Return iRetValue
    End Function

    Private Function ConvertTooth(ByVal strValue As String) As String
        Dim i As Integer, strReturn As String = ""
        For i = 1 To 14
            strReturn += Mid(strValue, i, 1) & ";"
        Next
        Return strReturn
    End Function
End Class
