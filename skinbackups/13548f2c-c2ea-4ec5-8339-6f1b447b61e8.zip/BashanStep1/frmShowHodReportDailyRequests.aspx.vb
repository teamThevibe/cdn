﻿Imports System.Text
Imports System.Globalization


Partial Public Class frmShowHodReportDailyRequests
    Inherits System.Web.UI.Page

    Dim objTreatmentService As New TreatmentConnect.TreatmentService()
    Dim iDoctorId As Integer
    Dim sClinicName As String
    Public iCompanySign As Integer
    Private isSibatDhiyaRefuitExists As Boolean

    Dim sValidDateForCaption As String

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load



        iCompanySign = eCompanySign.eDikla

        If Not Application("CompanyID") Is Nothing Then
            If CInt(Application("CompanyID")) = eCompanySign.eHarel Then
                iCompanySign = eCompanySign.eHarel
            End If
        End If

        objTreatmentService.Url = Application("TreatmentWebService").ToString()

        Dim iSugDivuach = CInt(Request.QueryString("SugDivuach"))
        Dim ds As New DataSet

        Dim iUserTz As Integer = CInt(Request.QueryString("UserTz"))

        Dim sValidDate As String = Request.QueryString("DayForReport")

        sValidDate = sValidDate.Replace("/", "")

        sValidDateForCaption = sValidDate.Substring(0, 2) + "/" + sValidDate.Substring(2, 2) + "/" + sValidDate.Substring(4, 4)

        ds = objTreatmentService.GetDataForHDReportDailyRequests("3692025C-B925-407E-9A17-4BCBB3ECC7A8", User.Identity.Name, iSugDivuach, iUserTz, iCompanySign, sValidDate, "")

        iDoctorId = CInt(ds.Tables(1).Rows(0)("DoctorID").ToString)
        'sClinicName = ds.Tables(1).Rows(0)("ClinicName").ToString
        sClinicName = ds.Tables(0).Rows(0)("ClinicName").ToString

        Response.Buffer = False
        Response.Clear()
        Response.Expires = -1

        Dim sRep As String

        If (Not ds Is Nothing) Then

            '-------------------
            If iSugDivuach = eSugDivuach.eRequests Then
                '-------------------
                sRep = GenerateReport(ds)

            End If

            '-------------------
            If iSugDivuach = eSugDivuach.eConsultations Then
                '-------------------
                sRep = GenerateReportConsultations(ds)

            End If

            '-------------------
            If iSugDivuach = eSugDivuach.eAccount Then
                '-------------------
                sRep = GenerateReportAccount(ds)

            End If

            Response.Write(sRep)
        Else
            Response.Write("ישנה תקלה בהפקת הדוח")
        End If
        Response.End()
    End Sub

    '******************************
    '    Requests - 11
    '******************************

    Function GetRepCaption(ByVal iRowes As Integer) As String

        Dim sbResult As New StringBuilder()
        sbResult.Append("<table width='100%' ><tr><td dit='rtl'>")
        sbResult.Append("   <DIV style='margin-bottom:10px;text-align:center;font-family:Arial;font-size:10pt;font-weight:bold'>" & vbNewLine)

        If eCompanySign.eHarel Then

            sbResult.Append("הראל חברה לביטוח בע'מ")
            sbResult.Append("</br>")
            '''''''''''''''''''''''sbResult.Append("     אגף ביטוח שיניים  </td>")
            sbResult.Append("   </div>" & vbNewLine)
            sbResult.Append("<td>")

        Else
            sbResult.Append("       </td>")
            sbResult.Append(" <td dit='rtl'>")
            sbResult.Append("  <img align='right' src='pics/shenhav_logo.gif' border='0' alt='' style='margin-right:0px'>")
            sbResult.Append(" </td>")
            sbResult.Append("<td>")

        End If








        sbResult.Append("   <DIV style='margin-bottom:10px;text-align:center;font-family:Arial;font-size:14pt;font-weight:bold'>" & vbNewLine)
        sbResult.Append("  סכום חשבון לרופא מס " & iDoctorId.ToString & "  " & sClinicName & vbNewLine)
        sbResult.Append("</br>")
        sbResult.Append("  הופק בתאריך  " & sValidDateForCaption & vbNewLine)
        sbResult.Append("   </DIV>" & vbNewLine)

        'sbResult.Append("<div dir='ltr' style='margin-bottom:10px;text-align:center;font-family:Arial;font-size:13pt;'>")

        'sbResult.Append("  נשלפו " + iRowes.ToString + " רשומות  " & vbNewLine)
        'sbResult.Append("   </div>" & vbNewLine)


        sbResult.Append("</td>")

        sbResult.Append(" <td >")


        If eCompanySign.eDikla Then
            sbResult.Append("  <img align='left' src='pics/IconLogoDikla.gif' border='0' alt='' style='margin-bottom:50px'>")

        Else
            sbResult.Append("  <img align='left' src='pics/IconLogo_Harel.gif' border='0' alt='' style='margin-bottom:50px'>")

        End If





        sbResult.Append(" </td>")



        sbResult.Append("</tr></table>")


        Return sbResult.ToString

    End Function

    Private Function GenerateReport(ByVal ds As DataSet) As String

        Dim sbResult As New StringBuilder()
        Dim drMailTypeEntries As DataRowCollection = ds.Tables(0).Rows


        sbResult.Append("<html>")
        sbResult.Append("  <head>")
        sbResult.Append("   <meta http-equiv='Cache-Control' content='no-cache'>" & vbCrLf)
        sbResult.Append("   <meta http-equiv='Pragma' content='no-cache'>" & vbCrLf)
        sbResult.Append("   <meta http-equiv='Expires' content='0'>" & vbCrLf)
        sbResult.Append("   <meta http-equiv='Content-Type' content='text/html; charset=windows-1255'>")
        sbResult.Append("<title>דוח סיכום פניות</title>")
        sbResult.Append("<script Language='JavaScript' src='JS/Report.js'></script>")
        sbResult.Append("<style>")
        sbResult.Append(" .OutPrint    { color : #000000; width: 60 ; height: 24; font-size: 12; font-family : Tahoma, Arial; text-align : center; text-decoration : none; cursor : default; border-top: 1px solid white; border-left: 1px solid silver; border-bottom: 1px solid gray; border-right: 1px solid gray; filter:progid:DXImageTransform.Microsoft.Gradient(GradientType=0, StartColorStr='#CCC8C0', EndColorStr='#FAFAF9'); }")
        sbResult.Append(" .OnPrint     { color : #000000; width: 60 ; height: 24; font-size: 12; font-family : Tahoma, Arial; text-align : center; text-decoration : none; cursor : default; border-top: 1px solid white; border-left: 1px solid silver; border-bottom: 1px solid gray; border-right: 1px solid gray; filter:progid:DXImageTransform.Microsoft.Gradient(GradientType=0, StartColorStr='#FAFAF9', EndColorStr='#CCC8C0'); }")
        sbResult.Append(" .OutBTT      { color : #000000; width: 24 ; height: 24; font-size: 12; font-family : Tahoma, Arial; text-align : center; text-decoration : none; cursor : default; border-top: 1px solid white; border-left: 1px solid silver; border-bottom: 1px solid gray; border-right: 1px solid gray; filter:progid:DXImageTransform.Microsoft.Gradient(GradientType=0, StartColorStr='#CCC8C0', EndColorStr='#FAFAF9'); }")
        sbResult.Append(" .OnBTT       { color : #000000; width: 24 ; height: 24; font-size: 12; font-family : Tahoma, Arial; text-align : center; text-decoration : none; cursor : default; border-top: 1px solid white; border-left: 1px solid silver; border-bottom: 1px solid gray; border-right: 1px solid gray; filter:progid:DXImageTransform.Microsoft.Gradient(GradientType=0, StartColorStr='#FAFAF9', EndColorStr='#CCC8C0'); }")
        sbResult.Append("</style>")
        sbResult.Append("  </head>")
        sbResult.Append("<body dir='rtl' BGCOLOR='#FFFFFF' BACKGROUND='' BGPROPERTIES='fixed' OnLoad='callShowActionButtons()' OnBeforePrint='callBeforePrint()' TEXT='#000000' LINK='#000000' VLINK='#000000' ALINK='#000000' LEFTMARGIN='0' TOPMARGIN='0' MARGINWIDTH=' ' MARGINHEIGHT=' '>")

        sbResult.Append("<table cellpadding='0' cellspacing='0' border='0' style='width: 100%'>")
        'sbResult.Append("<tr>")
        ''sbResult.Append(" <td>")
        ''sbResult.Append("  <img align='right' src='pics/IconLogoBig.gif' border='0' alt='' style='margin-bottom:50px'>")
        ''sbResult.Append(" </td>")
        'sbResult.Append("</tr>")

        sbResult.Append("<tr>")
        sbResult.Append(" <td>" & GetRepCaption(ds.Tables(0).Rows.Count) & " </td>")
        sbResult.Append("</tr>")

        sbResult.Append("</table>")


        sbResult.Append("<table cellpadding='0' cellspacing='0' border='1' style='width: 100%'>")
        sbResult.Append(" <tr style='background-color:#A5CBF7;color:#004080;font-family:Arial;font-size:13pt;font-weight:bold'>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>ת'ז </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>שם </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>מספר פניה </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>תאריך טיפול </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>שן </td>")
        'sbResult.Append("  <td style='padding-right:5px' width='7%'>משטח </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>קוד טיפול </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>שם טיפול </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>פוליסה </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>חלקיות </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>סכום החזר </td>")
        'sbResult.Append("  <td style='padding-right:5px' width='7%'>יחידות </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>אסמכתא </td>")
        sbResult.Append("  <td style='padding-right:5px' width='9%'>סיבות לדחיה </td>")
        sbResult.Append(" </tr>")

        For Each dr As DataRow In drMailTypeEntries

            sbResult.Append(" <tr style='font-family:Arial;font-size:11pt;'>")
            sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("TZ") & "</td>")
            sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("FullName") & "</td>")
            sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("MisparPniya") & "</td>")
            sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("TaarichTypul") & "</td>")
            sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("SHEN") & "</td>")

            ' ''If dr.Item("Mistah") Is Nothing Or dr.Item("Mistah") Is System.DBNull.Value Then
            ' ''    sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
            ' ''Else

            ' ''    If dr.Item("Mistah").ToString = "" Then
            ' ''        sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
            ' ''    Else
            ' ''        sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("Mistah") & "</td>")
            ' ''    End If

            ' ''End If


            sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("KodTypul") & "</td>")
            sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("ShemTypul") & "</td>")
            sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("Polisa") & "</td>")

            If String.IsNullOrEmpty(dr.Item("Chelkyut").ToString) = False Then
                sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("Chelkyut") & "</td>")
            Else
                sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
            End If



            sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("SchumHechzer") & "</td>")
            'sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("Yecidot") & "</td>")
            sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("Asmacta") & "</td>")


            Dim sSibatDchiya As String
            sSibatDchiya = dr.Item("SibatDchiya").ToString


            If sSibatDchiya = "No" Then
                sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
            Else
                sbResult.Append("  <td style='padding-right:5px;'>" & sSibatDchiya & "</td>")
            End If

            Dim sSibatDhiyaRefuit As String = dr.Item("SibatDhiyaRefuit")
            If sSibatDhiyaRefuit = "כ" Then
                isSibatDhiyaRefuitExists = True
            End If



            sbResult.Append(" </tr>")
        Next


        sbResult.Append(" <tr style='font-family:Arial;font-size:13pt;font-weight:bold'>")
        sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
        sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
        sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
        sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
        sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
        sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
        'sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")

        sbResult.Append("  <td colspan='4' style='padding-right:5px;'>" & "סה""כ ברוטו לתשלום בגין התביעות הנ""ל" & "</td>")

        Dim dcSum_TASHLUM_MEVUTAH As Decimal
        Dim sSum_TASHLUM_MEVUTAH As String

        Try


            dcSum_TASHLUM_MEVUTAH = Convert.ToDecimal(ds.Tables(0).Compute("Sum(SchumHechzer)", "True"))

        Catch ex As Exception
            dcSum_TASHLUM_MEVUTAH = 0
        End Try

        sSum_TASHLUM_MEVUTAH = dcSum_TASHLUM_MEVUTAH.ToString("c")


        sbResult.Append("  <td colspan='2' style='padding-right:5px;'>" & sSum_TASHLUM_MEVUTAH & "</td>")

        sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
        sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
        sbResult.Append(" </tr>")


        sbResult.Append(" <tr Rowspan='2' style='font-family:Arial;font-size:13pt;font-weight:bold'>")
        sbResult.Append("  <td colspan='14' style='padding-right:5px;'>" & "סכומי החזר שליליים מהוים קיזוז תשלום ששולם בעבר" & "</br>")
        sbResult.Append("  " & "דו'ח זה הינו לצורכי מידע בלבד. עשויים לחול שינויים עד למועד הדוח התקופתי המסכם, המהווה אסמכתא לתשלום." & "</td> </br>")
        sbResult.Append(" </tr>")





        If isSibatDhiyaRefuitExists Then

            sbResult.Append(" <tr Rowspan='2' style='font-family:Arial;font-size:13pt;font-weight:bold'>")
            sbResult.Append("  <td colspan='14' style='padding-right:5px;'>" & "*במקרה של דחיית פניה על בסיס רפואי - ההחלטה ניתנה על ידי המנהל הרפואי דר' אשר קליינשטרן מ.ר. 3171" & "</br>")
            sbResult.Append(" </tr>")

        End If





        'sbResult.Append(" <tr style='font-family:Arial;font-size:13pt;font-weight:bold'>")
        'sbResult.Append(" </tr>")
        sbResult.Append("</table>")


        sbResult.Append("</body>")
        sbResult.Append("</html>")

        Return sbResult.ToString()
    End Function

    '******************************
    '    Consultations - 41
    '******************************

    Function GetRepCaptionConsultations(ByVal iRowes As Integer, ByVal sTz As String, ByVal sFullName As String) As String

        Dim sbResult As New StringBuilder()
        sbResult.Append("<table width='100%' ><tr><td dit='rtl'>")
        sbResult.Append("   <DIV style='margin-bottom:10px;text-align:center;font-family:Arial;font-size:10pt;font-weight:bold'>" & vbNewLine)


        If eCompanySign.eHarel Then

            sbResult.Append("הראל חברה לביטוח בע'מ")
            sbResult.Append("</br>")
            '''''''''''''''''''''sbResult.Append("     אגף ביטוח שיניים  </td>")
            sbResult.Append("   </div>" & vbNewLine)
            sbResult.Append("<td>")


        Else
            sbResult.Append("       </td>")
            sbResult.Append(" <td dit='rtl'>")
            sbResult.Append("  <img align='right' src='pics/shenhav_logo.gif' border='0' alt='' style='margin-right:0px'>")
            sbResult.Append(" </td>")
            sbResult.Append("<td>")

        End If



        sbResult.Append("   <DIV style='margin-bottom:10px;text-align:center;font-family:Arial;font-size:14pt;font-weight:bold'>" & vbNewLine)
        sbResult.Append("  סיכום התיעצויות לרופא מס " & iDoctorId.ToString & "  " & sClinicName & vbNewLine)
        sbResult.Append("</br>")
        sbResult.Append("  עבור  " & sFullName & " " & " ת.ז. " & sTz & vbNewLine)

        sbResult.Append("</br>")
        sbResult.Append("  הופק בתאריך  " & sValidDateForCaption & vbNewLine)
        sbResult.Append("   </DIV>" & vbNewLine)



        sbResult.Append("</td>")

        sbResult.Append(" <td >")
        sbResult.Append("  <img align='left' src='pics/IconLogoBig.gif' border='0' alt='' style='margin-bottom:50px'>")
        sbResult.Append(" </td>")

        sbResult.Append("</tr>")




        sbResult.Append("</table>")


        Return sbResult.ToString

    End Function

    Private Function GenerateReportConsultations(ByVal ds As DataSet) As String

        Dim sbResult As New StringBuilder()
        Dim drMailTypeEntries As DataRowCollection = ds.Tables(0).Rows


        sbResult.Append("<html>")
        sbResult.Append("  <head>")
        sbResult.Append("   <meta http-equiv='Cache-Control' content='no-cache'>" & vbCrLf)
        sbResult.Append("   <meta http-equiv='Pragma' content='no-cache'>" & vbCrLf)
        sbResult.Append("   <meta http-equiv='Expires' content='0'>" & vbCrLf)
        sbResult.Append("   <meta http-equiv='Content-Type' content='text/html; charset=windows-1255'>")
        sbResult.Append("<title>דוח סיכום התיעצויות</title>")
        sbResult.Append("<script Language='JavaScript' src='JS/Report.js'></script>")
        sbResult.Append("<style>")
        sbResult.Append(" .OutPrint    { color : #000000; width: 60 ; height: 24; font-size: 12; font-family : Tahoma, Arial; text-align : center; text-decoration : none; cursor : default; border-top: 1px solid white; border-left: 1px solid silver; border-bottom: 1px solid gray; border-right: 1px solid gray; filter:progid:DXImageTransform.Microsoft.Gradient(GradientType=0, StartColorStr='#CCC8C0', EndColorStr='#FAFAF9'); }")
        sbResult.Append(" .OnPrint     { color : #000000; width: 60 ; height: 24; font-size: 12; font-family : Tahoma, Arial; text-align : center; text-decoration : none; cursor : default; border-top: 1px solid white; border-left: 1px solid silver; border-bottom: 1px solid gray; border-right: 1px solid gray; filter:progid:DXImageTransform.Microsoft.Gradient(GradientType=0, StartColorStr='#FAFAF9', EndColorStr='#CCC8C0'); }")
        sbResult.Append(" .OutBTT      { color : #000000; width: 24 ; height: 24; font-size: 12; font-family : Tahoma, Arial; text-align : center; text-decoration : none; cursor : default; border-top: 1px solid white; border-left: 1px solid silver; border-bottom: 1px solid gray; border-right: 1px solid gray; filter:progid:DXImageTransform.Microsoft.Gradient(GradientType=0, StartColorStr='#CCC8C0', EndColorStr='#FAFAF9'); }")
        sbResult.Append(" .OnBTT       { color : #000000; width: 24 ; height: 24; font-size: 12; font-family : Tahoma, Arial; text-align : center; text-decoration : none; cursor : default; border-top: 1px solid white; border-left: 1px solid silver; border-bottom: 1px solid gray; border-right: 1px solid gray; filter:progid:DXImageTransform.Microsoft.Gradient(GradientType=0, StartColorStr='#FAFAF9', EndColorStr='#CCC8C0'); }")
        sbResult.Append("</style>")
        sbResult.Append("  </head>")
        sbResult.Append("<body dir='rtl' BGCOLOR='#FFFFFF' BACKGROUND='' BGPROPERTIES='fixed' OnLoad='callShowActionButtons()' OnBeforePrint='callBeforePrint()' TEXT='#000000' LINK='#000000' VLINK='#000000' ALINK='#000000' LEFTMARGIN='0' TOPMARGIN='0' MARGINWIDTH=' ' MARGINHEIGHT=' '>")

        sbResult.Append("<table cellpadding='0' cellspacing='0' border='0' style='width: 100%'>")
        'sbResult.Append("<tr>")
        ''sbResult.Append(" <td>")
        ''sbResult.Append("  <img align='right' src='pics/IconLogoBig.gif' border='0' alt='' style='margin-bottom:50px'>")
        ''sbResult.Append(" </td>")
        'sbResult.Append("</tr>")

        sbResult.Append("<tr>")
        sbResult.Append(" <td>" & GetRepCaptionConsultations(ds.Tables(0).Rows.Count, ds.Tables(0).Rows(0)("TZ").ToString, ds.Tables(0).Rows(0)("FullName").ToString) & " </td>")
        sbResult.Append("</tr>")

        sbResult.Append("</table>")


        sbResult.Append("<table cellpadding='0' cellspacing='0' border='1' style='width: 100%'>")
        sbResult.Append(" <tr style='background-color:#A5CBF7;color:#004080;font-family:Arial;font-size:13pt;font-weight:bold'>")
        'sbResult.Append("  <td style='padding-right:5px' width='7%'>ת'ז </td>")
        'sbResult.Append("  <td style='padding-right:5px' width='7%'>שם </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>מספר פניה </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>מתאריך </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>שן </td>")
        'sbResult.Append("  <td style='padding-right:5px' width='7%'>משטח </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>קוד טיפול </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>שם טיפול </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>פוליסה </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>החלטה </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>חלקיות </td>")
        'sbResult.Append("  <td style='padding-right:5px' width='7%'>יחידות </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>השתתפות המתרפא </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>אסמכתא </td>")

        sbResult.Append(" </tr>")

        For Each dr As DataRow In drMailTypeEntries

            sbResult.Append(" <tr style='font-family:Arial;font-size:11pt;'>")
            'sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("TZ") & "</td>")
            'sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("FullName") & "</td>")
            sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("MisparPniya") & "</td>")
            sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("TaarichTypul") & "</td>")
            sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("SHEN") & "</td>")

            'If dr.Item("Mistah") Is Nothing Or dr.Item("Mistah") Is System.DBNull.Value Then
            '    sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
            'Else

            '    If dr.Item("Mistah").ToString = "" Then
            '        sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
            '    Else
            '        sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("Mistah") & "</td>")
            '    End If

            'End If


            sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("KodTypul") & "</td>")
            sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("ShemTypul") & "</td>")
            sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("Polisa") & "</td>")

            sbResult.Append("  <td style='padding-right:5px;'>" & SetSibatDchiya(dr.Item("SibatDchiya").ToString) & "</td>")


            If String.IsNullOrEmpty(dr.Item("Chelkyut").ToString) = False Then
                sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("Chelkyut") & "</td>")
            Else
                sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
            End If



            'sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("Yecidot") & "</td>")
            sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("SchumHechzer") & "</td>")

            sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("Asmacta") & "</td>")






            sbResult.Append(" </tr>")
        Next


        sbResult.Append(" <tr style='font-family:Arial;font-size:13pt;font-weight:bold'>")
        'sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
        'sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
        sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
        sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
        sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
        sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
        sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
        sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
        sbResult.Append("  <td colspan='3' style='padding-right:5px;'>" & "סה""כ השתתפות מתרפא" & "</td>")

        Dim dcSum_TASHLUM_MEVUTAH As Decimal
        Dim sSum_TASHLUM_MEVUTAH As String
        Try



            dcSum_TASHLUM_MEVUTAH = Convert.ToDecimal(ds.Tables(0).Compute("Sum(SchumHechzer)", "True"))

        Catch ex As Exception
            dcSum_TASHLUM_MEVUTAH = 0
        End Try

        sSum_TASHLUM_MEVUTAH = dcSum_TASHLUM_MEVUTAH.ToString("c")


        sbResult.Append("  <td colspan='2' style='padding-right:5px;'>" & sSum_TASHLUM_MEVUTAH & "</td>")

        sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")

        sbResult.Append(" </tr>")


        sbResult.Append(" <tr Rowspan='2' style='font-family:Arial;font-size:13pt;font-weight:bold'>")




        'sbResult.Append("<tr Rowspan='2'>")
        'sbResult.Append("< td   align=left colspan='14'>")


        'If eCompanySign.eDikla Then
        '    sbResult.Append("דקלה חברה לביטוח בע'מ")
        'Else
        '    sbResult.Append("הראל חברה לביטוח בע'מ")
        'End If



        'sbResult.Append(" </td>")


        'sbResult.Append("</tr>")




        sbResult.Append("</table>")



        sbResult.Append("<table style= 'width:100%' border='0'>")

        If eCompanySign.eDikla Then
            sbResult.Append(" </br>  <td colspan='14'  align='left'>" & "דקלה חברה לביטוח בע'מ" & "</br>")

        Else
            sbResult.Append("  </br>   <td colspan='14'  align='left' >" & "הראל חברה לביטוח בע'מ" & "</br>")


        End If



        sbResult.Append("  " & "" & "</td> </br>")
        sbResult.Append(" </tr>")

        sbResult.Append(" <tr style='font-family:Arial;font-size:13pt;font-weight:bold'>")
        sbResult.Append(" </tr>")


        sbResult.Append("</table>")





        sbResult.Append("</body>")
        sbResult.Append("</html>")

        Return sbResult.ToString()
    End Function

    '******************************
    '    Account - 10
    '******************************

    Function GetRepCaptionAccount(ByVal iRowes As Integer) As String

        Dim sbResult As New StringBuilder()
        sbResult.Append("<table width='100%'  ><tr><td dit='rtl'>")
        sbResult.Append("   <DIV style='margin-bottom:10px;text-align:center;font-family:Arial;font-size:10pt;font-weight:bold'>" & vbNewLine)



        If eCompanySign.eHarel Then

            sbResult.Append("הראל חברה לביטוח בע'מ")
            sbResult.Append("</br>")
            ''''''''''''''''''''''sbResult.Append("     אגף ביטוח שיניים  </td>")
            sbResult.Append("   </div>" & vbNewLine)
            sbResult.Append("<td>")

        Else
            sbResult.Append("       </td>")
            sbResult.Append(" <td dit='rtl'>")
            sbResult.Append("  <img align='right' src='pics/shenhav_logo.gif' border='0' alt='' style='margin-right:0px'>")
            sbResult.Append(" </td>")
            sbResult.Append("<td>")

        End If



        sbResult.Append("   <DIV style='margin-bottom:10px;text-align:center;font-family:Arial;font-size:14pt;font-weight:bold'>" & vbNewLine)
        sbResult.Append("  סכום חשבון לרופא מס " & iDoctorId.ToString & "  " & sClinicName & vbNewLine)
        sbResult.Append("</br>")
        sbResult.Append("  הופק בתאריך  " & sValidDateForCaption & vbNewLine)
        sbResult.Append("   </DIV>" & vbNewLine)

        'sbResult.Append("<div dir='ltr' style='margin-bottom:10px;text-align:center;font-family:Arial;font-size:13pt;'>")

        'sbResult.Append("  נשלפו " + iRowes.ToString + " רשומות  " & vbNewLine)
        'sbResult.Append("   </div>" & vbNewLine)


        sbResult.Append("</td>")

        sbResult.Append(" <td >")
        sbResult.Append("  <img align='left' src='pics/IconLogoBig.gif' border='0' alt='' style='margin-bottom:50px'>")
        sbResult.Append(" </td>")



        sbResult.Append("</tr></table>")


        Return sbResult.ToString

    End Function

    Private Function GenerateReportAccount(ByVal ds As DataSet) As String

        Dim sbResult As New StringBuilder()
        Dim drMailTypeEntries As DataRowCollection = ds.Tables(0).Rows


        sbResult.Append("<html>")
        sbResult.Append("  <head>")
        sbResult.Append("   <meta http-equiv='Cache-Control' content='no-cache'>" & vbCrLf)
        sbResult.Append("   <meta http-equiv='Pragma' content='no-cache'>" & vbCrLf)
        sbResult.Append("   <meta http-equiv='Expires' content='0'>" & vbCrLf)
        sbResult.Append("   <meta http-equiv='Content-Type' content='text/html; charset=windows-1255'>")
        sbResult.Append("<title>דוח סיכום חשבון לרופא</title>")
        sbResult.Append("<script Language='JavaScript' src='JS/Report.js'></script>")
        sbResult.Append("<style>")
        sbResult.Append(" .OutPrint    { color : #000000; width: 60 ; height: 24; font-size: 12; font-family : Tahoma, Arial; text-align : center; text-decoration : none; cursor : default; border-top: 1px solid white; border-left: 1px solid silver; border-bottom: 1px solid gray; border-right: 1px solid gray; filter:progid:DXImageTransform.Microsoft.Gradient(GradientType=0, StartColorStr='#CCC8C0', EndColorStr='#FAFAF9'); }")
        sbResult.Append(" .OnPrint     { color : #000000; width: 60 ; height: 24; font-size: 12; font-family : Tahoma, Arial; text-align : center; text-decoration : none; cursor : default; border-top: 1px solid white; border-left: 1px solid silver; border-bottom: 1px solid gray; border-right: 1px solid gray; filter:progid:DXImageTransform.Microsoft.Gradient(GradientType=0, StartColorStr='#FAFAF9', EndColorStr='#CCC8C0'); }")
        sbResult.Append(" .OutBTT      { color : #000000; width: 24 ; height: 24; font-size: 12; font-family : Tahoma, Arial; text-align : center; text-decoration : none; cursor : default; border-top: 1px solid white; border-left: 1px solid silver; border-bottom: 1px solid gray; border-right: 1px solid gray; filter:progid:DXImageTransform.Microsoft.Gradient(GradientType=0, StartColorStr='#CCC8C0', EndColorStr='#FAFAF9'); }")
        sbResult.Append(" .OnBTT       { color : #000000; width: 24 ; height: 24; font-size: 12; font-family : Tahoma, Arial; text-align : center; text-decoration : none; cursor : default; border-top: 1px solid white; border-left: 1px solid silver; border-bottom: 1px solid gray; border-right: 1px solid gray; filter:progid:DXImageTransform.Microsoft.Gradient(GradientType=0, StartColorStr='#FAFAF9', EndColorStr='#CCC8C0'); }")
        sbResult.Append("</style>")
        sbResult.Append("  </head>")
        sbResult.Append("<body dir='rtl' BGCOLOR='#FFFFFF' BACKGROUND='' BGPROPERTIES='fixed' OnLoad='callShowActionButtons()' OnBeforePrint='callBeforePrint()' TEXT='#000000' LINK='#000000' VLINK='#000000' ALINK='#000000' LEFTMARGIN='0' TOPMARGIN='0' MARGINWIDTH=' ' MARGINHEIGHT=' '>")

        sbResult.Append("<table cellpadding='0' cellspacing='0' border='0' style='width: 100%'>")
        'sbResult.Append("<tr>")
        ''sbResult.Append(" <td>")
        ''sbResult.Append("  <img align='right' src='pics/IconLogoBig.gif' border='0' alt='' style='margin-bottom:50px'>")
        ''sbResult.Append(" </td>")
        'sbResult.Append("</tr>")

        sbResult.Append("<tr>")
        sbResult.Append(" <td>" & GetRepCaptionAccount(ds.Tables(0).Rows.Count) & " </td>")
        sbResult.Append("</tr>")

        sbResult.Append("</table>")


        sbResult.Append("<table cellpadding='0' cellspacing='0' border='1' style='width: 100%'>")
        sbResult.Append(" <tr style='background-color:#A5CBF7;color:#004080;font-family:Arial;font-size:13pt;font-weight:bold'>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>ת'ז </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>שם </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>מספר פניה </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>תאריך טיפול </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>שן </td>")
        'sbResult.Append("  <td style='padding-right:5px' width='7%'>משטח </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>קוד טיפול </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>שם טיפול </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>פוליסה </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>חלקיות </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>סכום החזר </td>")
        'sbResult.Append("  <td style='padding-right:5px' width='7%'>יחידות </td>")
        sbResult.Append("  <td style='padding-right:5px' width='7%'>אסמכתא </td>")
        sbResult.Append("  <td style='padding-right:5px' width='9%'>סיבות לדחיה </td>")
        sbResult.Append(" </tr>")

        For Each dr As DataRow In drMailTypeEntries

            sbResult.Append(" <tr style='font-family:Arial;font-size:11pt;'>")
            sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("TZ") & "</td>")
            sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("FullName") & "</td>")
            sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("MisparPniya") & "</td>")
            sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("TaarichTypul") & "</td>")
            sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("SHEN") & "</td>")

            'If dr.Item("Mistah") Is Nothing Or dr.Item("Mistah") Is System.DBNull.Value Then
            '    sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
            'Else

            '    If dr.Item("Mistah").ToString = "" Then
            '        sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
            '    Else
            '        sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("Mistah") & "</td>")
            '    End If

            'End If


            sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("KodTypul") & "</td>")
            sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("ShemTypul") & "</td>")
            sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("Polisa") & "</td>")

            If String.IsNullOrEmpty(dr.Item("Chelkyut").ToString) = False Then
                sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("Chelkyut") & "</td>")
            Else
                sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
            End If



            sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("SchumHechzer") & "</td>")
            'sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("Yecidot") & "</td>")
            sbResult.Append("  <td style='padding-right:5px;'>" & dr.Item("Asmacta") & "</td>")


            Dim sSibatDchiya As String
            sSibatDchiya = dr.Item("SibatDchiya").ToString


            If sSibatDchiya = "No" Then
                sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
            Else
                sbResult.Append("  <td style='padding-right:5px;'>" & sSibatDchiya & "</td>")
            End If




            sbResult.Append(" </tr>")
        Next


        sbResult.Append(" <tr style='font-family:Arial;font-size:13pt;font-weight:bold'>")
        sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
        sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
        sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
        sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
        sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
        sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
        'sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")

        sbResult.Append("  <td colspan='4' style='padding-right:5px;'>" & "סה""כ ברוטו לתשלום בגין התביעות הנ""ל" & "</td>")

        Dim dcSum_TASHLUM_MEVUTAH As Decimal
        Dim sSum_TASHLUM_MEVUTAH As String

        Try


            dcSum_TASHLUM_MEVUTAH = Convert.ToDecimal(ds.Tables(0).Compute("Sum(SchumHechzer)", "True"))


        Catch ex As Exception
            dcSum_TASHLUM_MEVUTAH = 0
        End Try

        sSum_TASHLUM_MEVUTAH = dcSum_TASHLUM_MEVUTAH.ToString("c")


        sbResult.Append("  <td colspan='2' style='padding-right:5px;'>" & sSum_TASHLUM_MEVUTAH & "</td>")

        sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
        sbResult.Append("  <td style='padding-right:5px;'>" & "&nbsp;" & "</td>")
        sbResult.Append(" </tr>")


        sbResult.Append(" <tr Rowspan='2' style='font-family:Arial;font-size:13pt;font-weight:bold'>")
        sbResult.Append("  <td colspan='14' style='padding-right:5px;'>" & "סכומי החזר שליליים מהוים קיזוז תשלום ששולם בעבר" & "</br>")
        'sbResult.Append("  " & "דו'ח זה הינו לצורכי מידע בלבד. עשויים לחול שינויים עד למועד הדוח התקופתי המסכם, המהווה אסמכתא לתשלום." & "</td> </br>")
        sbResult.Append(" </tr>")


        sbResult.Append(" <tr Rowspan='4' style='font-family:Arial;font-size:13pt;font-weight:bold'>")
        sbResult.Append("  <td colspan='14' style='padding-right:5px;'>" & " בעקבות חישוב של " + Session("SumRowsForAccount").ToString + "   שורות התביעה " & "</br>")
        sbResult.Append("  " & " סה""כ לרפואה משמרת " + Session("sSumMesameretForAccount").ToString + " ש""ח . סה""כ לרפואה משקמת " + Session("sSumMesakemetForAccount").ToString + "  ש""ח" & "</br>")
        sbResult.Append("  " & " הודעה על סכום ההעברה נטו לחשבון הבנק ( לאחר ניכוי מס במקור )תשלח אליך בנפרד." & "</br>")
        sbResult.Append("  " & " הזיכוי יבוצע לא יאוחר מ   " + Session("sTaarichZikuytForAccount").ToString + "    בתנאי שהעברת אלינו אישור ניהול ספרים תקף." & "</br>")

        sbResult.Append(" </tr>")





        'sbResult.Append(" <tr style='font-family:Arial;font-size:13pt;font-weight:bold'>")
        'sbResult.Append(" </tr>")
        sbResult.Append("</table>")


        sbResult.Append("</body>")
        sbResult.Append("</html>")

        Return sbResult.ToString()
    End Function

    Protected Function SetSibatDchiya(ByRef objCode As String) As String
        Dim strReturn As String = ""
        If Not IsDBNull(objCode) Then

            Select Case objCode
                Case "No"
                    strReturn = "מכוסה"
                Case Else
                    strReturn = objCode

            End Select
        End If
        Return strReturn
    End Function
  
    Enum eSugDivuach As Integer
        eRequests = 11
        eConsultations = 41
        eAccount = 10
    End Enum

    Enum eCompanySign As Integer
        eDikla = 0
        eHarel = 1

    End Enum

End Class