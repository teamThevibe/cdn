Imports System.Text

Public Class frmRequestReport
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'Dim strFromDate As String = Request.QueryString("StartDate")
        'Dim strToDate As String = Request.QueryString("EndDate")


        If Session("Report_List_Current_User") Is Nothing Then
            Utils.LogOut()
        Else
            If Session("Report_List_Current_User").ToString = "" Then
                Utils.LogOut()
            End If
        End If



        Dim strFromDate As String = Session("Request_Report_From_Date")
        Dim strToDate As String = Session("Request_Report_To_Date")

        If strFromDate <> "00000000" And strFromDate <> "" Then
            strFromDate = Left(strFromDate, 2) & "/" & Mid(strFromDate, 3, 2) & "/" & Mid(strFromDate, 5, 4)
        End If
        If strToDate <> "00000000" And strToDate <> "" Then
            strToDate = Left(strToDate, 2) & "/" & Mid(strToDate, 3, 2) & "/" & Mid(strToDate, 5, 4)
        End If

        Response.Buffer = False
        Response.Clear()
        Response.Expires = -1
        Response.Write(GenerateReport(strFromDate, strToDate))
        Response.End()

    End Sub


    Private Function IsAfterMerging() As Boolean

        Dim MergingDate As DateTime
        If (Not DateTime.TryParseExact(Application("MergingDate"), "dd/MM/yyyy", System.Globalization.CultureInfo.CurrentCulture, System.Globalization.DateTimeStyles.None, MergingDate)) Then
            Return False
        End If

        If Now() >= MergingDate Then
            Return True
        End If

        Return False

    End Function

    Private Function GenerateReport(ByVal strFromDate As String, ByVal strToDate As String) As String
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

        'MaxRows
        Dim objSysTables As New ReportConnect.ReportService()
        objSysTables.Url = Application("ReportWebService").ToString()
        Dim MaxRequestsRepRows As Integer = objSysTables.GetMaxRequestRepRows("EB32C849-A26C-4603-9171-6097AEA10C91")


        Dim sbResult As New StringBuilder()
        sbResult.Append("<html>")
        sbResult.Append("<head>")
        sbResult.Append("<meta http-equiv='Content-Type' content='text/html; charset=windows-1255'>")
        sbResult.Append("<meta http-equiv='Cache-Control' content='no-cache'>" & vbCrLf)
        sbResult.Append("<meta http-equiv='Pragma' content='no-cache'>" & vbCrLf)
        sbResult.Append("<meta http-equiv='Expires' content='0'>" & vbCrLf)
        sbResult.Append("<title>.</title>")

        sbResult.Append("<SCRIPT Language='JavaScript' SRC='JS/Report.js'></SCRIPT>")
        sbResult.Append("<STYLE>")
        sbResult.Append(".OutPrint    { color : #000000; width: 60 ; height: 24; font-size: 12; font-family : Tahoma, Arial; text-align : center; text-decoration : none; cursor : default; border-top: 1px solid white; border-left: 1px solid silver; border-bottom: 1px solid gray; border-right: 1px solid gray; filter:progid:DXImageTransform.Microsoft.Gradient(GradientType=0, StartColorStr='#CCC8C0', EndColorStr='#FAFAF9'); }")
        sbResult.Append(".OnPrint     { color : #000000; width: 60 ; height: 24; font-size: 12; font-family : Tahoma, Arial; text-align : center; text-decoration : none; cursor : default; border-top: 1px solid white; border-left: 1px solid silver; border-bottom: 1px solid gray; border-right: 1px solid gray; filter:progid:DXImageTransform.Microsoft.Gradient(GradientType=0, StartColorStr='#FAFAF9', EndColorStr='#CCC8C0'); }")
        sbResult.Append(".OutBTT      { color : #000000; width: 24 ; height: 24; font-size: 12; font-family : Tahoma, Arial; text-align : center; text-decoration : none; cursor : default; border-top: 1px solid white; border-left: 1px solid silver; border-bottom: 1px solid gray; border-right: 1px solid gray; filter:progid:DXImageTransform.Microsoft.Gradient(GradientType=0, StartColorStr='#CCC8C0', EndColorStr='#FAFAF9'); }")
        sbResult.Append(".OnBTT       { color : #000000; width: 24 ; height: 24; font-size: 12; font-family : Tahoma, Arial; text-align : center; text-decoration : none; cursor : default; border-top: 1px solid white; border-left: 1px solid silver; border-bottom: 1px solid gray; border-right: 1px solid gray; filter:progid:DXImageTransform.Microsoft.Gradient(GradientType=0, StartColorStr='#FAFAF9', EndColorStr='#CCC8C0'); }")
        sbResult.Append("</STYLE>")
        sbResult.Append("  </head>")
        sbResult.Append("<body dir='rtl' BGCOLOR='#FFFFFF' BACKGROUND='' BGPROPERTIES='fixed' OnLoad='callShowActionButtons()' OnBeforePrint='callBeforePrint()' TEXT='#000000' LINK='#000000' VLINK='#000000' ALINK='#000000' LEFTMARGIN='0' TOPMARGIN='0' MARGINWIDTH=' ' MARGINHEIGHT=' '>")
        sbResult.Append("<TABLE cellpadding='0' cellspacing='0' border='0' style='width: 100%'>")
        sbResult.Append("<TR>")
        sbResult.Append("<TD>")
        If IsAfterMerging() Then
            sbResult.Append("<IMG id='imgLogo' align='right' src='pics/IconLogoMerging.gif' border='0' alt='' style='margin-bottom:50px'>")
        Else
            sbResult.Append("<IMG id='imgLogo' align='right' src='pics/IconLogo.gif' border='0' alt='' style='margin-bottom:50px'>")
        End If
        sbResult.Append("</TD>")
        sbResult.Append("</TR>")
        Dim objRequest As New TreatmentConnect.TreatmentService()
        objRequest.Url = Application("TreatmentWebService").ToString()
        Dim strUser As String = objUser.GetUserNameByID("C5C4C694-E524-41D3-8ECD-38CE8434FE4B", CInt(Session("Report_List_Current_User")))

        Dim ds As DataSet = objRequest.GetRequestsForReport("EBE4291A-EAC1-4E14-A1E0-BF1E78B723F1", Session("Request_Report_From_Date"), Session("Request_Report_To_Date"), strUser, Session("Request_Report_Viewed"), Session("Request_Report_NotViewed"), Session("Request_Report_InsuredID"), Session("Request_Report_Name"))

        If Not ds Is Nothing Then
            If ds.Tables.Count > 0 Then


                Dim iCount As Integer = ds.Tables("Requests").Rows.Count
                Dim iCurrent As Integer = 0
                sbResult.Append("<TR>")
                sbResult.Append("<TD>")
                Dim currRow As DataRow
                Dim attRow As DataRow
                If iCount > 0 Then
                    sbResult.Append("<TR>")
                    sbResult.Append("   <TD>")
                    sbResult.Append("   <DIV style='margin-bottom:10px;text-align:center;font-family:Arial;font-size:14pt;font-weight:bold'>")
                    sbResult.Append("��� ����� ����� ������")
                    sbResult.Append("   </DIV>")

                    sbResult.Append("<DIV dir='ltr' style='margin-bottom:10px;text-align:center;font-family:Arial;font-size:14pt;font-weight:bold'>")
                    If strFromDate <> strToDate Then
                        sbResult.Append("(")
                        If strFromDate <> "00000000" And strToDate = "00000000" Then
                            sbResult.Append("�-" & strFromDate)
                        ElseIf strFromDate = "00000000" And strToDate <> "00000000" Then
                            sbResult.Append("�� " & strToDate)
                        ElseIf strToDate <> "00000000" And strFromDate <> "00000000" Then
                            sbResult.Append(strFromDate & " - " & strToDate)
                        End If
                        sbResult.Append(")")
                    Else
                        If strFromDate <> "00000000" Then
                            sbResult.Append("(")
                            sbResult.Append(strFromDate)
                            sbResult.Append(")")
                        End If
                    End If
                    sbResult.Append("</DIV>")

                    sbResult.Append("</TD>")
                    sbResult.Append("</TR>")
                    currRow = ds.Tables("Requests").Rows(0)
                    sbResult.Append("<TABLE cellpadding='0' cellspacing='0' border='0' style='width: 100%'>")
                    sbResult.Append("<TR>")
                    sbResult.Append("<TD>")
                    sbResult.Append("<TABLE cellpadding='0' cellspacing='0' border='1' style='width: 100%'>")
                    sbResult.Append("<TR style='background-color:#A5CBF7;color:#004080;font-family:Arial;font-size:8pt;font-weight:bold;text-align:center'>")
                    sbResult.Append("   <td>�.�.</td>")
                    sbResult.Append("   <td>��<br>�����</td>")
                    sbResult.Append("   <td>��<br>����</td>")
                    sbResult.Append("   <td>���<br>����</td>")
                    sbResult.Append("   <td>���<br>�����</td>")
                    sbResult.Append("   <td>��<br>�����</td>")
                    sbResult.Append("   <td>���</td>")
                    sbResult.Append("   <td>��<br>��</td>")
                    sbResult.Append("   <td>������</td>")
                    sbResult.Append("   <td>�����<br>�����</td>")
                    sbResult.Append("   <td>����<br>�������</td>")
                    sbResult.Append("   <td>����</td>")
                    sbResult.Append("   <td>�����<br>�����</td>")
                    sbResult.Append("   <td>����<br>������</td>")
                    sbResult.Append("   <td>������</td>")
                    sbResult.Append("</TR>")
                    Dim dr As DataRelation
                    Dim dc1 As DataColumn
                    Dim dc2 As DataColumn
                    dc1 = ds.Tables("Requests").Columns("RequestID")
                    dc2 = ds.Tables("Attachments").Columns("RequestID")
                    dr = New System.Data.DataRelation("Requests2Attachments", dc1, dc2)
                    ds.Relations.Add(dr)
                    Dim aRows() As DataRow
                    For Each currRow In ds.Tables("Requests").Rows
                        sbResult.Append("<TR style='font-size:8pt'>")
                        sbResult.Append("   <td>" & currRow("InsuredID").ToString() & "</td>")
                        sbResult.Append("   <td>" & currRow("InsuredFan").ToString() & "</td>")
                        sbResult.Append("   <td>" & currRow("InsuredFir").ToString() & "</td>")
                        sbResult.Append("   <td>" & currRow("RequestType").ToString() & "</td>")
                        sbResult.Append("   <td>" & CEncode.StringEncode(currRow("Treatment").ToString()) & "</td>")
                        sbResult.Append("   <td>" & CEncode.StringEncode(currRow("TreatmentName").ToString()) & "</td>")
                        sbResult.Append("   <td>" & currRow("FTooth").ToString() & "</td>")
                        sbResult.Append("   <td>" & FormateNumber(currRow("ToTooth")) & "</td>")
                        sbResult.Append("   <td>" & FormateSurface(Trim(currRow("Surface").ToString())) & "</td>")
                        If IsDBNull(currRow("FinishDate")) Then
                            sbResult.Append("   <td>&nbsp;</td>")
                        Else
                            sbResult.Append("   <td>" & Format(currRow("FinishDate"), "dd/MM/yyyy") & "</td>")
                        End If
                        sbResult.Append("   <td>" & FormateNumber(currRow("Invoice")) & "</td>")
                        sbResult.Append("   <td>" & FormateNumber(currRow("Amount")) & "</td>")
                        sbResult.Append("   <td>" & Format(currRow("EntryDate"), "dd/MM/yyyy") & "</td>")
                        sbResult.Append("   <td>" & currRow("Reference").ToString() & "</td>")
                        sbResult.Append("   <td>")
                        aRows = currRow.GetChildRows(dr)
                        If aRows.Length > 0 Then
                            sbResult.Append("<TABLE cellpadding='0' cellspacing='0' border='0' style='width: 100%'>")
                            For Each attRow In currRow.GetChildRows(dr)
                                sbResult.Append("<TR style='font-size:8pt'><td>")
                                sbResult.Append(attRow("AttachName").ToString())
                                sbResult.Append("</td></TR>")
                            Next
                            sbResult.Append("</TABLE>")
                        Else
                            sbResult.Append("&nbsp;")
                        End If
                        sbResult.Append("</td>")
                        sbResult.Append("</TR>")
                        iCurrent += 1
                        If iCurrent = MaxRequestsRepRows Then
                            Exit For
                        End If
                    Next
                    sbResult.Append("</TABLE>")
                    If iCount > MaxRequestsRepRows Then
                        sbResult.Append("</TD>")
                        sbResult.Append("</TR>")
                        sbResult.Append("<TR>")
                        sbResult.Append("   <TD>")
                        sbResult.Append("   <DIV style='margin-bottom:10px;text-align:center;font-family:Arial;font-size:14pt;font-weight:bold'>")
                        sbResult.Append("����� ������ ������ ����� ���. �� ����� ���� ������� ������ ����� ���� �����")
                        sbResult.Append("   </DIV>")
                    End If
                Else
                    NoRows(sbResult)

                End If
            Else
                NoRows(sbResult)

            End If
        Else
            NoRows(sbResult)
        End If


        sbResult.Append("<BR>")
        sbResult.Append("</TD>")
        sbResult.Append("</TR>")
        sbResult.Append("</TABLE>")
        sbResult.Append("</body>")
        sbResult.Append("</html>")
        Return sbResult.ToString()
    End Function

    Private Function FormateNumber(ByRef objNum As Object) As String
        If IsDBNull(objNum) Then
            Return "&nbsp;"
        Else
            If IsNumeric(objNum.ToString()) Then
                Dim i As Integer = CInt(objNum)
                If i > 0 Then
                    Return CStr(i)
                Else
                    Return "&nbsp;"
                End If
            Else
                Return "&nbsp;"
            End If
        End If
    End Function

    Private Function FormateBool(ByRef objNum As Object) As String
        If IsDBNull(objNum) Then
            Return "&nbsp;"
        Else
            Dim i As Integer = CInt(objNum)
            If i Then
                Return "��"
            Else
                Return "��"
            End If
        End If
    End Function

    Private Function FormateSurface(ByVal strSurface As String) As String
        Dim strTemp As String = ""
        If InStr(strSurface, "C") Then
            strTemp += " CL-V "
        End If
        If InStr(strSurface, "B") Then
            strTemp += " B "
        End If
        If InStr(strSurface, "L") Then
            strTemp += " L/P "
        End If
        If InStr(strSurface, "D") Then
            strTemp += " D "
        End If
        If InStr(strSurface, "O") Then
            strTemp += " O "
        End If
        If InStr(strSurface, "M") Then
            strTemp += " M "
        End If
        If Len(strTemp) = 0 Then
            strTemp = "&nbsp;"
        End If
        Return strTemp
    End Function

    Private Sub NoRows(ByRef _sbResult As StringBuilder)
        _sbResult.Append("<TABLE cellpadding='0' cellspacing='0' border='0' style='width: 100%'>")
        _sbResult.Append("<TR>")
        _sbResult.Append("   <TD>")
        _sbResult.Append("   <DIV style='margin-bottom:10px;text-align:center;font-family:Arial;font-size:14pt;font-weight:bold'>")
        _sbResult.Append("�� ����� ����� �������� ������ ������ ������")
        _sbResult.Append("   </DIV>")
        _sbResult.Append("</TD>")
        _sbResult.Append("</TR>")
        _sbResult.Append("</TABLE>")
    End Sub
End Class
