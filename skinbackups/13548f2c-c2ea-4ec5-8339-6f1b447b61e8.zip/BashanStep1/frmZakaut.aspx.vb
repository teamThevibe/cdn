Imports System.IO

Public Class frmZakaut
    Inherits System.Web.UI.Page

    Protected WithEvents lstCareGroup As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstCareType As System.Web.UI.WebControls.DropDownList    
    Protected WithEvents lstOccasion As System.Web.UI.WebControls.DropDownList
    Protected WithEvents cmdExit As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdHelp As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdUserProp As System.Web.UI.HtmlControls.HtmlInputButton    
    Protected WithEvents cmdNew As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdPrint As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdSend As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents txtCareType As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtToday As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtError As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtLName As System.Web.UI.HtmlControls.HtmlInputHidden    
    Protected WithEvents txtFName As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtClinicName As System.Web.UI.WebControls.Label
    Protected WithEvents txtClinicNumber As System.Web.UI.WebControls.Label
    Protected WithEvents txtInsuredID As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtInsuredName As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtInsuredFamily As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtOccasion As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtFromTooth As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtAnswer As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents txtCareTypeCombo As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtOccasionCombo As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtCareCode As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtAppType As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtSkipCheck As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents lblPageTitle As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents hidInsuredNo As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidInsuredFamily As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidDisabledCare As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidInsuredName As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidTooth As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidOccasion As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidBashanCode As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents trOccasion As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents txtMessage As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents hidDisabledForm As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidHaveZakaut As System.Web.UI.HtmlControls.HtmlInputHidden



#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        cmdPrint.Disabled = True
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim ds As Data.DataSet
        Dim strTreatmentTypeID As String, strTreatmentDesc As String, strPhotoUnits As String, strXrayB As String, strXrayA As String
        Dim iSmileAgrementClinicPlus As Integer = 0
        If Application("Smile") = "1" Then
            iSmileAgrementClinicPlus = objUser.CheckIfAgrementClinicPlus("2AFAE3F5-79B5-459E-B1F9-C460BD34672A", User.Identity.Name)
        End If

        If Not objUser.GetBashanZakautPermitions("8CE02069-9F79-4D39-A07C-5DDE5BD7C3D9", User.Identity.Name) Then
            objUser.AddUserIllegalAction("24304391-6FDE-4237-A9B6-49630958EB26", User.Identity.Name, "frmZakaut")
            Response.Redirect("Login.aspx")
        End If
        If IsNothing(Session("Login_User")) OrElse Len(Session("Login_User")) = 0 Then
            Response.Redirect("Login.aspx")
        End If

        Dim iCompany As Integer
		Try
			iCompany = CInt(Application("CompanyID").ToString())
		Catch ex As Exception
			iCompany = 2
        End Try

        hidHaveZakaut.Value = ""

        If Not IsPostBack Then
            If Session("User_Login_First_Time") = "1" Then
                Response.Redirect("frmUserProp.aspx")
            End If

            txtToday.Value = Format(DateTime.Today, "ddMMyyyy")
            FillDefaults()

            If Application("Smile") = "1" Then
                Dim dsCareGroup As DataSet
                Dim objSmile As New SmileConnector.SmileConnector()
                objSmile.Url = Application("SmileWebService").ToString()

				Select Case iSmileAgrementClinicPlus
					Case 1
						dsCareGroup = objSmile.GetTreatmentTypesImmediateForServiceBasket("04DAF617-31B5-4828-9735-E8FC7CDB262D", iCompany, 1)
					Case 2
						dsCareGroup = objSmile.GetTreatmentTypesImmediateForServiceBasketPlus("1781AA85-A817-42D6-9A41-7789D97FE492", iCompany, 1)
					Case Else
						dsCareGroup = objSmile.GetTreatmentTypesImmediate("BFE468CC-0A57-4487-9CB3-0F28D9D0FD8F", iCompany, 1)
				End Select

                BindCombo("TreatmentType", "TreatmenTypetID", lstCareGroup, dsCareGroup)
                lstCareGroup.SelectedIndex = 0

                'Dim ds As DataSet = objSmile.GetTreatmentsWithOrderImmediate("691E0BF6-6CC2-4875-B87E-D62718B03B5F", lstCareGroup.SelectedItem.Value, iCompany, 1)
                'FillCareType(ds)
                txtSkipCheck.Value = "1"

                txtInsuredID.Value = Session("MRequest_InsuredID")
                txtInsuredName.Value = Session("MRequest_InsuredName")
                txtInsuredFamily.Value = Session("MRequest_InsuredFamily")
                'txtInsuredID.Disabled = True
                'txtInsuredName.Disabled = True
                'txtInsuredFamily.Disabled = True
                lblPageTitle.InnerText = "����� ����� ������� ������"
                txtMessage.Visible = False
                lstOccasion.Items.Add(New ListItem("���...", 0))
                cmdNew.Value = "����� ����� ����� ������"
                cmdNew.Style.Add("WIDTH", "220px")
            Else
                If Application("CompanyID").ToString = "3" Then
                    txtSkipCheck.Value = "2"
                    cmdNew.Visible = False
                    txtInsuredID.Value = Session("MRequest_InsuredID")
                    txtInsuredName.Value = Session("MRequest_InsuredName")
                    txtInsuredFamily.Value = Session("MRequest_InsuredFamily")
                Else
                    txtSkipCheck.Value = "0"
                End If

                'trOccasion.Visible = False
                trOccasion.Style.Add("display", "none")
                BindCareGroupCombo()
                lstCareGroup.SelectedIndex = 1
                lstCareGroup.Enabled = False

                Dim ds1 As DataSet
                Dim objTreatmentService As New TreatmentConnect.TreatmentService()
                objTreatmentService.Url = Application("TreatmentWebService").ToString()
                If Session("Leumit_OnlyServiceBasket") = "1" Then
                    ds1 = objTreatmentService.GetTreatmentsWithOrderForServiceBasket("24396BC1-5D9C-4634-B200-E3FDE8EB7080", 1, 0)
                Else
                    ds1 = objTreatmentService.GetTreatmentsWithOrder("10F8CFC2-99E1-4094-AABE-D477C8EA8BB0", 1, 0)
                End If
                BindCombo("Treatment", "TreatmentID", lstCareType, ds1)
            End If

            txtAppType.Value = Application("App_Type").ToString
        End If

        If Application("Smile") = "1" Then
            Dim objSmile As New SmileConnector.SmileConnector()
            objSmile.Url = Application("SmileWebService").ToString()

            Dim ds2 As DataSet

			Select Case iSmileAgrementClinicPlus
				Case 1
					ds2 = objSmile.GetTreatmentsWithOrderImmediateForServiceBasket("59F5738A-D582-4113-BC34-70C936F6EF35", lstCareGroup.SelectedItem.Value, iCompany, 1)
				Case 2
					ds2 = objSmile.GetTreatmentsWithOrderImmediateForServiceBasketPlus("574B9870-EBF7-4AA9-925B-8B99AD5F698C", lstCareGroup.SelectedItem.Value, iCompany, 1)
				Case Else
					ds2 = objSmile.GetTreatmentsWithOrderImmediate("691E0BF6-6CC2-4875-B87E-D62718B03B5F", lstCareGroup.SelectedItem.Value, iCompany, 1)
			End Select
            FillCareType(ds2)
        End If
        If Application("Smile") = "1" Or Application("CompanyID").ToString = "3" Then
            ' Smile or Leumit
            txtInsuredID.Attributes.Remove("onblur")
            SetReadOnly(txtInsuredID)
            SetReadOnly(txtInsuredName)
            SetReadOnly(txtInsuredFamily)
            hidDisabledForm.Value = "0"
        End If

    End Sub

    Sub SetReadOnly(ByVal txtField As HtmlInputText)
        txtField.Attributes.Add("readonly", "true")
        txtField.Style.Add("background-Color", "#D6D3CE")
    End Sub

    Private Sub FillDefaults()
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()

        Dim strDoctorCareName As String
        Dim strDoctorCareNumber As String
        Dim strClinicName As String
        Dim strClinicNumber As String
        If objTreatmentService.GetDoctorProperties("7EC6114A-62CD-4DC4-A940-1416BFB136D8", User.Identity.Name, strDoctorCareName, strDoctorCareNumber, strClinicName, strClinicNumber) Then
            txtClinicName.Text = CEncode.StringEncode(strClinicName)
            txtClinicNumber.Text = strClinicNumber
        End If

    End Sub

    Private Sub BindCareGroupCombo()
        lstCareGroup.Items.Add(New ListItem("���...", 0))
        lstCareGroup.Items.Add(New ListItem("�������", 1))
    End Sub

    Private Sub FillCareType(ByRef ds As Data.DataSet)
        Dim currRow As DataRow, objItem As ListItem
        lstCareType.Items.Clear()
        objItem = New ListItem("���...", 0)
        objItem.Attributes.Add("from", "")
        objItem.Attributes.Add("BashanCode", "0")
        objItem.Attributes.Add("SmileCode", "0")
        lstCareType.Items.Add(objItem)
        For Each currRow In ds.Tables(0).Rows
            objItem = New ListItem(Trim(currRow("Treatment").ToString()), currRow("TreatmentID").ToString())
            objItem.Attributes.Add("from", currRow("RangeID").ToString())
            objItem.Attributes.Add("BashanCode", currRow("BashanCode").ToString())
            objItem.Attributes.Add("SmileCode", currRow("SmileTreatmentID").ToString())
            lstCareType.Items.Add(objItem)
        Next
    End Sub

    Private Sub BindCombo(ByVal strTextField As String, ByVal strValueField As String, ByRef cbo As DropDownList, ByRef ds As Data.DataSet)
        Dim currRow As DataRow
        cbo.Items.Add(New ListItem("���...", 0))
        For Each currRow In ds.Tables(0).Rows
            cbo.Items.Add(New ListItem(currRow(strTextField).ToString(), currRow(strValueField).ToString()))
        Next
    End Sub

    Private Function checkSurface() As Boolean
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Return objTreatmentService.CheckFillingTreatmentSmile("7723069A-8815-4a9e-AFA2-4D94D901E118", Trim(txtCareType.Value)) > 0
        'Dim strTreatments As String = "1320;1321;1325;1330;1340;1342;1345;1355;1361;1800;1801;1802;1803;1804;1810;1812;1816;2165;2195"
        'Dim arr() As String = Split(strTreatments, ";")
        'Dim strTemp As String, strCurrentTreatment = Trim(txtCareType.Value)
        'If strCurrentTreatment <> "" Then
        '    For Each strTemp In arr
        '        If strTemp = strCurrentTreatment Then
        '            Return True
        '        End If
        '    Next
        'End If
        'Return False
    End Function

    Private Sub cmdSend_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSend.ServerClick
        Dim stMsg As String
        Dim stPelet As String
        Dim stRETURN_CODE As String
        Dim stQOD_ISHUR As String
        Dim stSXUM_HISTATFUT As String

        Dim objZakautService As New ZakautConnect.ZakautService()
        objZakautService.Url = Application("ZakautConnectorService").ToString()

        If Session("Leumit_CollectionProblem") = "1" Then
            Dim iResult As Integer
            iResult = CheckTreatmentForServiceBasket(CInt(txtCareType.Value))
            If iResult = 0 Then
                txtAnswer.InnerHtml = "��� ������ ������ ����� ����� ��� ��������.<BR>�� ����� ����� ����� ������ �� ��� ������ ��� ���� �����."
                Return
            End If
        End If
        If Application("Smile") = "1" Then
            Dim iTooth As Integer, strSurface As String = "", iCause As Integer
            iTooth = Val(hidTooth.Value)
            If checkSurface() Then
                strSurface = "M"
            End If
            iCause = Val(hidOccasion.Value)
            stPelet = objZakautService.CheckZakautSmile("D441DC59-A094-421F-AB43-C7220ED9E27B", CInt(txtClinicNumber.Text), CInt(hidInsuredNo.Value), CInt(hidBashanCode.Value), User.Identity.Name, hidInsuredFamily.Value, iTooth, strSurface, iCause)
        Else
            stPelet = objZakautService.CheckZakaut("6A8C542E-BFD4-4BBA-B522-2B80DA96A1D6", CInt(txtClinicNumber.Text), CInt(hidInsuredNo.Value), CInt(txtCareType.Value), User.Identity.Name, hidInsuredFamily.Value)
        End If

        Dim objZakaut
        Dim strMsg As String

        If Application("Smile") = "1" Then
            objZakaut = New BAL.CZakautSmile(stPelet)
            txtAnswer.InnerHtml = DirectCast(objZakaut, BAL.CZakautSmile).MsgSmile
            strMsg = DirectCast(objZakaut, BAL.CZakautSmile).Msg
        Else
            objZakaut = New BAL.CZakaut(stPelet)
            DirectCast(objZakaut, BAL.CZakaut).CompanyID = Val(Application("CompanyID"))
            strMsg = DirectCast(objZakaut, BAL.CZakaut).Msg
            txtAnswer.InnerHtml = strMsg
            If DirectCast(objZakaut, BAL.CZakaut).Ishur = "�" Then
                hidHaveZakaut.Value = "1"
            Else
                hidHaveZakaut.Value = "0"
            End If
        End If

        cmdSend.Disabled = True
        If strMsg.IndexOf("������ ���� ���� ���") > -1 Then
            cmdPrint.Disabled = True
            SendOutOfServiceError()
        Else
            cmdPrint.Disabled = False
            TreatCareFields(True)
        End If

        hidDisabledForm.Value = "1"

    End Sub

    Private Function CheckTreatmentForServiceBasket(ByVal iTreatmentValue As Integer) As Integer
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()

        Dim dsTreatment As DataSet = objTreatmentService.GetTreatmentByTreatmentID("CA459EC9-0EC6-42AD-AA10-72A5E50FEDB4", iTreatmentValue)
        Dim iServiceBasket As Integer = Val(dsTreatment.Tables(0).Rows(0)("ServiceBasket").ToString())

        If iServiceBasket <> 1 Then
            Return 0
        Else
            Return 1
        End If

    End Function

    Private Sub cmdExit_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdExit.ServerClick
        If Application("CompanyID") & "" = "3" Then
            Response.Redirect("frmLMCheck.aspx")
        ElseIf Application("Smile") = "1" Then
            Response.Redirect("frmCheckSM.aspx")
        Else
            Response.Redirect("frmStart.aspx")
        End If
    End Sub

    Private Sub cmdUserProp_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUserProp.ServerClick
        Session("User_Prop_Caller") = "frmZakaut.aspx"
        Response.Redirect("frmUserProp.aspx")
    End Sub

    Private Sub cmdNew_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdNew.ServerClick
        txtAnswer.InnerText = ""
        txtCareTypeCombo.Value = ""
        If Application("Smile") = "1" Then

        Else
            txtLName.Value = ""
            txtFName.Value = ""
        End If

        cmdSend.Disabled = False
        cmdPrint.Disabled = True

        TreatCareFields(False)

    End Sub

    Private Sub SendOutOfServiceError()
        Dim strUrl As String = Application("ErrorReportConnectorService").ToString()

        If strUrl <> "" Then
            Dim strMessage As String = "������ ����� ����� ������� ������ �� ����"
            Dim strSubject As String = ""
            If Application("Smile") = "1" Then
                strSubject = "�����-" & " "
            ElseIf Application("CompanyID") & "" = "3" Then
                strSubject = "������-" & " "
            ElseIf Application("CompanyID") & "" = "1" Then
                strSubject = "����-" & " "
            ElseIf Application("CompanyID") & "" = "0" Then
                strSubject = "�����-" & " "
            End If

            strSubject = strSubject & strMessage

            Dim objErrorReportConnect As New ErrorReportConnect.ErrorReportConnector()
            objErrorReportConnect.Url = strUrl
            Try
                objErrorReportConnect.SendErrorWithSubject("9F8D01F4-6CBF-4852-B5E0-1FD2A3AB7F60", strMessage, strSubject, False)
            Catch ex1 As Exception
                '
            End Try
        End If
    End Sub
    Private Sub TreatCareFields(ByVal isDisabled As Boolean)

        Me.txtCareCode.Disabled = isDisabled
        Me.hidDisabledCare.Value = CInt(isDisabled)
        Me.lstCareType.Enabled = Not isDisabled

    End Sub



    'Protected Overrides Sub OnError(ByVal e As System.EventArgs)
    '    Response.Clear()
    '    Dim strResult As String = "<html><head><meta http-equiv='Content-Type' content='text/html; charset=windows-1255'/></head><body dir=rtl>"
    '    strResult += "<DIV style='font-family:Arial;font-size:16pt;font-weight:bold;width:100%;text-align:center'>����� ��� ����� ������, ��� ��� ����� ����</DIV></body></html>"
    '    Response.Write(strResult)
    '    Dim ex As Exception = Server.GetLastError
    '    Response.Write("<DIV style='DISPLAY: none'>")
    '    Response.Write(ex.ToString)
    '    Response.Write("</DIV>")
    '    Response.End()
    'End Sub
End Class
