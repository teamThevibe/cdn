Public Class frmRepProp
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not IsPostBack Then
            Dim strCurrentReportID As String = Request.QueryString("CurrentReportID") & ""
            Dim strMode As String = Request.QueryString("mode") & ""

            'Avner 011109
            Dim isExcel As String = Request.QueryString("isExcel")
            Dim isPdf As String = Request.QueryString("isPdf")
            'End avner
            Dim strSubUser As String = "" & Request.QueryString("s")

            Dim sRepHtml As String
            If strCurrentReportID <> "" Then
                Dim objReports As New ReportConnect.ReportService()

                objReports.Url = Application("ReportWebService").ToString()
                objReports.Timeout = 300000
                'Avner 011109
                If isExcel = "1" Then

                    Response.Buffer = False
                    Response.Clear()
                    Response.Expires = -1

                    Dim sURL As String = ""
                    sURL = Request.Url.AbsoluteUri


                    ' sRepHtml = objReports.GetReportText("0D5DA238-109A-4BD8-86AB-CF395A063297", User.Identity.Name, strCurrentReportID)
                    sRepHtml = objReports.GetReportTextWithUrl("C3530033-3C9C-434F-8CD7-F67D42727452", User.Identity.Name, strCurrentReportID, sURL)

                    If sRepHtml.IndexOf("http-equiv") > 0 Then

                        sRepHtml = sRepHtml.Replace("text/html", "application/vnd.ms-excel")

                        sRepHtml = sRepHtml.Replace("windows-1255", "UTF-8")
                    Else

                        sRepHtml = sRepHtml.Replace("<html>", "<html><head> <meta http-equiv='Content-Type' content='application/vnd.ms-excel; charset=UTF-8'></head>")

                    End If

                    Response.AddHeader("Content-Disposition", "attachment;filename=activity.xls")
                    Response.ContentType = "application/vnd.ms-excel"
                    Response.ContentEncoding = System.Text.Encoding.UTF8
                    Response.Charset = "utf-8"
                    Response.Write(sRepHtml)
                    Response.Flush()
                ElseIf isPdf = "1" Then
                    Response.Buffer = False
                    Response.Clear()
                    Response.Expires = -1

                    Dim sURL As String = ""
                    sURL = Request.Url.AbsoluteUri


                    '' sRepHtml = objReports.GetReportText("0D5DA238-109A-4BD8-86AB-CF395A063297", User.Identity.Name, strCurrentReportID)
                    'sRepHtml = objReports.GetReportTextWithUrl("C3530033-3C9C-434F-8CD7-F67D42727452", User.Identity.Name, strCurrentReportID, sURL)

                    'If sRepHtml.IndexOf("http-equiv") > 0 Then

                    '    sRepHtml = sRepHtml.Replace("text/html", "application/pdf")

                    '    sRepHtml = sRepHtml.Replace("windows-1255", "UTF-8")
                    'Else

                    '    sepHtml = sRepHtml.Replace("<html>", "<html><head> <meta http-equiv='Content-Type' content='application/pdf; charset=UTF-8'></head>")

                    'End If

                    Dim pdfBytes As Byte() = objReports.GetReportPDF("726EF0C9-0E62-4007-85D4-477539792A41", User.Identity.Name, strCurrentReportID, sURL)
                    If pdfBytes.Length > 0 Then
                        Response.AddHeader("Content-Type", "binary/octet-stream")
                        Response.AddHeader("Content-Disposition", "attachment; filename=" & sURL & "; size=" & pdfBytes.Length.ToString())
                        Response.Flush()
                        Response.BinaryWrite(pdfBytes)
                    Else
                        Response.Write("")
                    End If
                    Response.Flush()
                    'Response.End()
                    'Response.AddHeader("Content-Disposition", "attachment;filename=activity.xls")
                    'Response.ContentType = "application/pdf"
                    'Response.ContentEncoding = System.Text.Encoding.UTF8
                    'Response.Charset = "utf-8"
                    'Response.Write(sRepHtml)
                    'Response.Flush()
                Else
                    Response.Buffer = False
                    Response.Clear()
                    Response.Expires = -1
                    Dim sURL As String = ""
                    sURL = Request.Url.AbsoluteUri

                    Try
                        'sRepHtml = objReports.GetReportText("0D5DA238-109A-4BD8-86AB-CF395A063297", User.Identity.Name, strCurrentReportID)
                        sRepHtml = objReports.GetReportTextWithUrl("C3530033-3C9C-434F-8CD7-F67D42727452", User.Identity.Name, strCurrentReportID, sURL)

                        If strMode.ToLower = "modal" Then
                            sRepHtml = sRepHtml.Replace("<CENTER", "<div id=""divBody""><CENTER")
                            sRepHtml = sRepHtml.Replace("</body>", "</div>dudi</body>")
                            sRepHtml = sRepHtml.Replace("var buttonsHTML", "var buttonsHTML=''; var prt")

                            sRepHtml = sRepHtml.Replace("OnLoad='callShowActionButtons()", "OnLoad='callShowActionButtons(); document.parentWindow.parent.document.getElementById(""frmBody"").height = document.getElementById(""divBody"").offsetHeight+30; document.parentWindow.parent.document.getElementById(""frmBody"").frameborder=""0""; ")
                        End If
                        If Application("BOReportEncoding").ToString() <> "" Then
                            Dim dsReport As DataSet

                            dsReport = objReports.GetReport("15732304-C958-4460-8B1A-A02E65D64788", Val(strCurrentReportID))
                            If dsReport.Tables.Count > 0 AndAlso dsReport.Tables(0).Rows.Count > 0 Then
                                If dsReport.Tables(0).Rows(0)("DeliveryFrom").ToString().ToUpper() = "B" Then
                                    Response.ContentEncoding = System.Text.Encoding.GetEncoding(Application("BOReportEncoding").ToString())
                                End If
                            End If
                        End If
                        Response.Write(sRepHtml)
						Response.Flush()
                    Catch ex As Exception
                        '
                    End Try

                    'add js to end of document, the script will push 
                    '  the rep title before existing title


                    'Dim sTitle As String = Split(UCase(sRepHtml) & "<TITLE></TITLE>", "TITLE>")(1)
                    'sTitle = Replace(Replace(Replace(sTitle, "&NBSP;", ""), " ", ""), "</", "") 'remove spaces
                    'If sTitle = "" Or Left(sTitle, 3) = "..." Then
                    '    'restore repName as title from db
                    '    Try
                    '        Dim ds As DataSet = objReports.GetReport("15732304-C958-4460-8B1A-A02E65D64788", Val(strCurrentReportID))
                    '        sTitle = ds.Tables(0).Rows(0).Item("RepName")
                    '        ds.Dispose()
                    '        sTitle = Replace(sTitle, "'", "")
                    '        sTitle = Replace(sTitle, """", "")
                    '        Response.Write("<script language='javascript'>document.title='" + sTitle + "'+document.title;</script>")
                    '    Catch
                    '        'do nothing
                    '    End Try
                    'End If
                End If
                Dim objUser As New UserConnect.UserService()
                objUser.Url = Application("UserWebService").ToString()
                Dim strUserID As String = objUser.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", User.Identity.Name)
                If Not IsNumeric(strSubUser) Then
                    strSubUser = strUserID
                Else
                    If Val(strSubUser) = 0 Then
                        strSubUser = strUserID
                    End If
                End If
                If Application("App_Type").ToString = "dist" Then
                    objReports.UpdateReportViewState("EB917314-AEB1-4F8D-A436-E7797568FD53", Val(strCurrentReportID), CInt(strUserID), CInt(strUserID), User.Identity.Name)
                Else
                    objReports.UpdateReportViewState("EB917314-AEB1-4F8D-A436-E7797568FD53", Val(strCurrentReportID), CInt(strUserID), CInt(strSubUser), User.Identity.Name)
                End If
				Response.End()
            End If

        End If
    End Sub

End Class
