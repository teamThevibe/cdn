Public Class frmPrioCheck
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim objResult As New System.Text.StringBuilder()
        Dim i As Integer, j As Integer
        Dim strCtlName As String, strValue As String
        Dim strInsuredID As String = Request.Form("hidPCheckInsuredID")
        If Not IsNumeric(strInsuredID) Then
            strInsuredID = "0"
        End If
        Dim strReferenceID As String, strBashanReference As String, iCheckType As Integer
        Dim iResult As Integer = objTreatmentService.GetLastPriodontRequest("BA6F88C0-0D77-47F0-AB3F-64531CC67108", CInt(strInsuredID), User.Identity.Name, strReferenceID, strBashanReference, iCheckType)
        objResult.Append("<HTML><HEAD><TITLE></TITLE>")
        objResult.Append("<meta http-equiv='Cache-Control' content='no-cache'>" & vbCrLf)
        objResult.Append("<meta http-equiv='Pragma' content='no-cache'>" & vbCrLf)
        objResult.Append("<meta http-equiv='Expires' content='0'>" & vbCrLf)
        objResult.Append("<META http-equiv='Content-Type' content='text/html; charset=windows-1255'>")
        objResult.Append("</HEAD>")
        objResult.Append("<BODY>")
        objResult.Append("<INPUT TYPE='hidden' ID='PrioCheckAnswer' value='" & iResult & "'>")
        objResult.Append("<INPUT TYPE='hidden' ID='LastPriodontRequest' value='" & strReferenceID & "'>")
        objResult.Append("<INPUT TYPE='hidden' ID='LastPriodontRequestBashan' value='" & strBashanReference & "'>")
        objResult.Append("<INPUT TYPE='hidden' ID='LastPriodontRequestType' value='" & CStr(iCheckType) & "'>")
        objResult.Append("<SCRIPT>")
        objResult.Append("	window.parent.document.all.oPrioNotificationCheck.value = 'OK';")
        objResult.Append("</SCRIPT>")
        objResult.Append("</BODY>")
        objResult.Append("</HTML>")
        Response.Write(objResult.ToString())
    End Sub
End Class
