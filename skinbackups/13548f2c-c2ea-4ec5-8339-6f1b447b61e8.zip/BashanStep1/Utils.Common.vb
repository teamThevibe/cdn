﻿Imports System.IO

Partial Public Class Utils

    Public Enum eLetterStatusCode
        ePrepare = 1 '	בהכנה	
        eReady = 2 '	הוכן	
        eSent = 3 '	נשלח	
        eManuallyEdited = 4 '	עודכן ידנית	
        eProblem = 5 '	הכנה נכשלה	
        eNotForTreatment = 6 '	לא לטיפול	
        eViewed = 7 '	נצפה	
        eWordTemplateMissing = 8 '	חסר מכתב	
        eManuallyEditedAndViewed = 9 '	עודכן ידנית ונצפה	
    End Enum

    Public Structure FileDetails
        Public Id As Integer
        Public Name As String
        Public Path As String
        Public Content() As Byte
    End Structure


    Shared Function StripTagsCharArray(ByVal source As String) As String
        Dim array As Char() = New Char(source.Length - 1) {}
        Dim arrayIndex As Integer = 0
        Dim inside As Boolean = False

        For i As Integer = 0 To source.Length - 1
            Dim [let] As Char = source(i)
            If [let] = "<"c Then
                inside = True
                Continue For
            End If
            If [let] = ">"c Then
                inside = False
                Continue For
            End If
            If Not inside Then
                array(arrayIndex) = [let]
                arrayIndex += 1
            End If
        Next
        Return New String(array, 0, arrayIndex)
    End Function



    Shared Sub BindCombo(ByVal strTextField As String, _
               ByVal strValueField As String, _
               ByRef cbo As DropDownList, _
               ByRef ds As Data.DataSet, _
               ByVal lAddSelect As Boolean)
        Dim currRow As DataRow

        cbo.Items.Clear()
        If (lAddSelect) Then

            cbo.Items.Add(New ListItem("בחר..", "0"))

        End If

        Dim sId As String
        For Each currRow In ds.Tables(0).Rows
            If Not IsDBNull(currRow(strValueField)) Then
                sId = CType(currRow(strValueField), String)
                cbo.Items.Add(New ListItem(currRow(strTextField).ToString(), sId))
            End If
        Next
    End Sub

    Shared Sub BindCombo(ByVal strTextField As String, _
               ByVal strValueField As String, _
               ByRef cbo As DropDownList, _
               ByRef dv As DataView, _
               ByVal lAddSelect As Boolean, _
               Optional ByVal selectText As String = "בחר..", _
               Optional ByVal selectedValue As String = "")
        '''' Enable Binding filtered & sorted Data + Set Selection

        cbo.Items.Clear()
        cbo.DataTextField = strTextField
        cbo.DataValueField = strValueField
        cbo.DataSource = dv
        cbo.DataBind()

        If (lAddSelect) Then
            cbo.Items.Insert(0, New ListItem(selectText, "0"))
        End If

        If selectedValue <> "" Then
            SetComboValue(cbo, selectedValue)
        End If

    End Sub

    Shared Function GetComboValue(ByVal cbo As DropDownList) As String
        Dim strRetValue As String = "0"
        Dim li As ListItem = cbo.SelectedItem
        If Not li Is Nothing Then
            strRetValue = li.Value
        End If
        Return strRetValue
    End Function

    Shared Function GetComboText(ByVal cbo As DropDownList) As String
        Dim strRetValue As String = String.Empty
        Dim li As ListItem = cbo.SelectedItem
        If Not li Is Nothing Then
            strRetValue = li.Text
        End If
        Return strRetValue
    End Function

    Shared Sub SetComboValue(ByRef cbo As DropDownList, ByVal strValue As String)
        Dim li As ListItem = cbo.Items.FindByValue(strValue)
        If Not li Is Nothing Then
            cbo.ClearSelection()
            li.Selected = True
        End If
    End Sub

    Public Function CheckAttachFiles(ByRef strError As String, ByVal strRightExtensions As String, ByVal strWhitelistFileExtensions As String, ByVal filesToUpload() As System.Web.UI.HtmlControls.HtmlInputFile, ByVal bAlert As Boolean, Optional ByVal lstAttachmentsType() As System.Web.UI.WebControls.DropDownList = Nothing) As Integer
        strError = ""

        Dim WhiteList() As String = strWhitelistFileExtensions.Split(";")
        Dim fileToUpload As System.Web.UI.HtmlControls.HtmlInputFile
        Dim lstAttachmentType As System.Web.UI.WebControls.DropDownList
        Dim strWrongExtension As String
        Dim strWrongFileName As String
        Dim strWrongAttachType As String
        Dim sIllegalFileTypeAlert As String = "<div style='direction:ltr;text-align:right'>" & ".אסורה {0} קובץ לא  חוקי, הסיומת" & Chr(10) & Chr(13) & "  הסיומות המותרות הן  " & " {1}</div>"
        'Dim sIllegalFileTypeTxt As String = "קובץ לא חוקי. הסיומת {0} " & " אסורה. " & " הסיומות המותרות הן {1}"

        Dim sIllegalFileTypeTxt As String = "קובץ  {2}  שצורף כ - {3} לא חוקי. הסיומת {0} " & " אסורה. " & " הסיומות המותרות הן {1}"

        Dim iRetValue As Integer = 0


        For Each fileToUpload In filesToUpload

            Dim i As Integer = 0

            If Not lstAttachmentsType Is Nothing Then
                lstAttachmentType = lstAttachmentsType(i)
            Else
                lstAttachmentType = Nothing
            End If
            If fileToUpload.PostedFile Is Nothing Then
                strError = "קובץ ריק " & vbNewLine
                Exit For
            End If
            If fileToUpload.PostedFile.ContentLength = 0 AndAlso fileToUpload.PostedFile.FileName.Trim.Length > 0 Then
                Dim sName As String = fileToUpload.PostedFile.FileName.Trim
                strError = "קובץ ריק " & vbNewLine & sName
                Exit For
            ElseIf fileToUpload.PostedFile.FileName.Trim.Length > 0 Then
                iRetValue += CheckAttachOneRow(fileToUpload, WhiteList, strWrongExtension, strWrongFileName, strWrongAttachType, lstAttachmentType)
            End If
            i = i + 1
        Next

        If strError = "" AndAlso strWrongExtension <> "" Then
            If bAlert Then
                strError = String.Format(sIllegalFileTypeAlert, strWrongExtension, strRightExtensions)
            Else
                strError = String.Format(sIllegalFileTypeTxt, strWrongExtension, strRightExtensions, strWrongFileName, strWrongAttachType)
            End If
        End If

        Return iRetValue
    End Function

    Public Function CheckAttachFilesExt(ByRef strError As String, ByVal strRightExtensions As String, ByVal strWhitelistFileExtensions As String, ByVal filesToUpload() As System.Web.UI.HtmlControls.HtmlInputFile, ByVal bAlert As Boolean, ByRef FileList As ArrayList, Optional ByVal lstAttachmentsType() As System.Web.UI.WebControls.DropDownList = Nothing) As Integer
        strError = ""

        Dim WhiteList() As String = strWhitelistFileExtensions.Split(";")
        Dim fileToUpload As System.Web.UI.HtmlControls.HtmlInputFile
        Dim lstAttachmentType As System.Web.UI.WebControls.DropDownList
        Dim strWrongExtension As String
        Dim strWrongFileName As String
        Dim strWrongAttachType As String
        Dim sIllegalFileTypeAlert As String = "<div style='direction:ltr;text-align:right'>" & ".אסורה {0} קובץ לא  חוקי, הסיומת" & Chr(10) & Chr(13) & "  הסיומות המותרות הן  " & " {1}</div>"
        'Dim sIllegalFileTypeTxt As String = "קובץ לא חוקי. הסיומת {0} " & " אסורה. " & " הסיומות המותרות הן {1}"

        Dim sIllegalFileTypeTxt As String = "לא ניתן לצרף הקובץ  {2}.  הסיומות המותרות הן {1}"
        '"קובץ  {2}  שצורף כ - {3} לא חוקי. הסיומת {0} " & " אסורה. " & " הסיומות המותרות הן {1}"
        Dim iValidFile As Integer = -1
        Dim iRetValue As Integer = 0

        Dim i As Integer = 0
        For Each fileToUpload In filesToUpload


            If Not lstAttachmentsType Is Nothing Then
                lstAttachmentType = lstAttachmentsType(i)
            Else
                lstAttachmentType = Nothing
            End If
            If fileToUpload.PostedFile Is Nothing Then
                strError = "קובץ ריק " & vbNewLine
                Exit For
            End If
            If fileToUpload.PostedFile.ContentLength = 0 AndAlso fileToUpload.PostedFile.FileName.Trim.Length > 0 Then
                Dim sName As String = fileToUpload.PostedFile.FileName.Trim
                strError = "קובץ ריק " & vbNewLine & sName
                Exit For
            ElseIf fileToUpload.PostedFile.FileName.Trim.Length > 0 Then
                iValidFile = CheckAttachOneRow(fileToUpload, WhiteList, strWrongExtension, strWrongFileName, strWrongAttachType, lstAttachmentType)
                iRetValue += iValidFile
                If (iValidFile = 1) Then
                    Dim arrFileInformation As String() = {Path.GetFileName(fileToUpload.PostedFile.FileName), lstAttachmentType.SelectedItem.Text}
                    FileList.Add(arrFileInformation)
                End If
            End If
            i = i + 1
        Next

        If strError = "" AndAlso strWrongExtension <> "" Then
            If bAlert Then
                strError = String.Format(sIllegalFileTypeAlert, strWrongExtension, strRightExtensions)
            Else
                strError = String.Format(sIllegalFileTypeTxt, strWrongExtension, strRightExtensions, strWrongFileName, strWrongAttachType)
            End If
        End If

        Return iRetValue
    End Function

    Private Function CheckAttachOneRow(ByRef ctlFile As HtmlInputFile, _
                                       ByVal WhiteList() As String, _
                                       ByRef WrongExtension As String, _
                                       ByRef strWrongFileName As String, _
                                       ByRef strWrongAttachType As String, _
                                       ByVal ctlAttachFile As DropDownList) As Integer

        Dim iRetValue As Integer = 0

        If Not ctlFile.PostedFile Is Nothing AndAlso Trim(ctlFile.PostedFile.FileName) <> String.Empty Then

            ' cancel checking
            Dim CheckFileContent As Object = HttpContext.Current.Application("CheckFileContent")
            If Not (CheckFileContent Is Nothing) AndAlso (Not CheckFileContent) Then
                iRetValue = 1
                Return iRetValue
            End If

            Dim ioReader As New BinaryReader(ctlFile.PostedFile.InputStream)
            ioReader.BaseStream.Seek(0, SeekOrigin.Begin)

            Dim arrFileContent(1) As Byte
            ioReader.Read(arrFileContent, 0, 2)

            Dim strHeader As String = arrFileContent(0).ToString() & arrFileContent(1).ToString()
            Dim fi As New FileInfo(ctlFile.PostedFile.FileName)
            Dim strExt As String = fi.Extension & ""
            If strExt <> "" Then
                strExt = strExt.Substring(1, Len(strExt) - 1)
            End If

            If (WhiteList.Length = 1) And (WhiteList(0) = "") Then
                iRetValue = 1 'valid
            Else
                Dim ext() As String
                Dim sExtW As String = ""
                Dim sHeaderW As String = ""
                Dim i As Integer
                For i = 0 To WhiteList.Length - 1
                    ext = WhiteList(i).Split(",")
                    If ext.Length >= 2 Then
                        sExtW = ext(0).ToUpper
                        sHeaderW = ext(1)
                        If strExt.ToUpper = sExtW AndAlso (Val(sHeaderW) = 0 Or strHeader = sHeaderW) Then
                            iRetValue = 1 'valid
                            Exit For
                        End If
                    End If
                Next
            End If


            If iRetValue < 1 And WrongExtension = String.Empty Then
                WrongExtension = Path.GetExtension(ctlFile.PostedFile.FileName)
                WrongExtension = WrongExtension.Replace(".", "") & ""

                If Not ctlAttachFile Is Nothing Then

                    strWrongFileName = Path.GetFileName(ctlFile.PostedFile.FileName)
                    strWrongAttachType = ctlAttachFile.SelectedItem.Text
                Else

                    strWrongFileName = Path.GetFileName(ctlFile.PostedFile.FileName)
                    strWrongAttachType = ""

                End If
            End If
        End If

        Return iRetValue

    End Function

    Public Function CheckFileCollection( _
                        ByRef ErrorDescription As String, _
                        ByVal strRightExtensions As String, _
                        ByVal strWhitelistFileExtensions As String, _
                        ByRef hfc As HttpFileCollection, _
                        ByVal bAlert As Boolean) As Integer

        Dim ReturnValue As Integer = 0
        Dim WhiteList() As String = strWhitelistFileExtensions.Split(";")
        Dim i As Integer = 0

        For i = 0 To hfc.Count - 1
            If hfc(i).ContentLength = 0 AndAlso hfc(i).FileName.Trim.Length > 0 Then
                ReturnValue = 0
                ErrorDescription = "קובץ ריק " & hfc(i).FileName.Trim
                Exit For
            ElseIf hfc(i).ContentLength > 0 Then
                ReturnValue += CheckPostedFile(hfc(i), WhiteList, ErrorDescription)
                If (ErrorDescription <> String.Empty) Then
                    ReturnValue = 0
                    Exit For
                End If
            End If
        Next

        Return ReturnValue ' number of valid files + ByRef strError - Error description

    End Function

    Public Function CheckFileCollection(ByRef strError As String, _
                                        ByVal strRightExtensions As String, _
                                        ByVal strWhitelistFileExtensions As String, _
                                        ByRef hfc As HttpFileCollection, _
                                        ByVal bAlert As Boolean, _
                                        ByVal iMaxSize As Integer) As Integer
        Dim WhiteList() As String = strWhitelistFileExtensions.Split(";")
        Dim fileToUpload As System.Web.UI.HtmlControls.HtmlInputFile
        Dim lstAttachmentType As System.Web.UI.WebControls.DropDownList
        Dim strWrongExtension As String
        Dim strWrongFileName As String
        Dim strWrongAttachType As String
        Dim sIllegalFileTypeAlert As String = "<div style='direction:ltr;text-align:right'>" & ".אסורה {0} קובץ לא  חוקי, הסיומת" & "</br>" & " {1} הסיומות המותרות הן  " & " </div>"
        'Dim sIllegalFileTypeTxt As String = "קובץ לא חוקי. הסיומת {0} " & " אסורה. " & " הסיומות המותרות הן {1}"

        Dim sIllegalFileTypeTxt As String = "קובץ  {2}  שצורף כ - {3} לא חוקי. הסיומת {0} " & " אסורה. " & " הסיומות המותרות הן {1}"

        Dim iRetValue As Integer = 0
        Dim i As Integer = 0
        For i = 0 To hfc.Count - 1
            If hfc(i).ContentLength = 0 AndAlso hfc(i).FileName.Trim.Length > 0 Then
                iRetValue = 0
                Dim sName As String = hfc(i).FileName.Trim
                strError = "קובץ ריק " & sName
                Exit For

            ElseIf hfc(i).ContentLength > 0 Then

                Dim iHfcContentLength As Integer
                iHfcContentLength = hfc(i).ContentLength

                If iMaxSize > 0 Then
                    If ((iHfcContentLength / 1024) > iMaxSize) Then
                        strError = "ניתן לצרף קבצים עד גודל של <br /> " & CStr(iMaxSize) & "  KB "
                        Exit For
                    End If
                End If

                iRetValue += CheckPostedFile(hfc(i), WhiteList, strWrongExtension, strWrongFileName, strWrongAttachType)
            End If
        Next

        If strError = "" Then
            If strWrongExtension = "" Then
                strError = ""
            Else
                If bAlert Then
                    If strWrongExtension.Length > 0 And strWrongFileName = "-1" Then 'DS strWrongFileName = "-1" serve as a Error flag
                        strError = strWrongExtension
                    Else
                        strError = String.Format(sIllegalFileTypeAlert, strWrongExtension, strRightExtensions)
                    End If

                Else
                    If strWrongExtension.Length > 0 And strWrongFileName = "-1" Then 'DS strWrongFileName = "-1" serve as a Error flag
                        strError = strWrongExtension
                    Else
                        strError = String.Format(sIllegalFileTypeTxt, strWrongExtension, strRightExtensions, strWrongFileName, strWrongAttachType)
                    End If
                End If
            End If
        End If

        Return iRetValue
    End Function


    Private Function CheckPostedFile(ByRef hpf As HttpPostedFile, _
                                       ByVal WhiteList() As String, _
                                       ByRef ErrorDescription As String) As Integer

        Dim ReturnValue As Integer = 1 ' 0-invalid, 1-valid
        ErrorDescription = String.Empty

        If hpf.ContentLength > 0 Then
            Dim CheckFileContent As Object = HttpContext.Current.Application("CheckFileContent")
            If Not (CheckFileContent Is Nothing) AndAlso (Not CheckFileContent) Then
                Return ReturnValue
            End If


            Dim ioReader As New BinaryReader(hpf.InputStream)
            ioReader.BaseStream.Seek(0, SeekOrigin.Begin)

            Dim arrFileContent(1) As Byte
            ioReader.Read(arrFileContent, 0, 2)

            Dim strHeader As String = arrFileContent(0).ToString() & arrFileContent(1).ToString()
            Dim fi As New FileInfo(hpf.FileName)
            Dim strExt As String = fi.Extension & ""
            If strExt <> "" Then
                strExt = strExt.Substring(1, Len(strExt) - 1)
            End If

            If (WhiteList.Length = 1) And (WhiteList(0) = "") Then
                'valid
            Else
                Dim ext() As String
                Dim sExtW As String = ""
                Dim sHeaderW As String = ""
                Dim i As Integer

                ReturnValue = 0
                ErrorDescription = String.Format("קובץ לא חוקי, הסיומת {0} אסורה.", strExt)

                For i = 0 To WhiteList.Length - 1
                    ext = WhiteList(i).Split(",")
                    If ext.Length >= 2 Then
                        sExtW = ext(0).ToUpper
                        sHeaderW = ext(1)
                        If strExt.ToUpper = sExtW Then
                            If (strHeader = sHeaderW) Then 'valid 
                                ReturnValue = 1
                                ErrorDescription = String.Empty
                            Else 'invalid
                                ErrorDescription = "קובץ לא חוקי, מבנה הקובץ לא תואם את השם שלו."
                            End If
                            Exit For
                        End If
                    End If
                Next
            End If
        End If

        Return ReturnValue

    End Function

















    ' not in use ?
    Private Function CheckPostedFile(ByRef hpf As HttpPostedFile, _
                                          ByVal WhiteList() As String, _
                                          ByRef WrongExtension As String, _
                                          ByRef strWrongFileName As String, _
                                          ByRef strWrongAttachType As String) As Integer

        Dim iRetValue As Integer = 0

        If hpf.ContentLength > 0 Then
            Dim CheckFileContent As Object = HttpContext.Current.Application("CheckFileContent")
            If Not (CheckFileContent Is Nothing) AndAlso (Not CheckFileContent) Then
                iRetValue = 1
                Return iRetValue
            End If

            Dim ioReader As New BinaryReader(hpf.InputStream)
            ioReader.BaseStream.Seek(0, SeekOrigin.Begin)

            Dim arrFileContent(1) As Byte
            ioReader.Read(arrFileContent, 0, 2)

            Dim strHeader As String = arrFileContent(0).ToString() & arrFileContent(1).ToString()
            Dim fi As New FileInfo(hpf.FileName)
            Dim strExt As String = fi.Extension & ""
            If strExt <> "" Then
                strExt = strExt.Substring(1, Len(strExt) - 1)
            End If

            If (WhiteList.Length = 1) And (WhiteList(0) = "") Then
                iRetValue = 1 'valid
            Else
                Dim ext() As String
                Dim sExtW As String = ""
                Dim sHeaderW As String = ""
                Dim i As Integer
                iRetValue = 0
                ' WrongExtension = String.Format("קובץ לא חוקי, הסיומת {0} אסורה.", strExt)

                For i = 0 To WhiteList.Length - 1
                    ext = WhiteList(i).Split(",")
                    If ext.Length >= 2 Then
                        sExtW = ext(0).ToUpper
                        sHeaderW = ext(1)
                        'DS 2/3/2014  added new error msg for checking the file header name (check file extension rename )
                        'If strExt.ToUpper = sExtW AndAlso (Val(sHeaderW) = 0 Or strHeader = sHeaderW) Then
                        '    iRetValue = 1 'valid
                        '    Exit For
                        'End If
                        If strExt.ToUpper = sExtW Then
                            If (strHeader = sHeaderW) Then 'valid 
                                iRetValue = 1
                                WrongExtension = String.Empty
                            Else 'invalid
                                WrongExtension = "קובץ לא חוקי, מבנה הקובץ לא תואם את השם שלו."
                                strWrongFileName = "-1" 'Use strWrongFileName filed as a flag for showing the upper New msg (check file extension rename match file extention )
                            End If
                            Exit For
                        End If
                    End If
                Next
            End If


            If iRetValue < 1 And WrongExtension = String.Empty Then
                WrongExtension = Path.GetExtension(hpf.FileName)
                WrongExtension = WrongExtension.Replace(".", "") & ""

                strWrongFileName = ""
                strWrongAttachType = ""
            End If
        End If

        Return iRetValue

    End Function

    Public Function GetAge(ByVal Birthdate As System.DateTime, Optional ByVal DateNow As System.DateTime = #1/1/1700#) As String

        Dim iMonths As Integer
        Dim iYears As Integer
        Dim dYears As Decimal
        Dim lDayOfBirth As Long
        Dim lDateNow As Long
        Dim iBirthMonth As Integer
        Dim iDateNowMonth As Integer

        If DateNow = "#1/1/1700#" Then
            DateNow = DateTime.Now
        End If
        lDayOfBirth = DatePart(DateInterval.Day, Birthdate)
        lDateNow = DatePart(DateInterval.Day, DateNow)

        iBirthMonth = DatePart(DateInterval.Month, Birthdate)
        iDateNowMonth = DatePart(DateInterval.Month, DateNow)

        iMonths = DateDiff(DateInterval.Month, Birthdate, DateNow)

        dYears = iMonths / 12

        iYears = Math.Floor(dYears)

        If iBirthMonth = iDateNowMonth Then
            If lDateNow < lDayOfBirth Then
                iYears = iYears - 1
            End If
        End If

        Return iYears
    End Function

    Shared Function YYYYMMDDToDate(ByVal sDate As String) As Date
        Try
            If sDate.Length = 8 And IsNumeric(sDate) Then
                Dim dRes As New Date(Left(sDate, 4), Mid(sDate, 5, 2), Right(sDate, 2))
                Return dRes
            Else
                Return Date.MinValue
            End If
        Catch ex As Exception
            Return Date.MinValue
        Finally
        End Try

    End Function

    Shared Function DDMMYYYYFormat(ByVal sDate As String) As String
        If sDate.Length = 8 Then
            Return Left(sDate, 2) & "/" & Mid(sDate, 3, 2) & "/" & Mid(sDate, 5, 4)
        ElseIf sDate.Length = 0 Then
            Return "00/00/0000"
        Else
            Return sDate
        End If
    End Function

    Shared Function DDMMYYYYDate(ByVal sDate As String) As Date
        Try
            If sDate.Length = 8 And IsNumeric(sDate) Then
                Dim dRes As New Date(Right(sDate, 4), Mid(sDate, 3, 2), Left(sDate, 2))
                Return dRes
            Else
                Return Date.MaxValue
            End If
        Catch ex As Exception
            Return Date.MaxValue
        Finally
        End Try
    End Function

    Shared Function StringToDate(ByVal sDate As String) As Date
        Dim dDate As Date = Date.MinValue
        Try
            If sDate.Length = 10 Then
                sDate = sDate.Replace("/", "")
                If sDate.Length = 8 And IsNumeric(sDate) And Val(sDate) > 0 Then
                    Dim dRes As New Date(Right(sDate, 4), Mid(sDate, 3, 2), Left(sDate, 2))
                    dDate = dRes
                Else
                    dDate = Date.MinValue
                End If

            End If
        Catch ex As Exception
            dDate = Date.MinValue
        End Try

        Return dDate
    End Function

    Shared Function IsEmptyDate(ByVal sDate As String) As Boolean
        If sDate = "00/00/0000" Or sDate = "00000000" Or sDate = "" Then
            Return True
        Else
            Return False
        End If
    End Function

    Shared Function IsDate(ByVal sDate As String) As Boolean
        Dim tDate = Mid(sDate, 5, 4) & "-" & Mid(sDate, 3, 2) & "-" & Left(sDate, 2)
        If Not Microsoft.VisualBasic.IsDate(tDate) Then
            Return False
        End If
        Try
            Convert.ToDateTime(tDate)
        Catch ex As Exception
            Return False
        End Try
        Return True
    End Function

    Private Function MakeUserName(ByVal context As HttpContext) As String

        Dim stRowUserName As String = context.Request.ServerVariables("LOGON_USER")
        Dim iSlashPos As String = InStr(stRowUserName, "\")
        Dim stUserName As String

        If iSlashPos > 0 Then
            stUserName = Mid(stRowUserName, iSlashPos + 1)
        Else
            stUserName = stRowUserName
        End If

        Return stUserName

    End Function

    Shared Function isEnglish(ByVal sStringToCheck) As Boolean

        Dim matchEng As Boolean = True

        Dim ascii As System.Text.Encoding = System.Text.Encoding.UTF8
        Dim encodedBytes As [Byte]() = ascii.GetBytes(sStringToCheck)
        For Each b As [Byte] In encodedBytes
            If (b >= 128) Then
                matchEng = False
                Exit For
            End If
        Next

        Return matchEng

    End Function

    Shared Function SetDateForReport(ByVal strFromDate As String, ByVal strToDate As String) As String
        Dim strReturn As String = ""

        If strFromDate Is Nothing Or strFromDate = "" Or strFromDate = "00000000" Then

            If strToDate Is Nothing Or strToDate = "" Or strToDate = "00000000" Then
                '*********No dates****************
            Else
                '*********No from-date****************
                strReturn = " עד " + strToDate
            End If

        Else

            If strToDate Is Nothing Or strToDate = "" Or strToDate = "00000000" Then
                '*********No to-date****************
                strReturn = " מ " + strFromDate
            Else
                '*********There is dates****************
                strReturn = " מ " + strFromDate + " עד " + strToDate
            End If

        End If

        Return strReturn

    End Function

    Sub SelectPageNo(ByVal grd As DataGrid, ByVal txtID As System.Web.UI.HtmlControls.HtmlInputHidden)
        Try
            Dim rw As DataRow
            Dim i As Integer = 0

            Dim ds As DataSet = grd.DataSource
            Dim iRowsCount = ds.Tables(0).Rows.Count
            Dim iPageIndex As Integer = 0

            If Val(txtID.Value) > 0 And iRowsCount > 0 Then
                For Each rw In ds.Tables(0).Rows
                    i = i + 1
                    If rw(grd.DataKeyField).ToString = txtID.Value Then
                        iPageIndex = (i - 1) \ grd.PageSize
                        Exit For
                    End If
                Next
                grd.CurrentPageIndex = iPageIndex
            End If

        Catch ex As Exception
            '
        End Try
    End Sub

    Shared Function GetRowsCount(ByVal ds As DataSet) As Integer

        Dim RowsCount = 0
        If Not ds Is Nothing AndAlso ds.Tables.Count > 0 Then
            RowsCount = ds.Tables(0).Rows.Count
        End If

        Return RowsCount

    End Function






#Region " Get Value Care "





    'Public Shared Function GetQueryString(ByVal name As String) As String

    '    Dim context As HttpContext = HttpContext.Current
    '    If (context.Request.QueryString(name) Is Nothing) Then
    '        Return String.Empty
    '    End If
    '    Return context.Request.QueryString(name)

    'End Function

    'Public Shared Function GetApplicationString(ByVal name As String) As String

    '    Dim context As HttpContext = HttpContext.Current
    '    If (context.Application(name) Is Nothing) Then
    '        Return String.Empty
    '    End If
    '    Return context.Application(name).ToString()

    'End Function

    'Public Shared Function GetSessionString(ByVal name As String) As String

    '    Dim context As HttpContext = HttpContext.Current
    '    If (context.Session(name) Is Nothing) Then
    '        Return String.Empty
    '    End If
    '    Return context.Session(name).ToString()

    'End Function

    'Public Shared Function GetSessionInteger(ByVal name As String) As Integer

    '    Dim context As HttpContext = HttpContext.Current
    '    If (context.Session(name) Is Nothing) Then
    '        Return 0
    '    End If

    '    If (TypeOf (context.Session(name)) Is Integer) Then
    '        Return context.Session(name)
    '    Else
    '        Return Val(context.Session(name).ToString())
    '    End If

    'End Function



    'Public Shared Function GetFirstTableFirstRowString(ByVal ds As DataSet, ByVal name As String) As String

    '    If ds Is Nothing Then
    '        Return String.Empty
    '    End If
    '    If ds.Tables Is Nothing Then
    '        Return String.Empty
    '    End If
    '    If ds.Tables.Count < 1 Then
    '        Return String.Empty
    '    End If
    '    If ds.Tables(0).Rows.Count < 1 Then
    '        Return String.Empty
    '    End If
    '    If Not ds.Tables(0).Columns.Contains(name) Then
    '        Return String.Empty
    '    End If
    '    Return ds.Tables(0).Rows(0)(name).ToString().Trim()

    'End Function

    'Public Shared Function GetDataRowString(ByVal dr As DataRow, ByVal name As String) As String

    '    If dr Is Nothing Then
    '        Return String.Empty
    '    End If
    '    If Not dr.Table.Columns.Contains(name) Then
    '        Return String.Empty
    '    End If
    '    If IsDBNull(dr(name)) Then
    '        Return String.Empty
    '    End If
    '    Return dr(name).ToString()

    'End Function

    'Public Shared Function GetDataRowString(ByVal dr As DataRowView, ByVal name As String, Optional ByVal FormatString As String = "") As String

    '    If Not dr.Row.Table.Columns.Contains(name) Then
    '        Return String.Empty
    '    End If
    '    If IsDBNull(dr.Row(name)) Then
    '        Return String.Empty
    '    End If

    '    If FormatString = "" Then
    '        Return dr.Row(name).ToString()
    '    Else
    '        Return String.Format(FormatString, dr.Row(name))
    '    End If

    'End Function



    'Public Shared Function GetFirstTableLastRowString(ByVal ds As DataSet, ByVal name As String) As String

    '    If ds Is Nothing Then
    '        Return String.Empty
    '    End If
    '    If ds.Tables Is Nothing Then
    '        Return String.Empty
    '    End If
    '    If ds.Tables.Count < 1 Then
    '        Return String.Empty
    '    End If
    '    If ds.Tables(0).Rows.Count < 1 Then
    '        Return String.Empty
    '    End If
    '    If Not ds.Tables(0).Columns.Contains(name) Then
    '        Return String.Empty
    '    End If
    '    Return ds.Tables(0).Rows(ds.Tables(0).Rows.Count - 1)(name).ToString()

    'End Function

    'Public Shared Function GetFirstTableLastRowInteger(ByVal ds As DataSet, ByVal name As String) As Integer

    '    Dim value As Integer = 0
    '    Integer.TryParse(GetFirstTableLastRowString(ds, name), value)
    '    Return value

    'End Function

#End Region



    Public Class Values

        Public Shared Function GetFirstTableRowsCount(ByVal ds As DataSet) As Integer

            If ds Is Nothing Then
                Return 0
            End If
            If ds.Tables Is Nothing Then
                Return 0
            End If
            If ds.Tables.Count < 1 Then
                Return 0
            End If
            Return ds.Tables(0).Rows.Count

        End Function

        Public Shared Function GetFirstTableFirstRowInteger(ByVal ds As DataSet, ByVal name As String) As Integer

            Dim value As Integer = 0
            Integer.TryParse(GetFirstTableFirstRowString(ds, name), value)
            Return value

        End Function

        Public Shared Function GetFirstTableFirstRowString(ByVal ds As DataSet, ByVal name As String, Optional ByVal FormatString As String = "") As String

            If ds Is Nothing Then
                Return String.Empty
            End If
            If ds.Tables Is Nothing Then
                Return String.Empty
            End If
            If ds.Tables.Count < 1 Then
                Return String.Empty
            End If
            If ds.Tables(0).Rows.Count < 1 Then
                Return String.Empty
            End If
            If Not ds.Tables(0).Columns.Contains(name) Then
                Return String.Empty
            End If

            If FormatString = "" Then
                Return ds.Tables(0).Rows(0)(name).ToString().Trim()
            Else
                Return String.Format(FormatString, ds.Tables(0).Rows(0)(name))
            End If

        End Function

        Public Shared Function GetDataRowString(ByVal dr As DataRow, ByVal name As String, Optional ByVal FormatString As String = "") As String

            If dr Is Nothing Then
                Return String.Empty
            End If
            If Not dr.Table.Columns.Contains(name) Then
                Return String.Empty
            End If
            If IsDBNull(dr(name)) Then
                Return String.Empty
            End If

            If FormatString = "" Then
                Return dr(name).ToString().Trim()
            Else
                Return String.Format(FormatString, dr(name)).Trim()
            End If

        End Function

        Public Shared Function GetDataRowInteger(ByVal dr As DataRow, ByVal name As String) As Integer

            Dim value As Integer = 0
            Integer.TryParse(GetDataRowString(dr, name), value)
            Return value

        End Function

        Public Shared Function GetDataRowString(ByVal dr As DataRowView, ByVal name As String, Optional ByVal FormatString As String = "") As String

            If Not dr.Row.Table.Columns.Contains(name) Then
                Return String.Empty
            End If
            If IsDBNull(dr.Row(name)) Then
                Return String.Empty
            End If

            If FormatString = "" Then
                Return dr.Row(name).ToString()
            Else
                Return String.Format(FormatString, dr.Row(name))
            End If

        End Function

        Public Shared Function GetSelectedItemString(ByVal list As DropDownList) As String

            If list Is Nothing Then
                Return String.Empty
            End If
            If list.SelectedItem Is Nothing Then
                Return String.Empty
            End If
            If list.SelectedItem.Value Is Nothing Then
                Return String.Empty
            End If

            Return list.SelectedItem.Value

        End Function

        Public Shared Function GetSelectedItemInteger(ByVal list As DropDownList) As Integer
            Return Integer.Parse("0" + GetSelectedItemString(list))
        End Function

        Public Shared Function GetQueryString(ByVal name As String) As String

            Dim context As HttpContext = HttpContext.Current
            If (context.Request.QueryString(name) Is Nothing) Then
                Return String.Empty
            End If
            Return context.Request.QueryString(name)

        End Function

        Public Shared Function GetApplicationString(ByVal name As String) As String

            Dim context As HttpContext = HttpContext.Current
            If (context.Application(name) Is Nothing) Then
                Return String.Empty
            End If
            Return context.Application(name).ToString()

        End Function

        Public Shared Function GetApplicationInteger(ByVal name As String) As Integer

            Dim ApplicationInteger As Integer = 0
            Integer.TryParse(GetApplicationString(name), ApplicationInteger)
            Return ApplicationInteger

        End Function

        Public Shared Function GetConfigurationString(ByVal name As String) As String

            Dim value As String = ConfigurationSettings.AppSettings(name)
            If (String.IsNullOrEmpty(value)) Then
                Return String.Empty
            Else
                Return value
            End If

        End Function

        Public Shared Function GetConfigurationInteger(ByVal name As String) As Integer

            Dim value As Integer
            If (Integer.TryParse(GetConfigurationString(name), value)) Then
                Return value
            Else
                Return 0
            End If
 
        End Function

        Public Shared Function GetSessionString(ByVal name As String) As String

            Dim context As HttpContext = HttpContext.Current
            If (context.Session(name) Is Nothing) Then
                Return String.Empty
            End If
            Return context.Session(name).ToString()

        End Function

        Public Shared Function GetSessionInteger(ByVal name As String) As Integer

            Dim SessionInteger As Integer = 0
            Integer.TryParse(GetSessionString(name), SessionInteger)
            Return SessionInteger

        End Function

    End Class

    Shared Function GetLong(ByVal value As String) As Long

        Dim ReturnValue As Long = 0
        Long.TryParse(value, ReturnValue)
        Return ReturnValue

    End Function






    Shared Function GetInteger(ByVal value As String) As Integer

        Dim ReturnValue As Integer = 0
        Integer.TryParse(value, ReturnValue)
        Return ReturnValue

    End Function

    Shared Function GetIntegerComboValue(ByVal cbo As DropDownList) As Integer

        Return GetInteger(GetComboValue(cbo))

    End Function

    Shared Function GetYYYYMMDDString(ByVal sDate As String) As String
        If sDate.Length = 10 Then
            Return sDate.Substring(6) & "-" & sDate.Substring(3, 2) & "-" & sDate.Substring(0, 2)
        Else
            Return String.Empty
        End If
    End Function

    Shared Function GetFieldString(ByVal drField As Object) As String
        If IsDBNull(drField) Then
            Return String.Empty
        Else
            Return drField.ToString()
        End If
    End Function

    Shared Function EncryptString(ByVal str As String, Optional ByVal WithUrlEncode As Boolean = True) As String

        If str.Length = 0 Then
            Return str
        End If
        str = cryptComtec.RijndaelSimple.EncryptSimple(str)
        str = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(str))
        If WithUrlEncode Then
            str = System.Web.HttpUtility.UrlEncode(str)
        End If
        Return str

    End Function

    Shared Function DecryptString(ByVal str As String) As String

        If str.Length = 0 Then
            Return str
        End If
        Try
            str = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(str))
            str = cryptComtec.RijndaelSimple.DencryptSimple(str)
        Catch ex As Exception
            str = String.Empty
        End Try
        Return str

    End Function

    Sub SelectPageNoInDataView(ByVal grd As DataGrid, ByVal txtID As System.Web.UI.HtmlControls.HtmlInputHidden)
        Try
            Dim drv As DataRowView
            Dim i As Integer = 0

            Dim dv As DataView = grd.DataSource
            Dim iRowsCount = dv.Count
            Dim iPageIndex As Integer = 0

            If Val(txtID.Value) > 0 And iRowsCount > 0 Then
                For Each drv In dv
                    i = i + 1
                    If drv(grd.DataKeyField).ToString = txtID.Value Then
                        iPageIndex = (i - 1) \ grd.PageSize
                        Exit For
                    End If
                Next
                grd.CurrentPageIndex = iPageIndex
            End If

        Catch ex As Exception
            '
        End Try
    End Sub

    Shared Function sortDataTable(ByVal dTable As DataTable, ByVal sSort As String) As DataView

        Dim dView As New DataView(dTable)
        dView.Sort = sSort
        Return dView
    End Function


    Shared Sub SetDataGridFirstLastPage(ByVal Grid As DataGrid, ByVal Item As DataGridItem)


        If (Item.ItemType = ListItemType.Pager) Then

            Dim PageCount As Integer = Grid.PageCount
            Dim CurrentPage As Integer = Grid.CurrentPageIndex

            If (PageCount > 10) Then

                Dim btnFirst As New LinkButton
                Dim btnLast As New LinkButton

                btnFirst.CommandArgument = "1"
                btnFirst.CommandName = "Page"
                btnFirst.Text = "1"
                btnFirst.Enabled = (CurrentPage >= 10)

                btnLast.CommandArgument = PageCount
                btnLast.CommandName = "Page"
                btnLast.Text = PageCount
                btnLast.Enabled = (CurrentPage < ((PageCount - 1) \ 10) * 10)

                If btnFirst.Enabled Then
                    Item.Cells(0).Controls.AddAt(0, New LiteralControl("&nbsp"))
                    Item.Cells(0).Controls.AddAt(0, btnFirst)
                End If

                If btnLast.Enabled Then
                    Item.Cells(0).Controls.Add(New LiteralControl("&nbsp"))
                    Item.Cells(0).Controls.Add(btnLast)
                End If

            End If

        End If

    End Sub

#Region " Enum Definition "

    Public Enum eRequestActivity As Integer
        eNeverTreat = 1
        eTreatInPast = 2
        eTreatNowByAnotherUser = 3
        eTreatNowByUser = 4
    End Enum

    Public Enum eActivityCode As Integer
        ePaymentsList = 10
        eSupplierPaymentsRequest = 20
        ePaymentsClose = 30

    End Enum

    Public Enum eActivityStartCode As Integer
        eEnterNewClaimShela = 210
        eCheckPaymentsRequest = 220

    End Enum

    Public Enum eActivityEndCode As Integer
        eClickButtonEshur = 110
        eClickButtonDchya = 120
        eClickButtonChazara = 130
        eClickButtonTafrit = 140
        eClickButtonEshurReshumot = 220

    End Enum

    Public Enum enAddReportResult As Integer
        EncryptPwdIsNull = 1
        ConfirmationFailed = 2
        FileExtensionError = 4
        ReminderEmailFailed = 8
        CopyFailed = 16
        DoNotCopyToItself = 32
    End Enum

    Public Enum ReplyPossibility As Integer
        CanNotReply = 0
        CanReply = 1
        EMailReply = 2
    End Enum

    Public Enum OutlookEventType As Integer ' Event Type for sending mails to outlook
        SentFromAdminSiteToRegisteredUser = 1
        SentFromAdminSiteToOccasionalUser = 2
        SentFromUserSiteToRegisteredUser = 3
        SentFromUserSiteToOccasionalUser = 4
        SentFromOutLook = 5
        SentReplyFromOccasionalSite = 6
        SentEntryConfirmationFromOccasionalSite = 7
        SentEntryConfirmation = 8
        SentFromOutlookGrader = 9
        SentFromCopyInfoFiles = 10
    End Enum

    Public Enum Permitions As Integer
        TablesManagment = 1
        UserManagement = 20
        SystemMessagesManagement = 30
        DrawersManagement = 40
        GroupsManagement = 50
        SystemSettings = 60
        InformationSending = 70
        SystemReports = 80
        Archiving = 90
        ArchiveRestoring = 100
    End Enum

#End Region


    Public Shared Function CleanInvalidXmlChars(ByVal text As String) As String
        ' From xml spec valid chars: ' #x9 | #xA | #xD | [#x20-#xD7FF] | [#xE000-#xFFFD] | [#x10000-#x10FFFF]    
        ' any Unicode character, excluding the surrogate blocks, FFFE,and FFFF. 
        'Dim re As String = "[^\x09\x0A\x0D\x20-\xD7FF\xE000-\xFFFD\x10000-x10FFFF]"

        Return text.Replace(Convert.ToChar(26), "")
    End Function

End Class

