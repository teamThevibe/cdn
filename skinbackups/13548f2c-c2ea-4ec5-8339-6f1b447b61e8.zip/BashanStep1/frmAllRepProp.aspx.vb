Public Class frmAllRepProp
    Inherits System.Web.UI.Page
    '! it is not the same as in DistAdminNew, for Elyahu (doar) the form is frmElyahuAllRepProp
#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Dim flagArrayCompare As Boolean = False

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not IsPostBack Then
            Dim strArrayReportsID As String = Request.QueryString("ArrayReportsID")
            Dim objUser As New UserConnect.UserService()
            objUser.Url = Application("UserWebService").ToString()
            Dim strUserID As String = objUser.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", User.Identity.Name)
            Dim strSubUserID As String = Request.QueryString("SubUserID")

            Dim strOriginalReport As String = ""
            Dim strBeforeBody As String = ""
            Dim strInsideBody As String = ""
            Dim strCloseBody As String = ""
            Dim j As Integer = 0
            Dim objReportsList As New ReportConnect.ReportService()
            objReportsList.Url = Application("ReportWebService").ToString()

            If strArrayReportsID <> "" Then

                Dim arrValuesBeforeFiltering() As String = strArrayReportsID.Split(";")

                Dim tmpArray As String = ""

                Dim k As Integer = 0
                For j = 0 To arrValuesBeforeFiltering.Length - 2
                    If LCase(Application("App_Type").ToString()) = "divur" Or LCase(Application("App_Type").ToString()) = "supp" Then

                        If objReportsList.GetActionTypeByRepID("A0B089D7-3A26-4488-AEC4-195CC0C6379D", arrValuesBeforeFiltering(j)) = 0 Then
                            If tmpArray = "" Then
                                tmpArray = arrValuesBeforeFiltering(j) & ";"
                            Else
                                tmpArray = tmpArray + arrValuesBeforeFiltering(j) & ";"
                            End If
                        End If

                    Else

                        If objReportsList.IsReportTypeForDownload("A0B089D7-3A26-4488-AEC4-195CC0C6379D", arrValuesBeforeFiltering(j)) = 0 Then
                            If tmpArray = "" Then
                                tmpArray = arrValuesBeforeFiltering(j) & ";"
                            Else
                                tmpArray = tmpArray + arrValuesBeforeFiltering(j) & ";"
                            End If
                        End If

                    End If
                Next

                UpdateReportsViewState(tmpArray, strUserID, strSubUserID)

                Dim arrValues() As String = tmpArray.Split(";")

                If arrValues.Length = arrValuesBeforeFiltering.Length Then
                    flagArrayCompare = True
                End If

                Response.Buffer = False
                Response.Clear()
                Response.Expires = -1
                Dim sURL As String = ""
                sURL = Request.Url.AbsoluteUri



                Try

                    ' strOriginalReport = objReportsList.GetReportText("0D5DA238-109A-4BD8-86AB-CF395A063297", User.Identity.Name, arrValues(0))
                    strOriginalReport = objReportsList.GetReportTextWithUrl("C3530033-3C9C-434F-8CD7-F67D42727452", User.Identity.Name, arrValues(0), sURL)

                    strBeforeBody = PrepareReportBody(strOriginalReport)
                    strInsideBody = CutReportForLoop(strOriginalReport)

                    Dim i As Integer

                    For i = 1 To arrValues.Length - 2

                        'strOriginalReport = objReportsList.GetReportText("0D5DA238-109A-4BD8-86AB-CF395A063297", User.Identity.Name, arrValues(i))
                        strOriginalReport = objReportsList.GetReportTextWithUrl("C3530033-3C9C-434F-8CD7-F67D42727452", User.Identity.Name, arrValues(i), sURL)
                        strInsideBody = strInsideBody + CutReportForLoop(strOriginalReport)

                    Next

                    strCloseBody = PrepareCloseBody()
                    Response.Write(strBeforeBody + strInsideBody + strCloseBody)

                Catch ex As Exception


                    '
                End Try
                Response.End()
            End If
        End If


    End Sub


    Function PrepareCloseBody() As String

        Dim strAfterInsideBody As String = ""
        If flagArrayCompare = False Then
            strAfterInsideBody = "<script>alert('����� ����� ����� ����� ������');</script></BODY></HTML>"
        Else
            strAfterInsideBody = "</BODY></HTML>"
        End If
        flagArrayCompare = False
        Return strAfterInsideBody

    End Function

    Function PrepareReportBody(ByVal strOriginalReport As String) As String

        Dim strBeforeBody As String = ""
        Dim strBodyAttribute As String = ""
        Dim indexBodyStart As Integer

        Try
            strBodyAttribute = "<BODY BGCOLOR='#FFFFFF' BACKGROUND='' SCROLL='' BGPROPERTIES='fixed' OnLoad='try{ShowActionButtons();}catch(e){}' OnBeforePrint='try{fnBeforePrint();}catch(e){}' OnContextMenu='//return false;' TEXT='#000000' LINK='#000000' VLINK='#000000' ALINK='#000000' LEFTMARGIN='0' TOPMARGIN='0' MARGINWIDTH='' MARGINHEIGHT=''>"
            indexBodyStart = InStr(strOriginalReport, "<BODY", CompareMethod.Text) - 1
            strBeforeBody = strOriginalReport.Substring(0, indexBodyStart)

        Catch ex As Exception

        End Try

        Return strBeforeBody + strBodyAttribute

    End Function

    Function CutReportForLoop(ByVal strOriginalReport As String) As String

        Dim strInsideBody As String = ""
        Dim strForFindInsideBodyIndex As String = ""
        Dim indexBodyStart As Integer
        Dim indexBodyClose As Integer
        Dim indexInsideBody As Integer

        Try
            indexBodyStart = InStr(strOriginalReport, "<BODY", CompareMethod.Text) - 1
            strForFindInsideBodyIndex = strOriginalReport.Substring(indexBodyStart + 1, strOriginalReport.Length - indexBodyStart - 1)
            indexInsideBody = InStr(strForFindInsideBodyIndex, "<", CompareMethod.Text) - 1
            indexInsideBody = indexInsideBody + indexBodyStart + 1
            indexBodyClose = InStr(strOriginalReport, "</BODY>", CompareMethod.Text) - 1
            strInsideBody = strOriginalReport.Substring(indexInsideBody, indexBodyClose - indexInsideBody - 1)

        Catch ex As Exception

        End Try

        Return strInsideBody

    End Function

    Private Sub UpdateReportsViewState(ByVal sReports As String, ByVal strUserID As String, ByVal strSubUserID As String)
        Dim objReportsList As New ReportConnect.ReportService()
        objReportsList.Url = Application("ReportWebService").ToString()

        If sReports <> "" Then
            Dim arrRep() As String = Split(sReports, ";")
            Dim sRepID As String
            For Each sRepID In arrRep
                If IsNumeric(sRepID) Then
                    Dim iReportID As Integer = CInt(sRepID)
                    If Application("App_Type").ToString = "dist" Then
                        objReportsList.UpdateReportViewState("EB917314-AEB1-4F8D-A436-E7797568FD53", iReportID, CInt(strUserID), CInt(strUserID), User.Identity.Name)
                    Else
                        objReportsList.UpdateReportViewState("EB917314-AEB1-4F8D-A436-E7797568FD53", iReportID, CInt(strUserID), CInt(strSubUserID), User.Identity.Name)
                    End If
                End If
            Next
        End If
    End Sub

End Class
