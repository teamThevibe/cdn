﻿Imports System.IO
Imports System.Text
Imports System.Text.RegularExpressions

Partial Public Class frmHDRequestb
    Inherits System.Web.UI.Page
    Protected WithEvents hidClinicNumber As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidDoctorCareNumber As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidInsuredNo As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidPolicy As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidWorkerID As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidInsuredFamily As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidInsuredName As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidRequestType As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidFromTooth As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidToTooth As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidCareType As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidOccasion As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidCLV As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidB As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidLP As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidD As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidO As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidM As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidDate As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidInvoiceID As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidSum As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidClaimID As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidNote As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidPan As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidStatus As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidFace As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidReferenceIDFromRequest As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidRequestIDFromRequest As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidReference2000 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidReference2000Bashan As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidReference2000Type As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidCareGroupID As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidGovTreatmentID As System.Web.UI.HtmlControls.HtmlInputHidden


    Protected WithEvents hidAnswer As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidReturnValue As System.Web.UI.HtmlControls.HtmlInputHidden

    Protected WithEvents lstAttachmentType1 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstAttachmentType2 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstAttachmentType3 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstAttachmentType4 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstAttachmentType5 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstAttachmentType6 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstAttachmentType7 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstAttachmentType8 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstAttachmentType9 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstAttachmentType10 As System.Web.UI.WebControls.DropDownList

    Protected WithEvents fileToUpload1 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents fileToUpload2 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents fileToUpload3 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents fileToUpload4 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents fileToUpload5 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents fileToUpload6 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents fileToUpload7 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents fileToUpload8 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents fileToUpload9 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents fileToUpload10 As System.Web.UI.HtmlControls.HtmlInputFile

    Protected WithEvents txtExistAttNo1 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistAttNo2 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistAttNo3 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistAttNo4 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistAttNo5 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistAttNo6 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistAttNo7 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistAttNo8 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistAttNo9 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistAttNo10 As System.Web.UI.HtmlControls.HtmlInputHidden

    Protected WithEvents txtExistRecNo1 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistRecNo2 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistRecNo3 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistRecNo4 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistRecNo5 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistRecNo6 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistRecNo7 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistRecNo8 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistRecNo9 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistRecNo10 As System.Web.UI.HtmlControls.HtmlInputHidden

    Protected WithEvents txtFileTitle1 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFileTitle2 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFileTitle3 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFileTitle4 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFileTitle5 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFileTitle6 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFileTitle7 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFileTitle8 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFileTitle9 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFileTitle10 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents verofbrowser As Global.System.Web.UI.HtmlControls.HtmlInputHidden



#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Public OK As String = "false"
    'Dim arrIndexTranslate As Integer() = {7, 6, 5, 4, 3, 2, 1, 0, 8, 9, 10, 11, 12, 13, 14, 15, 23, 22, 21, 20, 19, 18, 17, 16, 24, 25, 26, 27, 28, 29, 30, 31}
    Dim arrIndexTranslate As Integer() = {7, 6, 5, 4, 3, 2, 1, 0, 8, 9, 10, 11, 12, 13, 14, 15, 23, 22, 21, 20, 19, 18, 17, 16, 24, 25, 26, 27, 28, 29, 30, 31, 39, 38, 37, 36, 35, 34, 33, 32, 40, 41, 42, 43, 44, 45, 46, 47, 55, 54, 53, 52, 51, 50, 49, 48, 56, 57, 58, 59, 60, 61, 62, 63}

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim strInsuredID As String = hidInsuredNo.Value
        Dim bAllowSendFiles As Boolean = True
        hidAnswer.Value = String.Empty
        RequestIDs.Value = String.Empty
        Dim s As String = ""
        With Request.Browser
            s &= "Browser Capabilities" & vbCrLf
            s &= "Type = " & .Type & vbCrLf
            s &= "Name = " & .Browser & vbCrLf
            s &= "Version = " & .Version & vbCrLf
            s &= "Major Version = " & .MajorVersion & vbCrLf
            s &= "Minor Version = " & .MinorVersion & vbCrLf
            s &= "Platform = " & .Platform & vbCrLf
            s &= "Is Beta = " & .Beta & vbCrLf
            s &= "Is Crawler = " & .Crawler & vbCrLf
            s &= "Is AOL = " & .AOL & vbCrLf
            s &= "Is Win16 = " & .Win16 & vbCrLf
            s &= "Is Win32 = " & .Win32 & vbCrLf
            s &= "Supports Frames = " & .Frames & vbCrLf
            s &= "Supports Tables = " & .Tables & vbCrLf
            ' ''s &= "Supports Cookies = " & .Cookies & vbCrLf
            ' ''s &= "Supports VBScript = " & .VBScript & vbCrLf
            ' s &= "Supports JavaScript = " & _
            '     .EcmaScriptVersion.ToString() & vbCrLf
            ' s &= "Supports Java Applets = " & .JavaApplets & vbCrLf
            's &= "Supports ActiveX Controls = " & .ActiveXControls & _
            'vbCrLf
            ' s &= "Supports JavaScript Version = " & _
            ' Request.Browser("JavaScriptVersion") & vbCrLf
        End With
        verofbrowser.Value = s

        ' YT:
        If (hidToTooth.Value.Trim() = "0") Then
            hidToTooth.Value = String.Empty
        End If

        If IsPostBack Then
            Dim iMaxSize As Integer
            If IsNumeric(Session("UploadFileSize").ToString()) Then
                iMaxSize = Val(Session("UploadFileSize").ToString())
                If iMaxSize = 0 Then
                    bAllowSendFiles = False
                    ' hidReturnValue.Value = "-1"
                    'Return
                End If
            Else
                bAllowSendFiles = False
                ' hidReturnValue.Value = "-1"
                'Return
            End If
            Dim iRetValue As Integer = CheckAllFiles(iMaxSize)
            If iRetValue = 2 Then
                If bAllowSendFiles Then
                    hidAnswer.Value = "ניתן לצרף קבצים עד גודל " & CStr(iMaxSize / 1024) & "K!" & "  יש לשייך הנספחים מחדש  "
                Else
                    hidAnswer.Value = "אינך מורשה לצרף קבצים. נא פנה למנהל המערכת."
                End If

                iRetValue = 0
            ElseIf iRetValue = 1 Then
                hidAnswer.Value = "קובץ לא קיים"
                iRetValue = 0
                'ElseIf iRetValue = 3 Then
                '    hidAnswer.Value = "פורמט הנספח אינו חוקי"
                '    iRetValue = 0
            ElseIf iRetValue = 3 Then
                hidAnswer.Value = "קובץ לא חוקי"
                iRetValue = 0
            Else
                Dim bValidDate As Boolean = False
                Dim strTemDate As String = hidDate.Value
                If strTemDate <> "00000000" And strTemDate <> "" Then
                    strTemDate = Mid(strTemDate, 5, 4) & "-" & Mid(strTemDate, 3, 2) & "-" & Left(strTemDate, 2)
                    If IsDate(strTemDate) Then
                        bValidDate = True
                    End If
                End If
                If Not bValidDate And hidRequestType.Value = "0" Then
                    hidAnswer.Value = "תאריך גמר טיפול לא חוקי"
                    iRetValue = 0
                Else
                    Dim strFirstName As String = ""
                    Dim strLastName As String = ""
                    Dim strPolicyNo As String = ""
                    Dim strEmployeeNo As String = ""
                    Dim strEmpCD As String = ""
                    Dim objTreatmentService As New TreatmentConnect.TreatmentService()
                    objTreatmentService.Url = Application("TreatmentWebService").ToString()
                    If Application("Smile") = "1" Then
                        If hidRequestType.Value <> "9" Then
                            If Session("Smile_Porshei_Personel") = "1" Then
                                objTreatmentService.GetInsuredProp("5E25C46A-EADC-4C27-8A5A-DB8B13E129D3", Val(hidInsuredNo.Value), strFirstName, strLastName, strPolicyNo, strEmployeeNo, strEmpCD)
                                If strPolicyNo = "1015" Then
                                    If strFirstName = "" Then
                                        strFirstName = "א"
                                    End If
                                    strInsuredID = hidInsuredNo.Value
                                    hidPolicy.Value = strPolicyNo
                                Else
                                    strFirstName = ""
                                    strLastName = ""
                                End If
                            Else
                                Dim objRequest As New SmileConnector.SmileConnector
                                objRequest.Url = Application("SmileWebService")
                                Dim ds As DataSet
                                If Session("Smile_ShilaWorker") = "1" Then
                                    ds = objRequest.GetShilaEmployeeProp("60DED06E-37E5-45DE-9857-F61842C9CBC4", Val(hidInsuredNo.Value))
                                    hidPolicy.Value = Session("Smile_Policy")
                                Else
                                    ds = objRequest.GetLastAnswer("FF971BAA-4E34-4DCE-ABEF-27191AAF2C79", User.Identity.Name, Session("User_Password"), Val(hidInsuredNo.Value))
                                End If
                                If Not ds Is Nothing Then
                                    If ds.Tables(0).Rows.Count > 0 Then
                                        Dim objRow As DataRow = ds.Tables(0).Rows(0)
                                        strFirstName = Trim(objRow("InsuredFName").ToString())
                                        strLastName = Trim(objRow("InsuredLName").ToString())
                                        If strFirstName = "" Then
                                            strFirstName = "א"
                                        End If
                                    End If
                                End If
                            End If
                        End If
                    Else
                        If Application("CompanyID").ToString = "3" Then
                            strFirstName = Session("MRequest_InsuredName")
                            strLastName = Session("MRequest_InsuredFamily")
                            If hidRequestType.Value <> "9" Then
                                strInsuredID = Session("Leumit_CrntInsuredID")
                            Else
                                strInsuredID = hidInsuredNo.Value
                            End If
                        Else
                            objTreatmentService.GetInsuredProp("5E25C46A-EADC-4C27-8A5A-DB8B13E129D3", hidInsuredNo.Value, strFirstName, strLastName, strPolicyNo, strEmployeeNo, strEmpCD)
                            If UCase(Trim(strLastName)) = "ERROR" Then
                                objTreatmentService.GetSQLInsuredProp("6C865031-52E9-4422-950B-615B8F84600C", hidInsuredNo.Value, strFirstName, strLastName)
                            End If
                            strInsuredID = hidInsuredNo.Value

                        End If
                    End If

                    If Val(strInsuredID) < 1 Then
                        hidAnswer.Value = "תקלה בקליטת פרטי פניה"
                        iRetValue = 0
                    Else
                        Dim str2Chars As String = Left(strLastName, 2)
                        Dim str2FNChars As String = Left(strFirstName, 2)
                        iRetValue = 1
                        If hidRequestType.Value <> "9" Then
                            If str2Chars = "" Or str2FNChars = "" Then
                                hidAnswer.Value = "בחברת הביטוח לא נמצא מבוטח פעיל המתאים לפרטים שהוזנו"
                                iRetValue = 0
                            Else
                                If Regex.IsMatch(Mid(str2Chars, 2, 1), "[א-תa-zA-Z]") Then
                                    If str2Chars <> Left(hidInsuredFamily.Value, 2) Then
                                        hidAnswer.Value = "בחברת הביטוח לא נמצא מבוטח פעיל המתאים לפרטים שהוזנו"
                                        iRetValue = 0
                                    End If
                                Else
                                    If Left(str2Chars, 1) <> Left(hidInsuredFamily.Value, 1) Then
                                        hidAnswer.Value = "בחברת הביטוח לא נמצא מבוטח פעיל המתאים לפרטים שהוזנו"
                                        iRetValue = 0
                                    End If
                                End If
                                If Regex.IsMatch(Mid(str2FNChars, 2, 1), "[א-תa-zA-Z]") Then
                                    If str2FNChars <> Left(hidInsuredName.Value, 2) Then
                                        hidAnswer.Value = "בחברת הביטוח לא נמצא מבוטח פעיל המתאים לפרטים שהוזנו"
                                        iRetValue = 0
                                    End If
                                Else
                                    If Left(str2FNChars, 1) <> Left(hidInsuredName.Value, 1) Then
                                        hidAnswer.Value = "בחברת הביטוח לא נמצא מבוטח פעיל המתאים לפרטים שהוזנו"
                                        iRetValue = 0
                                    End If
                                End If
                            End If
                        End If
                    End If

                    If iRetValue > 0 Then
                        If Session("Leumit_CollectionProblem") = "1" Then
                            Dim dsTreatment As DataSet = objTreatmentService.GetTreatmentByTreatmentID("CA459EC9-0EC6-42AD-AA10-72A5E50FEDB4", Val(hidCareType.Value))
                            Dim iServiceBasket As Integer = Val(dsTreatment.Tables(0).Rows(0)("ServiceBasket").ToString())

                            If iServiceBasket <> 1 Then
                                hidAnswer.Value = "אין אפשרות להעניק טיפול שאינו בסל הטיפולים.<BR>נא לפנות לקופת חולים לאומית על מנת להסדיר חוב כספי לקופה."
                                iRetValue = 0
                            End If
                        End If
                    End If


                    If iRetValue > 0 Then

                        If IsNumeric(hidFromTooth.Value) Then
                            Dim ds As Data.DataSet = objTreatmentService.GetTeethRange("DAD91AA1-DE6F-4C28-8A11-CB0FF79BD302", Val(hidCareType.Value))
                            Dim objColl As DataRow() = ds.Tables(0).Select("FromTooth=88")
                            If ds.Tables(0).Rows.Count = 1 And objColl.Length > 0 Then
                                hidToTooth.Value = ""
                                If hidFromTooth.Value <> "88" Then
                                    hidAnswer.Value = "עבור הטיפול שנבחר שדה 'משן' חייב להכיל ערך 88"
                                    iRetValue = 0
                                End If
                            End If
                            If iRetValue > 0 Then
                                If Not ValidateTooth(CInt(hidFromTooth.Value), ds) Then
                                    hidAnswer.Value = "בחירת השיניים לא מתאימה לטיפול"
                                    iRetValue = 0
                                End If
                                If iRetValue > 0 And IsNumeric(hidToTooth.Value) Then
                                    objColl = ds.Tables(0).Select("AllowTeethRange=1")
                                    'If objColl.Length = 0 And CInt(hidFromTooth.Value) <> CInt(hidToTooth.Value) Then
                                    '    hidAnswer.Value = "עבור הטיפול שנבחר לא ניתן לציין תחום שיניים"
                                    '    iRetValue = 0
                                    'End If
                                    If iRetValue > 0 Then
                                        If Not ValidateTooth(CInt(hidToTooth.Value), ds) Then
                                            hidAnswer.Value = "ערך בשדה 'עד שן' לא חוקי"
                                            iRetValue = 0
                                        Else
                                            If CInt(hidToTooth.Value) < CInt(hidFromTooth.Value) Then
                                                hidAnswer.Value = "ערך בשדה 'עד שן' לא חוקי"
                                                iRetValue = 0
                                            Else
                                                If (CInt(hidFromTooth.Value) < 50) And (CInt(hidToTooth.Value) > 50) Then
                                                    hidAnswer.Value = "לא חוקי תחום שיניים"
                                                    iRetValue = 0
                                                End If
                                            End If
                                        End If
                                    End If
                                End If
                            End If
                        Else
                            hidAnswer.Value = "בחירת השיניים לא מתאימה לטיפול"
                            iRetValue = 0
                        End If
                    End If
                    Dim objUser As New UserConnect.UserService()
                    objUser.Url = Application("UserWebService").ToString()
                    Dim iDoctorType As Integer = objUser.GetUserDoctorType("C049B33B-243D-43C1-B2F5-AB4859F9EBD1", User.Identity.Name)
                    '''''''''''Dim iDoctorType As Integer = objUser.GetHDUserDoctorType("0B776BB2-51E1-11E4-8E10-7F911D5D46B0", User.Identity.Name)
                    If iDoctorType <> 3 Then
                        If hidDoctorCareNumber.Value = "" Or hidDoctorCareNumber.Value = "0" Then
                            hidAnswer.Value = "חובה לבחור רופא מטפל עם מספר רשיון במשרד הבריאות"
                            iRetValue = 0
                        End If
                    End If
                    If iRetValue > 0 Then ' !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! todo
                        Dim strSurface As String = Trim(hidM.Value)
                        strSurface = strSurface & Trim(hidO.Value)
                        strSurface = strSurface & Trim(hidD.Value)
                        strSurface = strSurface & Trim(hidLP.Value)
                        strSurface = strSurface & Trim(hidB.Value)
                        strSurface = strSurface & Trim(hidCLV.Value)
                        Dim bNote As Boolean = False
                        If Trim(hidNote.Value) <> "" Then
                            bNote = True
                        End If
                        Dim iInitValue As Integer = 0
                        If hidCareGroupID.Value = "4" And hidRequestType.Value = "4" And hidReference2000.Value <> "" Then
                            iInitValue = 1
                        End If
                        Dim strAttach As String = CStr(GetAttachValue(bNote, iInitValue))
                        Dim strXRayExist As String = CStr(CheckXrayExist())
                        Dim iXRayAttach As Integer
                        If CheckXrayAttach() Then
                            iXRayAttach = 1
                        Else
                            iXRayAttach = 0
                        End If
                        Dim strReferenceID As String = String.Empty
                        If Application("BSHN_WorkerIDRequired").ToString() <> "1" Then
                            If Not IsNumeric(hidPolicy.Value) Then
                                hidPolicy.Value = "0"
                            End If
                        End If
                        Dim strTempParameter1 As String, strTempParameter2 As String, strTempParameter3 As String, strTempParameter4 As String, strTempParameter5 As String, strUncomplitedReference As String
                        Dim strUserName As String
                        Dim iT0 As Integer = 0
                        If IsNumeric(hidToTooth.Value) Then
                            iT0 = CInt(hidToTooth.Value)
                        End If
                        strUncomplitedReference = objTreatmentService.CheckBashanRequestUncomplitedToday("6F0D5701-D25A-470D-B453-68F70079F993", Val(strInsuredID), hidClinicNumber.Value, hidRequestType.Value, Val(hidCareType.Value), Val(hidFromTooth.Value), iT0, hidDate.Value, strSurface, User.Identity.Name, Val(hidRequestIDFromRequest.Value))
                        If strUncomplitedReference <> "" Then
                            Dim strR1 As String = "קיימת כבר פניה זהה ביומן"
                            Dim strR2 As String = "   מספר אסמכתא: " & strUncomplitedReference
                            Dim strR3 As String = "   השליחה לא בוצעה"
                            hidAnswer.Value = strR1 & vbCrLf & strR2 & vbCrLf & strR3
                            hidReturnValue.Value = "-2"
                            Return
                        End If
                        If hidRequestType.Value = "9" Then
                            If hidClaimID.Value <> "" Then
                                Dim dsAnswers As DataSet = objTreatmentService.GetInsuredPropByReference("C202994D-651F-4D03-8917-C59B30D590A7", hidClaimID.Value, strTempParameter1, strTempParameter2, strTempParameter3, strTempParameter4, strTempParameter5)
                                If dsAnswers.Tables("Requests").Rows.Count < 1 Then
                                    hidAnswer.Value = "מספר האסמכתא שהוזן אינו נמצא ברשימת הפניות שהוגשו על ידך"
                                    hidReturnValue.Value = 0
                                    Return
                                Else
                                    strUserName = dsAnswers.Tables("Requests").Rows(0)("UserName")
                                    'If Application("CompanyID").ToString = "0" Then
                                    Dim strTmpClinicNo As String = dsAnswers.Tables("Requests").Rows(0)("ClinicNo")
                                    If strTmpClinicNo <> hidClinicNumber.Value Then
                                        hidAnswer.Value = "מספר האסמכתא שהוזן אינו נמצא ברשימת הפניות שהוגשו על ידך"
                                        hidReturnValue.Value = 0
                                        Return
                                    End If
                                    'Else
                                    '    If strUserName.ToUpper() <> User.Identity.Name.ToUpper() Then
                                    '        hidAnswer.Value = "מספר האסמכתא שהוזן אינו נמצא ברשימת הפניות שהוגשו על ידך"
                                    '        hidReturnValue.Value = 0
                                    '        Return
                                    '    End If
                                    'End If
                                    'Dim iCheckRequestBashanForUpdate As Integer = objTreatmentService.CheckRequestBashanForUpdate("42EDCD7F-EEB3-4150-A559-E6F77F37DFE0", hidClaimID.Value, hidFromTooth.Value, Val(hidToTooth.Value), hidCareType.Value, hidDate.Value)
                                    Dim iCheckRequestBashanForUpdate As Integer = objTreatmentService.CheckRequestBashanForUpdateExt("2A3A7421-0324-4DFC-BF8E-7CDFF88C05ED", hidClaimID.Value, hidFromTooth.Value, Val(hidToTooth.Value), hidCareType.Value, hidDate.Value, hidInvoiceID.Value, hidSum.Value)
                                    If iCheckRequestBashanForUpdate <> 1 And strAttach = "0" Then
                                        If iCheckRequestBashanForUpdate = -1 Then
                                            hidAnswer.Value = "הבירור מיותר. נתוניו זהים לנתוני הפניה "
                                        Else
                                            hidAnswer.Value = "הבירור לפניה כבר שודר בעבר"
                                        End If
                                        hidReturnValue.Value = 0
                                        Return
                                    End If

                                    Dim iFromTooth As Integer, iToTooth As Integer
                                    Dim iTeethChanged As Integer
                                    iFromTooth = Val(hidFromTooth.Value)
                                    iToTooth = Val(hidToTooth.Value)

                                    If iToTooth > 0 And iToTooth > iFromTooth Then
                                        iTeethChanged = objTreatmentService.CheckTeethChanged("C28507DA-1990-46AE-9370-923809867C5B", hidClaimID.Value, hidFromTooth.Value, hidToTooth.Value, hidCareType.Value)
                                        If iTeethChanged = 0 Then
                                            hidToTooth.Value = hidFromTooth.Value
                                        End If
                                    End If


                                End If
                            Else
                                hidAnswer.Value = "חסר נתונים בשדה אסמכתא לבירור"
                                hidReturnValue.Value = 0
                                Return
                            End If
                        Else
                            If hidRequestType.Value = "4" Then
                                Dim strAnswer As String = ""
                                Dim strErrTeeth As String = ""
                                Dim i As Integer, iFromTooth As Integer, iToTooth As Integer, iTreatmentValue As Integer, iArrIndex1 As Integer, iArrIndex2 As Integer
                                Dim arrToothCheck(64) As ArrayList
                                For i = 0 To 63
                                    arrToothCheck(i) = New ArrayList()
                                Next
                                iFromTooth = CInt(hidFromTooth.Value)
                                If IsNumeric(hidToTooth.Value) Then
                                    iToTooth = CInt(hidToTooth.Value)
                                Else
                                    iToTooth = 0
                                End If

                                iTreatmentValue = CInt(hidCareType.Value)
                                Select Case iFromTooth
                                    Case 91
                                        iFromTooth = 14
                                        iToTooth = 18
                                    Case 92
                                        iFromTooth = 13
                                        iToTooth = 23
                                    Case 93
                                        iFromTooth = 24
                                        iToTooth = 28
                                    Case 94
                                        iFromTooth = 34
                                        iToTooth = 38
                                    Case 95
                                        iFromTooth = 33
                                        iToTooth = 43
                                    Case 96
                                        iFromTooth = 44
                                        iToTooth = 48
                                    Case 97
                                        iFromTooth = 18
                                        iToTooth = 28
                                    Case 98
                                        iFromTooth = 38
                                        iToTooth = 48
                                    Case Else
                                        'If iFromTooth > 50 And iFromTooth < 88 Then
                                        '	iFromTooth = iFromTooth - 40
                                        'End If
                                        If iToTooth = 0 Then
                                            iToTooth = iFromTooth
                                            'Else
                                            '	If iToTooth > 50 And iToTooth < 88 Then
                                            '		iToTooth = iToTooth - 40
                                            '	End If
                                        End If
                                End Select
                                If iFromTooth = 88 Or iFromTooth = 0 Then
                                    iArrIndex1 = 0
                                    iArrIndex2 = 63
                                Else
                                    iArrIndex1 = arrIndexTranslate(Convert.ToInt16(CStr(iFromTooth - 11), 8))
                                    iArrIndex2 = arrIndexTranslate(Convert.ToInt16(CStr(iToTooth - 11), 8))
                                    i = iArrIndex1
                                    iArrIndex1 = Math.Min(iArrIndex1, iArrIndex2)
                                    iArrIndex2 = Math.Max(i, iArrIndex2)
                                End If
                                For i = iArrIndex1 To iArrIndex2
                                    arrToothCheck(i).Add(iTreatmentValue)
                                Next
                                Dim ds As DataSet = objTreatmentService.GetRequestBashanByInsured("63D49E2C-45CA-4515-8BC6-18443DA7C62A", Val(strInsuredID), User.Identity.Name, 4)
                                'Dim ds As DataSet = objTreatmentService.GetRequestBashanByInsuredWithTreatmentsSeries("9934CE93-2C00-4360-8B3F-3EDA0359A7AF", Val(strInsuredID), User.Identity.Name, 4, Val(Application("CompanyID")), 1)
                                Dim currRow As DataRow
                                iRetValue = 1
                                Dim bCheckPrevConsultation As Boolean
                                bCheckPrevConsultation = objTreatmentService.CheckPrevConsultation("2D10EF59-136F-4797-A214-BF147050EC64", Val(strPolicyNo))

                                For Each currRow In ds.Tables(0).Rows
                                    iTreatmentValue = CType(currRow("Treatment"), Integer)
                                    iFromTooth = CType(currRow("FTooth"), Integer)
                                    'If iFromTooth > 50 And iFromTooth < 88 Then
                                    '    iFromTooth = iFromTooth - 40
                                    'End If
                                    Select Case iFromTooth
                                        Case 91
                                            iFromTooth = 14
                                            iToTooth = 18
                                        Case 92
                                            iFromTooth = 13
                                            iToTooth = 23
                                        Case 93
                                            iFromTooth = 24
                                            iToTooth = 28
                                        Case 94
                                            iFromTooth = 34
                                            iToTooth = 38
                                        Case 95
                                            iFromTooth = 33
                                            iToTooth = 43
                                        Case 96
                                            iFromTooth = 44
                                            iToTooth = 48
                                        Case 97
                                            iFromTooth = 18
                                            iToTooth = 28
                                        Case 98
                                            iFromTooth = 38
                                            iToTooth = 48
                                        Case Else
                                            If Not IsDBNull(currRow("ToTooth")) Then

                                                If CInt(currRow("ToTooth")) > 0 Then

                                                    iToTooth = CType(currRow("ToTooth"), Integer)
                                                    'If iToTooth > 50 And iToTooth < 88 Then
                                                    '    iToTooth = iToTooth - 40
                                                    'End If

                                                Else
                                                    iToTooth = iFromTooth
                                                End If

                                            Else
                                                iToTooth = iFromTooth
                                            End If
                                    End Select

                                    If bCheckPrevConsultation Then
                                        If TestOldRow(iTreatmentValue, iFromTooth, iToTooth, arrToothCheck, strAnswer, strErrTeeth) = 0 Then
                                            iRetValue = 0
                                        End If
                                    End If

                                Next
                                If iRetValue = 0 Then
                                    hidAnswer.Value = strAnswer
                                    hidReturnValue.Value = "-2"
                                    Return
                                End If
                            Else
                                strReferenceID = objTreatmentService.CheckBashanRequest("F0E3C31A-7E2B-410B-83D2-94164EEED734", Val(strInsuredID), hidClinicNumber.Value, hidRequestType.Value, Val(hidCareType.Value), Val(hidFromTooth.Value), iT0, hidDate.Value, strSurface, User.Identity.Name)
                                If strReferenceID <> "" Then
                                    Dim strT1 As String
                                    Dim dsTempAnswers As DataSet = objTreatmentService.GetInsuredPropByReference("C202994D-651F-4D03-8917-C59B30D590A7", strReferenceID, strTempParameter1, strTempParameter2, strTempParameter3, strTempParameter4, strTempParameter5)
                                    If dsTempAnswers.Tables(0).Rows.Count > 0 Then
                                        Dim rTemp As DataRow = dsTempAnswers.Tables(0).Rows(0)
                                        strT1 = " דווח על ביצוע הטיפול בתאריך" & " " & Format(rTemp("EntryDate"), "dd/MM/yyyy")
                                    Else
                                        strT1 = ": דווח על ביצוע הטיפול "
                                    End If
                                    Dim strT2 As String = "   מספר אסמכתא: " & strReferenceID
                                    Dim strT3 As String = "   השליחה לא בוצעה"
                                    hidAnswer.Value = strT1 & vbCrLf & strT2 & vbCrLf & strT3
                                    hidReturnValue.Value = "-2"
                                    Return
                                End If
                            End If
                        End If
                        Dim iExtError As Integer = 0
                        If Application("Smile") = "1" Or Application("CompanyID").ToString = "3" Then
                            strFirstName = hidInsuredName.Value
                            strLastName = hidInsuredFamily.Value
                        End If

                        ' Save each tooth separately
                        'Dim Translator As Integer() = {28, 27, 26, 25, 24, 23, 22, 21, 11, 12, 13, 14, 15, 16, 17, 18, 38, 37, 36, 35, 34, 33, 32, 31, 41, 42, 43, 44, 45, 46, 47, 48, 65, 64, 63, 62, 61, 51, 52, 53, 54, 55, 75, 74, 73, 72, 71, 81, 82, 83, 84, 85, 88}
                        'If (hidFromTooth.Value = "88") Then
                        '    hidToTooth.Value = "88"
                        'End If

                        'Dim TranslatorU As Integer = GetIndex(Translator, hidFromTooth.Value)
                        'Dim TranslatorD As Integer = GetIndex(Translator, hidToTooth.Value)

                        'If TranslatorD < 0 Then
                        '    TranslatorD = TranslatorU
                        'End If
                        'If TranslatorU < 0 Then
                        '    TranslatorU = TranslatorD
                        'End If

                        'Dim iRequestID As Integer
                        'Dim indexCounter As Integer = 0
                        'For index As Integer = Math.Min(TranslatorD, TranslatorU) To Math.Max(TranslatorD, TranslatorU)
                        '    iRequestID = objTreatmentService.PutRequestExt("566674D8-B52B-40DA-A06C-0FFE34F54948", _
                        '            User.Identity.Name, _
                        '            hidClinicNumber.Value, _
                        '            hidDoctorCareNumber.Value, _
                        '            Val(strInsuredID), _
                        '            Val(hidPolicy.Value), _
                        '            hidWorkerID.Value, _
                        '            "0", _
                        '            strLastName, _
                        '            strFirstName, _
                        '            hidRequestType.Value, _
                        '            Translator(index).ToString, _
                        '            Translator(index).ToString, _
                        '            Val(hidCareType.Value), _
                        '            hidOccasion.Value, _
                        '            strSurface, _
                        '            hidDate.Value, _
                        '            hidInvoiceID.Value, _
                        '            hidSum.Value, _
                        '            hidClaimID.Value, _
                        '            "5", _
                        '            "ש", _
                        '            strAttach, _
                        '            strXRayExist, _
                        '            hidNote.Value, _
                        '            iXRayAttach, _
                        '            1, _
                        '            strReferenceID, _
                        '            hidGovTreatmentID.Value)
                        '    RequestIDs.Value += String.Format("{0}{1}", IIf(indexCounter = 0, "", ","), iRequestID)
                        '    indexCounter += 1
                        'Next

                        Dim iRequestID As Integer = objTreatmentService.PutRequestExt("566674D8-B52B-40DA-A06C-0FFE34F54948", _
                                                        User.Identity.Name, _
                                                        hidClinicNumber.Value, _
                                                        hidDoctorCareNumber.Value, _
                                                        Val(strInsuredID), _
                                                        Val(hidPolicy.Value), _
                                                        hidWorkerID.Value, _
                                                        "0", _
                                                        strLastName, _
                                                        strFirstName, _
                                                        hidRequestType.Value, _
                                                        hidFromTooth.Value, _
                                                        hidToTooth.Value, _
                                                        Val(hidCareType.Value), _
                                                        hidOccasion.Value, _
                                                        strSurface, _
                                                        hidDate.Value, _
                                                        hidInvoiceID.Value, _
                                                        hidSum.Value, _
                                                        hidClaimID.Value, _
                                                        "5", _
                                                        "ש", _
                                                        strAttach, _
                                                        strXRayExist, _
                                                        hidNote.Value, _
                                                        iXRayAttach, _
                                                        1, _
                                                        strReferenceID, _
                                                        hidGovTreatmentID.Value)
                        RequestIDs.Value = iRequestID.ToString()

                        If (strReferenceID <> "") And (iRequestID > 0) Then
                            ' Возможно, я хотел не добавить, а изменить строку (из йомана); В этом случае удаляю старую строку:
                            If Not String.IsNullOrEmpty(hidRequestIDFromRequest.Value) Then
                                Dim DelRequestBashanInWork As Boolean = objTreatmentService.DelRequestBashanInWork("1BE727A9-81B3-44FF-968A-A68E73ED8B95", hidRequestIDFromRequest.Value, Val(strInsuredID), User.Identity.Name)
                            End If

                            hidReferenceIDFromRequest.Value = strReferenceID
                            hidRequestIDFromRequest.Value = iRequestID
                            hidInsuredFamily.Value = strLastName
                            hidInsuredName.Value = strFirstName
                            If objTreatmentService.ArchiveRequest("170BA2F5-EC88-4190-A495-E97E3CB68F13", User.Identity.Name, iRequestID, Val(strInsuredID), Val(hidPolicy.Value), strReferenceID, Val(hidFromTooth.Value), hidClaimID.Value, Val(strXRayExist), hidDate.Value) Then
                                iRetValue = 1
                                If iXRayAttach > 0 Then
                                    iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType1"), objTreatmentService, fileToUpload1, txtExistAttNo1, txtExistRecNo1, iExtError)
                                    If iRetValue > 0 Then
                                        iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType2"), objTreatmentService, fileToUpload2, txtExistAttNo2, txtExistRecNo2, iExtError)
                                    End If
                                    If iRetValue > 0 Then
                                        iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType3"), objTreatmentService, fileToUpload3, txtExistAttNo3, txtExistRecNo3, iExtError)
                                    End If
                                    If iRetValue > 0 Then
                                        iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType4"), objTreatmentService, fileToUpload4, txtExistAttNo4, txtExistRecNo4, iExtError)
                                    End If
                                    If iRetValue > 0 Then
                                        iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType5"), objTreatmentService, fileToUpload5, txtExistAttNo5, txtExistRecNo5, iExtError)
                                    End If
                                    If iRetValue > 0 Then
                                        iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType6"), objTreatmentService, fileToUpload6, txtExistAttNo6, txtExistRecNo6, iExtError)
                                    End If
                                    If iRetValue > 0 Then
                                        iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType7"), objTreatmentService, fileToUpload7, txtExistAttNo7, txtExistRecNo7, iExtError)
                                    End If
                                    If iRetValue > 0 Then
                                        iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType8"), objTreatmentService, fileToUpload8, txtExistAttNo8, txtExistRecNo8, iExtError)
                                    End If
                                    If iRetValue > 0 Then
                                        iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType9"), objTreatmentService, fileToUpload9, txtExistAttNo9, txtExistRecNo9, iExtError)
                                    End If
                                    If iRetValue > 0 Then
                                        iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType10"), objTreatmentService, fileToUpload10, txtExistAttNo10, txtExistRecNo10, iExtError)
                                    End If
                                End If
                                If hidCareGroupID.Value = "4" And hidRequestType.Value = "4" And hidReference2000.Value <> "" Then
                                    Dim strRefTemp As String
                                    If hidReference2000Type.Value = "1" Then
                                        strRefTemp = hidReference2000.Value
                                    Else
                                        strRefTemp = hidReference2000Bashan.Value
                                    End If
                                    If Not objTreatmentService.CopyPriodontAttachment("D436066A-AB43-4A1A-953D-907E37C27B96", strRefTemp, strReferenceID) Then
                                        iRetValue = 0
                                    End If
                                End If
                            End If



                            ' todo 
                            'If iRetValue > 0 Then
                            '    Dim objReport As New ReportConnect.ReportService()
                            '    objReport.Url = Application("ReportWebService").ToString()
                            '    Dim strAnswer As String
                            '    objReport.AddRequestBashanReport("CF48E6AE-F060-4CCB-8A2B-2E39848B261A", User.Identity.Name, strReferenceID)
                            '    strAnswer = "<span style='color:black'>" & "מספר אסמכתא: <SPAN dir='ltr'><B>" & strReferenceID & "</B></SPAN></span>"
                            '    objTreatmentService.SetRequestComplited("1A529E7C-262A-4A6F-94D6-AA8C5AACBF8E", iRequestID)
                            '    'If objReport.AddRequestBashanReport("CF48E6AE-F060-4CCB-8A2B-2E39848B261A", User.Identity.Name, strReferenceID) Then
                            '    '    strAnswer = "מספר אסמכתא: <SPAN dir='ltr'><B>" & strReferenceID & "</B></SPAN>"
                            '    '    objTreatmentService.SetRequestComplited("1A529E7C-262A-4A6F-94D6-AA8C5AACBF8E", iRequestID)
                            '    'Else
                            '    '    strAnswer = "תקלה בעת העברת נתוני הפניה, אנא פנה למנהל המערכת"
                            '    '    iRetValue = 0
                            '    'End If
                            '    hidAnswer.Value = strAnswer
                            'Else
                            '    If iExtError > 0 Then
                            '        hidAnswer.Value = "פורמט הנספח אינו חוקי"
                            '    Else
                            '        hidAnswer.Value = "תקלה בעת העברת נתוני הפניה, אנא פנה למנהל המערכת"
                            '    End If
                            'End If

                            '''' hidAnswer.Value = String.Format("{0} השורה/ות התווספו ליומן בהצלחה", indexCounter) ' vbCrLf

                            OK = "true"
                            ClearValues()

                        Else
                            hidAnswer.Value = "תקלה בעת העברת נתוני הפניה, אנא פנה למנהל המערכת"
                            iRetValue = 0
                        End If
                    End If
                End If
            End If
            hidReturnValue.Value = iRetValue
        Else
            Dim objTreatmentService As New TreatmentConnect.TreatmentService()
            objTreatmentService.Url = Application("TreatmentWebService").ToString()
            Dim ds As DataSet = objTreatmentService.GetAllAttachTypes("5793D9EB-2CC1-44A3-BC46-84C21525AA07")
            BindCombo(lstAttachmentType1, ds)
            BindCombo(lstAttachmentType2, ds)
            BindCombo(lstAttachmentType3, ds)
            BindCombo(lstAttachmentType4, ds)
            BindCombo(lstAttachmentType5, ds)
            BindCombo(lstAttachmentType6, ds)
            BindCombo(lstAttachmentType7, ds)
            BindCombo(lstAttachmentType8, ds)
            BindCombo(lstAttachmentType9, ds)
            BindCombo(lstAttachmentType10, ds)

            'lstAttachmentType1.Items.Add(New ListItem("בחר...", 0))
            'lstAttachmentType2.Items.Add(New ListItem("בחר...", 0))
            'lstAttachmentType3.Items.Add(New ListItem("בחר...", 0))
            'lstAttachmentType4.Items.Add(New ListItem("בחר...", 0))
            'lstAttachmentType5.Items.Add(New ListItem("בחר...", 0))
            'lstAttachmentType6.Items.Add(New ListItem("בחר...", 0))
            'lstAttachmentType7.Items.Add(New ListItem("בחר...", 0))
            'lstAttachmentType8.Items.Add(New ListItem("בחר...", 0))
            'lstAttachmentType9.Items.Add(New ListItem("בחר...", 0))
            'lstAttachmentType10.Items.Add(New ListItem("בחר...", 0))
        End If
    End Sub

    Private Function ClearValues() As Boolean

        Utils.SetComboValue(lstAttachmentType1, "0")
        Utils.SetComboValue(lstAttachmentType2, "0")
        Utils.SetComboValue(lstAttachmentType3, "0")
        Utils.SetComboValue(lstAttachmentType4, "0")
        Utils.SetComboValue(lstAttachmentType5, "0")
        Utils.SetComboValue(lstAttachmentType6, "0")
        Utils.SetComboValue(lstAttachmentType7, "0")
        Utils.SetComboValue(lstAttachmentType8, "0")
        Utils.SetComboValue(lstAttachmentType9, "0")
        Utils.SetComboValue(lstAttachmentType10, "0")

        txtFileTitle1.Value = String.Empty
        txtFileTitle2.Value = String.Empty
        txtFileTitle3.Value = String.Empty
        txtFileTitle4.Value = String.Empty
        txtFileTitle5.Value = String.Empty
        txtFileTitle6.Value = String.Empty
        txtFileTitle7.Value = String.Empty
        txtFileTitle8.Value = String.Empty
        txtFileTitle9.Value = String.Empty
        txtFileTitle10.Value = String.Empty

    End Function

    Sub BindCombo(ByRef control As DropDownList, ByVal ds As Data.DataSet)

        control.Items.Clear()
        control.Items.Add(New ListItem("בחר..", "0"))

        Dim dr As DataRow
        Dim item As ListItem

        For Each dr In ds.Tables(0).Rows
            If Utils.Values.GetDataRowString(dr, "AttachID") <> String.Empty Then
                item = New ListItem(Utils.Values.GetDataRowString(dr, "AttachName"), Utils.Values.GetDataRowString(dr, "AttachID"))
                item.Attributes.Add("Prefix", Utils.Values.GetDataRowString(dr, "Prefix"))
                item.Attributes.Add("ForConsultation", Utils.Values.GetDataRowString(dr, "ForConsultationUse"))
                item.Attributes.Add("id", Utils.Values.GetDataRowString(dr, "id"))
                control.Items.Add(item)
            End If
        Next

        If control.Items.Count > 0 Then
            control.SelectedIndex = 0
        End If

    End Sub

    Private Function GetIndex(ByVal Translator As Integer(), ByVal value As String) As Integer

        Dim intValue As Integer = 0
        Integer.TryParse(value, intValue)

        For index As Integer = 0 To Translator.Length - 1
            If (Translator(index) = intValue) Then
                Return index
            End If
        Next
        Return -1

    End Function

    Private Function ProcessRow(ByVal strReferenceID As String, ByVal strComboSelectedValue As String, ByRef objTreatmentService As TreatmentConnect.TreatmentService, ByRef ctlFile As HtmlInputFile, ByRef ctlHidden1 As HtmlInputHidden, ByRef ctlHidden2 As HtmlInputHidden, ByRef iExtError As Integer) As Integer
        Dim iPhotoType As Integer = CInt(strComboSelectedValue)
        Dim iRetValue As Integer = 0
        iExtError = 0
        If Not ctlFile.PostedFile Is Nothing AndAlso Trim(ctlFile.PostedFile.FileName) <> "" Then
            Dim ioReader As New BinaryReader(ctlFile.PostedFile.InputStream)
            ioReader.BaseStream.Seek(0, SeekOrigin.Begin)
            Dim arrFileContent(ioReader.BaseStream.Length - 1) As Byte
            ioReader.Read(arrFileContent, 0, ioReader.BaseStream.Length)
            If CheckFileHeader(arrFileContent) > 0 Then
                Dim strFileName As String = ctlFile.PostedFile.FileName
                Dim iPt As Integer = InStrRev(strFileName, "\")
                If iPt > 0 Then
                    strFileName = Mid(strFileName, iPt + 1)
                End If
                If objTreatmentService.ArchiveAttachment("C7F043B7-8717-430D-A7B6-8A2EBDE30741", strReferenceID, iPhotoType, strFileName, arrFileContent) Then
                    iRetValue = 1
                End If
            Else
                iExtError = 1
            End If
        ElseIf (Trim(ctlHidden1.Value) <> "" And Trim(ctlHidden2.Value) <> "") Then
            Dim iRecordNo As Integer = CInt(ctlHidden2.Value)
            Dim iAttachNo As Integer = CInt(ctlHidden1.Value)
            If iRecordNo = 0 Then
                iRetValue = 1
            Else
                If objTreatmentService.CopyAttachment("DCAB5DEB-D32B-4B1B-9156-2A47D9ADAC96", iRecordNo, iAttachNo, strReferenceID) Then
                    iRetValue = 1
                End If
            End If
        Else
            iRetValue = 2
        End If
        Return iRetValue
    End Function

    Private Function CheckAllFiles(ByVal iMaxSize As Integer) As Integer
        Dim iRetValue As Integer
        iRetValue = CheckFileSize(fileToUpload1, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload2, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload3, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload4, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload5, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload6, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload7, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload8, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload9, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload10, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        Return 0
    End Function

    Private Function CheckFileSize(ByRef ctlFile As HtmlInputFile, ByVal iMaxSize As Integer) As Integer
        Dim iRetValue As Integer = 0
        If Not ctlFile.PostedFile Is Nothing AndAlso Trim(ctlFile.PostedFile.FileName) <> "" Then
            'If CheckFileHeader(ctlFile) > 0 Then
            '    iRetValue = 3
            'End If
            If ctlFile.PostedFile.ContentLength > iMaxSize Then
                iRetValue = 2
            ElseIf ctlFile.PostedFile.ContentLength < 1024 Then
                iRetValue = 3
            ElseIf ctlFile.PostedFile.ContentLength = 0 Then
                iRetValue = 1
            End If
        End If
        Return iRetValue
    End Function

    Private Function CheckFileHeader(ByRef byContent As Byte()) As Integer
        Dim iRetValue As Integer = 0
        If Application("CheckJpgHeader") = "1" Then
            Dim strJPEGStart As String = "255216"
            Dim strTIFFStartIntel As String = "7373"
            Dim strTIFFStartMotorola As String = "7777"
            Try
                Dim strHeader As String = byContent(0).ToString() & byContent(1).ToString()
                If strJPEGStart = strHeader Then
                    iRetValue = 1
                ElseIf strTIFFStartIntel = strHeader Or strTIFFStartMotorola = strHeader Then
                    iRetValue = 2
                End If
            Catch ex As Exception
                iRetValue = -1
            End Try
        Else
            iRetValue = 1
        End If
        Return iRetValue
    End Function

    'Private Function CheckFileHeader(ByRef ctlFile As HtmlInputFile) As Integer
    '    'Dim fs As New FileStream(ctlFile.PostedFile.FileName, FileMode.Open)
    '    Dim sr As New StreamReader(ctlFile.PostedFile.InputStream)
    '    Dim ch As Integer
    '    Dim str As String
    '    Dim sb As New StringBuilder()
    '    Dim i As Integer
    '    Dim iRetValue As Integer = 0
    '    Dim strJPEGStart As String = "016747073"
    '    Dim strTIFFStartIntel As String = "7373"
    '    Dim strTIFFStartMotorola As String = "7777"
    '    Try
    '        ch = sr.Read()
    '        While i < 5 And ch <> -1
    '            str = CType(ch, String)
    '            sb.Append(str)
    '            i = i + 1
    '            ch = sr.Read()
    '        End While

    '        If Path.GetExtension(ctlFile.PostedFile.FileName).ToUpper = ".JPG" Then
    '            If strJPEGStart <> sb.ToString() Then
    '                iRetValue = 3
    '            End If
    '        ElseIf Path.GetExtension(ctlFile.PostedFile.FileName).ToUpper = ".TIF" Then
    '            If Not sb.ToString().StartsWith(strTIFFStartIntel) And Not sb.ToString().StartsWith(strTIFFStartMotorola) Then
    '                iRetValue = 3
    '            End If

    '        End If

    '    Catch ex As Exception
    '        iRetValue = 3
    '    Finally
    '        sr.Close()
    '    End Try
    '    Return iRetValue
    'End Function

    Private Function CheckXrayExist() As Integer
        Dim iRetValue As Integer = 0
        If hidPan.Value = "1" Then
            iRetValue = 1
        End If
        If hidStatus.Value = "1" Then
            iRetValue = iRetValue Or 2
        End If
        If hidFace.Value = "1" Then
            iRetValue = iRetValue Or 4
        End If
        Return iRetValue
    End Function

    Private Function CheckXrayExistOld() As Integer
        Dim iRetValue As Integer = 0, iTestValue As Integer
        iTestValue = CheckXrayExistOneRow(txtExistAttNo1, txtExistRecNo1)
        iRetValue = iRetValue Or iTestValue
        iTestValue = CheckXrayExistOneRow(txtExistAttNo2, txtExistRecNo2)
        iRetValue = iRetValue Or iTestValue
        iTestValue = CheckXrayExistOneRow(txtExistAttNo3, txtExistRecNo3)
        iRetValue = iRetValue Or iTestValue
        iTestValue = CheckXrayExistOneRow(txtExistAttNo4, txtExistRecNo4)
        iRetValue = iRetValue Or iTestValue
        iTestValue = CheckXrayExistOneRow(txtExistAttNo5, txtExistRecNo5)
        iRetValue = iRetValue Or iTestValue
        iTestValue = CheckXrayExistOneRow(txtExistAttNo6, txtExistRecNo6)
        iRetValue = iRetValue Or iTestValue
        iTestValue = CheckXrayExistOneRow(txtExistAttNo7, txtExistRecNo7)
        iRetValue = iRetValue Or iTestValue
        iTestValue = CheckXrayExistOneRow(txtExistAttNo8, txtExistRecNo8)
        iRetValue = iRetValue Or iTestValue
        iTestValue = CheckXrayExistOneRow(txtExistAttNo9, txtExistRecNo9)
        iRetValue = iRetValue Or iTestValue
        iTestValue = CheckXrayExistOneRow(txtExistAttNo10, txtExistRecNo10)
        iRetValue = iRetValue Or iTestValue
        Return iRetValue
    End Function

    Private Function CheckXrayExistOneRow(ByRef ctlHidden1 As HtmlInputHidden, ByRef ctlHidden2 As HtmlInputHidden) As Integer
        Dim iRetValue As Integer = 0
        If (IsNumeric(ctlHidden1.Value) And IsNumeric(ctlHidden2.Value)) Then
            Dim iRecordNo As Integer = CInt(ctlHidden2.Value)
            Dim iAttachNo As Integer = CInt(ctlHidden1.Value)
            If iRecordNo = 0 Then
                iRetValue = Math.Abs(iAttachNo)
            End If
        End If
        Return iRetValue
    End Function

    Private Function CheckXrayAttach() As Boolean
        Dim bRetValue As Boolean = False
        bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType1"), fileToUpload1, txtExistAttNo1, txtExistRecNo1)
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType2"), fileToUpload2, txtExistAttNo2, txtExistRecNo2)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType3"), fileToUpload3, txtExistAttNo3, txtExistRecNo3)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType4"), fileToUpload4, txtExistAttNo4, txtExistRecNo4)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType5"), fileToUpload5, txtExistAttNo5, txtExistRecNo5)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType6"), fileToUpload6, txtExistAttNo6, txtExistRecNo6)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType7"), fileToUpload7, txtExistAttNo7, txtExistRecNo7)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType8"), fileToUpload8, txtExistAttNo8, txtExistRecNo8)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType9"), fileToUpload9, txtExistAttNo9, txtExistRecNo9)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType10"), fileToUpload10, txtExistAttNo10, txtExistRecNo10)
        End If
        Return bRetValue
    End Function

    Private Function CheckXrayAttachOneRow(ByVal strComboSelectedValue As String, ByRef ctlFile As HtmlInputFile, ByRef ctlHidden1 As HtmlInputHidden, ByRef ctlHidden2 As HtmlInputHidden) As Boolean
        Dim bRetValue As Boolean = False
        Dim i As Integer = CInt(strComboSelectedValue)
        If i > 0 Then
            If (IsNumeric(ctlHidden1.Value) And IsNumeric(ctlHidden2.Value)) Then
                Dim iRecordNo As Integer = CInt(ctlHidden2.Value)
                If iRecordNo > 0 Then
                    bRetValue = True
                End If
            ElseIf Not ctlFile.PostedFile Is Nothing AndAlso Trim(ctlFile.PostedFile.FileName) <> "" Then
                bRetValue = True
            End If
        End If
        Return bRetValue
    End Function

    Private Function GetAttachValue(ByVal bNote As Boolean, ByVal iInitValue As Integer) As Integer
        Dim iRetValue As Integer = iInitValue
        Dim iTestValue As Integer
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType1"), txtExistAttNo1)
        iRetValue = iRetValue Or iTestValue
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType2"), txtExistAttNo2)
        iRetValue = iRetValue Or iTestValue
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType3"), txtExistAttNo3)
        iRetValue = iRetValue Or iTestValue
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType4"), txtExistAttNo4)
        iRetValue = iRetValue Or iTestValue
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType5"), txtExistAttNo5)
        iRetValue = iRetValue Or iTestValue
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType6"), txtExistAttNo6)
        iRetValue = iRetValue Or iTestValue
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType7"), txtExistAttNo7)
        iRetValue = iRetValue Or iTestValue
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType8"), txtExistAttNo8)
        iRetValue = iRetValue Or iTestValue
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType9"), txtExistAttNo9)
        iRetValue = iRetValue Or iTestValue
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType10"), txtExistAttNo10)
        iRetValue = iRetValue Or iTestValue
        If bNote Then
            iRetValue += 4
        End If
        Return iRetValue
    End Function

    Private Function GetAttachValueOneRow(ByVal strComboSelectedValue As String, ByRef ctlHidden1 As HtmlInputHidden) As Integer
        Dim i As Integer = CInt(strComboSelectedValue)
        Dim iRetValue As Integer
        If i = 0 Then
            iRetValue = 0
        ElseIf i = 10 Then
            iRetValue = 2
        Else
            If (IsNumeric(ctlHidden1.Value)) Then
                If CInt(ctlHidden1.Value) < 0 Then
                    iRetValue = 0
                Else
                    iRetValue = 1
                End If
            Else
                iRetValue = 1
            End If
        End If
        Return iRetValue
    End Function

    Private Function ValidateTooth(ByVal iTooth As Integer, ByRef ds As Data.DataSet) As Boolean
        Dim bPassed As Boolean = False
        Dim currRow As Data.DataRow
        Dim iTempFrom As Integer, iTempTo As Integer
        For Each currRow In ds.Tables(0).Rows
            iTempFrom = CType(currRow("FromTooth"), Integer)
            iTempTo = CType(currRow("ToTooth"), Integer)
            If (iTooth >= iTempFrom) And (iTooth <= iTempTo) Then
                bPassed = True
                Exit For
            End If
        Next
        Return bPassed
    End Function

    Private Function TestOldRow(ByVal iTreatmentValue As Integer, ByVal iFromTooth As Integer, ByVal iToTooth As Integer, ByVal arrToothCheck() As ArrayList, ByRef strAnswer As String, ByRef strErrTeeth As String) As Integer
        Dim i As Integer, iArrIndex1 As Integer, iArrIndex2 As Integer
        If iFromTooth = 88 Or iFromTooth = 0 Then
            iArrIndex1 = 0
            iArrIndex2 = 63
        Else

            iArrIndex1 = arrIndexTranslate(Convert.ToInt16(CStr(iFromTooth - 11), 8))
            iArrIndex2 = arrIndexTranslate(Convert.ToInt16(CStr(iToTooth - 11), 8))
            i = iArrIndex1
            iArrIndex1 = Math.Min(iArrIndex1, iArrIndex2)
            iArrIndex2 = Math.Max(i, iArrIndex2)
        End If
        For i = iArrIndex1 To iArrIndex2
            If arrToothCheck(i).Contains(iTreatmentValue) Then
                strErrTeeth = strErrTeeth & CStr(CInt(Oct(i)) + 11) & "." & CStr(iTreatmentValue) & ";"
                strAnswer = "כבר הוגשה התייעצות עם צרוף שן/טיפול בחצי השנה האחרונה. נא לתקן ולהגיש מחדש"
            End If
        Next
        If strErrTeeth = "" Then
            Return 1
        Else
            Return 0
        End If
    End Function

End Class