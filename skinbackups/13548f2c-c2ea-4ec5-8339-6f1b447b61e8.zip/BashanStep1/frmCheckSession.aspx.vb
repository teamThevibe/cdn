﻿Public Partial Class frmCheckSession
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim LoginURL = String.Empty
        If Session.IsNewSession Then
            'LoginURL = String.Format("{0}{1}{2}{3}/{4}", Request.Url.Scheme, Request.Url.SchemeDelimiter, Request.Url.Host, Request.ApplicationPath, Application("FORMLogin"))
            LoginURL = Context.Application("FORMLogin")
        End If
        Response.Clear()
        Response.Write(LoginURL)
        Response.End()
    End Sub

End Class