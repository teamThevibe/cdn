var currColor = '';
function focusInput() {
    var e = event.srcElement;
    if (event.type == 'focus') {
        currColor = e.currentStyle.borderColor;
        e.style.borderColor = '#FF1818';
    }
    else {
        e.style.borderColor = currColor;
    }
}

var currFColor = '';
function focusButton() {
    var e = event.srcElement;

    if (event.type == 'mouseover' || event.type == 'focus') {
        //currFColor = e.currentStyle.color;
        e.style.color = '#CC0000';
    }
    else {
        e.style.color = '#242424';
    }
}

var bStopMarquee = false;
function StopMarquee(mrq) {
    bStopMarquee = !bStopMarquee;
    if (bStopMarquee) {
        mrq.stop();
    } else {
        mrq.start();
    }
}

function cleanString(str) {
    var sRet = str;
    var myString;

    myString = new String(sRet)
    var rExp = /&acute;/gi;
    newString = new String("'")
    sRet = myString.replace(rExp, newString)

    myString = new String(sRet)
    var rExp = /&quot;/gi;
    newString = new String('"')
    sRet = myString.replace(rExp, newString)

    return sRet;

}

function ReplaceSlash(strForReplace) {
    var myNewString = strForReplace;
    for (i = 0; i < 2; i++) {
        myNewString = myNewString.replace("/", "");
    }

    return myNewString;
}

/*Validating For Numarics */
function CheckNumbers(e, t) {
    if (e.keyCode < 48 || e.keyCode > 57)
        e.keyCode = 0;
    var string = t.value

}
/*For Filling /'s while entering date */
function FillDateFormat(e, t) {
    if (e.keyCode < 48 || e.keyCode > 57)
        e.keyCode = 0;
    var string = t.value;

    if ((string.length == 2) || (string.length == 5)) {
        string = string + "/";
        t.value = string;

    }
}

function isEmptyDate(sValue) {
    if ((sValue == "00/00/0000") || (sValue == "00000000") || (sValue == "")) {
        return true;
    }
    return false;
}


function SlashCutForDate() {
    try {
        return this.replace(/\//g, "");
    }
    catch (e) { return '' }
}

function SlashAddForDate() {
    try {
        var value = this.toString()
        if (value.length == 8) { return this.substring(0, 2) + "/" + this.substring(2, 4) + "/" + this.substring(4); }
        else { return '00/00/0000' }
    }
    catch (e) { return '00/00/0000' }
}


function DateGetString() {
    var strMonth = "0" + (this.getMonth() + 1)
    strMonth = strMonth.substr(strMonth.length - 2, 2);

    var strDay = "0" + this.getDate();
    strDay = strDay.substr(strDay.length - 2, 2);

    var strYear = this.getFullYear();
    return strDay + '/' + strMonth + '/' + strYear;
}

function DateGetDate() {
    var dt = null;
    try {
        dt = new Date(parseInt(this.substr(6, 4), 10), parseInt(this.substr(3, 2), 10) - 1, parseInt(this.substr(0, 2), 10));
    }
    catch (e) { }
    return dt
}

function getCurrentDate() {
    var dt = new Date();
    return dt.GetString();
}

String.prototype.SlashCut = SlashCutForDate;
String.prototype.SlashAdd = SlashAddForDate;
Date.prototype.GetString = DateGetString;
String.prototype.GetDate = DateGetDate;

String.prototype.trim = function() {
    var str = this.replace(/^\s\s*/, ''),
		ws = /\s/,
		i = str.length;
    while (ws.test(str.charAt(--i)));
    return str.slice(0, i + 1);
}


function IsValidForName(e)
{
    // 220='\' 219='[' 191='/' 221=']'

   var key = e.keyCode;   
   if ((key==191) || ((key>=219) && (key<=221)))
   {
     e.preventDefault();
     e.keyCode = 0;     
   }
}

function CheckLengthForTextArea(ob, maxLength) {
    var s = ob.value;

    if (s.length > maxLength)
        ob.value = s.substr(0, maxLength);

}

function isIe() {
    var ie = document.all;
    if (ie) return true;
    return false;

}

function CheckYearofDate(d) {
    if (d < 1899) {
        return false;
    }
    return true
}