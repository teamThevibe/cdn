﻿var config = new Object();    // create new config object

config.width = "100%";
config.height = "100px";
config.bodyStyle = 'background-color: white; font-family: "Verdana"; font-size: x-small;';
config.debug = 0;

// NOTE:  You can remove any of these blocks and use the default config!

config.toolbar = [
        ['fontname'],
        ['fontsize'],
        ['linebreak'],
        ['bold', 'italic', 'underline', 'separator'],
        ['strikethrough', 'subscript', 'superscript', 'separator'],
        ['justifyleft', 'justifycenter', 'justifyright', 'separator'],
        ['OrderedList', 'UnOrderedList', 'Outdent', 'Indent', 'separator'],
        ['forecolor', 'backcolor', 'separator'],
        ['HorizontalRule', 'Createlink', 'InsertImage', 'InsertTable', 'separator'],
        ['about', 'popupeditor'],
    ];
config.fontnames = {
    "Aharoni": "Aharoni",
    "Arial": "Arial",
    "Arial Black": "Arial Black",
    "Comic Sans MS": "Comic Sans MS",
    "Courier": "Courier",
    "Courier New": "Courier New",
    "David": "David",
    "David Transparent": "David Transparent",
    "Fixed Miriam Transparent": "Fixed Miriam Transparent",
    "Fixedsys": "Fixedsys",
    "FrankRuehl": "FrankRuehl",
    "Georgia": "Georgia",
    "Guttman Adii": "Guttman Adii",
    "Guttman Adii-Light": "Guttman Adii-Light",
    "Guttman Aharoni": "Guttman Aharoni",
    "Guttman Calligraphic": "Guttman Calligraphic",
    "Guttman David": "Guttman David",
    "Guttman Drogolin": "Guttman Drogolin",
    "Guttman Frank": "Guttman Frank",
    "Guttman Frnew": "Guttman Frnew",
    "Guttman Haim": "Guttman Haim",
    "Guttman Haim-Condensed": "Guttman Haim-Condensed",
    "Guttman Hatzvi": "Guttman Hatzvi",
    "Guttman Hodes": "Guttman Hodes",
    "Guttman Kav": "Guttman Kav",
    "Guttman Kav-Light": "Guttman Kav-Light",
    "Guttman Keren": "Guttman Keren",
    "Guttman Mantova-Decor": "Guttman Mantova-Decor",
    "Guttman Miryam": "Guttman Miryam",
    "Guttman Rashi": "Guttman Rashi",
    "Guttman Vilna": "Guttman Vilna",
    "Guttman Yad": "Guttman Yad",
    "Guttman Yad-Brush": "Guttman Yad-Brush",
    "Guttman Yad-Light": "Guttman Yad-Light",
    "Guttman-Aharoni": "Guttman-Aharoni",
    "Guttman-Aram": "Guttman-Aram",
    "Guttman-CourMir": "Guttman-CourMir",
    "Guttman-Soncino": "Guttman-Soncino",
    "Guttman-Toledo": "Guttman-Toledo",
    "Impact": "Impact",
    "Lucida Console": "Lucida Console",
    "Lucida Sans Unicode": "Lucida Sans Unicode",
    "Microsoft Sans Serif": "Microsoft Sans Serif",
    "Miriam": "Miriam",
    "Miriam Fixed": "Miriam Fixed",
    "Miriam Transparent": "Miriam Transparent",
    "Modern": "Modern",
    "MS Sans Serif": "MS Sans Serif",
    "MS Serif": "MS Serif",
    "Narkisim": "Narkisim",
    "Rod": "Rod",
    "Rod Transparent": "Rod Transparent",
    "Roman": "Roman",
    "Script": "Script",
    "Small Fonts": "Small Fonts",
    "Symbol": "Symbol",
    "System": "System",
    "Tahoma": "Tahoma",
    "Terminal": "Terminal",
    "Times New Roman": "Times New Roman",
    "Verdana": "Verdana",
    "Webdings": "Webdings",
    "Wingdings": "Wingdings"
};

config.fontsizes = {
    "1 (8 pt)": "1",
    "2 (10 pt)": "2",
    "3 (12 pt)": "3",
    "4 (14 pt)": "4",
    "5 (18 pt)": "5",
    "6 (24 pt)": "6",
    "7 (36 pt)": "7"
};


_editor_url = "";
var win_ie_ver = parseFloat(navigator.appVersion.split("MSIE")[1]);
if (navigator.userAgent.indexOf('Mac') >= 0) { win_ie_ver = 0; }
if (navigator.userAgent.indexOf('Windows CE') >= 0) { win_ie_ver = 0; }
if (navigator.userAgent.indexOf('Opera') >= 0) { win_ie_ver = 0; }
if (win_ie_ver >= 5.5) {
    document.write('<scr' + 'ipt src="' + _editor_url + 'editor.js"');
    document.write(' language="Javascript1.2"></scr' + 'ipt>');
} else { document.write('<scr' + 'ipt>function editor_generate() { return false; }</scr' + 'ipt>'); }  