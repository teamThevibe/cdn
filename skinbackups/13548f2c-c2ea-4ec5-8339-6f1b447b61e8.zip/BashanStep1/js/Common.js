var currColor = '';
function focusInput() {
    var e = event.srcElement;
    if (event.type == 'focus') {
        currColor = e.currentStyle.borderColor
        e.style.borderColor = '#FF0000';
    }
    else {
        e.style.borderColor = currColor;
    }
}

function SetCopyright() {
    try {
        document.all.ComtecLTD.innerHTML = GetCopyright();
    }
    catch (e) { }
}

function GetCopyright() {
    var d = new Date();

    var stCopyright = ""; // "����� ��&quot;� <FONT COLOR=\"#FF4500\">�</FONT> " + d.getFullYear() + " �� ������� ������";
    return stCopyright;
}
function cmd_Print() {
    document.all.cmdPrint.style.visibility = "hidden";
    window.print();
    window.setTimeout("fnShow()", 1000);
}

function fnShow() {
    document.all.cmdPrint.style.visibility = "visible";
}

function fnCheckMaxLen(oTextArea, iMaxLength) {
    if (oTextArea.value.toString().length > iMaxLength) {
        oTextArea.value = oTextArea.value.toString().substr(0, iMaxLength);
    }
}
function fnTrimString(sValue) {
    var stResult = sValue.toString();

    if (stResult.length > 0) {
        while (stResult.substr(0, 1) == " ") {
            stResult = stResult.substr(1);
        }

        var len = stResult.length;
        while (stResult.substr(--len) == " ") {
            stResult = stResult.substr(0, len);
            len = stResult.length;
        }
    }
    else {
        stResult = "";
    }

    return stResult;
}

function validateNumber(intKeyCode) {
    if ((intKeyCode < 48) || (intKeyCode > 57))
        event.returnValue = false;
    else
        event.returnValue = true;
}

function isNumber(e) {
    var regexp = /\d/;
    e = e || window.event;
    var target = e.target || e.srcElement;
    var isIE = document.all;
    if (target.tagName.toUpperCase() == 'INPUT') {
        var code = isIE ? e.keyCode : e.which;
        if (code < 32 || e.ctrlKey || e.altKey) return true;
        var char = String.fromCharCode(code);
        if (!regexp.test(char)) return false;
    }
    return true;
}

function validatePhoneNumber(intKeyCode) {
    if ((intKeyCode > 46) && (intKeyCode < 58) || (intKeyCode == 43) || (intKeyCode == 40) || (intKeyCode == 41) || (intKeyCode == 45) || (intKeyCode == 32))
        event.returnValue = true;
    else
        event.returnValue = false;
}

function validateDate(objDate) {
    value = objDate.value;
    value = value.replace("/", "")
    value = value.replace("/", "")

    if (value.length == 8) {
        dd = value.substring(0, 2);
        mm = value.substring(2, 4);
        yyyy = value.substring(4);

        dt = new Date(yyyy, mm - 1, dd, 0, 0, 0, 0);

        if (dt.getDate() == dd && dt.getMonth() + 1 == mm && dt.getFullYear() == yyyy) {
            objDate.value = dd + "/" + mm + "/" + yyyy;
        } else {
            objDate.value = "00/00/0000";
        }
    }
    else if (value.length == 6) {
        dd = value.substring(0, 2);
        mm = value.substring(2, 4);
        yyyy = "20" + value.substring(4);

        dt = new Date(yyyy, mm - 1, dd, 0, 0, 0, 0);

        if (dt.getDate() == dd && dt.getMonth() + 1 == mm && dt.getFullYear() == yyyy) {
            objDate.value = dd + "/" + mm + "/" + yyyy;
        } else {
            objDate.value = "00/00/0000";
        }

    }
    else {
        objDate.value = "00/00/0000";
    }
}

function CheckIDDigits(lngID) {
    if (parseInt(lngID) + '' == "NaN") {
        return 0;
    }
    var Digit;
    var Accum = 0;
    var F12 = 1;
    while (lngID != 0) {
        lngID = parseInt(lngID / 10);
        F12 = 3 - F12;
        Digit = (lngID % 10) * F12;
        Accum = Accum + parseInt(Digit / 10) + (Digit % 10);
    }
    return (100 - Accum) % 10;
}
function CheckID(strID) {
    var lngID;
    if (strID.length > 0) {
        lngID = parseInt(strID);
        if (CheckIDDigits(lngID) == (lngID % 10))
            return true;
        else
            return false;
    }
    else
        return false;
}
/* tz validation */
function CheckIdNumber(strID) {
    var num;
    num = parseInt(strID, 10);
    if (!CheckID(num.toString())) {
        if ((num < 10000000) || (num >= 30000000 && num < 40000000)) {
            num = num * 10 + CheckIDDigits(num * 10);
        }
        else {
            num = 0;
        }
    }
    return num.toString();
}

function GetParameterValue(aParams, sParamName) {
    var sResult = '';
    var sUperName = sParamName.toUpperCase();

    for (i = 0; i < aParams.length; i++) {
        if (aParams[i].toUpperCase().indexOf(sUperName) >= 0) {
            //debugger;
            sResult = aParams[i].substr(sParamName.length + 1);
            break;
        }
    }
    return sResult;
}

function getWindowSize(dim) {
    var myWidth = 0, myHeight = 0;
    if (typeof (window.innerWidth) == 'number') {
        //Non-IE
        myWidth = window.innerWidth;
        myHeight = window.innerHeight;
    } else if (document.body && (document.body.clientWidth || document.body.clientHeight)) {
        //IE 4 compatible
        myWidth = document.body.clientWidth;
        myHeight = document.body.clientHeight;
    } else if (document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {
        //IE 6+ in 'standards compliant mode'
        myWidth = document.documentElement.clientWidth;
        myHeight = document.documentElement.clientHeight;
    }
    if (dim.toLowerCase() == 'height' || dim.toLowerCase() == "v")
        return myHeight;
    else // 
        return myWidth;
}


function whichButton(event) {
    if (event.button == 2)//For right click
    {
        //alert("Right Click Not Allowed!");
    }

}

// This function is responsible for checking which key is being pressed. If user presses ctrl key then the an alert is coming out that "Sorry, this functionality is disabled.".

function noCTRL(e) {
    var code = (document.all) ? event.keyCode : e.which;

    var msg = "Sorry, this functionality is disabled.";
    if (parseInt(code) == 17) // This is the Key code for CTRL key
    {
        //alert(msg);
        window.event.returnValue = false;
    }
}

function getGUID() {
	//------------------
	var S4 = function() {
		return (
				Math.floor(
						Math.random() * 0x10000 /* 65536 */
					).toString(16)
			);
	};
	//------------------

	return (
			S4() + S4() + "-" +
			S4() + "-" +
			S4() + "-" +
			S4() + "-" +
			S4() + S4() + S4()
		);
};