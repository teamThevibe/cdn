﻿


function IsSessionExpired() {
    //*************************************************
    //TIMEOUT BEHAVIOR
    //*************************************************

    //This code is shared to all web sites.
    //CheckSession.ashx.vb is also shared to all web sites
    
    //Handler CheckSession checks Session timeout.    
    //CheckSession does not work after forms authentication timeout.
    //In this case ExitURL does not contain URL for exit, but ExitURL.length > 0.
    //To solve this problem the handler MUST be defined in 
    //web.config as in the following:
    
//    <location path="Handlers/CheckSession.ashx">
//		<system.web>
//			<authorization>
//				<allow users="*" />
//			</authorization>
//		</system.web>
//    </location>            
   
   
    var ExitURL = "";    

    $.ajax({    
        type: 'POST',
        dataType: 'text',                
        url: 'Handlers/CheckSession.ashx',
        async: false,        
        cache: false,
        success: function(Result) {
            ExitURL = Result;
        },
        error: function(Result) {
      
        }
    });

    if (ExitURL.length > 0) {
        window.location.href = ExitURL;
        return true;
    }
    
    return false;        
}

function IsSessionExpiredFromIframe() {


    var ExitURL = "";    

    $.ajax({    
        type: 'POST',
        dataType: 'text',                
        url: 'Handlers/CheckSession.ashx',
        async: false,        
        cache: false,
        success: function(Result) {
            ExitURL = Result;
        },
        error: function(Result) {
      
        }
    });

    if (ExitURL.length > 0) {
        window.parent.location.href = ExitURL;
        return true;
    }
    
    return false;        
}

