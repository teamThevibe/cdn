﻿function fnBeforePrint()
{
	document.all.cmdPrint.style.visibility = "hidden";
	window.setTimeout("fnShow()", 2000);
}

function fnPrint()
{
	window.print();
}

function fnShow()
{
	document.all.cmdPrint.style.visibility = "visible";
}

function fnExit()
{
	window.parent.close();
}

var buttonsHTML  = "<TABLE id='cmdPrint' border=0 cellspacing=0 cellpadding=0 DIR=ltr>";
    buttonsHTML += "<TR>";
    buttonsHTML += "<TD><INPUT type='button' value='הדפסה' class='OutPrint' onmouseover=\"this.className='OnPrint';\" onmouseout=\"this.className='OutPrint';\" onclick='fnPrint();' /></TD>";
    buttonsHTML += "<TD>&nbsp;</TD>";
    buttonsHTML += "<TD><INPUT type='button' value='חזרה' class='OutPrint' onmouseover=\"this.className='OnPrint';\" onmouseout=\"this.className='OutPrint';\" onclick='fnExit();'/></TD>";
    buttonsHTML += "</TR>";
    buttonsHTML += "</TABLE>";

var ns4=document.layers
var ie4=document.all
var ns6=document.getElementById&&!document.all

function regenerate()
{
	window.location.reload();
}

function regenerate2()
{
	if (ns4)
	{
		setTimeout("window.onresize=regenerate",400);
	}
}

if (ie4||ns6)
{
	document.write('<SPAN id="logo" style="position:absolute;top:-300;z-index:300">'+buttonsHTML+'</SPAN>');
}

function createtext()
{ //function for NS4
	staticimage = new Layer(5);
	staticimage.left=-300;
	staticimage.document.write(buttonsHTML);
	staticimage.document.close();
	staticimage.visibility = "show";
	regenerate2();
	staticitns();
}

function staticit()
{ //function for IE4/ NS6
	var w2=ns6? pageXOffset+w : document.body.scrollLeft+w;
	var h2=ns6? pageYOffset+h : document.body.scrollTop+h;
	crosslogo.style.left = w2;
	crosslogo.style.top = h2;
}

function staticit2()
{ //function for NS4
	staticimage.left = pageXOffset+window.innerWidth-staticimage.document.width-3
	staticimage.top = pageYOffset+window.innerHeight-staticimage.document.height-1;
}

function inserttext()
{ //function for IE4/ NS6
	if (ie4)
	{
		crosslogo=document.all.logo;
	}
	else if (ns6)
	{
		crosslogo=document.getElementById("logo");
	}

	crosslogo.innerHTML=buttonsHTML;
	//w = ns6? window.innerWidth-crosslogo.offsetWidth-3 : document.body.clientWidth-crosslogo.offsetWidth-3
	w=3;
	h = ns6? window.innerHeight-crosslogo.offsetHeight-1 : document.body.clientHeight-crosslogo.offsetHeight-1;
	crosslogo.style.left=w;
	crosslogo.style.top=h;

	if (ie4)
	{
		window.onscroll=staticit;
	}
	else if (ns6)
	{
		startstatic=setInterval("staticit()",100);
	}
}

function ShowActionButtons()
{
	if (ie4||ns6)
	{
		inserttext();
		window.onresize = new Function("window.location.reload()");
	}
	else if (ns4)
	{
		createtext();
	}
}

function staticitns()
{ //function for NS4
	startstatic=setInterval("staticit2()",90);
}

function callShowActionButtons()
{
	try
	{
		ShowActionButtons();
	}
	catch(e){}
}

function callBeforePrint()
{
	try
	{
		fnBeforePrint();
	}
	catch(e){}
}