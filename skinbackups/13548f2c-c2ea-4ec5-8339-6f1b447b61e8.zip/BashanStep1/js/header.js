
function locatorWin() 
{
 var lwin = window.open('./locwin.htm','findit','height=100,width=250,toolbar=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no'); lwin.moveTo(0,0); lwin.focus();
}