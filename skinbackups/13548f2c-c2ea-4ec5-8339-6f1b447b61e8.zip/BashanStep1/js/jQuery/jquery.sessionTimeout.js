﻿/*
* jquery.sessionTimeout.js
* Aouther: Avi Avital
* Copyright (c) 2011 Comtec 
* Dual licensed under the MIT and GPL licenses.
*
* Importent : 
* 1. use sto = new oSTO()  on Master Page
* 2. include jQuery 1.3.2 or later, UI 1.7.2 or later & this.js on Master Page
+
Web.config
WarnSessionTimeout
WarnSessionTimeoutMinutes
+
the same in glonal.asa
+
SessionTimeout
SessionWarning value in master page...
+
Handlers/keepAlive.ashx
+
ShowMessage function
*/

var sto;

$(document).ready(function() {

    sto = new oSTO();

    if (SessionTimeout > 0 && SessionWarning > 0) {
        //        SessionTimeout = 2;
        //        SessionWarning = 1;
        sto.initialize(SessionTimeout, SessionWarning);
        if (sto.formName.toLowerCase() != $('input[id$=FORMLogin]').val().toLowerCase()) {
            sto.start();
        }
    }
})

oSTO = function() {
    var TimeOutKey = "MessageType=TimeOut";
    this.loginto = window.location.pathname.split('/');
    this.loginto[1] = "/" + this.loginto[1];
    this.formName = this.loginto[this.loginto.length - 1];
    this.sessionTimeoutMin = 15;
    this.aboutToTimeoutWarningMin = 1;
    this.aboutToTimeoutWarningText = "לצורך שמירה על פרטיות המידע, הוגבל הזמן של חוסר הפעילות בגישה לאתר."
        + "<br /> זמן זה עומד להסתיים."
        + "<br /> אם ברצונך להמשיך לגלוש באתר באופן מאובטח עליך ללחוץ על 'אישור'."
    this.aboutToTimeoutWarningAlert = "לצורך שמירה על פרטיות המידע, הוגבל הזמן של חוסר הפעילות בגישה לאתר."
        + "\n זמן זה עומד להסתיים."
        + "\n אם ברצונך להמשיך לגלוש באתר באופן מאובטח עליך ללחוץ על 'המשך'."
    this.aboutToTimeoutWarningTitle = "התראה בנושא חוסר פעילות"
    this.loginPageWarningText = "המערכת סיימה את מהלך העבודה שלך מסיבות של חוסר פעילות"
        + "<br />באפשרותך להיכנס שוב למערכת"
    this.timeOut = (window.location.search.indexOf(TimeOutKey) > 0 ? true : false);
    this.timeoutOffsetSec = 1
    // this.exitOnTimeout = "var FORMLogin=$('input[id$=FORMLogin]').val();window.location='" + this.loginto[1] + "'+'/'+FORMLogin+'?" + TimeOutKey + "'";

    this.exitOnTimeout = function() {
        var FORMLogin = $('input[id$=FORMLogin]').val();
        window.location = sto.loginto[1] + "/" + FORMLogin + "?" + TimeOutKey;
    }

    this.timerAboutToTimeout = null;
    this.currentDate = new Date();
    this.warningTime = 0;
    this.timeoutTime = 0;
    this.timerTimeout = null
    this.enabled = null;
    this.$stoDialogWarning = null;
}

oSTO.prototype = {

    initialize: function(sessionTimeoutMin, TimeToWarn) {
        if (sessionTimeoutMin && TimeToWarn) {
            this.sessionTimeoutMin = sessionTimeoutMin;
            this.aboutToTimeoutWarningMin = TimeToWarn;
        }
        this.enabled = false;
    },

    restartTimeout: function() {
        var stOut = this;
        clearTimeout(this.timerAboutToTimeout);
        clearTimeout(this.timerTimeout);
        this.warningTime = ((this.sessionTimeoutMin - this.aboutToTimeoutWarningMin) * 60 - this.timeoutOffsetSec - 1) * 1000;
        this.timeoutTime = ((this.sessionTimeoutMin) * 60 - this.timeoutOffsetSec) * 1000;
        this.currentDate = new Date();
        this.timerAboutToTimeout = setTimeout(function() { stOut.showWarning() }, this.warningTime); // 1min
        this.timerTimeout = setTimeout(function() { stOut.timeoutAction() }, this.timeoutTime);      // 2min
    },

    timeoutAction: function() {
        this.enabled = false;
        setTimeout(this.exitOnTimeout, 0);
    },

    start: function() {
        if (this.sessionTimeoutMin > 0) {
            this.restartTimeout();
            this.enabled = true;
        }
    },

    stop: function() {
        clearTimeout(this.timerAboutToTimeout);
        clearTimeout(this.timerTimeout);
        this.enabled = false;
    },

    showWarning: function() {
        var isDialog = false;
        if (typeof jQuery.ui.dialog == 'function') {
            isDialog = true;
        }
        isDialog = false; // пока не хочу использовать ui
        if (isDialog) {
            ShowQuestion(this.aboutToTimeoutWarningText, this.answer);
        } else {
            var args = "frmMessage.aspx?Code=OkCancel&Mess=" + escape(this.aboutToTimeoutWarningAlert) + "&WinTitle=" + escape('אישור ביצוע פעולה'); ;
            var status = "dialogHeight: 240px; dialogWidth: 450px; scroll: no; status: no; center: yes; help: no";
            var value = window.showModalDialog("WinOpener.htm", args, status);

            if (value == undefined) {
                value = "Code=Cancel"
            }
            if (value.substring(value.indexOf("Code=") + 5) != "Cancel") {
                value = true;
            }
            else {
                value = false;
            }
            this.answer(null, null, value);
            // var isContinue = confirm(this.aboutToTimeoutWarningAlert);
            // this.answer(null, null, isContinue);
        }
    },

    answer: function(event, ui, flag) {
        if ((new Date() - this.currentDate) > (this.timeoutTime)) { // difference in milliseconds
            //    alert((new Date() - this.currentDate))
            //    alert((this.timeoutTime - this.warningTime))
            this.timeoutAction();
            return;
        }
        if (flag) {
            sto.resetServerSession();
        }
        else {
            sto.timeoutAction();
        }
    },

    resetServerSession: function() {
        retVal = false;
        $.ajax({
            url: "Handlers/keepAlive.ashx",
            dataType: "text",
            async: false,
            success: function(response, status) {
                sto.currentDate = new Date();
                retVal = true;
            }
        })
        return retVal;
    },

    isEnabled: function() {
        return (this.enabled == null ? false : this.enabled);
    },

    getSessionTimeout: function() {
        return this.sessionTimeoutMin;
    }

}

$(document).ajaxStop(function() {
    if (sto.isEnabled())
        sto.restartTimeout()
});
