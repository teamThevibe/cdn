﻿/*
* jQuery.infoBay.js
* use jQuery 1.3.2 or later
* Copyright (c) 2011 Comtec 
* Dual licensed under the MIT and GPL licenses.
*/

function IsOldBrowser() {
    return ($.browser.msie && parseFloat($.browser.version) <= 6.0)
}

/* 
* function disableButton
* aim   : ff hack for unavailable Button UI
* usage : $("#InputButton").disableInput(true);
* auther: av 3.2011
*/
(function($) {
    $.fn.disableButton = function(disabled) {
        if (disabled === undefined) {
            if (this.attr("disabled")) {
                disabled = true;
            }
            else {
                disabled = false;
            }
        }
        if (disabled) {
            this.attr("disabled", true);
            this.css("color", "gray");
        } else {
            this.removeAttr("disabled");
            this.css("color", "");
        }
    }
})(jQuery);

/* the same. more common only */
(function($) {
    $.fn.disable = function(disabled) {
        this.each(function() {
            var me = $(this)
            if (disabled === undefined) {
                disabled = me.attr("disabled");
            }
            if (me.attr("type") == "button") {
                me.disableButton(disabled);
            }
            if (me.attr("type") == "text") {
                me.disableInput(disabled);
            }
            if (me.attr("tagName").toLowerCase() == "img") {
                if (disabled) {
                    me.attr("disabled", true);
                    //this.addClass("InputDis");
                } else {
                    me.removeAttr("disabled");
                    //me.removeClass("InputDis");
                }
            }
            if (me.attr("tagName").toLowerCase() == "select") {
                if (disabled) {
                    me.attr("disabled", true);
                    //me.addClass("InputDis");
                } else {
                    me.removeAttr("disabled");
                    //me.removeClass("InputDis");
                }
            }
            if (me.attr("tagName").toLowerCase() == "tr") {
                if (disabled) {
                    me.attr("disabled", true);
                    //this.addClass("InputDis");
                } else {
                    me.removeAttr("disabled");
                    //me.removeClass("InputDis");
                }
            }
            if (me.attr("tagName").toLowerCase() == "div") {
                if (disabled) {
                    me.attr("disabled", true);
                    // $('div', me).disable(true).addClass("Disable");
                } else {
                    me.removeAttr("disabled");
                    // $('div', me).disable(false).removeClass("Disable");
                }
            }
        })
        return this;
    }
})(jQuery);

/* 
* function disableInput
* aim   : ff hack for unavailable Input Text UI
* usage : $("#InputText").disableInput(true);
* auther: av 3.2011
*/
(function($) {
    $.fn.disableInput = function(disabled) {
        if (disabled === undefined) {
            if (this.attr("disabled")) {
                disabled = true;
            }
            else {
                disabled = false;
            }
        }
        if (disabled) {
            this.attr("disabled", true);
            this.addClass("InputDis");
            /* { "color": "#d5d5d5lass
            , "background-image": "url(../../pics/InputDisBack.gif)"
            , "background-repeat": "repeat-x"
            */
        } else {
            this.removeAttr("disabled");
            this.removeClass("InputDis");
        }
    }
})(jQuery);
/* 
* function forcePhoneNumber
* aim   : prevent typing unwanted characters
* usage : $("#inpuText").forceNumber();
* auther: av 4.2011
*/
(function($) {
    $.fn.forceNumber = function() {
        $(this).keydown(function(e) {
            var key = (e.keyCode ? e.keyCode : e.which);
            if (!((key >= 48 && key <= 57) || (key >= 96 && key <= 105))
                && !((key == 8) || (key == 9))
                )
                e.preventDefault();
        });
    };
})(jQuery);

/* 
* function forcePhoneNumber
* aim   : prevent typing unwanted characters
* usage : $("#inpuText").forcePhoneNumber();
* remark: available charcters 0-9,(,),+,-,<space>
* auther: av 4.2011
*/
(function($) {
    $.fn.forcePhoneNumber = function() {
        $(this).keydown(function(e) {
            var key = (e.keyCode ? e.keyCode : e.which);
            if (!((key >= 48 && key <= 57) || (key >= 96 && key <= 105)) &&
                !((key == 40) || (key == 41) || (key == 43) || (key == 45) || (key == 32))
                && !((key == 8) || (key == 9))
                )
                e.preventDefault();
        });
    };
})(jQuery);

/* 
* function alertForMaxLength
* aim   : alert "Max characters for .." while trying to type more characters than allowed
* usage : $("#inpuText").alertForMaxLength();
* params:   maxlength - when attribute MaxLength is not predefined
*           msg - redefine default
* remark:   use ## in redefined msg to take place of maxLength number
* auther: av 4.2011
*/
(function($) {
    $.fn.alertForMaxLength = function(maxLength, msg) {
        if (isNaN(maxLength))
            maxLength = 0;
        if (this.attr("maxlength") > 0 && this.attr("maxlength") < 99999) // defined and not infinit
            maxLength = this.attr("maxlength")
        else if (maxLength > 0)
            this.attr("maxLength", maxLength);
        //
        if (msg == null)
            msg = "מספר התווים המקסימאלי הוא ##";
        //
        $(this).keypress(function(e) {
            var key = (e.keyCode ? e.keyCode : e.which);
            //
            if ((maxLength > 0 && $(this).val().length == maxLength) && (key >= 32))
                alert(msg.replace("##", maxLength));
        });
    }
})(jQuery);

/* 
* function bindList
* aim   : populate combo with json list
* usage : $("#combo").addItems({string Value:string Text,..});
* auther: av 4.2011
*/
$.fn.bindList = function(data) {
    return this.each(function() {
        var list = this;
        $.each(data, function(Value, Text) {
            var option = new Option(Text, Value);
            list.add(option);
        });
    });
};

/* 
* function alertForMaxLength
* aim   : chack eMail address validation
* usage : if(!$("#inpuText").isValidEmail()){ yor code};
* auther: av 4.2011
*/
(function($) {
    $.fn.isValidEmail = function() {
        var reWhitespace = /^\s+$/;
        var reEMail = /^(([A-Za-z0-9]+_+)|([A-Za-z0-9]+\-+)|([A-Za-z0-9]+\.+)|([A-Za-z0-9]+\++))*[A-Za-z0-9]+@((\w+\-+)|(\w+\.))*\w{1,63}\.[a-zA-Z]{2,6}$/;
        var strEMail = this.val();
        return (strEMail.length < 1 || reWhitespace.test(strEMail) || reEMail.test(strEMail));
    }
})(jQuery);

/*
*
* Copyright (c) 2008 Ca-Phun Ung <caphun at yelotofu dot com>
* Dual licensed under the MIT (MIT-LICENSE.txt)
* and GPL (GPL-LICENSE.txt) licenses.
*
* http://yelotofu.com/labs/jquery/snippets/outerhtml/
*
* outerHTML is based on the outerHTML work done by Brandon Aaron
* But adds the ability to replace an element.
*/

(function($) {
    $.fn.outerHTML = $.fn.HTML = function(s) {
        return (s)
			? this.before(s).remove()
			: $('<p>').append(this.eq(0).clone()).html();
    }
})(jQuery);

/* 
* function getUrlVars
* aim   : get parameter values from URL string and return them as an associative array.
* usage : var urlArrayArgs = $.getUrlVars();  // for all as array
*         var p1 = $.getUrlVars()["p1"];      // for p1
* auther: UZBEKJON 9.2009
*         http://jquery-howto.blogspot.com/2009/09/get-url-parameters-values-with-jquery.html
*/
$.extend({
    getUrlVars: function() {
        var vars = [], hash;
        var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
        for (var i = 0; i < hashes.length; i++) {
            hash = hashes[i].split('=');
            vars.push(hash[0]);
            vars[hash[0]] = hash[1];
        }
        return vars;
    },
    getUrlVar: function(name) {
        return $.getUrlVars()[name];
    }
});

(function($) {
    $.CheckSession = function(s) {
        var ExitURL = "";
        $.ajax({
            url: 'frmCheckSession.aspx',
            async: false,
            success: function(Result) {
                ExitURL = Result;
            },
            error: function(Result) {
            }
        });
        if (ExitURL.length > 0) {
            window.location.href = ExitURL;
            return false;
        }
        return true;
    }
})(jQuery);
 