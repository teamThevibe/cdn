
var nm = 0; 
var here = ""; 
if (opener != null) 
{
 here = opener.location.href;  
 var isLayers = 0;  
 var isAll = 0; 
 var isID = 0; 
 if (document.all) 
  {
   isAll = 1;
  } 
 else if (document.getElementById) 
  {
   isID = 1;
  } 
 else 
  { 
   browserVersion = parseInt(navigator.appVersion); 
   if ((navigator.appName.indexOf("Netscape") != -1) && (browserVersion == 4)) 
   {
    isLayers = 1;
   }
  }
}

function findInPage(str) 
 {
  if (opener.closed) 
   {
    alert("Unable to find as the main window has been closed."); 
    self.close(); 
    return false;
   } 
  else if (here != opener.location.href) 
   {
    here = opener.location.href; 
    nm = 0;
   } 
  if (str == "") 
   {
    alert("Please enter the text you want to locate."); 
    return false;
   } 
  var tx, i, found; 
  if (isLayers) 
  {
   if (!opener.find(str))
     while(opener.find(str,false,true)) n++; 
   else n++;
   if (n == 0) alert(str + " not found on this page.");  
  } 
  else if (isAll) 
  {
   tx = opener.document.body.createTextRange(); 
   for (i = 0; i <= nm && (found = tx.findText(str)) != false; i++) 
   {
    tx.moveStart("character", 1); 
    tx.moveEnd("textedit");
   } 
   if (found) 
   {
    tx.moveStart("character", -1); 
    tx.findText(str);
    tx.select(); 
    tx.scrollIntoView(); 
    nm++;
   }
   else 
    {
     if (nm > 0) 
      {
       nm = 0; 
       findInPage(str);
      }
    else alert(str + " not found on this page.");
    }
   }
  else if (isID) 
  {
   var ag = navigator.userAgent.toLowerCase();
   var isG = (ag.indexOf('gecko') != -1); 
   var isR=0;
   if (isG) {t = ag.split("rv:"); 
   isR = parseFloat(t[1]);
  }
  if (isR >=1) 
  {
   if (!opener.find(str,false,false,true,false,true,false)) alert(str + " not found on this page.");
   document.search.sub.focus();
  }
  else alert("Find function not supported on this browser");
 } 
 return false;
} 
function mnWin() 
{
 if (opener.closed) 
  {
   alert("Main window has been closed."); 
   self.close();
  }
  else 
   {
    opener.focus(); 
    locatorWin();
   }
 }
function findBody() 
 {
  document.write('<div align="center"><form name="search" onsubmit="return findInPage(this.string.value);"><input name="string" id="string" type="text" size="22" onchange="nm = 0;" ><br><br><input class="OutSmallButton" name="sub" type="submit" value="Find"></form><script type="text/javascript">document.search.string.focus();</script></div>');
 }
 
 
 
