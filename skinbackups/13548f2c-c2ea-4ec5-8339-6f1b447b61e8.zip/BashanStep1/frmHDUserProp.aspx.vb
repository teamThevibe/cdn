Imports System.Web.Security
Imports System.Text.RegularExpressions
Imports VB = Microsoft.VisualBasic

Public Class frmHDUserProp
    Inherits System.Web.UI.Page
    Protected WithEvents cmdReturn As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdConfirmation As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents ErrorMessage As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents ExtraIdAnswer As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtQuestion As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFName As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtLName As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtUserName As System.Web.UI.WebControls.TextBox
    Protected WithEvents cmdCancel As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents txtPhone As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtMobile As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtMobileNum As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtFax As System.Web.UI.WebControls.TextBox
    Protected WithEvents UserNameConfirmation As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents PasswordConfirmation As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtEMail As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtUserEmail As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtError As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAppType As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtNewPassword As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtConfirmPassword As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents chkPassword As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents txtPassword As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents cmdLogout As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cboGridRowCount As System.Web.UI.WebControls.DropDownList
    Protected WithEvents txtStreet As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtHouse As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtCity As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtZIP As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtClinicID As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtClinicName As System.Web.UI.WebControls.TextBox
    Protected WithEvents cmdBack As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdOK As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents txtUserType As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtErrorType As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExpired As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents cmdHelp As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents txtFormIdentity As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents divRIcon As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents cboSection As System.Web.UI.WebControls.DropDownList
    Protected WithEvents cboCare As System.Web.UI.WebControls.DropDownList
    Protected WithEvents hidCare As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents trBshnPerm As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents trSuppPref As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents trExtraQuestion As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents trExtraAnswer As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents trEmail As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents lblMessage As System.Web.UI.WebControls.Label
    Protected WithEvents trMiscSep As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents trClinic As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents txtNewEMail As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents aIconLink2 As System.Web.UI.HtmlControls.HtmlAnchor
    Protected WithEvents lblPasswordError As System.Web.UI.WebControls.Label
    Protected WithEvents Tr1 As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents cmdDoctors As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents divPasswordError As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents tblTabs As System.Web.UI.WebControls.Table
    Protected WithEvents UserConfirmation As UserConfirmation

    Protected WithEvents gridHours As System.Web.UI.HtmlControls.HtmlTable
    Protected WithEvents txt1Open1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txt1Close1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txt1Open2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txt1Close2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txt1Comment As System.Web.UI.WebControls.TextBox

    Protected WithEvents txtMailDeliveryCity As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtMailDeliveryStreet As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtMailDeliveryHouse As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtMailDeliveryZip As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtMailDeliveryZip7 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtMailDeliveryPosition As System.Web.UI.WebControls.TextBox

    Protected WithEvents txtClinicCity As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtClinicStreet As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtClinicHouse As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtClinicZip As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtClinicZip7 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtClinicPosition As System.Web.UI.WebControls.TextBox

    Protected WithEvents txtClinicPrePhone As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtClinicPrePhone1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtClinicPrePhone2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtClinicPhone As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtClinicPhone1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtClinicPhone2 As System.Web.UI.WebControls.TextBox

    Protected WithEvents txtFaxNum As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtWeb As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtUnits As System.Web.UI.WebControls.TextBox

    Protected WithEvents chkKids As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents chkAccessDisabled As System.Web.UI.HtmlControls.HtmlInputCheckBox

    Protected WithEvents grdListClinicDoctors As System.Web.UI.WebControls.DataGrid
    Protected WithEvents txtDoctorNo As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDoctorName As System.Web.UI.WebControls.TextBox
    Protected WithEvents cmdSaveDoctor As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdNewDoctor As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdCancelDoctor As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents txtCurrentID As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtSpecialistLicense As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtStartWorkDate As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtEndWorkDate As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtLeaveReason As System.Web.UI.WebControls.TextBox
    Protected WithEvents hidUpdateDoctor As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidCheckDoctorResult As System.Web.UI.HtmlControls.HtmlInputHidden

    Dim Utl As New Utils


    'Protected WithEvents txt2Open1 As System.Web.UI.WebControls.TextBox
    'Protected WithEvents txt2Close1 As System.Web.UI.WebControls.TextBox
    'Protected WithEvents txt2Open2 As System.Web.UI.WebControls.TextBox
    'Protected WithEvents txt2Close2 As System.Web.UI.WebControls.TextBox
    'Protected WithEvents txt2Comment As System.Web.UI.WebControls.TextBox

    Protected Const sEmptyWorkHours As String = "hh:mm"

    Enum eDoctorsCheck As Integer
        Correct = 0
        DoctorNotFound = 1
        DoctorCheckDateIsEmpty = 2
        DoctorNoNotFound = 6

        ClinicDoctorNoNotFound = 3
        ClinicCheckDateIsEmpty = 4
        ClinicDoctorOnlyOne = 5
    End Enum

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load





        ' CType(Master.FindControl("MainTitle"), Literal).Text = "����� ��� - ���� �����"
        Dim sMainTitle As String = "����� ��� - " & Page.Title
        CType(Master.FindControl("MainTitle"), Literal).Text = sMainTitle
        Page.Title = sMainTitle

        Dim strUserType As String

        If Not IsPostBack Then

            If Session("User_Login_First_Time") = "1" Then
                Response.Redirect((New Utils).GetLinkForNextForm("frmHDUserPass.aspx"))
            End If

            Dim objUser As New UserConnect.UserService()
            objUser.Url = Application("UserWebService").ToString()

            If Application("RightLogo") = "1" Then
                divRIcon.Visible = True
            Else
                divRIcon.Visible = False
            End If

            divRIcon.Visible = False

            Dim strUserName As String = User.Identity.Name
            Dim strFName As String
            Dim strLName As String
            Dim strStreet As String
            Dim strHouse As String
            Dim strCity As String
            Dim strZIP As String
            Dim strPhone As String
            Dim strMobile As String
            Dim strFax As String
            Dim strEMail As String
            Dim strCFName As String
            Dim strCLName As String
            Dim strCStreet As String
            Dim strCHouse As String
            Dim strCCity As String
            Dim strCZIP As String
            Dim strCPhone As String
            Dim strCMobile As String
            Dim strCFax As String
            Dim strCEMail As String
            Dim strBank As String
            Dim strBranch As String
            Dim strAccount As String
            Dim strMailStreet As String
            Dim strMailPhone As String
            Dim strMailHouse As String
            Dim strMailEMail As String
            Dim strMailCity As String
            Dim strMailZIP As String
            Dim strService1 As String
            Dim strService2 As String
            Dim strService3 As String
            Dim strService4 As String
            Dim strService5 As String
            Dim strService6 As String
            Dim strProf1 As String
            Dim strProf2 As String
            Dim strProf3 As String
            Dim strProf4 As String
            Dim strProf5 As String
            Dim strClinicID As String
            Dim strClinicName As String
            Dim strDoctorID As String
            Dim strSupplierID As String
            Dim strSection As String
            Dim strCare As String
            Dim strDefaultExecutor As String = ""
            Dim strGridRowCount As String
            Dim iSection As Integer = -1
            Dim iSupplierID As Integer
            Dim iShilaSupplier As Integer = objUser.IsShilaSupplier("4DA7CCB6-14A5-4D27-9DF3-AD449A470103", User.Identity.Name)

            Dim strExtraIdQuestion As String
            Dim strExtraIdAnswer As String
            Dim dsServices As Data.DataSet = objUser.GetServices("8BEF9B3C-5CCB-43E8-8253-4DCD6E5334F6")



            Dim dsProf As Data.DataSet = objUser.GetProficiencies("7EF9182D-B6D5-48F1-8719-DE71CB54A522")

            Dim arrValues() As Integer = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15}

            cboGridRowCount.DataSource = arrValues
            cboGridRowCount.DataBind()

            objUser.GetProperties("305A57FB-F38A-4592-AA8E-882D66B1DEFC", strUserName, strUserType, strFName, strLName, strStreet, strHouse, strCity, strZIP, strPhone, strMobile, strFax, strEMail, _
                                  strCFName, strCLName, strCStreet, strCHouse, strCCity, strCZIP, strCPhone, strCMobile, strCFax, strCEMail, _
                                  strBank, strBranch, strAccount, strMailStreet, strMailPhone, strMailHouse, strMailEMail, strMailCity, strMailZIP, _
                                  strService1, strService2, strService3, strService4, strService5, strService6, strProf1, strProf2, strProf3, strProf4, _
                                  strProf5, strClinicID, strClinicName, strDoctorID, strSupplierID, strSection, strCare, strGridRowCount, strExtraIdQuestion, strExtraIdAnswer)
            txtUserName.Text = Utils.AntiXSSHtml(strUserName)

            Dim objRequest As New SupplierConnect.RequestClaim()
            objRequest.Url = Application("SupplierWebService").ToString()
            If IsNumeric(strSupplierID) Then
                iSupplierID = CInt(strSupplierID)
            End If

            Dim ds As Data.DataSet = objRequest.GetSectionsList("0CBD2A1A-C450-424E-801C-8E90FDC01998", iSupplierID)
            Dim currRow As Data.DataRow

            cboSection.Items.Add(New ListItem("��� ���", ""))

            For Each currRow In ds.Tables(0).Rows
                cboSection.Items.Add(New ListItem(currRow("SectionName").ToString(), currRow("SectionCode").ToString()))
            Next
            If IsNumeric(strSection) Then
                iSection = CInt(strSection)
            End If
            ds = objRequest.GetCareBySection("491AE412-CF31-4644-AC7C-59DD8505B5A1", iSection)

            cboCare.Items.Add(New ListItem("��� �����", ""))
            For Each currRow In ds.Tables(0).Rows
                cboCare.Items.Add(New ListItem(currRow("CareName").ToString(), currRow("CareID").ToString()))
            Next

            Dim strToday As String = Date.Today.ToString("ddMMyyyy")
            ds = objRequest.GetSubSuppliersList("949BE198-F48B-4E9D-8B4A-5983224F93EC", iSupplierID, strToday)

            Dim bBshnPerm As Boolean = False
            Dim bSuppPref As Boolean = False
            Dim bCarePref As Boolean = False

            cmdHelp.Disabled = False
            txtClinicID.ReadOnly = True
            txtClinicID.Attributes.Remove("onfocus")
            txtClinicID.Attributes.Remove("onblur")
            txtClinicName.ReadOnly = True
            txtClinicName.Attributes.Remove("onfocus")
            txtClinicName.Attributes.Remove("onblur")
            bBshnPerm = True

            txtUserType.Value = strUserType
            trBshnPerm.Visible = bBshnPerm
            trSuppPref.Visible = bSuppPref
            txtAppType.Value = Application("App_Type").ToString
            txtFName.Text = strFName
            txtLName.Text = strLName
            txtStreet.Text = strStreet
            txtHouse.Text = strHouse
            txtCity.Text = strCity
            txtZIP.Text = strZIP
            txtPhone.Text = strPhone
            txtMobile.Text = strMobile
            txtFax.Text = strFax
            txtEMail.Text = Trim(strEMail)

            txtClinicID.Text = strClinicID
            txtClinicName.Text = strClinicName

            'UsersExtra info
            Dim UserService As New UserConnect.UserService()
            UserService.Url = Utils.Values.GetApplicationString("UserWebService")
            Dim dsExtra As DataSet = UserService.GetUserExtraData("D393D747-2C1F-49EB-956F-2083EA210108", strUserName)

            txtMailDeliveryCity.Text = _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_DOAR_YESHUV").Trim() + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "RO_DOAR_YESHUV").Trim()
            txtMailDeliveryStreet.Text = _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_DOAR_REHOV").Trim() + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "RO_DOAR_REHOV").Trim()
            txtMailDeliveryHouse.Text = _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_DOAR_BAIT") + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "RO_DOAR_BAIT")
            txtMailDeliveryZip.Text = _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_MIQUD") + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "RO_MIQUD")
            txtMailDeliveryZip7.Text = _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_MIQUD_A") + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "RO_MIQUD_A")
            txtMailDeliveryPosition.Text = _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_DOAR_MIQUM") + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "RO_DOAR_MIQUM")
            txtClinicCity.Text = _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_MIRPAA_YESHUV").Trim() + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "RO_MIRPAA_YESHUV").Trim()
            txtClinicStreet.Text = _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_MIRPAA_REHOV").Trim() + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "RO_MIRPAA_REHOV").Trim()
            txtClinicHouse.Text = _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_MIRPAA_BAIT") + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "RO_MIRPAA_BAIT")
            txtClinicZip.Text = _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_MIRPAA_MIQUD") + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "RO_MIRPAA_MIQUD")
            txtClinicZip7.Text = _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_MIRPAA_MIQUD_A") + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "RO_MIRPAA_MIQUD_A")
            txtClinicPosition.Text = _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_MIRPAA_MIQUM") + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "RO_MIRPAA_MIQUM")
            txtClinicPrePhone.Text = _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_QIDOMET_TELEFON") + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "RO_QIDOMET_TELEFON")
            txtClinicPhone.Text = _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_TELEFON") + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "RO_TELEFON")
            txtClinicPrePhone1.Text = _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_QIDOMET_TELEFON_NOSAF1") + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "RO_QIDOMET_TELEFON_NOSAF1") + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_QID_TELEFON_NOSAF1")
            txtClinicPhone1.Text = _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_TELEFON_NOSAF1") + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "RO_TELEFON_NOSAF1")
            txtClinicPrePhone2.Text = _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_QIDOMET_TELEFON_NOSAF2") + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "RO_QIDOMET_TELEFON_NOSAF2") + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_QID_TELEFON_NOSAF2")
            txtClinicPhone2.Text = _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_TELEFON_NOSAF2") + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "RO_TELEFON_NOSAF2")
            txtFaxNum.Text = _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_FAX") + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "RO_FAX")
            txtMobileNum.Text = _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_MOBILE") + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "RO_MOBILE")
            txtUserEmail.Text = _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_E_MAIL").Trim() + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "RO_E_MAIL").Trim()
            txtWeb.Text = _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_WEB_SITE_NAME").Trim() + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "RO_WEB_SITE_NAME").Trim()
            txtUnits.Text = _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_UNITS_NUMBER") + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "RO_UNITS_NUMBER")

            Dim sKids As String = _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_YELADIM").Trim() + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "RO_YELADIM").Trim()

            If sKids = "�" Then
                chkKids.Checked = True
            End If

            Dim sAccessDisabled As String = _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_GISA_LENECHIM") + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "RO_GISA_LENECHIM")
            If sAccessDisabled = "�" Then
                chkAccessDisabled.Checked = True
            End If


            ' YT: Some fields not in use...
            '   RO_MISPAR_ROFE, 
            '   RO_MAHUT_ROFE, 
            '   RO_SHEM_ROFE, 
            '   RO_TAARIX_SIYUM_AHRAYUT
            Dim Val As String
            Val = _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_MISPAR_ROFE") + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "RO_MISPAR_ROFE")
            If Val.Length > 0 Then
                txtClinicID.Text = Val
            End If
            Val = _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "HDBS_SHEM_ROFE").Trim() + _
                Utils.Values.GetFirstTableFirstRowString(dsExtra, "RO_SHEM_ROFE").Trim()
            If Val.Length > 0 Then
                txtClinicName.Text = Val
            End If
            ' YT

            SetComboValue(cboGridRowCount, strGridRowCount)

            Dim ExtraIdQuestionFromTable As String = ""
            Dim ExtraIdAnswerFromTable As String = ""

            trExtraQuestion.Style.Add("display", "none")
            trExtraAnswer.Style.Add("display", "none")
            Tr1.Style.Add("display", "none")
            lblMessage.Text = Utils.AntiXSSHtml(Session("Message_Text"))

            If Session("User_Login_First_Time") = "1" Then
                txtError.Value = "�� ����� �����"
                txtExpired.Value = "1"
                txtNewEMail.Value = Trim(strEMail)
            Else
                trEmail.Visible = False
                txtExpired.Value = ""
            End If

            BindGridClinicDoctors()

            FillOpeningHours(strUserName)
        Else
            strUserType = txtUserType.Value
            divPasswordError.Visible = False
        End If

        Dim iCheckDoctorResult As Integer = Utils.Values.GetSessionInteger("CheckDoctorResult")
        If iCheckDoctorResult = 0 Then
            DirectCast(Me.Master, HDMasterPage).SetDisableMenu("0")
        Else
            DirectCast(Me.Master, HDMasterPage).SetDisableMenu("1")
        End If
        If Not IsPostBack Then
            If iCheckDoctorResult <> 0 Then
                cmdOK.Disabled = True
            End If
            hidCheckDoctorResult.Value = iCheckDoctorResult.ToString
        End If

    End Sub

    Function CheckDoctors() As Integer

        Dim iCheckDoctorResult As Integer = 0

        If Application("CheckDoctorID") = "1" Then
            Dim objUser As New UserConnect.UserService()
            objUser.Url = Application("UserWebService").ToString()
            iCheckDoctorResult = objUser.CheckDoctorID("EB2F60ED-E277-42EA-9310-EDBB15B97445", User.Identity.Name)
        End If

        Session("CheckDoctorResult") = iCheckDoctorResult
        hidCheckDoctorResult.Value = iCheckDoctorResult.ToString

        If iCheckDoctorResult = 0 Then
            cmdOK.Disabled = False
        Else
            cmdOK.Disabled = True
        End If

        Return iCheckDoctorResult

    End Function

    Private Sub AfterDoctorUpdate()
        Dim iCheckDoctorResult As Integer = Val(Session("CheckDoctorResult") & "")


        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

        objUser.UpdateDoctorCheckDate("461FD5B6-9A6D-42CD-90A3-AB7753107E01", User.Identity.Name)

        Dim bIndependent As Boolean
        Dim bAllowClaims As Boolean
        Dim bWebInterfaceAllow As Boolean
        Dim bWebServiceAllow As Boolean
        objUser.GetBashanUserPermitions("83EC08DB-E750-45BA-8F6D-B4B6BF76D018", User.Identity.Name, bIndependent, bAllowClaims, bWebInterfaceAllow, bWebServiceAllow)
        If bIndependent Then
            Session("BSHN_Independed") = "1"
        Else
            Session("BSHN_Independed") = ""
        End If

        CheckDoctors()

    End Sub

    'Sub SetDoctorsMessage(ByVal iCheckDoctorResult As Integer)
    '    'setDoctorsMessage Msg - on Client side
    '    If iCheckDoctorResult = 0 Then
    '        trDoctorsMsg.Style.Item("display") = "none"
    '    Else
    '        trDoctorsMsg.Style.Item("display") = "block"
    '        'setDoctorsMessage Msg - on Client side
    '    End If


    'End Sub


    Private Sub cmdOK_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdOK.ServerClick

        Dim strUserName As String = User.Identity.Name
        Dim strPassword As String
        Dim emailvalue As String

        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

        If objUser.GetUserAllowChangePassword("32B79620-E74B-11DF-9492-0800200C9A66", User.Identity.Name) Then
            If chkPassword.Disabled Then
                chkPassword.Checked = True
            End If
        End If

        If chkPassword.Checked = True Then
            strPassword = Trim(txtPassword.Value)
            If Len(strPassword) = 0 Then
                ShowError("���� �����")
                Return
            End If

            Dim iResult As Integer = objUser.CheckUser("79D565C1-784C-4606-935B-68BA32141600", strUserName, strPassword, "0", -1, Request.UserHostAddress, User.Identity.Name)
            If iResult = -20 Then
                Dim SignOut As Boolean = (New Utils).SignOut(Application("FORMLogin"))
            End If
            If iResult <> 0 And iResult <> 10 Then
                ShowError("������ ������� �����")
                Return
            End If

            If Trim(txtNewPassword.Value) <> Trim(txtConfirmPassword.Value) Then
                ShowError("����� ����� �� ��� ������ �����")
                Return
            End If

            If LCase(Trim(txtNewPassword.Value)) = LCase(Trim(txtUserName.Text)) Then
                ShowError("���� ������� ���� ��� ��� ������")
                Return
            End If

            strPassword = Trim(txtNewPassword.Value)
            If Trim(txtPassword.Value) = strPassword Then
                ShowError("���� ������� ����� ���� ��� ������ �������")
                Return
            End If

            If (CBool(Application("PasswordVerification"))) Then
                Dim strRegEx As String = Application("PasswordRegEx").ToString() & ""
                Dim nCheck As Integer = objUser.CheckNewPasswordEx("2DDEF6A6-4053-491A-8642-CF441B81BA46", strPassword, strRegEx)
                Select Case nCheck
                    Case 4, 5
                        divPasswordError.InnerHtml = objUser.GetPassInstruction("B8CD9DE5-95C1-466d-AC29-E8170E3BCA2E")
                        txtErrorType.Value = "2"
                        divPasswordError.Visible = True
                        Return
                    Case 6
                        ShowError("����� ����� ���")
                        Return
                End Select
            Else
                Select Case objUser.CheckNewPassword("2A8A46F2-A060-4FD9-B74E-3784FEC1C0EF", strPassword)
                    Case 1
                        ShowError("���� ������ ���� ����� ��� 6 � 10 �����")
                        Return
                    Case 2
                        ShowError("�� ������ ������� ������� ����")
                        Return
                    Case 3
                        ShowError("��� ����� �� ���� ���� �� ����� ���� �������")
                        Return
                End Select
            End If

            If objUser.CheckPasswordHistory("6BC8399D-247C-48E4-8312-7FC05ECA207E", strUserName, strPassword) Then
                ShowError("������ ����� ���� ��� ������")
                Return
            End If
        End If

        If Not CheckRegularexpression() Then
            Return
        End If

        If Session("User_Login_First_Time") = "1" Then
            If Not CheckRegularexpression() Then
                Return
            End If
        End If

        If chkPassword.Checked = True Then
            If objUser.UpdatePassword("5561A874-D4D7-4E5C-AA3D-4EC0EBAA8B7F", strUserName, strPassword, 1, User.Identity.Name) And Application("App_Type").ToString.ToUpper() = "SUPP" Then
                Session("User_Password") = strPassword
            End If
        End If

        Dim strService1 As String = ""
        Dim strService2 As String = ""
        Dim strService3 As String = ""
        Dim strService4 As String = ""
        Dim strService5 As String = ""
        Dim strService6 As String = ""
        Dim strProf1 As String = ""
        Dim strProf2 As String = ""
        Dim strProf3 As String = ""
        Dim strProf4 As String = ""
        Dim strProf5 As String = ""
        Dim strSection As String = GetComboValue(cboSection)
        Dim strCare As String = hidCare.Value
        Dim iExecutor As Integer
        Dim iGridRowCount As Integer
        Dim iShilaSupplier As Integer = objUser.IsShilaSupplier("4DA7CCB6-14A5-4D27-9DF3-AD449A470103", User.Identity.Name)

        iGridRowCount = CInt(cboGridRowCount.SelectedItem.Value)

        Dim sTxtStreet As String = VB.Left(Trim(txtStreet.Text), 24)
        Dim sTxtZIP As String = VB.Left(Trim(txtZIP.Text), 6)
        Dim bOK As Boolean = False


        bOK = objUser.UpdateProperties("0D792E26-D8BA-40B9-8A93-51B685CF92FD", strUserName, txtFName.Text, txtLName.Text, sTxtStreet, txtHouse.Text, txtCity.Text, sTxtZIP, _
                                    txtPhone.Text, txtMobile.Text, txtFax.Text, txtEMail.Text, "", "", "", "", "", "", "", "", "", "", _
                                    "", "", "", "", "", "", "", "", "", strService1, strService2, strService3, strService4, _
                                    strService5, strService6, strProf1, strProf2, strProf3, strProf4, strProf5, txtClinicID.Text, txtClinicName.Text, "", strSection, strCare, iGridRowCount, User.Identity.Name)

        If (bOK) Then
            bOK = SaveOpeningHours()
        End If

        If (bOK) Then
            bOK = SaveExtraDetails()
        End If

        If (bOK) Then
            Dim currRow As Data.DataRow
            Dim objRequest As New SupplierConnect.RequestClaim()
            objRequest.Url = Application("SupplierWebService").ToString()

            Dim ds As Data.DataSet = Nothing
            If Not strSection.Equals("") Then
                ds = objRequest.GetCareBySection("491AE412-CF31-4644-AC7C-59DD8505B5A1", strSection)
            End If

            cboCare.Items.Clear()
            cboCare.Items.Add(New ListItem("��� �����", ""))
            If Not ds Is Nothing Then
                If Application("TikshuvEnabled").ToString() = "1" Then
                    cboCare.Items.Add(New ListItem("���", "0"))
                End If
                For Each currRow In ds.Tables(0).Rows
                    cboCare.Items.Add(New ListItem(currRow("CareName").ToString(), currRow("CareID").ToString()))
                Next
                SetComboValue(cboCare, strCare)
            End If

            If Session("User_Login_First_Time") = "1" Then
                Session("User_Login_First_Time") = ""
                Session("User_Prop_Caller") = Application("FORMRepStat")
            End If

            chkPassword.Disabled = False
            chkPassword.Checked = False
            txtError.Value = "������� ������ ������"
            txtErrorType.Value = ""
            txtExpired.Value = ""
            hidUpdateDoctor.Value = ""
        Else
            txtError.Value = "���� ��� ����� �������!"
        End If

    End Sub

    Private Sub SetComboValue(ByRef cbo As DropDownList, ByVal strValue As String)
        Dim li As ListItem = cbo.Items.FindByValue(strValue)
        If Not li Is Nothing Then
            li.Selected = True
        End If
    End Sub

    Private Function GetComboValue(ByVal cbo As DropDownList) As String
        Dim strRetValue As String = "0"
        Dim li As ListItem = cbo.SelectedItem
        If Not li Is Nothing Then
            strRetValue = li.Value
        End If
        Return strRetValue
    End Function

    Private Sub ShowError(ByVal strMessage As String)
        txtError.Value = strMessage
        txtErrorType.Value = "1"
    End Sub

    Private Sub cmdLogout_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdLogout.ServerClick
        Dim SignOut As Boolean
        If Application("HKLLDP") <> "" Then
            SignOut = (New Utils).SignOut("LoginHKL.aspx?out=1")
        Else
            SignOut = (New Utils).SignOut(Application("FORMLogin"))
        End If
    End Sub

    Private Sub cmdReturn_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.ServerClick
        Response.Redirect(Application("FORMStart"))
    End Sub

    Private Sub cmdBack_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdBack.ServerClick
        Dim FormUserProp As String = Application("FORMUserProp")
        'mesh
        If Application("HasCB") = "1" Then
            Response.Redirect("frmCBMenu.aspx")
        End If
        'meshend
    End Sub

    Private Function CheckRegularexpression() As Boolean
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim emailvalue As String
        Dim sRegExpr As String
        emailvalue = txtEMail.Text.ToLower
        If (emailvalue.Trim().Length() > 0) Then
            sRegExpr = objUser.GetEmailValidation("E600F1B9-D4C7-4FC4-B1B6-922F3967456E")
            If Not Regex.IsMatch(emailvalue, sRegExpr) Then
                ShowError("����� ����''� �� �����")
                Return False
            End If
        End If
        Return True
    End Function

    Private aColumnNames As String() = {"UserName", "WeekDay", "OpenTime1", "CloseTime1", "OpenTime2", "CloseTime2", "Comment", "CodePrezentation"}
    Private aControlNames As String() = {"txt{0}Open1", "txt{0}Close1", "txt{0}Open2", "txt{0}Close2", "txt{0}Comment", "txtCodePrezentation{0}"}

    Private Sub FillOpeningHours(ByVal strUserName As String)
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim sUserName As String = User.Identity.Name

        Dim ds As DataSet = objUser.GetOpeningHours("4AF52CED-8D73-4D34-A6B7-8315CF2B97EB", sUserName)
        If (ds.Tables.Count > 0) Then
            Dim dTable As DataTable = ds.Tables(0)

            Dim iWeekDay As Integer = -1
            Dim sColumnName As String = ""
            Dim sControlID As String = ""
            Dim sControlValue As String
            Dim CurrentTextBox As TextBox = Nothing

            For Each dr As DataRow In dTable.Rows
                iWeekDay = dr("WeekDay")
                For iControl As Integer = 0 To aControlNames.Length - 1
                    sColumnName = aColumnNames(iControl + 2)
                    sControlValue = dr(sColumnName)
                    If (sControlValue <> "") Then
                        sControlID = String.Format(aControlNames(iControl), iWeekDay)
                        If TypeOf gridHours.FindControl(sControlID) Is DropDownList Then
                            If sControlValue.ToString().Trim() = "1" Then
                                CType(gridHours.FindControl(sControlID), DropDownList).Text = "1"
                            Else
                                CType(gridHours.FindControl(sControlID), DropDownList).Text = "0"
                            End If
                        Else
                            CurrentTextBox = CType(gridHours.FindControl(sControlID), TextBox)
                            CurrentTextBox.Text = sControlValue.ToString().Trim()
                        End If
                    End If
                    'If ((sControlValue = "") And (iControl < aControlNames.Length - 1)) Then
                    '    sControlValue = sEmptyWorkHours
                    'End If
                    'CurrentTextBox.Text = sControlValue
                Next
            Next
        End If
    End Sub

    Private Function SaveExtraDetails() As Boolean
        Dim bOk As Boolean = False
        bOk = True

        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()


        Dim sUserName As String = User.Identity.Name

        Dim sIsKidsTreat As String
        sIsKidsTreat = "�"
        If chkKids.Checked Then
            sIsKidsTreat = "�"
        End If

        Dim sIsAccess As String
        sIsAccess = "�"
        If chkAccessDisabled.Checked Then
            sIsAccess = "�"
        End If

        bOk = objUser.UpdateUserExtra("BD3EE2FA-EDEB-4941-84AF-CED977157C1D", sUserName, txtMailDeliveryCity.Text, txtMailDeliveryStreet.Text, txtMailDeliveryHouse.Text, Val(txtMailDeliveryZip.Text), Val(txtMailDeliveryZip7.Text), txtMailDeliveryPosition.Text, txtClinicCity.Text, txtClinicStreet.Text, txtClinicHouse.Text, Val(txtClinicZip.Text), Val(txtClinicZip7.Text), txtClinicPosition.Text, _
          txtClinicPrePhone.Text, txtClinicPhone.Text, txtClinicPrePhone1.Text, txtClinicPhone1.Text, txtClinicPrePhone2.Text, txtClinicPhone2.Text, txtWeb.Text, Val(txtUnits.Text), sIsKidsTreat, sIsAccess, txtFaxNum.Text, txtMobileNum.Text, txtUserEmail.Text, User.Identity.Name)

        Return bOk
    End Function

    Private Function SaveOpeningHours() As Boolean
        Dim bOk As Boolean = False

        Dim sUserName As String = User.Identity.Name
        Dim dTable As New DataTable()
        Dim dColumn As DataColumn
        Dim dRow As DataRow

        For iColumn As Integer = 0 To aColumnNames.Length - 1
            dColumn = New DataColumn()
            dColumn.Caption = aColumnNames(iColumn)
            dColumn.ColumnName = aColumnNames(iColumn)
            If (iColumn = 1) Then
                dColumn.DataType = Type.[GetType]("System.Int32") 'System.Integer
            Else
                dColumn.DataType = Type.[GetType]("System.String")
            End If
            dTable.Columns.Add(dColumn)
        Next

        Dim bAddRow As Boolean = False
        Dim sColumnName As String = ""
        Dim sControlID As String = ""
        Dim sControlValue As String
        Dim CurrentTextBox As TextBox = Nothing

        For iWeekDay As Integer = 1 To 7
            bAddRow = False

            dRow = dTable.NewRow()
            dRow("UserName") = sUserName
            dRow("WeekDay") = iWeekDay

            For iControl As Integer = 0 To aControlNames.Length - 1
                sControlID = String.Format(aControlNames(iControl), iWeekDay)
                If TypeOf gridHours.FindControl(sControlID) Is DropDownList Then
                    sControlValue = CType(gridHours.FindControl(sControlID), DropDownList).Text
                Else
                    CurrentTextBox = CType(gridHours.FindControl(sControlID), TextBox)
                    sControlValue = CurrentTextBox.Text
                End If
                If (sControlValue = sEmptyWorkHours) Then
                    sControlValue = ""
                ElseIf (sControlValue <> "") Then
                    bAddRow = True
                End If
                sColumnName = aColumnNames(iControl + 2)
                dRow(sColumnName) = sControlValue
            Next

            If (bAddRow) Then
                dTable.Rows.Add(dRow)
            End If
        Next

        Dim ds As New DataSet()
        ds.Tables.Add(dTable)

        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

        objUser.SaveOpeningHours("CD48FCAA-37BE-4786-96F5-DC3D88F19CD4", sUserName, ds)

        bOk = True

        Return bOk

    End Function

    'grdListClinicDoctors
    Protected Function EncodeField(ByRef objCode As Object) As String
        Dim strReturn As String = ""
        If Not IsDBNull(objCode) Then
            strReturn = CEncode.StringEncode(objCode.ToString())
        End If
        Return strReturn
    End Function

    Private Sub BindGridClinicDoctors()
        Dim objList As New UserConnect.UserService()
        objList.Url = Application("UserWebService").ToString()
        grdListClinicDoctors.DataSource = objList.GetDoctorList("03407803-DE6A-41AA-87DC-60D1D0329753", User.Identity.Name)
        grdListClinicDoctors.DataBind()
    End Sub

    Private Sub cmdSaveClinicDoctors_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSaveDoctor.ServerClick

        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim sDoctorNo As String = Trim(txtDoctorNo.Text)
        Dim sDoctorName As String = Trim(txtDoctorName.Text)

        If Not Len(sDoctorNo) > 0 Or Not Len(sDoctorName) > 0 Then
            txtError.Value = "�� ������ ���� ����� ��� ���� ���� ������ �����"
            Return
        End If
        If DoctorIDExist(CInt(sDoctorNo)) Then
            txtError.Value = "���� ����� ������ ��� ����, ��� ���� ���� ���"
            txtDoctorNo.Text = ""
            Return
        End If

        Dim iSpecialistLicense As Integer = Val(Trim(txtSpecialistLicense.Text))
        Dim dStartWorkDate As Date = Utl.StringToDate(txtStartWorkDate.Text)
        Dim dEndWorkDate As Date = Utl.StringToDate(txtEndWorkDate.Text)
        Dim iLeaveReason As Integer = Val(Trim(txtLeaveReason.Text))
        If Not objUser.AddNewCaringDoctor("91F850A70-6AD6-470C-9AFF-CD9A645684C1", User.Identity.Name, sDoctorNo, sDoctorName, iSpecialistLicense, dStartWorkDate, dEndWorkDate, iLeaveReason, User.Identity.Name) Then
            txtError.Value = "���� ������ ������ �����"
            Return
        End If

        txtDoctorNo.Text = ""
        txtDoctorName.Text = ""
        txtSpecialistLicense.Text = ""
        txtStartWorkDate.Text = ""
        txtEndWorkDate.Text = ""
        txtLeaveReason.Text = ""

        grdListClinicDoctors.EditItemIndex = -1 'Set the EditItemIndex property to -1 to exit editing mode. 
        hidUpdateDoctor.Value = "N" ' Not Edit mode
        AfterDoctorUpdate()

        cmdOK.Disabled = False
        cmdNewDoctor.Disabled = False

        BindGridClinicDoctors()
    End Sub

    Private Function DoctorIDExist(ByVal iDoctorID As Integer, Optional ByVal iRowID As Long = -1) As Boolean
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Return objUser.DoctorIDExist("B4B3D83D-7B35-4FA5-8EC6-34EF15A8C3F3", User.Identity.Name, iDoctorID, iRowID)
    End Function

    Private Sub grdList_EditCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdListClinicDoctors.EditCommand
        grdListClinicDoctors.EditItemIndex = e.Item.ItemIndex
        hidUpdateDoctor.Value = "Y" ' Edit mode
        BindGridClinicDoctors()

        cmdOK.Disabled = True
        cmdNewDoctor.Disabled = True

    End Sub

    Private Sub grdList_CancelCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdListClinicDoctors.CancelCommand
        grdListClinicDoctors.EditItemIndex = -1
        hidUpdateDoctor.Value = "N"
        CheckDoctors()
        BindGridClinicDoctors()

        cmdOK.Disabled = False
        cmdNewDoctor.Disabled = False

    End Sub

    Private Sub grdListClinicDoctors_UpdateCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdListClinicDoctors.UpdateCommand
        Dim CurrentTextBox As TextBox

        Dim iRowID As Integer = grdListClinicDoctors.DataKeys(CInt(e.Item.ItemIndex))

        CurrentTextBox = CType(e.Item.FindControl("DocNo"), TextBox)   'e.Item.Cells(1).Controls(0)
        Dim sDoctorNo As String = Trim(CurrentTextBox.Text)
        If Len(sDoctorNo) > 6 Or Len(sDoctorNo) = 0 Then
            txtError.Value = "�� ������ ���� ����� ����"
            Return
        End If
        Dim iDoctorNo As Integer = Val(sDoctorNo)
        If iDoctorNo = 0 Then
            txtError.Value = "�� ������ ���� ����� ����"
            Return
        End If

        CurrentTextBox = CType(e.Item.FindControl("DocName"), TextBox)
        Dim sDoctorName As String = Trim(CurrentTextBox.Text)
        If Not Len(sDoctorName) > 0 Then
            txtError.Value = "���� ������ �� ���� "
            Return
        End If

        If DoctorIDExist(CInt(sDoctorNo), iRowID) Then
            txtError.Value = "���� ������� ������ ��� ���� ������" & vbNewLine & "�� ������ ���� ������ ������ �� ���� ���"
            Return
        End If

        CurrentTextBox = CType(e.Item.FindControl("SpecialistLicense"), TextBox)
        Dim iSpecialistLicense As Integer = Val(Trim(CurrentTextBox.Text))

        CurrentTextBox = CType(e.Item.FindControl("StartWorkDate"), TextBox)
        Dim dStartWorkDate As Date = Utl.StringToDate(CurrentTextBox.Text)


        CurrentTextBox = CType(e.Item.FindControl("EndWorkDate"), TextBox)
        Dim dEndWorkDate As Date = Utl.StringToDate(CurrentTextBox.Text)

        'CurrentTextBox = CType(e.Item.FindControl("LeaveReason"), TextBox)
        'Dim iLeaveReason As Integer = Val(Trim(CurrentTextBox.Text))
        Dim iLeaveReason As Integer
        iLeaveReason = 0

        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

        If objUser.UpdateCaringDoctorByID("91F850A70-6AD6-470C-9AFF-CD9A645684C2", iRowID, iDoctorNo, sDoctorName, iSpecialistLicense, dStartWorkDate, dEndWorkDate, iLeaveReason, User.Identity.Name) Then
            grdListClinicDoctors.EditItemIndex = -1
            hidUpdateDoctor.Value = "N"
            AfterDoctorUpdate()
            BindGridClinicDoctors()

            cmdOK.Disabled = False
            cmdNewDoctor.Disabled = False

        End If
    End Sub

    Protected Function FormatDateTime(ByRef dtViewDate As Object) As String
        If IsDBNull(dtViewDate) Then
            Return ""
        Else
            Return Format(dtViewDate, "dd/MM/yyyy")
        End If
    End Function


    Private Sub grdListClinicDoctors_DeleteCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdListClinicDoctors.DeleteCommand
        hidUpdateDoctor.Value = "N"
        If Not IsDBNull(grdListClinicDoctors.DataKeys(CInt(e.Item.ItemIndex))) Then
            Dim iRowID As Integer = grdListClinicDoctors.DataKeys(CInt(e.Item.ItemIndex))
            If grdListClinicDoctors.DataKeys.Count > 1 Or grdListClinicDoctors.PageCount > 1 Then
                Dim objUser As New UserConnect.UserService()
                objUser.Url = Application("UserWebService").ToString()
                If objUser.DeleteDoctorByID("50824D86-4116-4883-AEEC-A850147021E0", iRowID, User.Identity.Name) Then
                    grdListClinicDoctors.EditItemIndex = -1
                    CheckDoctors()
                    BindGridClinicDoctors()
                End If
            Else
                txtError.Value = "��� ������ ����� ���� �����"
            End If
        Else
            txtError.Value = "����� �� �����"
        End If
    End Sub


    Private Sub grdList_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles grdListClinicDoctors.PageIndexChanged
        grdListClinicDoctors.CurrentPageIndex = e.NewPageIndex
        BindGridClinicDoctors()
    End Sub


End Class
