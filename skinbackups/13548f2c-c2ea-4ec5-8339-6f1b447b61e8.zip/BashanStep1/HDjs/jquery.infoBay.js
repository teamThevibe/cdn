﻿
(function($) {
    $.fn.disableButton = function(disabled) {
        if (disabled === undefined) {
            if (this.attr("disabled")) {
                disabled = true;
            }
            else {
                disabled = false;
            }
        }
        if (disabled) {
            this.attr("disabled", true);
            this.css("color", "gray");
            this.prop("Bcolor", this.css("background-color"));
            this.css("background-color", "#6D7792");
        } else {
            this.removeAttr("disabled");
            this.css("color", "");
            var Bcolor = this.prop("Bcolor");
            if (Bcolor==undefined) {
                this.css("background-color", "");
            }
            else{
                this.css("background-color", Bcolor);
            }
        }
    }
})(jQuery);
