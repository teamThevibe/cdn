﻿Public Partial Class frmHDExpirePwd
    Inherits System.Web.UI.Page

    Protected WithEvents tdRightPic As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents imgRightPic As System.Web.UI.HtmlControls.HtmlImage
    Protected WithEvents divRIcon As System.Web.UI.HtmlControls.HtmlGenericControl

    Protected WithEvents tdAlertMsg As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents tdTitle As System.Web.UI.HtmlControls.HtmlTableCell

    Protected WithEvents cmdChangePassword As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents aIconLink As System.Web.UI.HtmlControls.HtmlAnchor
    Protected WithEvents aIconLink2 As System.Web.UI.HtmlControls.HtmlAnchor
    Protected WithEvents cmdContinue As System.Web.UI.HtmlControls.HtmlInputButton

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        DirectCast(Me.Master, HDMasterPage).SetDisableMenu("1")
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Session("User_Login_First_Time") = "1" Then
            Response.Redirect("frmUserProp.aspx")
        End If

        If Not IsPostBack Then


            If Application("RightLogo") = "1" Then
#If NewDesign Then
               '' tdRightPic.Attributes("background") = "pics/BannerTopRightTransp.gif"
               '' imgRightPic.Attributes("src") = "pics/BannerTopRightTransp.gif"
#End If
                ''  divRIcon.Visible = True
            Else
#If NewDesign Then
               '' tdRightPic.Attributes("background") = "pics/BannerTopRightPic.gif"
               '' imgRightPic.Attributes("src") = "pics/BannerTopRightPic.gif"
#End If
                ''  divRIcon.Visible = False
            End If


            Dim iExpiraionLevel As Integer = Val(Session("ExpirationLevel") & "")
            Dim iExpirationRestDays As Integer = Val(Session("ExpirationRestDays") & "")
            Dim iExpirationRestTimes As Integer = Val(Session("ExpirationRestTimes") & "")
            Select Case iExpiraionLevel
                Case 1
                    tdTitle.InnerText = "תוקף סיסמתך עומד לפוג"
                    cmdContinue.Visible = True

                    If iExpirationRestDays = 1 Then
                        tdAlertMsg.InnerText = " נשאר יום אחד " & " עד סיום תוקף הסיסמה"
                    Else
                        tdAlertMsg.InnerText = "נשארו " & iExpirationRestDays & " ימים " & " עד סיום תוקף הסיסמה"
                    End If
                Case 2
                    Dim msg As String = "כדי להחליף את הסיסמה יש ללחוץ על כפתור  " & "<i>שינוי סיסמה</i>"
                    tdTitle.InnerText = "תוקף סיסמתך פג"
                    cmdContinue.Visible = True

                    If iExpirationRestTimes = 1 Then
                        tdAlertMsg.InnerHtml = " נשארה כניסה אחת " & "<br>" & msg
                    ElseIf iExpirationRestTimes = 0 Then
                        tdAlertMsg.InnerHtml = "בכניסתך הבאה תחוייב להחליף סיסמה" & "<br>" & msg
                    Else
                        tdAlertMsg.InnerHtml = " נשארו " & iExpirationRestTimes & " כניסות " & "<br>" & msg
                    End If
                    'י &acute;
                Case 3
                    tdTitle.InnerText = "תוקף סיסמתך פג"
                    cmdContinue.Visible = False

                    tdAlertMsg.InnerHtml = "יש לשנות את הסיסמה כדי להכנס למערכת"
            End Select

        End If
    End Sub

    Private Sub cmdContinue_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdContinue.ServerClick
        'Dim sUrl As String = Session("Expiration_NextPage") & ""
        'If sUrl <> "" Then
        '    Session("User_Login_First_Time") = ""
        '    Response.Redirect(sUrl)
        'End If

        '' ''If (Application("AllowUrgentMessage")) Then
        '' ''    Response.Redirect("frmHDUrgentMessage.aspx")
        '' ''Else
        '' ''    Response.Redirect(Application("FORMStart"))
        '' ''End If

        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

        Dim iCheckDoctorResult As Integer = objUser.CheckDoctorID("EB2F60ED-E277-42EA-9310-EDBB15B97445", User.Identity.Name)
        Session("CheckDoctorResult") = iCheckDoctorResult
        Dim sUrl As String = UrlForDoctor()
        Response.Redirect(sUrl)



    End Sub

    Private Function UrlForDoctor() As String
        Dim iCheckDoctorResult As Integer = 0

        If Application("CheckDoctorID") = "1" Then
            iCheckDoctorResult = CheckDoctorID()
        End If

        Session("CheckDoctorResult") = iCheckDoctorResult

        Select Case iCheckDoctorResult
            Case 0
                If (Application("AllowUrgentMessage")) Then 'AndAlso "1".Equals(Application("InsuredStatusAsMainScreen"))) Then
                    Return "frmHDUrgentMessage.aspx"
                Else
                    Return Application("FORMStart")
                End If
            Case Else
                'Return "frmAddDoctor.aspx?Type=" & iCheckDoctorResult.ToString()
                If Application("InsuredStatusAsMainScreen") = "1" Then
                    'Return "frmHDUpdateDoctor.aspx?Type=" & CStr(iCheckDoctorResult)
                    Return "frmHDUserProp.aspx"

                Else
                    'Return "frmUpdateDoctorList.aspx?Type=" & CStr(iCheckDoctorResult)
                    Return "frmAddDoctor.aspx?Type=" & CStr(iCheckDoctorResult)
                End If
        End Select

    End Function

    Private Function CheckDoctorID() As Integer
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Return objUser.CheckDoctorID("EB2F60ED-E277-42EA-9310-EDBB15B97445", User.Identity.Name)


    End Function

    Private Sub cmdChangePassword_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdChangePassword.ServerClick
        Session("User_Login_First_Time") = "1"
        Response.Redirect("frmUserProp.aspx")
    End Sub
End Class
