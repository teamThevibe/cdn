Public Class frmHDNotes
    Inherits System.Web.UI.Page
    Protected WithEvents grdList As System.Web.UI.WebControls.DataGrid
    Protected WithEvents txtAppType As System.Web.UI.HtmlControls.HtmlInputHidden

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not IsPostBack Then
            Response.Expires = -1
            'Response.Cache.SetNoServerCaching()
            Dim strInsuredID As String = Request.QueryString("ID")
            Dim strRequestType As String = Request.QueryString("RequestType")

            Dim objTreatmentService As New TreatmentConnect.TreatmentService()
            objTreatmentService.Url = Application("TreatmentWebService").ToString()
            Dim ds As DataSet = Nothing
            If strRequestType = "Teeth" Then
                ds = objTreatmentService.GetNotesTeeth("AC341D55-6F04-4FFA-A1A9-9E6C2C70D617", User.Identity.Name, strInsuredID)
            Else
                ds = objTreatmentService.GetNotes("97B486F5-FAFA-49CE-9896-504954038C6C", User.Identity.Name, strInsuredID)
            End If


            Dim iCount As Integer = ds.Tables(0).Rows.Count
            Dim iPageCount As Integer = (iCount - 1) \ grdList.PageSize
            grdList.DataSource = ds
            If grdList.CurrentPageIndex > iPageCount Then
                grdList.CurrentPageIndex = iPageCount
            End If
            grdList.DataBind()
            If iPageCount > 0 Then
                grdList.PagerStyle.Visible = True
            Else
                grdList.PagerStyle.Visible = False
            End If
            txtAppType.Value = Application("App_Type").ToString
        End If
    End Sub

    Protected Function FormatRequestType(ByRef objCode As Object) As String
        Dim strReturn As String = ""
        If Not IsDBNull(objCode) Then
            Dim iType As Integer = CType(objCode, Integer)
            Select Case Val(objCode)
                Case 0
                    strReturn = "�����"
                Case 4
                    strReturn = "��������"
                Case 9
                    strReturn = "�����"
            End Select
        End If
        Return strReturn
    End Function

    Protected Function EncodeField(ByRef objCode As Object) As String
        Dim strReturn As String = ""
        If Not IsDBNull(objCode) Then
            strReturn = CEncode.StringEncode(objCode.ToString())
        End If
        Return strReturn
    End Function
End Class
