﻿Public Partial Class frmHDSearchInfo
    Inherits System.Web.UI.Page
    Protected WithEvents lstDoctorCare As System.Web.UI.WebControls.DropDownList
    Protected WithEvents txtError As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtDoctorCareName As System.Web.UI.WebControls.Label
    Protected WithEvents txtDoctorCareNumber As System.Web.UI.WebControls.Label
    Protected WithEvents txtClinicName As System.Web.UI.WebControls.Label
    Protected WithEvents txtClinicNumber As System.Web.UI.WebControls.Label
    Protected WithEvents txtInsuredID As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtInsuredName As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtInsuredFamily As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents cmdSearch4 As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdSearch0 As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents grdList As System.Web.UI.WebControls.DataGrid

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'If IsNothing(Session("Login_User")) OrElse Len(Session("Login_User")) = 0 Then
        '    Response.Redirect("Login.aspx")
        'End If
        If Not IsPostBack Then
            'If Session("User_Login_First_Time") = "1" Then
            '    Response.Redirect("frmUserProp.aspx")
            'End If
            Dim strDoctorCareName As String
            Dim strDoctorCareNumber As String
            Dim strClinicName As String
            Dim strClinicNumber As String
            Dim objTreatmentService As New TreatmentConnect.TreatmentService()
            objTreatmentService.Url = Application("TreatmentWebService").ToString()
            If objTreatmentService.GetDoctorProperties("7EC6114A-62CD-4DC4-A940-1416BFB136D8", User.Identity.Name, strDoctorCareName, strDoctorCareNumber, strClinicName, strClinicNumber) Then
                If Session("BSHN_Independed") = "1" Then
                    txtDoctorCareName.Text = strDoctorCareName
                    txtDoctorCareNumber.Text = strDoctorCareNumber
                Else
                    Dim objUser As New UserConnect.UserService()
                    objUser.Url = Application("UserWebService").ToString()
                    lstDoctorCare.DataSource = objUser.GetDoctorList("03407803-DE6A-41AA-87DC-60D1D0329753", User.Identity.Name)
                    lstDoctorCare.DataBind()
                    If lstDoctorCare.Items.Count > 1 Then
                        lstDoctorCare.Items.Insert(0, New ListItem("בחר...", "0"))
                    Else
                        txtDoctorCareNumber.Text = strDoctorCareNumber
                    End If
                End If
                txtClinicName.Text = strClinicName
                txtClinicNumber.Text = strClinicNumber
            End If
            If Session("BSHN_Independed") = "1" Then
                lstDoctorCare.Visible = False
                txtDoctorCareName.Visible = True
            Else
                lstDoctorCare.Visible = True
                txtDoctorCareName.Visible = False
            End If
            Session("BSHN_LastSearchInfo") = "4"
        End If
    End Sub

    Private Sub BindGrid(ByVal iRequestType As Integer)
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim ds As DataSet = objTreatmentService.GetAllRequestsBashanByInsured("A08DB0A6-D4C5-473C-8A79-B58E5452BDB8", Val(txtInsuredID.Value), User.Identity.Name, iRequestType)
        Dim iCount As Integer = ds.Tables(0).Rows.Count

        Dim iPageCount As Integer = (iCount - 1) \ grdList.PageSize
        grdList.DataSource = ds
        If iPageCount > -1 Then
            If grdList.CurrentPageIndex > iPageCount Then
                grdList.CurrentPageIndex = iPageCount
            End If
        Else
            grdList.CurrentPageIndex = 0
        End If
        grdList.DataBind()
    End Sub

    Private Sub grdList_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles grdList.PageIndexChanged
        grdList.CurrentPageIndex = e.NewPageIndex
        BindGrid(val(Session("BSHN_LastSearchInfo")))
    End Sub

    Private Sub cmdSearch0_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch0.ServerClick
        If ValidateInsuredID() Then
            Session("BSHN_LastSearchInfo") = "0"
            BindGrid(0)
        Else
            BindGrid(-1)
            txtError.Value = "בחברת הביטוח לא נמצא מבוטח פעיל המתאים לפרטים שהוזנו"
        End If
    End Sub

    Private Sub cmdSearch4_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch4.ServerClick
        Session("BSHN_LastSearchInfo") = "4"
        BindGrid(4)
    End Sub

    Private Function ValidateInsuredID() As Boolean
        Dim strFirstName As String = ""
        Dim strLastName As String = ""
        Dim strEmployeeNo As String = ""
        Dim strEmpCD As String = ""
        Dim strPolicyNo As String = ""
        Dim strInsuredID As String = Trim(txtInsuredID.Value)
        txtInsuredName.Value = strFirstName
        txtInsuredFamily.Value = strLastName
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()

        objTreatmentService.GetInsuredProp("5E25C46A-EADC-4C27-8A5A-DB8B13E129D3", strInsuredID, strFirstName, strLastName, strPolicyNo, strEmployeeNo, strEmpCD)
        If UCase(Trim(strLastName)) = "ERROR" Then
            objTreatmentService.GetSQLInsuredProp("6C865031-52E9-4422-950B-615B8F84600C", strInsuredID, strFirstName, strLastName)
        End If
        Dim str2Chars As String = Left(strLastName, 2)
        Dim str2FNChars As String = Left(strFirstName, 2)
        Dim bRetValue As Boolean
        If str2Chars = "" Or str2FNChars = "" Then
            bRetValue = False
        Else
            txtInsuredName.Value = strFirstName
            txtInsuredFamily.Value = strLastName
            bRetValue = True
        End If
    End Function
End Class