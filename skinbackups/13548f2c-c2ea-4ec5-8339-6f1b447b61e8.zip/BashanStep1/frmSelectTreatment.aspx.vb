﻿Public Partial Class frmSelectTreatment
    Inherits System.Web.UI.Page
    Protected WithEvents grdList As System.Web.UI.WebControls.DataGrid
    Protected WithEvents txtAppType As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtValues As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtLocalFilesCount As System.Web.UI.HtmlControls.HtmlInputHidden


#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not IsPostBack Then
            Response.Expires = -1
            'Response.Cache.SetNoServerCaching()
            Dim strGovTreatmentID As String = Request.QueryString("GovTreatmentID").Trim()
            Dim objTreatmentService As New TreatmentConnect.TreatmentService()
            objTreatmentService.Url = Application("TreatmentWebService").ToString()
            Dim dsTreatments As DataSet
            Dim iConsultation As Integer = Val(Request.QueryString("Consultation"))


            dsTreatments = objTreatmentService.GetTreatmentsByGovTreatment("BD69571E-920A-48F8-89B3-5D13423B8A39", strGovTreatmentID, iConsultation)

            Dim iCount As Integer = dsTreatments.Tables(0).Rows.Count
            Dim iPageCount As Integer = (iCount - 1) \ grdList.PageSize

            grdList.DataSource = dsTreatments
            If grdList.CurrentPageIndex > iPageCount Then
                grdList.CurrentPageIndex = iPageCount
            End If
            grdList.DataBind()
            If iPageCount > 0 Then
                grdList.PagerStyle.Visible = True
            Else
                grdList.PagerStyle.Visible = False
            End If
        End If
    End Sub

End Class