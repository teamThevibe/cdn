Public Class frmGetUserInsured
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim strID As String = Request.Form("hidInsuredID")
        Dim strFirstName As String = ""
        Dim strLastName As String = ""
        Dim iRetValue As Integer = 0
        Dim objBoLink As New TreatmentConnect.TreatmentService()
        objBoLink.Url = Application("TreatmentWebService").ToString()
        iRetValue = objBoLink.GetUserInsuredProp("844BA895-C4E9-4EAC-A2F0-435F31CB221C", strID, User.Identity.Name, strFirstName, strLastName)
        Dim objResult As New System.Text.StringBuilder()
        objResult.Append("<HTML><HEAD><TITLE></TITLE>")
        objResult.Append("<meta http-equiv='Cache-Control' content='no-cache'>" & vbCrLf)
        objResult.Append("<meta http-equiv='Pragma' content='no-cache'>" & vbCrLf)
        objResult.Append("<meta http-equiv='Expires' content='0'>" & vbCrLf)
        objResult.Append("<META http-equiv='Content-Type' content='text/html; charset=windows-1255'>")
        objResult.Append("</HEAD>")
        objResult.Append("<BODY>")
        objResult.Append("<INPUT type='hidden' id='txtFirstName' value='" & strFirstName & "'>")
        objResult.Append("<INPUT type='hidden' id='txtLastName' value='" & strLastName & "'>")
        objResult.Append("<SCRIPT>")
        objResult.Append("	window.parent.document.all.oNotificationUserInsured.value = 'OK';")
        objResult.Append("</SCRIPT>")
        objResult.Append("</BODY>")
        objResult.Append("</HTML>")
        Response.Write(objResult.ToString())
    End Sub
End Class
