﻿Partial Public Class frmReportDailyRequests
    Inherits System.Web.UI.Page

    Dim objTreatmentService As New TreatmentConnect.TreatmentService()
    Dim objUser As New UserConnect.UserService()
    Public dcSum_TASHLUM_MEVUTAH As Decimal
    Public sSum_TASHLUM_MEVUTAH As String

    Public iCompanySign As Integer
    Private isSibatDhiyaRefuitExists As Boolean

    Public sTaarichZikuy As String
    Public sSumMesameret As String
    Public sSumMesakemet As String
    Public sSumRows As String

    Public frmRequestURL As String = Utils.Navigation.GetURL("frmRequestt.aspx")

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


        iCompanySign = eCompanySign.eDikla

        If Not Application("CompanyID") Is Nothing Then
            If CInt(Application("CompanyID")) = eCompanySign.eHarel Then
                iCompanySign = eCompanySign.eHarel
            End If
        End If



        If iCompanySign = eCompanySign.eDikla Then
            divRIcon.Visible = True
            divRIcon1.Visible = False





        Else
            divRIcon.Visible = False
            divRIcon1.Visible = True



        End If


        ''''''''''''''''''''''Dim iGridRowCount As Integer

        If Not IsPostBack Then


            If Not Request.QueryString("DayForReport") Is Nothing Then
                HidDayForReport.Value = Request.QueryString("DayForReport").ToString
            Else
                HidDayForReport.Value = ""
            End If


            Me.HidSort.Value = "TZ ASC"

            objUser.Url = Application("UserWebService").ToString()

            ' '' '' ''iGridRowCount = objUser.GetGridRowCount("9CDE451A-D418-40EC-9588-64CA4592AC55", User.Identity.Name)

            ' '' '' ''tdGridRowCount.Visible = False

            ' '' '' ''If LCase(Application("App_Type").ToString) = "dist" Or LCase(Application("App_Type").ToString) = "claim" Or LCase(Application("App_Type").ToString) = "supp" Or LCase(Application("App_Type").ToString) = "divur" Or LCase(Application("App_Type").ToString) = "doar" Or LCase(Application("App_Type").ToString) = "eng" Then
            ' '' '' ''    grdList.PagerStyle.HorizontalAlign = HorizontalAlign.Right
            ' '' '' ''    tdGridRowCount.Visible = True
            ' '' '' ''    If Not IsPostBack Then
            ' '' '' ''        Dim arrValues() As Integer = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15}
            ' '' '' ''        cboGridRowCount.DataSource = arrValues
            ' '' '' ''        cboGridRowCount.DataBind()
            ' '' '' ''        cboGridRowCount.SelectedIndex = iGridRowCount - 1




            ' '' '' ''    End If

            ' '' '' ''End If


            If Not Request.QueryString("SugDivuach") Is Nothing Then

                Session("SugDivuachBack") = "frmReportDailyRequests.aspx" + _
                    "?SugDivuach=" + Request.QueryString("SugDivuach").ToString + _
                    "&tz=" + Request.QueryString("tz").ToString + _
                    "&DayForReport=" + Request.QueryString("dayForReport").ToString

                HidSugDivuach.Value = CInt(Request.QueryString("SugDivuach"))

                '-----------
                If HidSugDivuach.Value = eSugDivuach.eRequests Then
                    '-----------

                    Label1.Visible = True

                    grdList.Visible = True
                    grdListAccount.Visible = False
                    grdListConsultations.Visible = False
                    tdDistTitle.InnerHtml = "סיכום פניות"

                    'If iGridRowCount > 0 Then
                    '    grdList.PageSize = iGridRowCount
                    'End If

                    BindGrid(Me.HidSort.Value)
                End If

                '-----------
                If HidSugDivuach.Value = eSugDivuach.eConsultations Then
                    '-----------
                    If Not Request.QueryString("tz") Is Nothing Then

                        HidInsuredID.Value = Request.QueryString("tz").ToString
                    Else
                        HidInsuredID.Value = ""
                    End If

                    If iCompanySign = eCompanySign.eDikla Then

                        LabelDivSum.Text = "דיקלה חברה לביטוח בע'מ"

                    Else

                        LabelDivSum.Text = "הראל חברה לביטוח בע'מ"

                    End If

                    grdList.Visible = False
                    grdListAccount.Visible = False
                    grdListConsultations.Visible = True
                    tdDistTitle.InnerHtml = "סיכום התיעצויות"

                    'If iGridRowCount > 0 Then
                    '    grdListConsultations.PageSize = iGridRowCount
                    'End If

                    BindgrdListConsultations(Me.HidSort.Value)
                End If

                '-----------
                If HidSugDivuach.Value = eSugDivuach.eAccount Then
                    '-----------
                    Label1.Visible = True
                    Label4.Visible = True

                    grdList.Visible = False
                    grdListConsultations.Visible = False
                    grdListAccount.Visible = True
                    tdDistTitle.InnerHtml = "סיכום חשבון לרופא"

                    'If iGridRowCount > 0 Then
                    '    grdListAccount.PageSize = iGridRowCount
                    'End If

                    BindGridAccount(Me.HidSort.Value)
                End If




            End If

        End If

    End Sub




    Private Sub cmdBack_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdBack.ServerClick
        Response.Redirect((New Utils).GetLinkForNextForm(Application("FORMRepList")))
    End Sub

    Private Sub cmdReturn_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.ServerClick
        Response.Redirect("frmStart.aspx")
    End Sub

    Private Sub cboGridRowCount_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboGridRowCount.SelectedIndexChanged
        Dim iGridRowCount As Integer

        If cboGridRowCount.SelectedItem.Value <> "" Then
            iGridRowCount = CInt(cboGridRowCount.SelectedItem.Value)

            Dim objUser As New UserConnect.UserService()
            objUser.Url = Application("UserWebService").ToString()

            objUser.UpdateGridRowCount("5561A874-D4D7-4E5C-AA3D-4EC0EBAA8B7F", User.Identity.Name, iGridRowCount, User.Identity.Name)

            '-----------
            If HidSugDivuach.Value = eSugDivuach.eRequests Then
                '-----------


                If iGridRowCount > 0 Then
                    grdList.PageSize = iGridRowCount
                End If

                BindGrid(Me.HidSort.Value)
            End If

            '-----------
            If HidSugDivuach.Value = eSugDivuach.eConsultations Then
                '-----------


                If iGridRowCount > 0 Then
                    grdListConsultations.PageSize = iGridRowCount
                End If

                BindgrdListConsultations(Me.HidSort.Value)
            End If

            '-----------
            If HidSugDivuach.Value = eSugDivuach.eAccount Then
                '-----------


                If iGridRowCount > 0 Then
                    grdListAccount.PageSize = iGridRowCount
                End If

                BindGridAccount(Me.HidSort.Value)
            End If
        End If
    End Sub


    '******************************
    '    grdList
    '******************************
    Private Sub BindGrid(ByVal sSort As String)


        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim ds As New DataSet

        Dim sDayForReport As String = HidDayForReport.Value

        sDayForReport = sDayForReport.Replace("/", "")


        ds = objTreatmentService.GetDataForHDReportDailyRequests("3692025C-B925-407E-9A17-4BCBB3ECC7A8", User.Identity.Name, _
                                                                 CInt(HidSugDivuach.Value), 0, iCompanySign, sDayForReport, "")

        If Not ds Is Nothing Then
            If ds.Tables.Count > 0 Then
                If ds.Tables(0).Rows.Count > 0 Then

                    Dim sSibatDhiyaRefuit As String = ds.Tables(0).Rows(0)("SibatDhiyaRefuit").ToString
                    If sSibatDhiyaRefuit = "כ" Then
                        Label2.Visible = True
                    End If

                    HiDoctorId.Value = ds.Tables(1).Rows(0)("DoctorID").ToString
                    'HiDoctorName.Value = ds.Tables(1).Rows(0)("ClinicName").ToString
                    HiDoctorName.Value = ds.Tables(0).Rows(0)("ClinicName").ToString
                    tdDistTitle.InnerHtml = "סיכום פניות"
                    tdDistTitle.InnerHtml = tdDistTitle.InnerHtml & " לרופא מס'  " + HiDoctorId.Value + "</br>" + _
                                            " " + HiDoctorName.Value
                    dcSum_TASHLUM_MEVUTAH = Convert.ToDecimal(ds.Tables(0).Compute("Sum(SchumHechzer)", "True"))
                    sSum_TASHLUM_MEVUTAH = dcSum_TASHLUM_MEVUTAH.ToString("c")
                    Dim dv As DataView

                    '''''''''''''''Dim iCount As Integer = ds.Tables(0).Rows.Count
                    ''''''''''''''''''''Dim iPageCount As Integer = (iCount - 1) \ grdList.PageSize


                    dv = New DataView(ds.Tables(0), _
                           "", _
                           sSort, DataViewRowState.CurrentRows)

                    dv.Sort() = sSort


                    grdList.DataSource = dv
                    '' '' '' '' ''If iPageCount > -1 Then
                    '' '' '' '' ''    If grdList.CurrentPageIndex > iPageCount Then
                    '' '' '' '' ''        grdList.CurrentPageIndex = iPageCount
                    '' '' '' '' ''    End If
                    '' '' '' '' ''Else
                    '' '' '' '' ''    grdList.CurrentPageIndex = 0
                    '' '' '' '' ''End If





                    grdList.DataBind()
                    '' '' '' '' '' ''If iPageCount > 0 Then
                    '' '' '' '' '' ''    grdList.PagerStyle.Visible = True
                    '' '' '' '' '' ''Else
                    '' '' '' '' '' ''    grdList.PagerStyle.Visible = False
                    '' '' '' '' '' ''End If

                End If
            End If
        End If


    End Sub

    Private Sub grdList_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles grdList.SortCommand
        Try
            Dim currentPage As Integer = Me.grdList.CurrentPageIndex
            Dim SortExpression As String = e.SortExpression.ToString()
            Dim SortValue As String = ""
            Select Case SortExpression
                'SortValue 
                Case "TZ ASC"
                    SortValue = "TZ ASC"
                    grdList.Columns(12).SortExpression = SortValue
                    Exit Select

                    'Case "TZ DESC"
                    '    SortValue = "TZ ASC"
                    '    grdList.Columns(11).SortExpression = SortValue
                    '    Exit Select

                Case "FullName ASC"
                    SortValue = "FullName ASC"
                    grdList.Columns(11).SortExpression = SortValue
                    Exit Select

                    'Case "FullName DESC"
                    '    SortValue = "FullName ASC"
                    '    grdList.Columns(10).SortExpression = SortValue
                    '    Exit Select



                Case Else

                    SortValue = "TZ ASC"
                    grdList.Columns(11).SortExpression = SortValue
                    Exit Select



            End Select

            HidSort.Value = SortValue

            Me.BindGrid(SortValue)

        Catch ex As Exception

            Throw ex

        End Try


    End Sub

    Private Sub datagrid_ItemCreated(ByVal sender As Object, ByVal e As DataGridItemEventArgs) Handles grdList.ItemCreated
        If e.Item.ItemType = ListItemType.Footer Then
            e.Item.Cells(5).ColumnSpan = 2
            e.Item.Cells.RemoveAt(4)
        End If
    End Sub

    Private Sub grdList_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles grdList.PageIndexChanged
        grdList.CurrentPageIndex = e.NewPageIndex
        BindGrid(Me.HidSort.Value)
    End Sub


    '******************************
    '    grdListConsultations
    '******************************
    Private Sub BindgrdListConsultations(ByVal sSort As String)


        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim ds As New DataSet

        Dim iUserTz As Integer = Val(Me.HidInsuredID.Value)
        Dim sDayForReport As String = HidDayForReport.Value

        sDayForReport = sDayForReport.Replace("/", "")

        ds = objTreatmentService.GetDataForHDReportDailyRequests("3692025C-B925-407E-9A17-4BCBB3ECC7A8", User.Identity.Name, _
                                                                 CInt(HidSugDivuach.Value), iUserTz, iCompanySign, sDayForReport, "")

        If Not ds Is Nothing Then
            If ds.Tables.Count > 0 Then
                If ds.Tables(0).Rows.Count > 0 Then








                    HiDoctorId.Value = ds.Tables(1).Rows(0)("DoctorID").ToString
                    'HiDoctorName.Value = ds.Tables(1).Rows(0)("ClinicName").ToString
                    HiDoctorName.Value = ds.Tables(0).Rows(0)("ClinicName").ToString
                    tdDistTitle.InnerHtml = "סיכום התיעצויות"
                    tdDistTitle.InnerHtml = tdDistTitle.InnerHtml & " לרופא מס'  " + HiDoctorId.Value + "</br>" + _
                        " " + HiDoctorName.Value + "</br>" + "  עבור " + _
                        ds.Tables(0).Rows(0)("FullName").ToString + " ת.ז. " + ds.Tables(0).Rows(0)("TZ").ToString


                    dcSum_TASHLUM_MEVUTAH = Convert.ToDecimal(ds.Tables(0).Compute("Sum(SchumHechzer)", "True"))
                    sSum_TASHLUM_MEVUTAH = dcSum_TASHLUM_MEVUTAH.ToString("c")
                    Dim dv As DataView

                    ' Dim iCount As Integer = ds.Tables(0).Rows.Count
                    'Dim iPageCount As Integer = (iCount - 1) \ grdListConsultations.PageSize


                    dv = New DataView(ds.Tables(0), _
                           "", _
                           sSort, DataViewRowState.CurrentRows)

                    dv.Sort() = sSort


                    grdListConsultations.DataSource = dv
                    '' '' '' '' ''If iPageCount > -1 Then
                    '' '' '' '' ''    If grdListConsultations.CurrentPageIndex > iPageCount Then
                    '' '' '' '' ''        grdListConsultations.CurrentPageIndex = iPageCount
                    '' '' '' '' ''    End If
                    '' '' '' '' ''Else
                    '' '' '' '' ''    grdListConsultations.CurrentPageIndex = 0
                    '' '' '' '' ''End If





                    grdListConsultations.DataBind()
                    '' '' '' ''If iPageCount > 0 Then
                    '' '' '' ''    grdListConsultations.PagerStyle.Visible = True
                    '' '' '' ''Else
                    '' '' '' ''    grdListConsultations.PagerStyle.Visible = False
                    '' '' '' ''End If

                End If
            End If
        End If


    End Sub

    Private Sub grdListConsultations_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles grdListConsultations.SortCommand
        Try
            Dim currentPage As Integer = Me.grdListConsultations.CurrentPageIndex
            Dim SortExpression As String = e.SortExpression.ToString()
            Dim SortValue As String = ""
            Select Case SortExpression
                'SortValue 
                Case "TZ ASC"
                    SortValue = "TZ ASC"
                    grdListConsultations.Columns(12).SortExpression = SortValue
                    Exit Select

                    'Case "TZ DESC"
                    '    SortValue = "TZ ASC"
                    '    grdListConsultations.Columns(11).SortExpression = SortValue
                    '    Exit Select

                Case "FullName ASC"
                    SortValue = "FullName ASC"
                    grdListConsultations.Columns(11).SortExpression = SortValue
                    Exit Select

                    'Case "FullName DESC"
                    '    SortValue = "FullName ASC"
                    '    grdListConsultations.Columns(10).SortExpression = SortValue
                    '    Exit Select



                Case Else

                    SortValue = "TZ ASC"
                    grdListConsultations.Columns(11).SortExpression = SortValue
                    Exit Select



            End Select

            HidSort.Value = SortValue

            Me.BindgrdListConsultations(SortValue)

        Catch ex As Exception

            Throw ex

        End Try


    End Sub

    Private Sub grdListConsultations_ItemCreated(ByVal sender As Object, ByVal e As DataGridItemEventArgs) Handles grdListConsultations.ItemCreated
        If e.Item.ItemType = ListItemType.Footer Then
            e.Item.Cells(4).ColumnSpan = 2
            e.Item.Cells.RemoveAt(3)
        End If
    End Sub

    Private Sub grdListConsultations_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles grdListConsultations.PageIndexChanged
        grdListConsultations.CurrentPageIndex = e.NewPageIndex
        BindgrdListConsultations(Me.HidSort.Value)
    End Sub


    '******************************
    '    grdListAccount
    '******************************
    Private Sub BindGridAccount(ByVal sSort As String)


        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim ds As New DataSet


        Dim sDayForReport As String = HidDayForReport.Value

        sDayForReport = sDayForReport.Replace("/", "")


        ds = objTreatmentService.GetDataForHDReportDailyRequests("3692025C-B925-407E-9A17-4BCBB3ECC7A8", User.Identity.Name, _
                                                                 CInt(HidSugDivuach.Value), 0, iCompanySign, sDayForReport, "")

        If Not ds Is Nothing Then
            If ds.Tables.Count > 0 Then
                If ds.Tables(0).Rows.Count > 0 Then


                    sSumMesameret = ds.Tables(0).Compute("sum(SchumHechzer)", "SUG_TIPUL = 1")
                    sSumMesakemet = ds.Tables(0).Compute("sum(SchumHechzer)", "SUG_TIPUL > 1")
                    Dim sTaarichZikuyLocal = ds.Tables(0).Rows(0)("TaarichZikuy").ToString
                    sTaarichZikuy = Right(sTaarichZikuyLocal, 2) + "/" + Mid(sTaarichZikuyLocal, 5, 2) + "/" + Left(sTaarichZikuyLocal, 4)

                    sSumRows = ds.Tables(0).Rows.Count

                    Session("sSumMesameretForAccount") = sSumMesameret
                    Session("sSumMesakemetForAccount") = sSumMesakemet
                    Session("sTaarichZikuytForAccount") = sTaarichZikuy
                    Session("SumRowsForAccount") = sSumRows

                    HiDoctorId.Value = ds.Tables(1).Rows(0)("DoctorID").ToString
                    'HiDoctorName.Value = ds.Tables(1).Rows(0)("ClinicName").ToString
                    HiDoctorName.Value = ds.Tables(0).Rows(0)("ClinicName").ToString
                    tdDistTitle.InnerHtml = "סיכום חשבון"
                    tdDistTitle.InnerHtml = tdDistTitle.InnerHtml & " לרופא מס'  " + HiDoctorId.Value + "</br>" + _
                                            " " + HiDoctorName.Value
                    dcSum_TASHLUM_MEVUTAH = Convert.ToDecimal(ds.Tables(0).Compute("Sum(SchumHechzer)", "True"))
                    sSum_TASHLUM_MEVUTAH = dcSum_TASHLUM_MEVUTAH.ToString("c")
                    Dim dv As DataView

                    '''''Dim iCount As Integer = ds.Tables(0).Rows.Count
                    '''''''Dim iPageCount As Integer = (iCount - 1) \ grdListAccount.PageSize


                    dv = New DataView(ds.Tables(0), _
                           "", _
                           sSort, DataViewRowState.CurrentRows)

                    dv.Sort() = sSort


                    grdListAccount.DataSource = dv
                    ' '' ''If iPageCount > -1 Then
                    ' '' ''    If grdListAccount.CurrentPageIndex > iPageCount Then
                    ' '' ''        grdListAccount.CurrentPageIndex = iPageCount
                    ' '' ''    End If
                    ' '' ''Else
                    ' '' ''    grdListAccount.CurrentPageIndex = 0
                    ' '' ''End If





                    grdListAccount.DataBind()
                    '' '' ''If iPageCount > 0 Then
                    '' '' ''    grdListAccount.PagerStyle.Visible = True
                    '' '' ''Else
                    '' '' ''    grdListAccount.PagerStyle.Visible = False
                    '' '' ''End If

                End If
            End If
        End If


    End Sub

    Private Sub grdListAccount_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles grdListAccount.SortCommand
        Try
            Dim currentPage As Integer = Me.grdListAccount.CurrentPageIndex
            Dim SortExpression As String = e.SortExpression.ToString()
            Dim SortValue As String = ""
            Select Case SortExpression
                'SortValue 
                Case "TZ ASC"
                    SortValue = "TZ ASC"
                    grdListAccount.Columns(12).SortExpression = SortValue
                    Exit Select

                    'Case "TZ DESC"
                    '    SortValue = "TZ ASC"
                    '    grdListAccount.Columns(12).SortExpression = SortValue
                    '    Exit Select

                Case "FullName ASC"
                    SortValue = "FullName ASC"
                    grdListAccount.Columns(11).SortExpression = SortValue
                    Exit Select

                    'Case "FullName DESC"
                    '    SortValue = "FullName ASC"
                    '    grdListAccount.Columns(11).SortExpression = SortValue
                    '    Exit Select



                Case Else

                    SortValue = "TZ ASC"
                    grdListAccount.Columns(11).SortExpression = SortValue
                    Exit Select



            End Select

            HidSort.Value = SortValue

            Me.BindGridAccount(SortValue)

        Catch ex As Exception

            Throw ex

        End Try


    End Sub

    Private Sub grdListAccount_ItemCreated(ByVal sender As Object, ByVal e As DataGridItemEventArgs) Handles grdListAccount.ItemCreated
        If e.Item.ItemType = ListItemType.Footer Then
            e.Item.Cells(5).ColumnSpan = 2
            e.Item.Cells.RemoveAt(4)
        End If
    End Sub

    Private Sub grdListAccount_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles grdListAccount.PageIndexChanged
        grdListAccount.CurrentPageIndex = e.NewPageIndex
        BindGridAccount(Me.HidSort.Value)
    End Sub





    Protected Function SetSibatDchiya(ByRef objCode As Object) As String
        Dim strReturn As String = ""
        If Not IsDBNull(objCode) Then

            Select Case objCode
                Case "No"
                    strReturn = "מכוסה"
                Case Else
                    strReturn = objCode

            End Select
        End If
        Return strReturn
    End Function


    Enum eSugDivuach As Integer
        eRequests = 11
        eConsultations = 41
        eAccount = 10

    End Enum

    Enum eCompanySign As Integer
        eDikla = 0
        eHarel = 1

    End Enum

End Class