Public Class frmTCheck
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    'Dim arrIndexTranslate As Integer() = {7, 6, 5, 4, 3, 2, 1, 0, 8, 9, 10, 11, 12, 13, 14, 15, 23, 22, 21, 20, 19, 18, 17, 16, 24, 25, 26, 27, 28, 29, 30, 31}
    Dim arrIndexTranslate As Integer() = {7, 6, 5, 4, 3, 2, 1, 0, 8, 9, 10, 11, 12, 13, 14, 15, 23, 22, 21, 20, 19, 18, 17, 16, 24, 25, 26, 27, 28, 29, 30, 31, 39, 38, 37, 36, 35, 34, 33, 32, 40, 41, 42, 43, 44, 45, 46, 47, 55, 54, 53, 52, 51, 50, 49, 48, 56, 57, 58, 59, 60, 61, 62, 63}

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim strInsuredID As String = Trim(Request.Form("hidTCheckInsuredID"))
        Dim strPolicyNo As String = Trim(Request.Form("hidPolicyNo"))
        Dim strTreatmentsValue As String = Trim(Request.Form("hidTCheckValue"))
        Dim strAnswer As String = ""
        Dim strErrTeeth As String = ""
        Dim objResult As New System.Text.StringBuilder()
        Dim iResult As Integer
        If Not IsNumeric(strInsuredID) Then
            iResult = 0
            strAnswer = "����� ������ �� ���� ����� ���� ������ ������ ������"
        Else
            iResult = TestInput(strTreatmentsValue, strAnswer, strErrTeeth)
            If iResult > 0 Then
                Dim arrTreatmentsRows() As String = Split(strTreatmentsValue, ";")
                Dim strTreatmentRow As String, arrOneRow() As String, strTreatmentValue As String, strCauseValue As String, strFromTooth As String, strToTooth As String
                Dim i As Integer, iFromTooth As Integer, iToTooth As Integer, iTreatmentValue As Integer, iCauseValue As Integer
                Dim arrToothCheck(64) As ArrayList
                For i = 0 To 63
                    arrToothCheck(i) = New ArrayList()
                Next
                For Each strTreatmentRow In arrTreatmentsRows
                    arrOneRow = Split(strTreatmentRow, ".")
                    If arrOneRow.Length = 4 Then
                        strTreatmentValue = arrOneRow(0)
                        strCauseValue = arrOneRow(1)
                        strFromTooth = arrOneRow(2)
                        strToTooth = arrOneRow(3)
                        If IsNumeric(strTreatmentValue) Then
                            iTreatmentValue = CInt(strTreatmentValue)
                        Else
                            iTreatmentValue = 0
                        End If
                        If IsNumeric(strCauseValue) Then
                            iCauseValue = CInt(strCauseValue)
                        Else
                            iCauseValue = 0
                        End If
                        If IsNumeric(strFromTooth) Then
                            iFromTooth = CInt(strFromTooth)
                        Else
                            iFromTooth = 0
                        End If
                        If IsNumeric(strToTooth) Then
                            iToTooth = CInt(strToTooth)
                        Else
                            iToTooth = iFromTooth
                        End If
                        If TestRow(iTreatmentValue, iCauseValue, iFromTooth, iToTooth, arrToothCheck, strAnswer, strErrTeeth) = 0 Then
                            iResult = 0
                        End If
                        If Session("Leumit_CollectionProblem") = "1" Then
                            If iResult > 0 Then
                                iResult = CheckTreatmentForServiceBasket(iTreatmentValue, strAnswer)
                            End If

                        End If
                    End If
                Next
                If iResult > 0 Then
                    Dim objTreatmentService As New TreatmentConnect.TreatmentService()
                    objTreatmentService.Url = Application("TreatmentWebService").ToString()
                    Dim ds As DataSet = objTreatmentService.GetRequestBashanByInsured("63D49E2C-45CA-4515-8BC6-18443DA7C62A", CInt(strInsuredID), User.Identity.Name, 4)
                    'Dim ds As DataSet = objTreatmentService.GetRequestBashanByInsuredWithTreatmentsSeries("9934CE93-2C00-4360-8B3F-3EDA0359A7AF", Val(strInsuredID), User.Identity.Name, 4, Val(Application("CompanyID")), 1)

                    Dim currRow As DataRow
                    Dim bCheckPrevConsultation As Boolean
                    bCheckPrevConsultation = objTreatmentService.CheckPrevConsultation("2D10EF59-136F-4797-A214-BF147050EC64", Val(strPolicyNo))


                    For Each currRow In ds.Tables(0).Rows
                        iTreatmentValue = CType(currRow("Treatment"), Integer)
                        If Not IsDBNull(currRow("Cause")) Then
                            iCauseValue = CType(currRow("Cause"), Integer)
                        Else
                            iCauseValue = 0
                        End If
                        iFromTooth = CType(currRow("FTooth"), Integer)
                        'If iFromTooth > 50 And iFromTooth < 88 Then
                        '    iFromTooth = iFromTooth - 40
                        'End If
                        Select Case iFromTooth
                            Case 91
                                iFromTooth = 14
                                iToTooth = 18
                            Case 92
                                iFromTooth = 13
                                iToTooth = 23
                            Case 93
                                iFromTooth = 24
                                iToTooth = 28
                            Case 94
                                iFromTooth = 34
                                iToTooth = 38
                            Case 95
                                iFromTooth = 33
                                iToTooth = 43
                            Case 96
                                iFromTooth = 44
                                iToTooth = 48
                            Case 97
                                iFromTooth = 18
                                iToTooth = 28
                            Case 98
                                iFromTooth = 38
                                iToTooth = 48
                            Case Else
                                If Not IsDBNull(currRow("ToTooth")) Then
                                    iToTooth = CType(currRow("ToTooth"), Integer)
                                    'If iToTooth > 50 And iToTooth < 88 Then
                                    '    iToTooth = iToTooth - 40
                                    'End If
                                Else
                                    iToTooth = iFromTooth
                                End If
                        End Select
                        If bCheckPrevConsultation Then
                            If TestOldRow(iTreatmentValue, iCauseValue, iFromTooth, iToTooth, arrToothCheck, strAnswer, strErrTeeth) = 0 Then
                                iResult = 0
                            End If
                        End If

                    Next
                End If
            End If
        End If
        objResult.Append("<HTML><HEAD><TITLE></TITLE>")
        objResult.Append("<meta http-equiv='Cache-Control' content='no-cache'>" & vbCrLf)
        objResult.Append("<meta http-equiv='Pragma' content='no-cache'>" & vbCrLf)
        objResult.Append("<meta http-equiv='Expires' content='0'>" & vbCrLf)
        objResult.Append("<META http-equiv='Content-Type' content='text/html; charset=windows-1255'>")
        objResult.Append("</HEAD>")
        objResult.Append("<BODY>")
        objResult.Append("<INPUT TYPE='hidden' ID='TCheckAnswer' value='" & CStr(iResult) & "'>")
        objResult.Append("<INPUT TYPE='hidden' ID='TCheckError' value='" & strAnswer & "'>")
        objResult.Append("<INPUT TYPE='hidden' ID='TCheckErrTeeth' value='" & strErrTeeth & "'>")
        objResult.Append("<SCRIPT>")
        objResult.Append("	window.parent.document.all.oTNotificationCheck.value = 'OK';")
        objResult.Append("</SCRIPT>")
        objResult.Append("</BODY>")
        objResult.Append("</HTML>")
        Response.Write(objResult.ToString())
    End Sub

    Private Function TestRow(ByVal iTreatmentValue As Integer, ByVal iCauseValue As Integer, ByVal iFromTooth As Integer, ByVal iToTooth As Integer, ByVal arrToothCheck() As ArrayList, ByRef strAnswer As String, ByRef strErrTeeth As String) As Integer
        Dim i As Integer, iArrIndex1 As Integer, iArrIndex2 As Integer
        If iFromTooth = 88 Then
            iArrIndex1 = 0
            iArrIndex2 = 63
        Else
            iArrIndex1 = arrIndexTranslate(Convert.ToInt16(CStr(iFromTooth - 11), 8))
            iArrIndex2 = arrIndexTranslate(Convert.ToInt16(CStr(iToTooth - 11), 8))
            i = iArrIndex1
            iArrIndex1 = Math.Min(iArrIndex1, iArrIndex2)
            iArrIndex2 = Math.Max(i, iArrIndex2)
        End If
        For i = iArrIndex1 To iArrIndex2
            If arrToothCheck(i).Contains(iTreatmentValue) Then
                strErrTeeth = strErrTeeth & CStr(CInt(Oct(i)) + 11) & "." & CStr(iTreatmentValue) & ";"
                strAnswer = "��� ����� �������� �� ���� ��/����� ���� ���� �������. �� ���� ������ ����"
            Else
                arrToothCheck(i).Add(iTreatmentValue)
            End If
        Next
        If strErrTeeth = "" Then
            Return 1
        Else
            Return 0
        End If
    End Function

    Private Function TestOldRow(ByVal iTreatmentValue As Integer, ByVal iCauseValue As Integer, ByVal iFromTooth As Integer, ByVal iToTooth As Integer, ByVal arrToothCheck() As ArrayList, ByRef strAnswer As String, ByRef strErrTeeth As String) As Integer
        Dim i As Integer, iArrIndex1 As Integer, iArrIndex2 As Integer
        If iFromTooth = 88 Then
            iArrIndex1 = 0
            iArrIndex2 = 63
        Else
            iArrIndex1 = arrIndexTranslate(Convert.ToInt16(CStr(iFromTooth - 11), 8))
            iArrIndex2 = arrIndexTranslate(Convert.ToInt16(CStr(iToTooth - 11), 8))
            i = iArrIndex1
            iArrIndex1 = Math.Min(iArrIndex1, iArrIndex2)
            iArrIndex2 = Math.Max(i, iArrIndex2)
        End If
        For i = iArrIndex1 To iArrIndex2
            If arrToothCheck(i).Contains(iTreatmentValue) Then
                strErrTeeth = strErrTeeth & CStr(CInt(Oct(i)) + 11) & "." & CStr(iTreatmentValue) & ";"
                strAnswer = "��� ����� �������� �� ���� ��/����� ���� ���� �������. �� ���� ������ ����"
            End If
        Next
        If strErrTeeth = "" Then
            Return 1
        Else
            Return 0
        End If
    End Function

    Private Function TestInput(ByVal strTreatmentsValue As String, ByRef strAnswer As String, ByRef strErrTeeth As String) As Integer
        Dim retValue As Integer = 0
        strErrTeeth = ""
        Dim arrTreatmentsRows() As String
        If strTreatmentsValue <> "" Then
            arrTreatmentsRows = Split(strTreatmentsValue, ";")
            If arrTreatmentsRows.Length > 0 Then
                If Len(arrTreatmentsRows(0)) > 0 Then
                    retValue = 1
                End If
            End If
        End If
        If retValue = 0 Then
            strAnswer = "��� �����"
            Return 0
        End If
        Dim strTreatmentRow As String, arrOneRow() As String, strTreatmentValue As String, strCauseValue As String, strFromTooth As String, strToTooth As String
        Dim i As Integer, iArrIndex1 As Integer, iArrIndex2 As Integer, iFromTooth As Integer, iToTooth As Integer, iTreatmentValue As Integer, iCauseValue As Integer ', strTestValue As String
        Dim arrToothCheck(64) As ArrayList
        For i = 0 To 63
            arrToothCheck(i) = New ArrayList()
        Next
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim dsTreatmentTypes As DataSet = objTreatmentService.GetTreatmentTypesForConsultation("D7BA44CC-36D7-4755-BE56-D217C1089527")
        Dim dsCauseList As DataSet = objTreatmentService.GetCauseListForConsultation("788DDC06-CA83-49A1-B132-40A8FAC1C905")
        Dim dsToothRange As DataSet = objTreatmentService.GetToothRangeForConsultation("9420205B-6BE4-4B39-86F4-2A1D446A4A70")
        For Each strTreatmentRow In arrTreatmentsRows
            arrOneRow = Split(strTreatmentRow, ".")
            If arrOneRow.Length = 4 Then
                strTreatmentValue = arrOneRow(0)
                strCauseValue = arrOneRow(1)
                strFromTooth = arrOneRow(2)
                strToTooth = arrOneRow(3)
                If IsNumeric(strTreatmentValue) Then
                    iTreatmentValue = CInt(strTreatmentValue)
                Else
                    iTreatmentValue = 0
                End If
                If IsNumeric(strCauseValue) Then
                    iCauseValue = CInt(strCauseValue)
                Else
                    iCauseValue = 0
                End If
                If IsNumeric(strFromTooth) Then
                    iFromTooth = CInt(strFromTooth)
                Else
                    iFromTooth = 0
                End If
                If IsNumeric(strToTooth) Then
                    iToTooth = CInt(strToTooth)
                Else
                    iToTooth = iFromTooth
                End If
                If iTreatmentValue > 0 And iFromTooth > 0 Then
                    Select Case CheckTreatment(CStr(iTreatmentValue), Not (iToTooth = iFromTooth), dsTreatmentTypes)
                        Case 0
                            strAnswer = "��� ���� ����� �� ����"
                            strErrTeeth = strErrTeeth & CStr(iFromTooth) & "." & CStr(iTreatmentValue) & ";"
                            retValue = 0
                        Case -1
                            strAnswer = "�� ���� ����� ���� ������ ������ ��"
                            strErrTeeth = CStr(iFromTooth)
                            retValue = 0
                    End Select
                    'Select Case CheckCause(CStr(iTreatmentValue), CStr(iCauseValue), dsCauseList)
                    '    Case -1
                    '        strAnswer = "�� ���� ����� ���� ������ ��"
                    '        Return 0
                    '    Case -2
                    '        strAnswer = "��� ��� ���� ����"
                    '        Return 0
                    '    Case -3
                    '        strAnswer = "��� ���� ���� �� ����"
                    '        Return 0
                    'End Select
                    Select Case CheckTooth(CStr(iTreatmentValue), CStr(iFromTooth), CStr(iToTooth), dsToothRange)
                        Case 0
                            strAnswer = "��� ���� ����� �� ����"
                            strErrTeeth = strErrTeeth & CStr(iFromTooth) & "." & CStr(iTreatmentValue) & ";"
                            retValue = 0
                        Case -1
                            strAnswer = "��� ���� '���' �� ����"
                            strErrTeeth = strErrTeeth & CStr(iFromTooth) & "." & CStr(iTreatmentValue) & ";"
                            retValue = 0
                        Case -2
                            strAnswer = "��� ���� '�� ��' �� ����"
                            strErrTeeth = strErrTeeth & CStr(iToTooth) & "." & CStr(iTreatmentValue) & ";"
                            retValue = 0
                        Case -3
                            strAnswer = "����� ����� '���' �- '�� ��' �� �����"
                            strErrTeeth = strErrTeeth & CStr(iFromTooth) & "." & CStr(iTreatmentValue) & ";"
                            retValue = 0
                    End Select
                    If iFromTooth = 88 Then
                        iArrIndex1 = 0
                        iArrIndex2 = 63
                    Else
                        iArrIndex1 = arrIndexTranslate(Convert.ToInt16(CStr(iFromTooth - 11), 8))
                        iArrIndex2 = arrIndexTranslate(Convert.ToInt16(CStr(iToTooth - 11), 8))
                        i = iArrIndex1
                        iArrIndex1 = Math.Min(iArrIndex1, iArrIndex2)
                        iArrIndex2 = Math.Max(i, iArrIndex2)
                    End If
                    For i = iArrIndex1 To iArrIndex2
                        If arrToothCheck(i).Contains(iTreatmentValue) Then
                            strErrTeeth = strErrTeeth & CStr(CInt(Oct(i)) + 11) & "." & CStr(iTreatmentValue) & ";"
                            strAnswer = "�� ���� ����� �� ����� ���� ���� ��� ���"
                            retValue = 0
                        Else
                            arrToothCheck(i).Add(iTreatmentValue)
                        End If
                    Next
                Else
                    strAnswer = "����� �� ������"
                    Return 0
                End If
            End If
        Next
        For i = 0 To 63
            If arrToothCheck(i).Count > 5 Then
                strErrTeeth = strErrTeeth & CStr(CInt(Oct(i)) + 11) & ";"
                strAnswer = "�� ���� ����� �� ���� ������ ������� ���"
                retValue = 0
            End If
        Next
        If strErrTeeth = "" Then
            Return 1
        Else
            Return 0
        End If
    End Function

    Private Function CheckTreatmentForServiceBasket(ByVal iTreatmentValue As Integer, ByRef strAnswer As String) As Integer
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()

        Dim dsTreatment As DataSet = objTreatmentService.GetTreatmentByTreatmentID("CA459EC9-0EC6-42AD-AA10-72A5E50FEDB4", iTreatmentValue)
        Dim iServiceBasket As Integer = Val(dsTreatment.Tables(0).Rows(0)("ServiceBasket").ToString())

        If iServiceBasket <> 1 Then
            strAnswer = "��� ������ ������ ����� ����� ��� ��������.<BR>�� ����� ����� ����� ������ �� ��� ������ ��� ���� �����."
            Return 0
        Else
            Return 1
        End If

    End Function

    Private Function CheckCause(ByVal strTreatmentValue As String, ByVal strCause As String, ByRef ds As DataSet) As Integer
        Dim foundRows() As DataRow
        Dim retValue As Integer = 0
        foundRows = ds.Tables(0).Select("TreatmentID=" & strTreatmentValue)
        If foundRows.Length > 0 Then
            If strCause = "0" Then
                retValue = -2
            Else
                foundRows = ds.Tables(0).Select("TreatmentID=" & strTreatmentValue & " AND CauseID=" & strCause)
                If foundRows.Length > 0 Then
                    retValue = 1
                Else
                    retValue = -3
                End If
            End If
        Else
            If strCause = "0" Then
                retValue = 1
            Else
                retValue = -1
            End If
        End If
        Return retValue
    End Function

    Private Function CheckTreatment(ByVal strTreatmentValue As String, ByVal bRange As Boolean, ByRef ds As DataSet) As Integer
        Dim foundRows() As DataRow
        Dim retValue As Integer = 0
        foundRows = ds.Tables(0).Select("TreatmentID=" & strTreatmentValue)
        If foundRows.Length > 0 Then
            If foundRows(0).Item("AllowRange").ToString() = "1" Then
                retValue = 1
            Else
                If bRange Then
                    retValue = -1
                Else
                    retValue = 1
                End If
            End If
        End If
        Return retValue
    End Function

    Private Function CheckTooth(ByVal strTreatmentValue As String, ByVal strFromTooth As String, ByVal strToTooth As String, ByRef ds As DataSet) As Integer
        Dim foundRows() As DataRow
        Dim currRow As Data.DataRow
        Dim retValue As Integer = 0
        Dim bResultFrom As Boolean = False
        Dim bResultTo As Boolean = False
        Dim iTempFrom As Integer, iTempTo As Integer
        foundRows = ds.Tables(0).Select("TreatmentID=" & strTreatmentValue)
        If foundRows.Length > 0 Then
            For Each currRow In foundRows
                iTempFrom = CInt(currRow("FromTooth").ToString())
                iTempTo = CInt(currRow("ToTooth").ToString())
                If ValidateTooth(CInt(strFromTooth), iTempFrom, iTempTo) Then
                    bResultFrom = True
                End If
                If ValidateTooth(CInt(strToTooth), iTempFrom, iTempTo) Then
                    bResultTo = True
                End If
                If bResultFrom And bResultTo Then
                    retValue = 1
                    Exit For
                End If
            Next
            If retValue = 0 Then
                If Not bResultFrom Then
                    retValue = -1
                End If
                If Not bResultTo Then
                    retValue += -2
                End If
            End If
        End If
        Return retValue
    End Function

    Private Function ValidateTooth(ByVal iTooth As Integer, ByVal iFromTooth As Integer, ByVal iToTooth As Integer) As Boolean
        If (iTooth >= iFromTooth) And (iTooth <= iToTooth) Then
            Return True
        Else
            Return False
        End If
    End Function
End Class
