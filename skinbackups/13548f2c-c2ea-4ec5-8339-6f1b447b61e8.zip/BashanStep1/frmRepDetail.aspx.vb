Public Class frmRepDetail
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim sReport As String = ""
        Dim CompanyID As Integer
        If Application("CompanyID") Is Nothing Then
            CompanyID = 0
        Else
            Try
                CompanyID = Integer.Parse(Application("CompanyID").ToString)
            Catch
                CompanyID = 0
            End Try
        End If
        If Not IsPostBack Then
            Dim ConnectRef As String = Request.QueryString("ConnectRef")
            If ConnectRef <> "" Then
                Dim objReportsList As New ReportConnect.ReportService()
                objReportsList.Url = Application("ReportWebService").ToString()
                Response.Buffer = False
                Response.Clear()
                Response.Expires = -1
                Try
                    objReportsList.GetTeethDetailByConnectRef("8FB372FE-D9D0-49BA-91DE-DC2610B654B2", ConnectRef, CompanyID, sReport)
                    'Response.Write(objReportsList.GetReportText("0D5DA238-109A-4BD8-86AB-CF395A063297", User.Identity.Name, strCurrentReportID))
                    Response.Write(sReport)
                Catch ex As Exception
                    '
                End Try
                Response.End()
            End If
        End If

    End Sub


End Class
