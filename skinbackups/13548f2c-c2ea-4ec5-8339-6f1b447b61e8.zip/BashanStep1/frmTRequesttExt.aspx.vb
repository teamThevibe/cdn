﻿Public Partial Class frmTRequesttExt
    Inherits System.Web.UI.Page

    'Protected WithEvents lstDoctorCare As System.Web.UI.WebControls.DropDownList

    'Protected WithEvents cmdExit As System.Web.UI.HtmlControls.HtmlInputButton
    'Protected WithEvents cmdSend As System.Web.UI.HtmlControls.HtmlInputButton
    'Protected WithEvents cmdNewReq As System.Web.UI.HtmlControls.HtmlInputButton

    'Protected WithEvents txtDoctorCareName As System.Web.UI.WebControls.Label
    'Protected WithEvents txtDoctorCareNumber As System.Web.UI.WebControls.Label
    'Protected WithEvents txtClinicName As System.Web.UI.WebControls.Label
    'Protected WithEvents txtClinicNumber As System.Web.UI.WebControls.Label
    'Protected WithEvents txtInsuredID As System.Web.UI.HtmlControls.HtmlInputText
    'Protected WithEvents txtInsuredName As System.Web.UI.HtmlControls.HtmlInputText
    'Protected WithEvents txtInsuredFamily As System.Web.UI.HtmlControls.HtmlInputText
    'Protected WithEvents txtNote As System.Web.UI.HtmlControls.HtmlTextArea
    'Protected WithEvents txtAnswer As System.Web.UI.HtmlControls.HtmlGenericControl
    'Protected WithEvents txtError As System.Web.UI.HtmlControls.HtmlInputHidden
    'Protected WithEvents txtLName As System.Web.UI.HtmlControls.HtmlInputHidden
    'Protected WithEvents txtFName As System.Web.UI.HtmlControls.HtmlInputHidden
    'Protected WithEvents txtData As System.Web.UI.HtmlControls.HtmlInputHidden
    'Protected WithEvents txtDoctorType As System.Web.UI.HtmlControls.HtmlInputHidden
    'Protected WithEvents txtSkipCheck As System.Web.UI.HtmlControls.HtmlInputHidden

    'Protected WithEvents chkPan As System.Web.UI.HtmlControls.HtmlInputCheckBox
    'Protected WithEvents chkStatus As System.Web.UI.HtmlControls.HtmlInputCheckBox
    'Protected WithEvents chkFace As System.Web.UI.HtmlControls.HtmlInputCheckBox

    'Protected WithEvents lstCareType As System.Web.UI.HtmlControls.HtmlSelect
    'Protected WithEvents lstOccasion As System.Web.UI.HtmlControls.HtmlSelect
    'Protected WithEvents lstToothRange As System.Web.UI.HtmlControls.HtmlSelect

    'Protected WithEvents lstCareGroup0 As System.Web.UI.HtmlControls.HtmlSelect
    'Protected WithEvents lstCareGroup1 As System.Web.UI.HtmlControls.HtmlSelect
    'Protected WithEvents lstCareGroup2 As System.Web.UI.HtmlControls.HtmlSelect
    'Protected WithEvents lstCareGroup3 As System.Web.UI.HtmlControls.HtmlSelect
    'Protected WithEvents lstCareGroup4 As System.Web.UI.HtmlControls.HtmlSelect

    'Protected WithEvents cmdClean As System.Web.UI.HtmlControls.HtmlInputButton
    'Protected WithEvents cmdCopy As System.Web.UI.HtmlControls.HtmlInputButton
    'Protected WithEvents hidHasReportConsultation As System.Web.UI.HtmlControls.HtmlInputHidden
    'Protected WithEvents cmdShowConsultations As System.Web.UI.HtmlControls.HtmlInputButton
    'Protected WithEvents cmdShowOldTreatments0 As System.Web.UI.HtmlControls.HtmlInputButton
    'Protected WithEvents cmdShowOldTreatments1 As System.Web.UI.HtmlControls.HtmlInputButton
    'Protected WithEvents cmdShowOldTreatments2 As System.Web.UI.HtmlControls.HtmlInputButton
    'Protected WithEvents cmdShowOldTreatments3 As System.Web.UI.HtmlControls.HtmlInputButton
    'Protected WithEvents cmdShowOldTreatments4 As System.Web.UI.HtmlControls.HtmlInputButton

    'Protected WithEvents hidWinName As System.Web.UI.HtmlControls.HtmlInputHidden
    'Protected WithEvents hidGovernmentTreatments As System.Web.UI.HtmlControls.HtmlInputHidden

    Dim iFromCmdClean As Integer

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        If Not objUser.GetConsultationPermitions("AB699114-1C1D-4EB7-8186-033B5306E799", User.Identity.Name) Then
            objUser.AddUserIllegalAction("24304391-6FDE-4237-A9B6-49630958EB26", User.Identity.Name, "frmTRequestt")
            Response.Redirect("Login.aspx")
        End If
        If IsNothing(Session("Login_User")) OrElse Len(Session("Login_User")) = 0 Then
            Response.Redirect("Login.aspx")
        End If
        'Avner280110************
        If Not Request.QueryString("fromCmdClean") Is Nothing Then
            iFromCmdClean = Convert.ToInt32(Request.QueryString("fromCmdClean").ToString)
        End If
        'End avner280110************
        hidGovernmentTreatments.Value = Application("GovernmentTreatments").ToString()
        If Application("GovernmentTreatments").ToString() = "1" And Application("ShowOldTreatments").ToString() = "1" Then
            cmdShowOldTreatments0.Visible = True
            cmdShowOldTreatments1.Visible = True
            cmdShowOldTreatments2.Visible = True
            cmdShowOldTreatments3.Visible = True
            cmdShowOldTreatments4.Visible = True
        Else
            cmdShowOldTreatments0.Visible = False
            cmdShowOldTreatments1.Visible = False
            cmdShowOldTreatments2.Visible = False
            cmdShowOldTreatments3.Visible = False
            cmdShowOldTreatments4.Visible = False
        End If


        If Not IsPostBack Then
            If Session("MRequest_Source") = "1" Then
                If Session("BSHN_Independed") <> "1" Then
                    Try
                        If IsNumeric(Session("MRequest_DoctorCare")) Then
                            lstDoctorCare.SelectedIndex = CInt(Session("MRequest_DoctorCare"))
                            txtDoctorCareNumber.Text = Session("MRequest_DoctorCareName").ToString
                        End If
                    Catch ex As Exception
                        '
                    End Try
                End If

                txtInsuredID.Value = Session("MRequest_InsuredID")
                txtInsuredName.Value = Session("MRequest_InsuredName")
                txtInsuredFamily.Value = Session("MRequest_InsuredFamily")
                txtLName.Value = Session("MRequest_LName")
                txtFName.Value = Session("MRequest_FName")


                Session("MRequest_Source") = ""
            End If

            If Session("User_Login_First_Time") = "1" Then
                Response.Redirect("frmUserProp.aspx")
            End If
            If Application("Smile") = "1" Or Application("CompanyID").ToString = "3" Then
                'cmdCopy.Visible = False
                cmdNewReq.Visible = False
                cmdClean.Visible = False
                txtSkipCheck.Value = "1"
            End If
            If Session("BSHN_Independed") = "1" Then
                lstDoctorCare.Visible = False
                txtDoctorCareName.Visible = True
            Else
                lstDoctorCare.Visible = True
                txtDoctorCareName.Visible = False
            End If

            If Application("CompanyID").ToString = "3" Then

                ' cmdNewReq.Visible = False
                'cmdNew.Visible = False
                'txtSkipCheck.Value = "1"
                Dim iAge As Integer = Val(Session("Leumit_Insured_Age"))
                If iAge < 6 Then
                    '    rTTypeM.Checked = True
                    txtAgeRange.Value = "0"
                Else
                    If iAge < 12 Then
                        txtAgeRange.Value = "1"
                    Else
                        txtAgeRange.Value = "2"
                    End If
                End If
                'tblMlkTeeth.Style.Add("display", "none")
            End If
            txtCompanyID.Value = Application("CompanyID").ToString
            txtDoctorType.Value = CStr(objUser.GetUserDoctorType("C049B33B-243D-43C1-B2F5-AB4859F9EBD1", User.Identity.Name))
            ''''''''''''''''''txtDoctorType.Value = CStr(objUser.GetHDUserDoctorType("0B776BB2-51E1-11E4-8E10-7F911D5D46B0", User.Identity.Name))


            FillDefaults()
            FillNameAndId()
        End If
    End Sub

    Private Sub FillDefaults()
        txtData.Value = ""
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()

        Dim strDoctorCareName As String
        Dim strDoctorCareNumber As String
        Dim strClinicName As String
        Dim strClinicNumber As String
        If objTreatmentService.GetDoctorProperties("7EC6114A-62CD-4DC4-A940-1416BFB136D8", User.Identity.Name, strDoctorCareName, strDoctorCareNumber, strClinicName, strClinicNumber) Then
            '''''''''''''''If objTreatmentService.GetHdDoctorProperties("C4AEB905-6C91-4FC8-93BE-1486B99518E57", User.Identity.Name, strDoctorCareName, strDoctorCareNumber, strClinicName, strClinicNumber) Then

            If Session("BSHN_Independed") = "1" Then
                txtDoctorCareName.Text = strDoctorCareName
                txtDoctorCareNumber.Text = strDoctorCareNumber

            Else

                Dim objUser As New UserConnect.UserService()
                objUser.Url = Application("UserWebService").ToString()
                lstDoctorCare.DataSource = objUser.GetDoctorList("03407803-DE6A-41AA-87DC-60D1D0329753", User.Identity.Name)
                lstDoctorCare.DataBind()

                If lstDoctorCare.Items.Count > 1 Then
                    lstDoctorCare.Items.Insert(0, New ListItem("בחר...", "0"))
                Else
                    txtDoctorCareNumber.Text = strDoctorCareNumber
                End If

                'Avner280110************
                If iFromCmdClean = 1 Then
                    If Session("BSHN_Independed") <> "1" Then
                        Try
                            If IsNumeric(Session("MRequest_DoctorCare")) Then
                                lstDoctorCare.SelectedIndex = CInt(Session("MRequest_DoctorCare"))
                                txtDoctorCareNumber.Text = Session("MRequest_DoctorCareName").ToString
                            End If
                        Catch e As Exception
                            '
                        End Try
                    End If
                    iFromCmdClean = 1
                End If
                'End avner 280110***********
                'SetComboValue(lstDoctorCare, strDoctorCareNumber)
            End If
            txtClinicName.Text = strClinicName
            txtClinicNumber.Text = strClinicNumber
        End If
        FillCareGroup(lstCareGroup0)
        FillCareGroup(lstCareGroup1)
        FillCareGroup(lstCareGroup2)
        FillCareGroup(lstCareGroup3)
        FillCareGroup(lstCareGroup4)
        FillCareType()
        FillOccasion()
        FillToothRange()
    End Sub

    Private Sub FillCareGroup(ByRef cbo As HtmlSelect)
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

        Dim isSmileAgrementClinic As Boolean = False
        Dim iSmileAgrementClinicPlus As Integer = 0
        If Application("Smile") = "1" Then
            iSmileAgrementClinicPlus = objUser.CheckIfAgrementClinicPlus("2AFAE3F5-79B5-459E-B1F9-C460BD34672A", User.Identity.Name)
            If iSmileAgrementClinicPlus > 0 Then
                isSmileAgrementClinic = True
            End If
        End If

        cbo.Items.Clear()
        cbo.Items.Add(New ListItem(" ", 0))
        If Application("Smile") = "1" And Application("Smile_Platinum_18_Supported") = "1" And Session("Smile_Platinum_18") = "1" And Not isSmileAgrementClinic Then
            Dim PhotosTreatmentTypeID As Integer = Val(objUser.GetGeneralParameter("3FCAAB6E-4AAD-4231-A9F2-B9CCA67EE079", "PhotosTreatmentTypeID"))
            Dim PreservativesTreatmentTypeID As Integer = Val(objUser.GetGeneralParameter("3FCAAB6E-4AAD-4231-A9F2-B9CCA67EE079", "PreservativesTreatmentTypeID"))
            cbo.Items.Add(New ListItem("משמר", PreservativesTreatmentTypeID))
            cbo.Items.Add(New ListItem("צילומים", PhotosTreatmentTypeID))
        Else
            Dim objTreatmentService As New TreatmentConnect.TreatmentService()
            objTreatmentService.Url = Application("TreatmentWebService").ToString()

            Dim ds As DataSet
            If Session("Leumit_OnlyServiceBasket") = "1" Or isSmileAgrementClinic Then
                If iSmileAgrementClinicPlus = 2 Then
                    ds = objTreatmentService.GetCareGroupForConsultationForServiceBasketPlus("981DE358-008E-4116-A15C-D1222E0AED40")
                Else
                    ds = objTreatmentService.GetCareGroupForConsultationForServiceBasket("179909B0-2E90-487B-9849-B6AAB5C67CEF")
                End If
            ElseIf Session("Smile_OnlyServiceBasketNet") = "1" Then
                ds = objTreatmentService.GetCareGroupForConsultationForServiceBasketNet("C83F5B6B-3B1A-4DA5-A5FD-6EBFD88F929B")
            Else
                ds = objTreatmentService.GetCareGroupForConsultation("E8696D07-B050-43A7-BC46-B8A736FED345")
            End If

            Dim currRow As DataRow
            For Each currRow In ds.Tables(0).Rows
                cbo.Items.Add(New ListItem(Trim(currRow("TreatmentType").ToString()), currRow("TreatmenTypetID").ToString()))
            Next
        End If
        cbo.SelectedIndex = 0
    End Sub

    Private Sub FillCareType()
        Dim bGovernmentTreatments As Boolean = CBool(Application("GovernmentTreatments").ToString() = "1")

        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim ds As DataSet
        Dim isSmileAgrementClinic As Boolean = False
        Dim iSmileAgrementClinicPlus As Integer = 0
        If Application("Smile") = "1" Then
            iSmileAgrementClinicPlus = objUser.CheckIfAgrementClinicPlus("2AFAE3F5-79B5-459E-B1F9-C460BD34672A", User.Identity.Name)
            If iSmileAgrementClinicPlus > 0 Then
                isSmileAgrementClinic = True
            End If
        End If
        If Session("Leumit_OnlyServiceBasket") = "1" Or isSmileAgrementClinic Then
            If iSmileAgrementClinicPlus = 2 Then
                ds = objTreatmentService.GetTreatmentTypesForConsultationForServiceBasketPlus("EA543323-0B36-4D72-A262-78F8DE6CCF7B")
            Else
                ds = objTreatmentService.GetTreatmentTypesForConsultationForServiceBasket("0E3C7076-A683-462C-92B1-FD4A6E282A2F")
            End If
        ElseIf Session("Smile_OnlyServiceBasketNet") = "1" Then
            ds = objTreatmentService.GetTreatmentTypesForConsultationForServiceBasketNet("1012E246-2EA9-4A22-B61F-565F68744B2A")
        ElseIf bGovernmentTreatments Then
            ds = objTreatmentService.GetTreatmentTypesForConsultationGov("88181708-FB22-4FA8-9866-716FDD2184AE")
        Else
            ds = objTreatmentService.GetTreatmentTypesForConsultation("D7BA44CC-36D7-4755-BE56-D217C1089527")
        End If
        Dim currRow As DataRow, objItem As ListItem
        lstCareType.Items.Clear()
        Dim bCheckType2 As Boolean = False
        If Application("Smile") = "1" And Application("Smile_Platinum_18_Supported") = "1" And Session("Smile_Platinum_18") = "1" And Not isSmileAgrementClinic Then
            bCheckType2 = True
        End If
        Dim bSmile As Boolean = CBool(Application("Smile") = "1")
        For Each currRow In ds.Tables(0).Rows
            If bCheckType2 And CType(currRow("TreatmentTypeID"), Integer) <> 1 Then
                '
            Else
                If bGovernmentTreatments Then
                    objItem = New ListItem(Trim(currRow("GovTreatmentDescription").ToString()), currRow("TreatmentID").ToString())
                Else
                    objItem = New ListItem(Trim(currRow("Treatment").ToString()), currRow("TreatmentID").ToString())
                End If
                objItem.Attributes.Add("CareGroup", currRow("TreatmentTypeID").ToString())
                objItem.Attributes.Add("AllowRange", currRow("AllowRange").ToString())
                If bSmile Then
                    objItem.Attributes.Add("SmileCode", currRow("SmileTreatmentID").ToString())
                ElseIf bGovernmentTreatments Then
                    objItem.Attributes.Add("SmileCode", currRow("GovTreatmentID").ToString())
                Else
                    objItem.Attributes.Add("SmileCode", currRow("TreatmentID").ToString())
                End If

                objItem.Attributes.Add("IsFilling", currRow("IsFilling").ToString())

                lstCareType.Items.Add(objItem)
            End If
        Next
    End Sub

    Private Sub FillOccasion()
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim ds As DataSet = objTreatmentService.GetCauseListForConsultation("788DDC06-CA83-49A1-B132-40A8FAC1C905")
        Dim currRow As DataRow, objItem As ListItem
        lstOccasion.Items.Clear()
        For Each currRow In ds.Tables(0).Rows
            objItem = New ListItem(Trim(currRow("Cause").ToString()), currRow("CauseID").ToString())
            objItem.Attributes.Add("Treatment", currRow("TreatmentID").ToString())
            lstOccasion.Items.Add(objItem)
        Next
    End Sub

    Private Sub FillToothRange()
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim ds As DataSet = objTreatmentService.GetToothRangeForConsultationExt("C25E100D-EEA0-4109-AF74-5B008D0D5775")
        Dim currRow As DataRow, objItem As ListItem
        lstToothRange.Items.Clear()
        For Each currRow In ds.Tables(0).Rows
            objItem = New ListItem(Trim(currRow("ToTooth").ToString()), currRow("FromTooth").ToString())
            objItem.Attributes.Add("Treatment", currRow("TreatmentID").ToString())
            lstToothRange.Items.Add(objItem)
        Next
    End Sub

    Private Sub SetComboValue(ByRef cbo As DropDownList, ByVal strValue As String)
        Dim li As ListItem = cbo.Items.FindByValue(strValue)
        If Not li Is Nothing Then
            li.Selected = True
        End If
    End Sub

    Private Sub cmdExit_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdExit.ServerClick
        Session("Filter_On") = ""

        Session("Filter_To_Date") = ""
        Session("Filter_From_Date") = ""
        Session("MRequest_Source") = "1"
        Session("Filter_InsuredID") = ""
        Session("Report_List_ReportType") = ""

        Session("MRequest_DoctorCare") = ""
        Session("MRequest_DoctorCareName") = ""

        Session("TRequest_InsuredID") = ""
        Session("TRequest_InsuredName") = ""
        Session("TRequest_InsuredFamily") = ""
        Session("MRequest_LName") = ""
        Session("MRequest_FName") = ""
        Session("MRequest_RequestType") = ""

        Session("From_Consultation") = ""
        CheckWindowName()
        If Application("CompanyID") & "" = "3" Then
            Response.Redirect("frmLMCheck.aspx")
        ElseIf Application("Smile") = "1" Then
            Response.Redirect("frmCheckSM.aspx")
        Else
            Response.Redirect("frmStart.aspx")
        End If
    End Sub

    Private Sub FillNameAndId()
        txtInsuredID.Value = Session("TRequest_InsuredID")
        txtInsuredName.Value = Session("TRequest_InsuredName")
        txtInsuredFamily.Value = Session("TRequest_InsuredFamily")
        If IsNumeric(Session("MRequest_DoctorCare")) Then
            lstDoctorCare.SelectedIndex = CInt(Session("MRequest_DoctorCare"))
            txtDoctorCareNumber.Text = Session("MRequest_DoctorCareName").ToString
        End If

        If Application("Smile") = "1" Or Application("CompanyID").ToString = "3" Then
            ' Smile or Leumit
            txtInsuredID.Attributes.Remove("onblur")
            txtFName.Value = Session("TRequest_InsuredName")
            txtLName.Value = Session("TRequest_InsuredFamily")
            SetReadOnly(txtInsuredID)
            SetReadOnly(txtInsuredName)
            SetReadOnly(txtInsuredFamily)
        Else
            Session("TRequest_InsuredID") = ""
            Session("TRequest_InsuredName") = ""
            Session("TRequest_InsuredFamily") = ""
        End If
    End Sub

    Sub SetReadOnly(ByVal txtField As HtmlInputText)
        txtField.Attributes.Add("readonly", "true")
        txtField.Style.Add("background-Color", "#D6D3CE")
    End Sub

    Private Sub cmdClean_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClean.ServerClick
        CheckWindowName()
        If Session("BSHN_Independed") <> "1" Then
            Session("MRequest_DoctorCare") = CStr(lstDoctorCare.SelectedIndex)
            Session("MRequest_DoctorCareName") = CStr(lstDoctorCare.SelectedValue)

        Else
            Session("MRequest_DoctorCare") = "0"
            Session("MRequest_DoctorCareName") = txtDoctorCareNumber.Text
        End If

        Response.Redirect("frmTRequestt.aspx?fromCmdClean=1")
    End Sub

    Private Sub cmdCopy_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCopy.ServerClick
        CheckWindowName()
        Session("MRequest_Source") = "1"

        Session("Filter_On") = ""

        Session("Filter_To_Date") = ""
        Session("Filter_From_Date") = ""
        Session("Filter_InsuredID") = ""
        Session("Report_List_ReportType") = ""
        Session("From_Consultation") = ""

        If Session("BSHN_Independed") <> "1" Then
            Session("MRequest_DoctorCare") = CStr(lstDoctorCare.SelectedIndex)
            Session("MRequest_DoctorCareName") = CStr(lstDoctorCare.SelectedValue)

        Else
            Session("MRequest_DoctorCare") = "0"
            Session("MRequest_DoctorCareName") = txtDoctorCareNumber.Text
        End If
        Session("MRequest_InsuredID") = txtInsuredID.Value
        Session("MRequest_InsuredName") = txtInsuredName.Value
        Session("MRequest_InsuredFamily") = txtInsuredFamily.Value
        If Application("Smile") = "1" Or Application("CompanyID").ToString = "3" Then
            Session("MRequest_RequestType") = "1"
        End If
        Response.Redirect(Utils.Navigation.GetURL("frmRequestt.aspx"))
    End Sub

    Private Sub cmdNewReq_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdNewReq.ServerClick
        CheckWindowName()
        Response.Redirect("frmTRequesttExt.aspx")
    End Sub

    Private Sub cmdShowConsultations_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdShowConsultations.ServerClick
        CheckWindowName()
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

        Dim iShowReportConsultationPerion As Integer

        iShowReportConsultationPerion = Val(objUser.GetGeneralParameter("3FCAAB6E-4AAD-4231-A9F2-B9CCA67EE079", "ConsultationShowPeriod"))

        If iShowReportConsultationPerion = 0 Then
            iShowReportConsultationPerion = 6
        End If


        Session("Filter_On") = "1"

        Session("Filter_To_Date") = DateTime.Now.ToString("ddMMyyyy")
        Session("Filter_From_Date") = DateAdd(DateInterval.Month, -iShowReportConsultationPerion, DateTime.Now).ToString("ddMMyyyy")
        Session("MRequest_Source") = "1"
        Session("Filter_InsuredID") = txtInsuredID.Value
        Session("Report_List_ReportType") = "41"
        Session("Filter_Viewed") = "1"
        Session("Filter_NotViewed") = "1"

        'Session("MRequest_DoctorCare") = lstDoctorCare.SelectedIndex
        'Session("MRequest_DoctorCareName") = lstDoctorCare.SelectedItem.Value

        If Session("BSHN_Independed") <> "1" Then
            Session("MRequest_DoctorCare") = CStr(lstDoctorCare.SelectedIndex)
            Session("MRequest_DoctorCareName") = CStr(lstDoctorCare.SelectedValue)
        Else
            Session("MRequest_DoctorCare") = "0"
            Session("MRequest_DoctorCareName") = txtDoctorCareNumber.Text
        End If

        Session("TRequest_InsuredID") = txtInsuredID.Value
        Session("TRequest_InsuredName") = txtInsuredName.Value
        Session("TRequest_InsuredFamily") = txtInsuredFamily.Value
        ' ''Session("MRequest_LName") = txtLName.Value
        ' ''Session("MRequest_FName") = txtFName.Value

        Session("From_Consultation") = "2"

        Response.Redirect("frmRepList.aspx")
    End Sub

    Private Sub CheckWindowName()
        If Session("winname") = "" Then
            If (hidWinName.Value <> "") Then
                Session("winname") = hidWinName.Value
            End If
        Else
            If hidWinName.Value <> Session("winname") Then
                Response.Redirect("frmInvalidOperation.aspx")
            End If
        End If
    End Sub

End Class