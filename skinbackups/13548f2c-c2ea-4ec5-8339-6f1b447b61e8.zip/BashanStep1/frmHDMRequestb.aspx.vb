Imports System.IO
Imports System.Text.RegularExpressions

Public Class frmHDMRequestb
    Inherits System.Web.UI.Page
    Protected WithEvents hidClinicNumber As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidDoctorCareNumber As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidInsuredNo As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidInsuredFamily As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidInsuredName As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidDate As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidNote As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidPan As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidStatus As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidFace As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidInvoiceID As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidSum As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidRequestType As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidClaimID As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidMType As System.Web.UI.HtmlControls.HtmlInputHidden

    Protected WithEvents hidAvnit As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidSmoke As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidHigyena As System.Web.UI.HtmlControls.HtmlInputHidden

    Protected WithEvents hid11 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid12 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid13 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid14 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid15 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid16 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid17 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid18 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid21 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid22 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid23 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid24 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid25 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid26 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid27 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid28 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid31 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid32 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid33 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid34 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid35 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid36 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid37 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid38 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid41 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid42 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid43 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid44 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid45 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid46 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid47 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hid48 As System.Web.UI.HtmlControls.HtmlInputHidden

    Protected WithEvents hidAnswer As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidReturnValue As System.Web.UI.HtmlControls.HtmlInputHidden

    Protected WithEvents lstAttachmentType1 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstAttachmentType2 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstAttachmentType3 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstAttachmentType4 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstAttachmentType5 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstAttachmentType6 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstAttachmentType7 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstAttachmentType8 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstAttachmentType9 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstAttachmentType10 As System.Web.UI.WebControls.DropDownList

    Protected WithEvents fileToUpload1 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents fileToUpload2 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents fileToUpload3 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents fileToUpload4 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents fileToUpload5 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents fileToUpload6 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents fileToUpload7 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents fileToUpload8 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents fileToUpload9 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents fileToUpload10 As System.Web.UI.HtmlControls.HtmlInputFile

    Protected WithEvents txtExistAttNo1 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistAttNo2 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistAttNo3 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistAttNo4 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistAttNo5 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistAttNo6 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistAttNo7 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistAttNo8 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistAttNo9 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistAttNo10 As System.Web.UI.HtmlControls.HtmlInputHidden

    Protected WithEvents txtExistRecNo1 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistRecNo2 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistRecNo3 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistRecNo4 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistRecNo5 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistRecNo6 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistRecNo7 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistRecNo8 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistRecNo9 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistRecNo10 As System.Web.UI.HtmlControls.HtmlInputHidden

    Protected WithEvents txtFileTitle1 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFileTitle2 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFileTitle3 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFileTitle4 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFileTitle5 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFileTitle6 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFileTitle7 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFileTitle8 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFileTitle9 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtAttachTypesCombo1 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAttachTypesCombo2 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAttachTypesCombo3 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAttachTypesCombo4 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAttachTypesCombo5 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAttachTypesCombo6 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAttachTypesCombo7 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAttachTypesCombo8 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAttachTypesCombo9 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAttachTypesCombo10 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtFileTitle10 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents verofbrowser As Global.System.Web.UI.HtmlControls.HtmlInputHidden

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim strInsuredID As String = hidInsuredNo.Value

        Dim s As String = ""
        With Request.Browser
            s &= "Browser Capabilities" & vbCrLf
            s &= "Type = " & .Type & vbCrLf
            s &= "Name = " & .Browser & vbCrLf
            s &= "Version = " & .Version & vbCrLf
            s &= "Major Version = " & .MajorVersion & vbCrLf
            s &= "Minor Version = " & .MinorVersion & vbCrLf
            s &= "Platform = " & .Platform & vbCrLf
            s &= "Is Beta = " & .Beta & vbCrLf
            s &= "Is Crawler = " & .Crawler & vbCrLf
            s &= "Is AOL = " & .AOL & vbCrLf
            s &= "Is Win16 = " & .Win16 & vbCrLf
            s &= "Is Win32 = " & .Win32 & vbCrLf
            s &= "Supports Frames = " & .Frames & vbCrLf
            s &= "Supports Tables = " & .Tables & vbCrLf
            s &= "Supports Cookies = " & .Cookies & vbCrLf
            's &= "Supports VBScript = " & .VBScript & vbCrLf
            's &= "Supports JavaScript = " & _
            '     .EcmaScriptVersion.ToString() & vbCrLf
            ' s &= "Supports Java Applets = " & .JavaApplets & vbCrLf
            's &= "Supports ActiveX Controls = " & .ActiveXControls & _
            'vbCrLf
            's &= "Supports JavaScript Version = " & _
            ' Request.Browser("JavaScriptVersion") & vbCrLf
        End With
        verofbrowser.Value = s
        If IsPostBack Then
            Dim iMaxSize As Integer
            Dim regexWhiteList As Regex
            regexWhiteList = CType(Application("WhiteList"), Regex)

            If Not (regexWhiteList.IsMatch(hidInsuredFamily.Value) And _
            regexWhiteList.IsMatch(hidInsuredName.Value) And _
            regexWhiteList.IsMatch(hidNote.Value)) Then
                hidReturnValue.Value = "-2"
                Return
            End If

            If IsNumeric(Session("UploadFileSize").ToString()) Then
                iMaxSize = Val(Session("UploadFileSize").ToString())
                If iMaxSize = 0 Then
                    Utils.AddSystemLog("frmHDMRequestb point 1:  hidReturnValue.Value = -1", "Log out in javascript...")
                    hidReturnValue.Value = "-1"
                    Return
                End If
            Else
                Utils.AddSystemLog("frmHDMRequestb point 2:  hidReturnValue.Value = -1", "Log out in javascript...")
                hidReturnValue.Value = "-1"
                Return
            End If
            Dim strPolicyNo As String = ""
            Dim iRetValue As Integer = CheckAllFiles(iMaxSize)
            If iRetValue = 2 Then
                hidAnswer.Value = "���� ���� ����� �� ���� " & CStr(iMaxSize / 1024) & "K!" & "  �� ����� ������� ����  "
                iRetValue = 0
            ElseIf iRetValue = 1 Then
                hidAnswer.Value = "���� �� ����"
                iRetValue = 0
                'ElseIf iRetValue = 3 Then
                '    hidAnswer.Value = "����� ����� ���� ����"
                '    iRetValue = 0
            ElseIf iRetValue = 3 Then
                hidAnswer.Value = "���� �� ����"
                iRetValue = 0
            Else
                Dim bValidDate As Boolean = False
                Dim strTemDate As String = hidDate.Value
                If strTemDate <> "00000000" And strTemDate <> "" Then
                    strTemDate = Mid(strTemDate, 5, 4) & "-" & Mid(strTemDate, 3, 2) & "-" & Left(strTemDate, 2)
                    If IsDate(strTemDate) Then
                        bValidDate = True
                    End If
                End If
                If Not bValidDate Then
                    hidAnswer.Value = "����� ������ �� ����"
                    iRetValue = 0
                Else
                    Dim strFirstName As String = ""
                    Dim strLastName As String = ""
                    Dim strEmployeeNo As String = ""
                    Dim strEmpCD As String = ""
                    Dim objTreatmentService As New TreatmentConnect.TreatmentService()
                    objTreatmentService.Url = Application("TreatmentWebService").ToString()

                    objTreatmentService.GetInsuredProp("5E25C46A-EADC-4C27-8A5A-DB8B13E129D3", hidInsuredNo.Value, strFirstName, strLastName, strPolicyNo, strEmployeeNo, strEmpCD)
                    If UCase(Trim(strLastName)) = "ERROR" Then
                        objTreatmentService.GetSQLInsuredProp("6C865031-52E9-4422-950B-615B8F84600C", hidInsuredNo.Value, strFirstName, strLastName)
                    End If
                    strInsuredID = hidInsuredNo.Value

                    Dim str2Chars As String = Left(strLastName, 2)
                    Dim str2FNChars As String = Left(strFirstName, 2)
                    iRetValue = 1
                    If str2Chars = "" Or str2FNChars = "" Then
                        hidAnswer.Value = "����� ������ �� ���� ����� ���� ������ ������ ������"
                        iRetValue = 0
                    Else
                        If Regex.IsMatch(Mid(str2Chars, 2, 1), "[�-�a-zA-Z]") Then
                            If str2Chars <> Left(hidInsuredFamily.Value, 2) Then
                                hidAnswer.Value = "����� ������ �� ���� ����� ���� ������ ������ ������"
                                iRetValue = 0
                            End If
                        Else
                            If Left(str2Chars, 1) <> Left(hidInsuredFamily.Value, 1) Then
                                hidAnswer.Value = "����� ������ �� ���� ����� ���� ������ ������ ������"
                                iRetValue = 0
                            End If
                        End If
                        If Regex.IsMatch(Mid(str2FNChars, 2, 1), "[�-�a-zA-Z]") Then
                            If str2FNChars <> Left(hidInsuredName.Value, 2) Then
                                hidAnswer.Value = "����� ������ �� ���� ����� ���� ������ ������ ������"
                                iRetValue = 0
                            End If
                        Else
                            If Left(str2FNChars, 1) <> Left(hidInsuredName.Value, 1) Then
                                hidAnswer.Value = "����� ������ �� ���� ����� ���� ������ ������ ������"
                                iRetValue = 0
                            End If
                        End If
                    End If
                    Dim objUser As New UserConnect.UserService()
                    objUser.Url = Application("UserWebService").ToString()
                    Dim iDoctorType As Integer = objUser.GetUserDoctorType("C049B33B-243D-43C1-B2F5-AB4859F9EBD1", User.Identity.Name)
                    ''''''''''''''''''''''''''''Dim iDoctorType As Integer = objUser.GetHDUserDoctorType("0B776BB2-51E1-11E4-8E10-7F911D5D46B0", User.Identity.Name)
                    If iDoctorType <> 3 Then
                        If hidDoctorCareNumber.Value = "" Or hidDoctorCareNumber.Value = "0" Then
                            hidAnswer.Value = "���� ����� ���� ���� �� ���� ����� ����� �������"
                            iRetValue = 0
                        End If
                    End If
                    If iRetValue > 0 Then
                        Dim bNote As Boolean = False
                        If Trim(hidNote.Value) <> "" Then
                            bNote = True
                        End If
                        Dim strAttach As String = CStr(GetAttachValue(bNote))
                        Dim strXRayExist As String = CStr(CheckXrayExist())
                        Dim iXRayAttach As Integer
                        If CheckXrayAttach() Then
                            iXRayAttach = 1
                        Else
                            iXRayAttach = 0
                        End If
                        Dim strReferenceID As String
                        Dim iExtError As Integer = 0
                        If Application("Smile") = "1" Then
                            strFirstName = hidInsuredName.Value
                            strLastName = hidInsuredFamily.Value
                        End If
                        Dim iRequestID As Integer = objTreatmentService.PutTeethRequest("A627BF72-829A-4D58-A406-600DB17933F4", Val(strInsuredID), strFirstName, strLastName, "", strPolicyNo, Val(hidRequestType.Value), Val(hidClinicNumber.Value), hidDoctorCareNumber.Value, 0, hidAvnit.Value, hidSmoke.Value, hidHigyena.Value, hidInvoiceID.Value, hidSum.Value, "1", User.Identity.Name, Val(strAttach), hidDate.Value, Trim(hidNote.Value), strXRayExist, 1, hidClaimID.Value, strReferenceID)
                        If (strReferenceID <> "") And (iRequestID > 0) Then
                            If objTreatmentService.ArchiveRequest("170BA2F5-EC88-4190-A495-E97E3CB68F13", User.Identity.Name, iRequestID, Val(strInsuredID), 0, strReferenceID, 0, "", Val(strXRayExist), hidDate.Value) Then
                                Dim strT11 As String = Trim(Replace(hid11.Value, ";", ""))
                                Dim strT12 As String = Trim(Replace(hid12.Value, ";", ""))
                                Dim strT13 As String = Trim(Replace(hid13.Value, ";", ""))
                                Dim strT14 As String = Trim(Replace(hid14.Value, ";", ""))
                                Dim strT15 As String = Trim(Replace(hid15.Value, ";", ""))
                                Dim strT16 As String = Trim(Replace(hid16.Value, ";", ""))
                                Dim strT17 As String = Trim(Replace(hid17.Value, ";", ""))
                                Dim strT18 As String = Trim(Replace(hid18.Value, ";", ""))
                                Dim strT21 As String = Trim(Replace(hid21.Value, ";", ""))
                                Dim strT22 As String = Trim(Replace(hid22.Value, ";", ""))
                                Dim strT23 As String = Trim(Replace(hid23.Value, ";", ""))
                                Dim strT24 As String = Trim(Replace(hid24.Value, ";", ""))
                                Dim strT25 As String = Trim(Replace(hid25.Value, ";", ""))
                                Dim strT26 As String = Trim(Replace(hid26.Value, ";", ""))
                                Dim strT27 As String = Trim(Replace(hid27.Value, ";", ""))
                                Dim strT28 As String = Trim(Replace(hid28.Value, ";", ""))
                                Dim strT31 As String = Trim(Replace(hid31.Value, ";", ""))
                                Dim strT32 As String = Trim(Replace(hid32.Value, ";", ""))
                                Dim strT33 As String = Trim(Replace(hid33.Value, ";", ""))
                                Dim strT34 As String = Trim(Replace(hid34.Value, ";", ""))
                                Dim strT35 As String = Trim(Replace(hid35.Value, ";", ""))
                                Dim strT36 As String = Trim(Replace(hid36.Value, ";", ""))
                                Dim strT37 As String = Trim(Replace(hid37.Value, ";", ""))
                                Dim strT38 As String = Trim(Replace(hid38.Value, ";", ""))
                                Dim strT41 As String = Trim(Replace(hid41.Value, ";", ""))
                                Dim strT42 As String = Trim(Replace(hid42.Value, ";", ""))
                                Dim strT43 As String = Trim(Replace(hid43.Value, ";", ""))
                                Dim strT44 As String = Trim(Replace(hid44.Value, ";", ""))
                                Dim strT45 As String = Trim(Replace(hid45.Value, ";", ""))
                                Dim strT46 As String = Trim(Replace(hid46.Value, ";", ""))
                                Dim strT47 As String = Trim(Replace(hid47.Value, ";", ""))
                                Dim strT48 As String = Trim(Replace(hid48.Value, ";", ""))
                                If objTreatmentService.PutTeethVector("21EEA173-29FF-4997-A3AA-A0D7F5B32279", iRequestID, strT11, strT12, strT13, strT14, strT15, strT16, strT17, strT18, strT21, strT22, strT23, strT24, strT25, strT26, strT27, strT28, _
                                                                      strT31, strT32, strT33, strT34, strT35, strT36, strT37, strT38, strT41, strT42, strT43, strT44, strT45, strT46, strT47, strT48) Then
                                    iRetValue = 1
                                    If iXRayAttach > 0 Then
                                        iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType1"), objTreatmentService, fileToUpload1, txtExistAttNo1, txtExistRecNo1, iExtError)
                                        If iRetValue > 0 Then
                                            iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType2"), objTreatmentService, fileToUpload2, txtExistAttNo2, txtExistRecNo2, iExtError)
                                        End If
                                        If iRetValue > 0 Then
                                            iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType3"), objTreatmentService, fileToUpload3, txtExistAttNo3, txtExistRecNo3, iExtError)
                                        End If
                                        If iRetValue > 0 Then
                                            iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType4"), objTreatmentService, fileToUpload4, txtExistAttNo4, txtExistRecNo4, iExtError)
                                        End If
                                        If iRetValue > 0 Then
                                            iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType5"), objTreatmentService, fileToUpload5, txtExistAttNo5, txtExistRecNo5, iExtError)
                                        End If
                                        If iRetValue > 0 Then
                                            iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType6"), objTreatmentService, fileToUpload6, txtExistAttNo6, txtExistRecNo6, iExtError)
                                        End If
                                        If iRetValue > 0 Then
                                            iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType7"), objTreatmentService, fileToUpload7, txtExistAttNo7, txtExistRecNo7, iExtError)
                                        End If
                                        If iRetValue > 0 Then
                                            iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType8"), objTreatmentService, fileToUpload8, txtExistAttNo8, txtExistRecNo8, iExtError)
                                        End If
                                        If iRetValue > 0 Then
                                            iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType9"), objTreatmentService, fileToUpload9, txtExistAttNo9, txtExistRecNo9, iExtError)
                                        End If
                                        If iRetValue > 0 Then
                                            iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType10"), objTreatmentService, fileToUpload10, txtExistAttNo10, txtExistRecNo10, iExtError)
                                        End If
                                    End If
                                Else
                                    iRetValue = 0
                                End If
                            End If
                            If iRetValue > 0 Then
                                Dim objReport As New ReportConnect.ReportService()
                                objReport.Url = Application("ReportWebService").ToString()
                                Dim bMilk As Boolean = False
                                If hidMType.Value = "1" Then
                                    bMilk = True
                                End If
                                Dim strAnswer As String
                                objReport.AddRequestTeethReport("EC57D5DF-B71D-46E9-9A3F-A83E10BB58C4", User.Identity.Name, strReferenceID, bMilk, "I")
                                objTreatmentService.SetRequestTeethComplited("8814B333-3F5D-47C3-A337-6C49B563FA7F", iRequestID)
                                strAnswer = "���� ������: <SPAN dir='ltr'><B>" & strReferenceID & "</B></SPAN>"
                                'If objReport.AddRequestTeethReport("EC57D5DF-B71D-46E9-9A3F-A83E10BB58C4", User.Identity.Name, strReferenceID, bMilk) Then
                                '    objTreatmentService.SetRequestTeethComplited("8814B333-3F5D-47C3-A337-6C49B563FA7F", iRequestID)
                                '    strAnswer = "���� ������: <SPAN dir='ltr'><B>" & strReferenceID & "</B></SPAN>"
                                'Else
                                '    strAnswer = "���� ��� ����� ����� �����, ��� ��� ����� ������"
                                '    iRetValue = 0
                                'End If
                                hidAnswer.Value = strAnswer
                                hidInsuredFamily.Value = strLastName
                                hidInsuredName.Value = strFirstName

                            Else
                                If iExtError > 0 Then
                                    hidAnswer.Value = "����� ����� ���� ����"
                                Else
                                    hidAnswer.Value = "���� ��� ����� ����� �����, ��� ��� ����� ������"
                                End If
                            End If
                        Else
                            hidAnswer.Value = "���� ��� ����� ����� �����, ��� ��� ����� ������"
                            iRetValue = 0
                        End If
                    Else
                        hidAnswer.Value = "���� ��� ����� ����� �����, ��� ��� ����� ������"
                        iRetValue = 0
                    End If
                End If
            End If

            If iRetValue = -1 Then
                Utils.AddSystemLog("frmHDMRequestb point 3:  hidReturnValue.Value = -1", "Log out in javascript...")
            End If

            hidReturnValue.Value = iRetValue
        Else
            Dim objTreatmentService As New TreatmentConnect.TreatmentService()
            objTreatmentService.Url = Application("TreatmentWebService").ToString()
            Dim ds As Data.DataSet
            ds = objTreatmentService.GetAttachTypes("34E108A0-761B-4AD9-B226-61227A144F2F", 1)
            FillCombobox("AttachID", "AttachName", ds, lstAttachmentType1)
            FillCombobox("AttachID", "AttachName", ds, lstAttachmentType2)
            FillCombobox("AttachID", "AttachName", ds, lstAttachmentType3)
            FillCombobox("AttachID", "AttachName", ds, lstAttachmentType4)
            FillCombobox("AttachID", "AttachName", ds, lstAttachmentType5)
            FillCombobox("AttachID", "AttachName", ds, lstAttachmentType6)
            FillCombobox("AttachID", "AttachName", ds, lstAttachmentType7)
            FillCombobox("AttachID", "AttachName", ds, lstAttachmentType8)
            FillCombobox("AttachID", "AttachName", ds, lstAttachmentType9)
            FillCombobox("AttachID", "AttachName", ds, lstAttachmentType10)
        End If
    End Sub

    Private Sub FillCombobox(ByVal strValueField As String, ByVal strDescField As String, ByRef ds As Data.DataSet, ByRef objLstAttachmentType As System.Web.UI.WebControls.DropDownList)
        Dim currRow As Data.DataRow
        objLstAttachmentType.Items.Add(New ListItem("���...", 0))
        For Each currRow In ds.Tables(0).Rows
            objLstAttachmentType.Items.Add(New ListItem(currRow(strDescField).ToString(), currRow(strValueField).ToString()))
        Next
    End Sub

    Private Function CheckAllFiles(ByVal iMaxSize As Integer) As Integer
        Dim iRetValue As Integer
        iRetValue = CheckFileSize(fileToUpload1, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload2, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload3, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload4, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload5, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload6, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload7, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload8, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload9, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload10, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        Return 0
    End Function

    Private Function CheckFileSize(ByRef ctlFile As HtmlInputFile, ByVal iMaxSize As Integer) As Integer
        Dim iRetValue As Integer = 0
        If Not ctlFile.PostedFile Is Nothing AndAlso Trim(ctlFile.PostedFile.FileName) <> "" Then
            'If CheckFileHeader(ctlFile) > 0 Then
            '    iRetValue = 3
            'End If
            If ctlFile.PostedFile.ContentLength > iMaxSize Then
                iRetValue = 2
            ElseIf ctlFile.PostedFile.ContentLength < 1024 Then
                iRetValue = 3
            ElseIf ctlFile.PostedFile.ContentLength = 0 Then
                iRetValue = 1
            End If
        End If
        Return iRetValue
    End Function

    Private Function CheckFileHeader(ByRef byContent As Byte()) As Integer
        Dim iRetValue As Integer = 0
        If Application("CheckJpgHeader") = "1" Then
            Dim strJPEGStart As String = "255216"
            Dim strTIFFStartIntel As String = "7373"
            Dim strTIFFStartMotorola As String = "7777"
            Try
                Dim strHeader As String = byContent(0).ToString() & byContent(1).ToString()
                If strJPEGStart = strHeader Then
                    iRetValue = 1
                ElseIf strTIFFStartIntel = strHeader Or strTIFFStartMotorola = strHeader Then
                    iRetValue = 2
                End If
            Catch ex As Exception
                iRetValue = -1
            End Try
        Else
            iRetValue = 1
        End If
        Return iRetValue
    End Function

    'Private Function CheckFileHeader(ByRef ctlFile As HtmlInputFile) As Integer
    '    Dim sr As New StreamReader(ctlFile.PostedFile.InputStream)
    '    Dim ch As Integer
    '    Dim str As String
    '    Dim sb As New System.Text.StringBuilder()
    '    Dim i As Integer
    '    Dim iRetValue As Integer = 0
    '    Dim strJPEGStart As String = "016747073"
    '    Dim strTIFFStartIntel As String = "7373"
    '    Dim strTIFFStartMotorola As String = "7777"
    '    Try
    '        ch = sr.Read()
    '        While i < 5 And ch <> -1
    '            str = CType(ch, String)
    '            sb.Append(str)
    '            i = i + 1
    '            ch = sr.Read()
    '        End While

    '        If Path.GetExtension(ctlFile.PostedFile.FileName).ToUpper = ".JPG" Then
    '            If strJPEGStart <> sb.ToString() Then
    '                iRetValue = 3
    '            End If
    '        ElseIf Path.GetExtension(ctlFile.PostedFile.FileName).ToUpper = ".TIF" Then
    '            If Not sb.ToString().StartsWith(strTIFFStartIntel) And Not sb.ToString().StartsWith(strTIFFStartMotorola) Then
    '                iRetValue = 3
    '            End If

    '        End If
    '    Catch ex As Exception
    '        iRetValue = 3
    '    Finally
    '        sr.Close()
    '    End Try
    '    Return iRetValue
    'End Function

    Private Function GetAttachValue(ByVal bNote As Boolean) As Integer
        Dim iRetValue As Integer = 0
        Dim iTestValue As Integer
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType1"), txtExistAttNo1)
        iRetValue = iRetValue Or iTestValue
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType2"), txtExistAttNo2)
        iRetValue = iRetValue Or iTestValue
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType3"), txtExistAttNo3)
        iRetValue = iRetValue Or iTestValue
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType4"), txtExistAttNo4)
        iRetValue = iRetValue Or iTestValue
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType5"), txtExistAttNo5)
        iRetValue = iRetValue Or iTestValue
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType6"), txtExistAttNo6)
        iRetValue = iRetValue Or iTestValue
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType7"), txtExistAttNo7)
        iRetValue = iRetValue Or iTestValue
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType8"), txtExistAttNo8)
        iRetValue = iRetValue Or iTestValue
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType9"), txtExistAttNo9)
        iRetValue = iRetValue Or iTestValue
        iTestValue = GetAttachValueOneRow(Request.Form.Item("lstAttachmentType10"), txtExistAttNo10)
        iRetValue = iRetValue Or iTestValue
        If bNote Then
            iRetValue += 4
        End If
        Return iRetValue
    End Function

    Private Function GetAttachValueOneRow(ByVal strComboSelectedValue As String, ByRef ctlHidden1 As HtmlInputHidden) As Integer
        Dim i As Integer = CInt(strComboSelectedValue)
        Dim iRetValue As Integer
        If i = 0 Then
            iRetValue = 0
        ElseIf i = 10 Then
            iRetValue = 2
        Else
            If (IsNumeric(ctlHidden1.Value)) Then
                If CInt(ctlHidden1.Value) < 0 Then
                    iRetValue = 0
                Else
                    iRetValue = 1
                End If
            Else
                iRetValue = 1
            End If
        End If
        Return iRetValue
    End Function

    Private Function CheckXrayExist() As Integer
        Dim iRetValue As Integer = 0
        If hidPan.Value = "1" Then
            iRetValue = 1
        End If
        If hidStatus.Value = "1" Then
            iRetValue = iRetValue Or 2
        End If
        If hidFace.Value = "1" Then
            iRetValue = iRetValue Or 4
        End If
        Return iRetValue
    End Function

    Private Function CheckXrayAttach() As Boolean
        Dim bRetValue As Boolean = False
        bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType1"), fileToUpload1, txtExistAttNo1, txtExistRecNo1)
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType2"), fileToUpload2, txtExistAttNo2, txtExistRecNo2)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType3"), fileToUpload3, txtExistAttNo3, txtExistRecNo3)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType4"), fileToUpload4, txtExistAttNo4, txtExistRecNo4)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType5"), fileToUpload5, txtExistAttNo5, txtExistRecNo5)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType6"), fileToUpload6, txtExistAttNo6, txtExistRecNo6)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType7"), fileToUpload7, txtExistAttNo7, txtExistRecNo7)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType8"), fileToUpload8, txtExistAttNo8, txtExistRecNo8)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType9"), fileToUpload9, txtExistAttNo9, txtExistRecNo9)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType10"), fileToUpload10, txtExistAttNo10, txtExistRecNo10)
        End If
        Return bRetValue
    End Function

    Private Function CheckXrayAttachOneRow(ByVal strComboSelectedValue As String, ByRef ctlFile As HtmlInputFile, ByRef ctlHidden1 As HtmlInputHidden, ByRef ctlHidden2 As HtmlInputHidden) As Boolean
        Dim bRetValue As Boolean = False
        Dim i As Integer = CInt(strComboSelectedValue)
        If i > 0 Then
            If (IsNumeric(ctlHidden1.Value) And IsNumeric(ctlHidden2.Value)) Then
                Dim iRecordNo As Integer = CInt(ctlHidden2.Value)
                If iRecordNo > 0 Then
                    bRetValue = True
                End If
            ElseIf Not ctlFile.PostedFile Is Nothing AndAlso Trim(ctlFile.PostedFile.FileName) <> "" Then
                bRetValue = True
            End If
        End If
        Return bRetValue
    End Function

    Private Function ProcessRow(ByVal strReferenceID As String, ByVal strComboSelectedValue As String, ByRef objTreatmentService As TreatmentConnect.TreatmentService, ByRef ctlFile As HtmlInputFile, ByRef ctlHidden1 As HtmlInputHidden, ByRef ctlHidden2 As HtmlInputHidden, ByRef iExtError As Integer) As Integer
        Dim iPhotoType As Integer = CInt(strComboSelectedValue)
        Dim iRetValue As Integer = 0
        iExtError = 0
        If Not ctlFile.PostedFile Is Nothing AndAlso Trim(ctlFile.PostedFile.FileName) <> "" Then
            Dim ioReader As New BinaryReader(ctlFile.PostedFile.InputStream)
            ioReader.BaseStream.Seek(0, SeekOrigin.Begin)
            Dim arrFileContent(ioReader.BaseStream.Length - 1) As Byte
            ioReader.Read(arrFileContent, 0, ioReader.BaseStream.Length)
            If CheckFileHeader(arrFileContent) > 0 Then
                Dim strFileName As String = ctlFile.PostedFile.FileName
                Dim iPt As Integer = InStrRev(strFileName, "\")
                If iPt > 0 Then
                    strFileName = Mid(strFileName, iPt + 1)
                End If
                If objTreatmentService.ArchiveAttachment("C7F043B7-8717-430D-A7B6-8A2EBDE30741", strReferenceID, iPhotoType, strFileName, arrFileContent) Then
                    iRetValue = 1
                End If
            Else
                iExtError = 1
            End If
        ElseIf (Trim(ctlHidden1.Value) <> "" And Trim(ctlHidden2.Value) <> "") Then
            Dim iRecordNo As Integer = CInt(ctlHidden2.Value)
            Dim iAttachNo As Integer = CInt(ctlHidden1.Value)
            If iRecordNo = 0 Then
                iRetValue = 1
            Else
                If objTreatmentService.CopyAttachment("DCAB5DEB-D32B-4B1B-9156-2A47D9ADAC96", iRecordNo, iAttachNo, strReferenceID) Then
                    iRetValue = 1
                End If
            End If
        Else
            iRetValue = 2
        End If
        Return iRetValue
    End Function
End Class
