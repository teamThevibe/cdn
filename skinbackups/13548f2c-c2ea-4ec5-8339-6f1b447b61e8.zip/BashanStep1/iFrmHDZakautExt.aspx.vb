﻿Imports System.IO
Imports System.Text.RegularExpressions

Partial Public Class iFrmHDZakautExt
    Inherits System.Web.UI.Page

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        cmdPrint.Disabled = True

        If Not Session("InsuredIDNotFound") Is Nothing Then
            HidErrorFromParent.Value = "11"
        Else
            HidErrorFromParent.Value = ""
        End If



        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

        If IsNothing(Session("Login_User")) OrElse Len(Session("Login_User")) = 0 Then
            hidSessionExpired.Value = "1"
            Return
        End If

        If Session("User_Login_First_Time") = "1" Then
            Response.Redirect("frmUserProp.aspx")
        End If

        Dim iCompany As Integer = 1
        'Try
        If Not Application("CompanyID") Is Nothing Then
            If Not Application("CompanyID") = "" Then
                iCompany = CInt(Application("CompanyID").ToString())
            End If
        End If



        txtCompany.Value = iCompany.ToString

        hidHaveZakaut.Value = ""

        If Not IsPostBack Then

            If Not Session("HDInsuredID") Is Nothing Then
                If Session("HDInsuredID").ToString <> "" Then

                    If Not Session("HidReloadPageFromParent") Is Nothing Then
                        If Session("HidReloadPageFromParent") = "1" Then
                        Else
                            txtInsuredID.Value = Session("HDInsuredID").ToString
                        End If
                    Else
                        txtInsuredID.Value = Session("HDInsuredID").ToString
                    End If

                End If

            End If

            If Not Session("HDSHEM") Is Nothing Then
                If Session("HDSHEM").ToString <> "" Then

                    If Not Session("HidReloadPageFromParent") Is Nothing Then
                        If Session("HidReloadPageFromParent") = "1" Then
                        Else
                            txtInsuredName.Value = Session("HDSHEM").ToString
                        End If
                    Else
                        txtInsuredName.Value = Session("HDSHEM").ToString
                    End If





                End If
            End If

            If Not Session("HDMISP") Is Nothing Then
                If Session("HDMISP").ToString <> "" Then


                    If Not Session("HidReloadPageFromParent") Is Nothing Then
                        If Session("HidReloadPageFromParent") = "1" Then
                        Else
                            txtInsuredFamily.Value = Session("HDMISP").ToString
                        End If
                    Else
                        txtInsuredFamily.Value = Session("HDMISP").ToString
                    End If




                End If
            End If

            If Not Session("HDPolGovTreatment") Is Nothing Then
                If Session("HDPolGovTreatment").ToString <> "" Then


                    If Not Session("HidReloadPageFromParent") Is Nothing Then
                        If Session("HidReloadPageFromParent") = "1" Then
                        Else
                            hidPolGovTreatment.Value = Session("HDPolGovTreatment").ToString
                        End If
                    Else
                        hidPolGovTreatment.Value = Session("HDPolGovTreatment").ToString
                    End If




                End If
            End If

            Session.Remove("HidReloadPageFromParent")





            Dim ds As Data.DataSet
            txtToday.Value = Format(DateTime.Today, "ddMMyyyy")
            FillDefaults()

            Dim objTreatmentService As New TreatmentConnect.TreatmentService()
            objTreatmentService.Url = Application("TreatmentWebService").ToString()

            Dim iDoctorType As Integer = objUser.GetUserDoctorType("C049B33B-243D-43C1-B2F5-AB4859F9EBD1", User.Identity.Name)
            ''''''''''''''''''''Dim iDoctorType As Integer = objUser.GetHDUserDoctorType("0B776BB2-51E1-11E4-8E10-7F911D5D46B0", User.Identity.Name)
           
            If ((iDoctorType = 1) Or (iDoctorType = 2)) Then
                'frmZakautExt.aspx
                ds = objTreatmentService.GetTreatmentTypes("1C39E920-093F-46B2-BEE7-A4D459A3F1CC")
                BindCombo("TreatmentType", "TreatmenTypetID", lstCareGroup, ds)
                lstOccasion.Items.Add(New ListItem("בחר...", 0))
                lstCareGroup.SelectedIndex = 0
                txtSkipCheck.Value = "1"
                FillCareType()  'ds)
            Else
                'frmZakaut.aspx
                BindCareGroupCombo()
                lstOccasion.Visible = False
                tblOccasion.Visible = False
                txtSkipCheck.Value = "0"
                lstCareGroup.SelectedIndex = 1
                FillCareType1()
            End If

            hidHaveGovernmentTreatments.Value = Application("GovernmentTreatments").ToString()
            hidShowOldTreatments.Value = Application("ShowOldTreatments").ToString()

            If Not Session("TRequest_InsuredID") Is Nothing Then
                If Not Session("TRequest_InsuredID").ToString() = "" Then
                    txtInsuredID.Value = Session("TRequest_InsuredID")
                End If
            End If


            If Not Session("TRequest_InsuredName") Is Nothing Then
                If Not Session("TRequest_InsuredName").ToString() = "" Then
                    txtInsuredName.Value = Session("TRequest_InsuredName")
                End If
            End If

            If Not Session("TRequest_InsuredFamily") Is Nothing Then
                If Not Session("TRequest_InsuredFamily").ToString() = "" Then
                    txtInsuredFamily.Value = Session("TRequest_InsuredFamily")
                End If
            End If



            txtMessage.Visible = False
            txtAppType.Value = Application("App_Type").ToString


            hidDisabledForm.Value = ""
        End If
    End Sub

    Private Sub BindCareGroupCombo()
        lstCareGroup.Items.Add(New ListItem("בחר...", 0))
        lstCareGroup.Items.Add(New ListItem("צילומים", 1))
    End Sub

    Private Sub FillDefaults()
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()

        Dim strDoctorCareName As String
        Dim strDoctorCareNumber As String
        Dim strClinicName As String
        Dim strClinicNumber As String
        If objTreatmentService.GetDoctorProperties("7EC6114A-62CD-4DC4-A940-1416BFB136D8", User.Identity.Name, strDoctorCareName, strDoctorCareNumber, strClinicName, strClinicNumber) Then
            '''''''''''''''''''''''''''If objTreatmentService.GetHdDoctorProperties("C4AEB905-6C91-4FC8-93BE-1486B99518E57", User.Identity.Name, strDoctorCareName, strDoctorCareNumber, strClinicName, strClinicNumber) Then

            txtClinicName.Text = CEncode.StringEncode(strClinicName)
            txtClinicNumber.Text = strClinicNumber
        End If

    End Sub

    Private Sub FillCareType() 'ByRef ds As Data.DataSet)
        Dim currRow As DataRow, objItem As ListItem
        lstCareType.Items.Clear()
        objItem = New ListItem("בחר...", 0)
        objItem.Attributes.Add("from", "")
        objItem.Attributes.Add("BashanCode", "0")
        objItem.Attributes.Add("SmileCode", "0")
        objItem.Attributes.Add("EarlyConsultation", "0")

    End Sub

    Private Sub FillCareType1()
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim currRow As DataRow, objItem As ListItem
        Dim ds As Data.DataSet = objTreatmentService.GetTreatmentsWithOrder("10F8CFC2-99E1-4094-AABE-D477C8EA8BB0", 1, 0)
        lstCareType.Items.Clear()
        objItem = New ListItem("בחר...", 0)
        objItem.Attributes.Add("from", "")
        objItem.Attributes.Add("BashanCode", "0")
        objItem.Attributes.Add("SmileCode", "0")
        lstCareType.Items.Add(objItem)
        For Each currRow In ds.Tables(0).Rows
            objItem = New ListItem(Trim(currRow("Treatment").ToString()), currRow("TreatmentID").ToString())
            objItem.Attributes.Add("from", currRow("RangeID").ToString())
            objItem.Attributes.Add("BashanCode", currRow("BashanCode").ToString())
            objItem.Attributes.Add("SmileCode", currRow("SmileTreatmentID").ToString())
            lstCareType.Items.Add(objItem)
        Next
    End Sub

    Private Sub BindCombo(ByVal strTextField As String, ByVal strValueField As String, ByRef cbo As DropDownList, ByRef ds As Data.DataSet)
        Dim currRow As DataRow
        cbo.Items.Add(New ListItem("בחר...", 0))
        For Each currRow In ds.Tables(0).Rows
            cbo.Items.Add(New ListItem(currRow(strTextField).ToString(), currRow(strValueField).ToString()))
        Next
    End Sub

    Private Function checkSurface() As Boolean
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Return objTreatmentService.CheckFillingTreatment("C0CA1528-F264-4131-8C97-18811CC6FD5D", Trim(txtCareType.Value)) > 0
    End Function

    Private Sub cmdSend_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSend.ServerClick
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim strFirstName As String = ""
        Dim strLastName As String = ""
        Dim str2Chars As String
        Dim str2FNChars As String
        Dim strPolicyNo As String = ""
        Dim strEmployeeNo As String = ""
        Dim strEmpCD As String = ""
        Dim strErr As String = ""
        Dim iRetValue As Integer = 1
        objTreatmentService.GetInsuredProp("5E25C46A-EADC-4C27-8A5A-DB8B13E129D3", hidInsuredNo.Value, strFirstName, strLastName, strPolicyNo, strEmployeeNo, strEmpCD)
        If UCase(Trim(strLastName)) = "ERROR" Then
            objTreatmentService.GetSQLInsuredProp("6C865031-52E9-4422-950B-615B8F84600C", hidInsuredNo.Value, strFirstName, strLastName)
        End If
        str2Chars = Left(strLastName, 2)
        str2FNChars = Left(strFirstName, 2)
        If str2Chars = "" Or str2FNChars = "" Then
            strErr = "בחברת הביטוח לא נמצא מבוטח פעיל המתאים לפרטים שהוזנו"
            iRetValue = 0
        Else
            If Regex.IsMatch(Mid(str2Chars, 2, 1), "[א-תa-zA-Z]") Then
                If str2Chars <> Left(hidInsuredFamily.Value, 2) Then
                    strErr = "בחברת הביטוח לא נמצא מבוטח פעיל המתאים לפרטים שהוזנו"
                    iRetValue = 0
                End If
            Else
                If Left(str2Chars, 1) <> Left(hidInsuredFamily.Value, 1) Then
                    strErr = "בחברת הביטוח לא נמצא מבוטח פעיל המתאים לפרטים שהוזנו"
                    iRetValue = 0
                End If
            End If
            If Regex.IsMatch(Mid(str2FNChars, 2, 1), "[א-תa-zA-Z]") Then
                If str2FNChars <> Left(hidInsuredName.Value, 2) Then
                    strErr = "בחברת הביטוח לא נמצא מבוטח פעיל המתאים לפרטים שהוזנו"
                    iRetValue = 0
                End If
            Else
                If Left(str2FNChars, 1) <> Left(hidInsuredName.Value, 1) Then
                    strErr = "בחברת הביטוח לא נמצא מבוטח פעיל המתאים לפרטים שהוזנו"
                    iRetValue = 0
                End If
            End If
        End If
        If iRetValue = 0 Then
            txtAnswer.InnerText = strErr
            Return
        End If
        If txtClinicNumber.Text = "" Then
            txtAnswer.InnerText = "חסר נתונים בשדה מספר מרפאה"
            Return
        End If
        If hidBashanCode.Value = "" Then
            txtAnswer.InnerText = "חסר נתונים בשדה קוד טיפול"
            Return
        End If

        Dim stMsg As String
        Dim stPelet As String
        Dim stRETURN_CODE As String
        Dim stQOD_ISHUR As String
        Dim stSXUM_HISTATFUT As String

        Dim objZakautService As New ZakautConnect.ZakautService()
        objZakautService.Url = Application("ZakautConnectorService").ToString()

        Dim iTooth As Integer, strSurface As String = "", iCause As Integer

        If Not hidTooth.Value Is String.Empty Then
            iTooth = Val(hidTooth.Value)
        End If


        If checkSurface() Then
            strSurface = "M"
        End If
        iCause = Val(hidOccasion.Value)


        ''If txtClinicNumber.Text = "" Or hidInsuredNo.Value = "" Or hidBashanCode.Value = "" Then


        ''txtAnswer.InnerHtml = "הבדיקה נכשלה"
        ''SendOutOfServiceError()

        '' Else
        stPelet = objZakautService.CheckZakautSmile("D441DC59-A094-421F-AB43-C7220ED9E27B", CInt(txtClinicNumber.Text), CInt(hidInsuredNo.Value), CInt(hidBashanCode.Value), User.Identity.Name, hidInsuredFamily.Value, iTooth, strSurface, iCause)

        Dim strMsg As String

        Dim objZakaut As New BAL.CZakautSmile(stPelet)
        txtAnswer.InnerHtml = objZakaut.MsgHarel
        strMsg = objZakaut.Msg

        If objZakaut.Ishur = "כ" Or (objZakaut.Ishur = "ל" And objZakaut.m_Sibot(0) = 781) Then
            hidHaveZakaut.Value = "1"
        Else
            hidHaveZakaut.Value = "0"
        End If

        cmdSend.Disabled = True

        If strMsg.IndexOf("השירות אינו זמין כעת") > -1 Then
            cmdPrint.Disabled = True
            SendOutOfServiceError()
        Else
            cmdPrint.Disabled = False
            TreatCareFields(True)
        End If

        hidDisabledForm.Value = "1"

        dvTime.InnerHtml = String.Format("הבדיקה בוצעה בתאריך {0} בשעה {1}", _
                                         Today.ToString("dd/MM/yyyy"), Now.ToString("HH:mm"))


        '' End If

    End Sub


    Private Sub cmdUserProp_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUserProp.ServerClick
        Session("User_Prop_Caller") = "frmHDZakautExt.aspx"
        Response.Redirect("frmUserProp.aspx")
    End Sub

    Private Sub cmdNew_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdNew.ServerClick
        txtAnswer.InnerText = ""
        txtCareTypeCombo.Value = ""
        txtOccasionCombo.Value = ""
        txtCareCode.Value = ""
        txtLName.Value = ""
        txtFName.Value = ""
        hidDisabledForm.Value = ""
        cmdPrint.Disabled = True
        TreatCareFields(False)
        cmdSend.Disabled = False
        txtFromTooth.Value = ""
        txtInsuredName.Value = ""
        txtInsuredFamily.Value = ""
    End Sub

    Private Sub SendOutOfServiceError()
        Dim strUrl As String = Application("ErrorReportConnectorService").ToString()

        If strUrl <> "" Then
            Dim strMessage As String = "השירות בדיקת זכאות בש''ן לא פעיל"
            Dim strSubject As String = ""
            If Application("Smile") = "1" Then
                strSubject = "סמייל-" & " "
            ElseIf Application("CompanyID") & "" = "3" Then
                strSubject = "לאומית-" & " "
            ElseIf Application("CompanyID") & "" = "1" Then
                strSubject = "הראל-" & " "
            ElseIf Application("CompanyID") & "" = "0" Then
                strSubject = "דיקלה-" & " "
            End If

            strSubject = strSubject & strMessage

            Dim objErrorReportConnect As New ErrorReportConnect.ErrorReportConnector()
            objErrorReportConnect.Url = strUrl
            Try
                objErrorReportConnect.SendErrorWithSubject("9F8D01F4-6CBF-4852-B5E0-1FD2A3AB7F60", strMessage, strSubject, False)
            Catch ex1 As Exception
                '
            End Try
        End If
    End Sub

    Private Sub TreatCareFields(ByVal isDisabled As Boolean)
        Me.txtCareCode.Disabled = isDisabled
        Me.hidDisabledCare.Value = CInt(isDisabled)
        Me.lstCareType.Enabled = Not isDisabled
    End Sub

    Private Sub cmdCopy_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCopy.ServerClick
        Dim strInsuredID As String = txtInsuredID.Value
        Dim strInsuredName As String = txtInsuredName.Value
        Dim strInsuredFamily As String = txtInsuredFamily.Value
        Dim strLName As String = txtLName.Value
        Dim strFName As String = txtFName.Value

        Dim strPolGovTreatment As String = hidPolGovTreatment.Value

        MyBase.ViewState.Clear()
        If txtSkipCheck.Value = "1" Then
            lstCareGroup.SelectedIndex = 0
            lstOccasion.Items.Clear()
            FillCareType()
            'FillDefaults()
        Else
            lstCareGroup.SelectedIndex = 1
            FillCareType1()
        End If
        txtInsuredID.Value = strInsuredID
        txtInsuredName.Value = strInsuredName
        txtInsuredFamily.Value = strInsuredFamily
        txtLName.Value = strLName
        txtFName.Value = strFName
        txtAnswer.InnerText = ""
        txtCareTypeCombo.Value = ""
        txtOccasionCombo.Value = ""
        txtCareCode.Value = ""
        txtFromTooth.Value = ""
        hidBashanCode.Value = ""
        hidDisabledForm.Value = ""
        hidDisabledCare.Value = "-2"
        TreatCareFields(False)

        hidPolGovTreatment.Value = strPolGovTreatment
        cmdSend.Disabled = False

    End Sub










End Class