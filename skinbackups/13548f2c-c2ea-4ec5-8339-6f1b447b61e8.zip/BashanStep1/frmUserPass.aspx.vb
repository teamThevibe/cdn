Imports System.Text.RegularExpressions

Public Class frmUserPass
    Inherits System.Web.UI.Page
    Protected WithEvents trAllowChangePassword As System.Web.UI.HtmlControls.HtmlTableRow

    Protected WithEvents aIconLink As System.Web.UI.HtmlControls.HtmlAnchor
    Protected WithEvents chkPassword As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents txtPassword As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtNewPassword As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents LPass2 As System.Web.UI.WebControls.Literal
    Protected WithEvents LConfirmPass As System.Web.UI.WebControls.Literal
    Protected WithEvents LExtraQuestion As System.Web.UI.WebControls.Literal
    Protected WithEvents LExtraAnswer As System.Web.UI.WebControls.Literal
    Protected WithEvents txtConfirmPassword As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents trEmail As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents trPassword As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents txtNewEMail As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents Tr1 As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents Tr2 As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents Tr3 As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents trExtraQuestion As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents txtQuestion As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents trExtraAnswer As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents ExtraIdAnswer As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents cmdHelp As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdReturn As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdCancel As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdOK As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents divPasswordError As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents txtError As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtUserType As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtErrorType As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtErrorEMail As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExpired As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAppType As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtFormIdentity As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents divRIcon As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents aIconLink2 As System.Web.UI.HtmlControls.HtmlAnchor
    Protected WithEvents cmdBack As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents txtUserName As System.Web.UI.HtmlControls.HtmlInputText

#If NewDesign Then
    Protected WithEvents tdRightPic As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents imgRightPic As System.Web.UI.HtmlControls.HtmlImage
    Protected WithEvents imgLeftPic As System.Web.UI.HtmlControls.HtmlImage
    Protected WithEvents txtHasCB As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents divUserName As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents chkExtra As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents trchkExtra As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents imgPwdToolTip As System.Web.UI.HtmlControls.HtmlImage
    Protected WithEvents QuestionMark1 As System.Web.UI.HtmlControls.HtmlAnchor
    Protected WithEvents divPromtTitle As System.Web.UI.HtmlControls.HtmlGenericControl
#If Not EngDesign Then
    Protected WithEvents hidNoFailCurrentPasswordLocal As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidNoFailCurrentPasswordGeneral As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents trMobile As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents txtMobile As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents hidClaimApp As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents HidLoginFromEmail As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents trAnswerWord As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents txtAnswerWord As Global.System.Web.UI.HtmlControls.HtmlInputPassword
#End If
#Else
    Protected WithEvents lblMessage As System.Web.UI.WebControls.Label
#End If

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Class Messages
#If EngDesign Then ' YT:
        Public Const YouMustChangePassword As String = "You must change password"
        Public Const MissingPassword As String = "Missing Password"
        Public Const IncorrectPassword As String = "Incorrect password"
        Public Const PasswordConfirmationNotIdentical As String = "Password confirmation not identical to the new password."
        Public Const PasswordMustBeDifferent As String = "Password must be different from the user name."
        Public Const TheNewPasswordMustBeDifferent As String = "The new password must be different from the old."
        Public Const PasswordLengthMustBeBetween As String = "Password length must be between 6 and 10 signs"
        Public Const UseOnlyLettersAndNumbers As String = "Use only letters and numbers"
        Public Const DoNotRepeatLetterOrNumber As String = "Do not repeat letter or number more then twice."
        Public Const YouAlreadyUsedThisPassword As String = "You already used this Password"
        Public Const LoginQuestionMissing As String = "Login question missing"
        Public Const LoginResponseMissing As String = "Login Response missing"
        Public Const InvalidLoginDetail As String = "Invalid login detail. Please type letters and digits only"
        Public Const InvalidEMailAddress As String = "Invalid eMail address"
        Public Const DataUpdatedSuccessfully As String = "Data Updated Successfully"
        Public Const WrongUserName As String = "Wrong User Name"
        Public Const MissingUserName As String = "Missing User Name"
        Public Const UserIdentificationFailed As String = "User identification failed"
        Public Const MissingNewPassword As String = "Missing New Password"
#Else
        Public Const YouMustChangePassword As String = "�� ����� �����"
        Public Const MissingPassword As String = "���� �����"
        Public Const IncorrectPassword As String = "������ ������� �����"
        Public Const PasswordConfirmationNotIdentical As String = "����� ����� �� ��� ������ �����"
        Public Const PasswordMustBeDifferent As String = "���� ������� ���� ��� ��� ������"
        Public Const TheNewPasswordMustBeDifferent As String = "���� ������� ����� ���� ��� ������ �������"
        Public Const PasswordLengthMustBeBetween As String = "���� ������ ���� ����� ��� 6 � 10 �����"
        Public Const UseOnlyLettersAndNumbers As String = "�� ������ ������� ������� ����"
        Public Const DoNotRepeatLetterOrNumber As String = "��� ����� �� ���� ���� �� ����� ���� �������"
        Public Const YouAlreadyUsedThisPassword As String = "������ ����� ���� ��� ������"
        Public Const LoginQuestionMissing As String = "���� ���� �����"
        Public Const LoginResponseMissing As String = "���� ����� �����"
        Public Const InvalidLoginDetail As String = "��� ����� ���� �� ���� - ���� ������ �� ������ �������"
        Public Const InvalidEMailAddress As String = "����� ����''� �� �����"
        Public Const DataUpdatedSuccessfully As String = "������� ������ ������"
        Public Const WrongUserName As String = "�� ����� ����"
        Public Const MissingUserName As String = "�� ����� ���"
        Public Const UserIdentificationFailed As String = "����� ����� ����"
        Public Const MissingNewPassword As String = "���� ����� ����"
#End If
    End Class

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not IsPostBack Then
            aIconLink.HRef = Application("ClientSiteLink")
            Dim objUser As New UserConnect.UserService()
            objUser.Url = Application("UserWebService").ToString()

#If NewDesign And Not EngDesign Then


            If Application("HasCB") = "1" Then
                txtHasCB.Value = "1"
            Else
                txtHasCB.Value = "0"
            End If
            'michal
            ' Dim iEmailExists As Integer = objUser.CheckIsEMailExists("AD6A52B0-928A-4C54-9535-7DC878BBD35E", User.Identity.Name)
            'If iEmailExists = 0 Then
            'txtErrorEMail.Value = " ��� �� ����� ����.���� ����� �� ����� ����� ����� ������"
            'End If

            Dim sMailMobileExist As String = objUser.CheckIsEMailAndMobileExist("1E65EA6F-23E3-4EE6-ACEB-8CA20F658CC5", User.Identity.Name)
            Select Case (sMailMobileExist)
                Case "00"
                    txtErrorEMail.Value = "�����  ������ �� ����� ����""�  ����� �����" + vbNewLine + "�����  ������ �� ������ �����  ����� �����"
                Case "01"
                    txtErrorEMail.Value = "�����  ������ �� ������ �����  ����� �����"
                Case "10"
                    txtErrorEMail.Value = "�����  ������ �� ������ �����  ����� �����"
                Case "11"
                    txtErrorEMail.Value = ""
            End Select
            If Application("IsPool") & "" = "1" Then
                hidClaimApp.Value = "2"
            End If
#End If

#If NewDesign Then
            If Application("HasHani").ToString() = "1" Then
                cmdBack.Visible = False
            End If
#End If

#If NewDesign Then
            If Application("HasHani").ToString() = "1" Then
                imgLeftPic.Src = "pics/" & objUser.GetLogoName("17060B94-065E-4DB4-975D-A3988FFD63CC", User.Identity.Name)
            End If
#End If

            If Application("RightLogo") = "1" Then
#If NewDesign Then
                tdRightPic.Attributes("background") = "pics/BannerTopRightTransp.gif"
                imgRightPic.Attributes("src") = "pics/BannerTopRightTransp.gif"
#End If
                divRIcon.Visible = True
            Else
#If NewDesign Then
                tdRightPic.Attributes("background") = "pics/BannerTopRightPic.gif"
                imgRightPic.Attributes("src") = "pics/BannerTopRightPic.gif"
#End If
                divRIcon.Visible = False
            End If
#If Not NewDesign Then
            divRIcon.Visible = False
#End If


            Dim strUserName As String = User.Identity.Name
            Dim strUserType As String
            Dim strFName As String
            Dim strLName As String
            Dim strStreet As String
            Dim strHouse As String
            Dim strCity As String
            Dim strZIP As String
            Dim strPhone As String
            Dim strMobile As String
            Dim strFax As String
            Dim strEMail As String
            Dim strCFName As String
            Dim strCLName As String
            Dim strCStreet As String
            Dim strCHouse As String
            Dim strCCity As String
            Dim strCZIP As String
            Dim strCPhone As String
            Dim strCMobile As String
            Dim strCFax As String
            Dim strCEMail As String
            Dim strBank As String
            Dim strBranch As String
            Dim strAccount As String
            Dim strMailStreet As String
            Dim strMailPhone As String
            Dim strMailHouse As String
            Dim strMailEMail As String
            Dim strMailCity As String
            Dim strMailZIP As String
            Dim strService1 As String
            Dim strService2 As String
            Dim strService3 As String
            Dim strService4 As String
            Dim strService5 As String
            Dim strService6 As String
            Dim strProf1 As String
            Dim strProf2 As String
            Dim strProf3 As String
            Dim strProf4 As String
            Dim strProf5 As String
            Dim strClinicID As String
            Dim strClinicName As String
            Dim strDoctorID As String
            Dim strSupplierID As String
            Dim strSection As String
            Dim strCare As String
            Dim strGridRowCount As String

            Dim ExtraIdQuestionFromTable As String = ""
            Dim ExtraIdAnswerFromTable As String = ""

            '            If Application("AllowExtraID") = "1" Then
            '                objUser.GetExtraId("204A61C3-ACD7-4719-88B8-1B13313E9844", strUserName, ExtraIdQuestionFromTable, ExtraIdAnswerFromTable)
            '#If NewDesign Then
            '                trchkExtra.Visible = True
            '                txtQuestion.Disabled = False
            '                If Len(ExtraIdAnswerFromTable) = 0 Then
            '                    chkExtra.Checked = True
            '                    txtQuestion.Attributes("class") = "InputStyle"
            '                    ExtraIdAnswer.Attributes("class") = "InputStyle"
            '                    If Session("User_Login_First_Time") = "1" Then
            '                        chkExtra.Disabled = True
            '                    End If
            '                Else
            '                    chkExtra.Checked = False
            '                    txtQuestion.Attributes("class") = "InputDis"
            '                    ExtraIdAnswer.Attributes("class") = "InputDis"
            '                End If
            '            Else
            '                trchkExtra.Style.Add("display", "none")
            '                txtQuestion.Style.Add("display", "none")
            '                trExtraAnswer.Style.Add("display", "none")
            '#End If
            '            End If

            objUser.GetProperties("305A57FB-F38A-4592-AA8E-882D66B1DEFC", strUserName, strUserType, strFName, strLName, strStreet, strHouse, strCity, strZIP, strPhone, strMobile, strFax, strEMail, _
                                  strCFName, strCLName, strCStreet, strCHouse, strCCity, strCZIP, strCPhone, strCMobile, strCFax, strCEMail, _
                                  strBank, strBranch, strAccount, strMailStreet, strMailPhone, strMailHouse, strMailEMail, strMailCity, strMailZIP, _
                                  strService1, strService2, strService3, strService4, strService5, strService6, strProf1, strProf2, strProf3, strProf4, _
                                  strProf5, strClinicID, strClinicName, strDoctorID, strSupplierID, strSection, strCare, strGridRowCount, "", "")

            Select Case Application("App_Type").ToString.ToUpper()
                Case "DIST"
                    If Session("AS400_User") = "1" Then
                        txtUserType.Value = "4"
                    Else
                        txtUserType.Value = "3"
                    End If
                    If Session("Allow_Action_Type_Upload") = "1" Then
                        cmdReturn.Visible = True
                    Else
                        cmdReturn.Visible = False
                    End If
                Case "DIVUR"
                    cmdHelp.Disabled = False
                    txtUserType.Value = strUserType
                Case "CLAIM", "ENG"
                    cmdHelp.Disabled = False
                    txtUserType.Value = strUserType
                    ' Yug 31.12.09 trEmail.Visible = False
                    ' Yug 31.120.09 trMobile.Visible = False
                    If Session("Allow_Action_Type_Upload") = "1" Then
                        cmdReturn.Visible = True
                    Else
                        If Not cmdBack Is Nothing Then
                            cmdBack.Visible = False
                        End If
                        cmdReturn.Visible = False
                    End If
                Case "DOAR"
                    cmdHelp.Disabled = False
                    txtUserType.Value = "30"
                    cmdReturn.Value = "�����"
                    cmdReturn.Attributes("onclick") = "window.close();return;"
                Case "SUPP"
                    cmdOK.Attributes.Remove("onclick")
                    cmdHelp.Disabled = False
                    txtUserType.Value = "40"
            End Select
            txtAppType.Value = Application("App_Type").ToString
#If NewDesign Then
            divUserName.InnerText = Trim(strFName & " " & strLName)
#End If
            Dim bShowExtra As Boolean = (Application("AllowExtraID") = "1")
            If Application("App_Type").ToString.ToUpper() = "SUPP" Then
                bShowExtra = True
            End If

            If bShowExtra Then
                trExtraQuestion.Visible = True
                trExtraAnswer.Visible = True
#If Not EngDesign Then
                Tr3.Visible = True
#End If
                objUser.GetExtraId("204A61C3-ACD7-4719-88B8-1B13313E9844", strUserName, ExtraIdQuestionFromTable, ExtraIdAnswerFromTable)
                If Len(ExtraIdAnswerFromTable) = 0 Then
#If NewDesign Then
                    chkExtra.Checked = True
#End If
                    txtQuestion.Attributes("class") = "InputStyle"
                    ExtraIdAnswer.Attributes("class") = "InputStyle"
                    If Session("User_Login_First_Time") = "1" Then
#If NewDesign Then
                        chkExtra.Disabled = True
#End If
                    End If
                Else
#If NewDesign Then
                    chkExtra.Checked = False
#End If
                    txtQuestion.Attributes("class") = "InputDis"
                    ExtraIdAnswer.Attributes("class") = "InputDis"
                End If






            Else
#If NewDesign Then
                trchkExtra.Style.Add("display", "none")
#End If
                trExtraQuestion.Style.Add("display", "none")
                trExtraAnswer.Style.Add("display", "none")
#If Not EngDesign Then
                Tr3.Style.Add("display", "none")
#End If
            End If
            '#End If
            chkPassword.Disabled = True
#If Not NewDesign Then
            lblMessage.Text = Session("Message_Text")
#End If
            If Session("User_Login_First_Time") = "1" Then

                txtError.Value = Messages.YouMustChangePassword
#If NewDesign And Not EngDesign Then
                If Not Session("PassLoginFromEmail") Is Nothing Then
                    trPassword.Visible = False
                    trAnswerWord.Visible = bShowExtra ' true if allowed
                End If
#End If
                txtExpired.Value = "1"
                txtNewEMail.Value = Trim(strEMail)
#If NewDesign And Not EngDesign Then
                txtMobile.Value = strMobile.Trim()
#End If

#If NewDesign And Not EngDesign Then
                Dim bRet As Boolean = objUser.GetUserAllowChangePassword("32B79620-E74B-11DF-9492-0800200C9A66", _
                                                                         User.Identity.Name)

                setAllowChangePassword(bRet)

                chkPassword.Disabled = True ' User_Login_First_Time - have to change password


                If (bRet) Then


                    Dim iNoFailCurrentPasswordLocal As Integer

                    Dim iNoFailCurrentPasswordGeneral As _
                    Integer = objUser.GetNoFailCurrentPassword("7496C790-E751-11DF-9492-0800200C9A66")

                    hidNoFailCurrentPasswordGeneral.Value = iNoFailCurrentPasswordGeneral

                End If
#End If

            Else
                trEmail.Visible = False
#If NewDesign And Not EngDesign Then
                trMobile.Visible = False
#End If
                txtExpired.Value = ""
            End If

#If NewDesign Then
            Dim sInstr As String = ""
#If EngDesign Then
            sInstr = objUser.GetPassInstructionExt("B8CD9DE5-95C1-466d-AC29-E8170E3BCA2E", 1)
#Else
            sInstr = objUser.GetPassInstruction("B8CD9DE5-95C1-466d-AC29-E8170E3BCA2E")
#End If

            divPromtTitle.InnerHtml = sInstr
            'imgPwdToolTip.Style("display") = "inline"
            QuestionMark1.Style.Add("display", "block")
#End If

        Else

            divPasswordError.Visible = False
        End If

#If NewDesign And Not EngDesign Then
        If HidLoginFromEmail.Value = "1" Then
            cmdBack.Visible = False
            cmdReturn.Visible = False
            cmdCancel.Visible = False
            cmdOK.Visible = True
            cmdOK.Value = "����"
            HidLoginFromEmail.Value = "1"
        End If
        If Not Request.QueryString("LoginFromEmail") Is Nothing Then
            Dim bLoginFromEmail As Boolean = CType(Request.QueryString("LoginFromEmail"), Boolean)
            If bLoginFromEmail Then
                cmdBack.Visible = False
                cmdReturn.Visible = False
                cmdCancel.Visible = False
                cmdOK.Visible = True
                cmdOK.Value = "����"
                HidLoginFromEmail.Value = "1"
            End If
        End If


#End If

    End Sub





    Private Sub Page_PreRender(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.PreRender

        If Not IsPostBack Then
            ' Cancel using Mobile & Email (always)
            trEmail.Visible = False
#If NewDesign And Not EngDesign Then
            Tr2.Visible = False
            trMobile.Visible = False
            txtErrorEMail.Value = ""
#End If


#If NewDesign Then
            ' Cancel using Answer & Question (exclude ����� ��� � ����� ������)
            If chkExtra.Checked Then ' Display
#If NOT EngDesign THEN
                Tr3.Visible = True
#End If
                trchkExtra.Visible = True
                trExtraQuestion.Visible = True
                trExtraAnswer.Visible = True
            Else
#If NOT EngDesign THEN
                Tr3.Visible = False
#End If
                trchkExtra.Visible = False
                trExtraQuestion.Visible = False
                trExtraAnswer.Visible = False
            End If
#End If

        End If

        LPass2.Visible = (chkPassword.Disabled And chkPassword.Checked)
        LConfirmPass.Visible = (chkPassword.Disabled And chkPassword.Checked)

#If NewDesign Then
        LExtraQuestion.Visible = (chkExtra.Disabled And chkExtra.Checked)
        LExtraAnswer.Visible = (chkExtra.Disabled And chkExtra.Checked)
#End If
    End Sub


    Private Sub cmdOK_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdOK.ServerClick

        Dim strUserName As String = User.Identity.Name
        Dim strPassword As String
        Dim emailvalue As String

        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

        If chkPassword.Disabled Then
            chkPassword.Checked = True
        End If

        If Trim(txtUserName.Value) = "" Then
            ShowError(Messages.MissingUserName)

            '''''''''''''''''''''''''''''setNoFailCurrentPassword()

            Return
        End If

        If strUserName.ToLower() <> Trim(txtUserName.Value.ToLower()) Then
            ShowError(Messages.UserIdentificationFailed) '(Messages.WrongUserName)

            '''''''''''''''''''''''''''''''setNoFailCurrentPassword()

            Return

        End If

        strPassword = Trim(txtPassword.Value)
        If (Not trPassword.Visible) And (Not Session("PassLoginFromEmail") Is Nothing) Then
            strPassword = Session("PassLoginFromEmail").ToString
        End If

        If Len(strPassword) = 0 Then
            ShowError(Messages.MissingPassword)

            setNoFailCurrentPassword()

            Return
        End If

        Dim iResult As Integer = objUser.CheckUser("79D565C1-784C-4606-935B-68BA32141600", strUserName, strPassword, "0", -1, Request.UserHostAddress, User.Identity.Name)
        If iResult <> 0 And iResult <> 10 Then
            ShowError(Messages.UserIdentificationFailed)

            setNoFailCurrentPassword()

            Return
        End If

#If NewDesign And Not EngDesign Then
        ' forgotten password. identification answer needed
        If (trAnswerWord.Visible) And (Not Session("PassLoginFromEmail") Is Nothing) Then
            Dim ExtraIdQuestionFromTable As String = ""
            Dim ExtraIdAnswerFromTable As String = ""
            objUser.GetExtraId("204A61C3-ACD7-4719-88B8-1B13313E9844", strUserName, ExtraIdQuestionFromTable, ExtraIdAnswerFromTable)
            If Not (ExtraIdAnswerFromTable = txtAnswerWord.Value) Then
                ShowError(Messages.UserIdentificationFailed)

                '''''''''''''''''''''''''''''''''''''''setNoFailCurrentPassword()

                Return
            End If
        End If
#End If

        If chkPassword.Checked = True Then

            strPassword = Trim(txtNewPassword.Value)
            If strPassword.Length < 1 Then
                ShowError(Messages.MissingNewPassword)

                '''''''''''''''''''''''''''''setNoFailCurrentPassword()

                Return
            End If
            'Dim iOrganizationCode As Integer = Val(Session("Karnit_OrganisationCode") & "")
            'Dim sAgreementCode As String = Session("Karnit_AgreementCode") & ""
            If Trim(txtNewPassword.Value) <> Trim(txtConfirmPassword.Value) Then
                ShowError(Messages.PasswordConfirmationNotIdentical)

                ''''''''''''''''''''''''''''setNoFailCurrentPassword()

                Return
            End If
            If LCase(Trim(txtNewPassword.Value)) = LCase(Trim(strUserName)) Then
                ShowError(Messages.PasswordMustBeDifferent)

                ''''''''''''''''''''''''''''''''''setNoFailCurrentPassword()

                Return
            End If
            If Trim(txtPassword.Value) = strPassword Then
                ShowError(Messages.TheNewPasswordMustBeDifferent)

                ''''''''''''''''''''''''''''''''''setNoFailCurrentPassword()

                Return
            End If

            If (CBool(Application("PasswordVerification"))) Then
                Dim strRegEx As String = Application("PasswordRegEx").ToString() & ""
                Dim nCheck As Integer = objUser.CheckNewPasswordEx("2DDEF6A6-4053-491A-8642-CF441B81BA46", strPassword, strRegEx)
                If nCheck > 0 Then
#If EngDesign Then
                    divPasswordError.InnerHtml="<ul dir=rtl >" & _
                                               "<li>"  & _
                                                "<div align=right><span class=884111608-11102007><font face=Arial size=2 color=Red>�� ������ ����� ����� �� 8 ����� �����</font></span></div>" & _
                                                "<li>" & _
                                                "<div align=right><span class=884111608-11102007><font face=Arial size=2 color=Red>�� ������ ����� ������ ������� ������</font></span></div>" & _
                                                "<li>" & _
                                                "<div align=right><span class=884111608-11102007><font face=Arial size=2 color=Red>�� ������ ������� ���� ���� ��� ������</font></span></div></li></ul>" 
#Else
                    divPasswordError.InnerHtml = objUser.GetPassInstruction("B8CD9DE5-95C1-466d-AC29-E8170E3BCA2E")
#End If
                    txtErrorType.Value = "2"
                    divPasswordError.Visible = True

                    ''''''''''''''''''''''''''''''setNoFailCurrentPassword()

                    Return
                End If
            Else
                Select Case objUser.CheckNewPassword("2A8A46F2-A060-4FD9-B74E-3784FEC1C0EF", strPassword)
                    Case 1
                        'too short or too long
                        ShowError(Messages.PasswordLengthMustBeBetween)

                        ''''''''''''''''''''''''''''''''''''''setNoFailCurrentPassword()

                        Return
                    Case 2
                        'invalid char
                        ShowError(Messages.UseOnlyLettersAndNumbers)

                        ''''''''''''''''''''''''''''''''setNoFailCurrentPassword()

                        Return
                    Case 3
                        'one char
                        ShowError(Messages.DoNotRepeatLetterOrNumber)

                        ''''''''''''''''''''''''''''''''setNoFailCurrentPassword()

                        Return
                End Select
            End If

            If objUser.CheckPasswordHistory("6BC8399D-247C-48E4-8312-7FC05ECA207E", strUserName, strPassword) Then
                'one char
                ShowError(Messages.YouAlreadyUsedThisPassword)

                ''''''''''''''''''''''''''''''''setNoFailCurrentPassword()

                Return
            End If
        End If

        If Application("App_Type").ToString.ToUpper() = "SUPP" Or Application("App_Type").ToString.ToUpper() = "CLAIM" Or Application("App_Type").ToString.ToUpper() = "ENG" Or Application("App_Type").ToString.ToUpper() = "DIVUR" Then
#If NewDesign Then
            If chkExtra.Checked Then
#End If
                If Application("AllowExtraID") = "1" Then
                    If Session("User_Login_First_Time") = "1" Then

                        If Trim(txtQuestion.Value) = "" Then
                            ShowError(Messages.LoginQuestionMissing)

                            ''''''''''''''''''''''''''''''''''setNoFailCurrentPassword()

                            Return
                        End If

                        If Trim(ExtraIdAnswer.Value) = "" Then
                            ShowError(Messages.LoginResponseMissing)

                            '''''''''''''''''''''''''''''''''''''setNoFailCurrentPassword()

                            Return
                        End If

                        If Regex.IsMatch(ExtraIdAnswer.Value, "[^0-9�-�a-zA-Z]") Then
                            ShowError(Messages.InvalidLoginDetail)

                            ''''''''''''''''''''''''''''''setNoFailCurrentPassword()

                            Return
                        End If
                        Dim sTxtQuestion As String = ""
                        If Not txtQuestion.Value Is Nothing And txtQuestion.Value.Length >= 24 Then
                            sTxtQuestion = txtQuestion.Value.Substring(0, 24)
                        Else
                            sTxtQuestion = txtQuestion.Value.ToString
                        End If
                        objUser.UpdateExstraId("7C2895C8-6FFC-4999-B6EF-A5CB7E522EC6", strUserName, sTxtQuestion, ExtraIdAnswer.Value, User.Identity.Name)
                    End If
                End If
#If NewDesign Then
            End If
#End If

            If Session("User_Login_First_Time") = "1" Then


#If Not NewDesign Then

                '/---------------ilia---------------
                Dim sRegExpr As String
                emailvalue = txtNewEMail.Value
                If (emailvalue.Trim().Length() > 0) Then
                    sRegExpr = objUser.GetEmailValidation("E600F1B9-D4C7-4FC4-B1B6-922F3967456E")
                    If Not Regex.IsMatch(emailvalue, sRegExpr) Then
                        '/If Not objUser.GetEmailValidation("E600F1B9-D4C7-4FC4-B1B6-922F3967456E") Then
                        ShowError(Messages.InvalidEMailAddress)
                        Return
                    End If

                End If
                '/------------------------------


                objUser.UpdateUserEMail("9848A9BA-DCE8-467C-9F80-5C17864F3FC3", strUserName, Trim(txtNewEMail.Value))



#End If

#If NewDesign And Not EngDesign Then
                objUser.UpdateUserMobile("7D8EA3F5-9D28-4EC5-9928-5127EB4C89EC", strUserName, txtMobile.Value.Trim())
#End If
            End If

            If objUser.UpdatePassword("5561A874-D4D7-4E5C-AA3D-4EC0EBAA8B7F", strUserName, strPassword, 1, User.Identity.Name) Then
                If Session("User_Login_First_Time") = "1" Then
                    Session("User_Login_First_Time") = ""
                    Select Case Application("App_Type").ToString().ToUpper()
                        Case "INPOST"
                            Session("User_Prop_Caller") = "frmPostEntry.aspx"
                        Case "SUPP"
                            Session("User_Prop_Caller") = Application("FORMClaimMenu").ToString
                            Session("User_Password") = strPassword
                        Case "DIVUR"
                            Session("User_Prop_Caller") = "frmStart.aspx"
                        Case Else
                            'Session("User_Prop_Caller") = "frmRepStat.aspx" YT:
                            If Session("Allow_Action_Type_Upload") = "1" Or Session("Allow_Download_Files") = "1" Or Session("Allow_ForeignWorkers_Claims") = "1" Then
                                Session("User_Prop_Caller") = "frmStart.aspx"
                            Else
                                Session("User_Prop_Caller") = Application("FORMRepStat")
                            End If
                    End Select

#If NewDesign And Not EngDesign Then
                    If Me.HidLoginFromEmail.Value = "1" Then
                        cmdBack_ServerClick(Nothing, Nothing)
                    End If
#End If
                End If

                chkPassword.Disabled = False
                chkPassword.Checked = False
                txtError.Value = Messages.DataUpdatedSuccessfully
                trPassword.Visible = True
                txtErrorType.Value = ""
                txtExpired.Value = ""
                'DS 17/11/2010 after we receive  the  DataUpdatedSuccessfully message we need to return to the menu
                'Select Case Application("App_Type").ToString().ToUpper()
                '    Case "KUPA_INFO"
                '        Response.Redirect("KupaInfoMenu.aspx")
                '    Case "SUPP"
                '        Response.  Redirect("ClaimMenu.   aspx")
                '    Case Else
                '        Response.Redirect("frmStart.aspx")
                'End Select
				Response.Redirect((New Utils).GetLinkForNextForm(Session("User_Prop_Caller")))
            Else

                ''''''''''''''''''''''''''''setNoFailCurrentPassword()

                txtError.Value = "Error!"
            End If

        End If
    End Sub

    Private Sub ShowError(ByVal strMessage As String)
        txtError.Value = strMessage
        txtErrorType.Value = "1"
    End Sub

    Private Sub cmdCancel_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.ServerClick
        If Session("User_Prop_Caller") <> "" Then
            'Response.Redirect(Session("User_Prop_Caller"))
            Response.Redirect((New Utils).GetLinkForNextForm(Session("User_Prop_Caller")))
        End If
    End Sub

    Private Sub cmdReturn_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.ServerClick
        Select Case Application("App_Type").ToString().ToUpper()
            Case "KUPA_INFO"
                Response.Redirect("KupaInfoMenu.aspx")
            Case "SUPP"                
                Response.Redirect(Application("FORMClaimMenu").ToString)
            Case Else
                Response.Redirect("frmStart.aspx")
        End Select
    End Sub

#If NewDesign Then
    Private Sub cmdBack_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdBack.ServerClick
        If Application("HasCB") = "1" Then
            'Response.Redirect("frmCBMenu.aspx")
            Response.Redirect((New Utils).GetLinkForNextForm("frmCBMenu.aspx"))

        ElseIf Application("App_Type").ToString.ToUpper() = "ENG" Then
            cmdBack.Attributes.Remove("onclick")
            If Session("User_Login_First_Time") = "1" Then
                Response.Redirect(Application("FORMUserPass"))
            Else
                'Response.Redirect(Application("FORMRepStat") & GetLinkForNextForm(Application("FORMRepStat")))
                Response.Redirect((New Utils).GetLinkForNextForm(Application("FORMRepStat")))
            End If

        ElseIf Application("App_Type").ToString().ToUpper() = "CLAIM" Then
            cmdBack.Attributes.Remove("onclick")
            If Session("User_Login_First_Time") = "1" Then
                Response.Redirect(Application("FORMUserPass"))
            Else
                Response.Redirect("frmStart.aspx")
            End If

        ElseIf Application("App_Type").ToString().ToUpper() = "SUPP" Then

            cmdBack.Attributes.Remove("onclick")
            If Session("User_Login_First_Time") = "1" Then

#If Not engDesign Then
                If Me.HidLoginFromEmail.Value = "1" Then
                    Response.Redirect(Application("FORMUserPass") + "?LoginFromEmail=true")
                Else
                    Response.Redirect(Application("FORMUserPass"))
                End If
#Else
                Response.Redirect(Application("FORMUserPass"))
#End If

            End If

            Dim url As String = Application("FORMLogin")

            If Not Session("User_Population_Type") = "0" And Session("User_Population_Type") <> "" Then
                Select Case Session("User_Population_Type")
                    Case "101", "501", "701"
                        url = Application("FORMClaimMenu").ToString
                    Case Else
                        Session("User_Population_Type") = "0"
                        'url = Application("FORMRepStat") & GetLinkForNextForm(Application("FORMRepStat"))
                        Response.Redirect((New Utils).GetLinkForNextForm(Application("FORMRepStat")))
                End Select

            End If
            Response.Redirect(url)

        End If
    End Sub
#End If

    Private Sub setAllowChangePassword(ByVal isAllowChangePassword As Boolean)
        If isAllowChangePassword Then
            txtUserName.Disabled = False
            txtPassword.Disabled = False
            txtNewPassword.Disabled = False
            txtConfirmPassword.Disabled = False
#If NewDesign And Not EngDesign Then
            txtAnswerWord.Disabled = False
#End If
            chkPassword.Checked = True
            chkPassword.Disabled = False
        Else
            trAllowChangePassword.Visible = True
            txtErrorType.Value = ""
            txtExpired.Value = ""
            txtUserName.Disabled = True
            txtPassword.Disabled = True
            txtNewPassword.Disabled = True
            txtConfirmPassword.Disabled = True
#If NewDesign And Not EngDesign Then
            txtAnswerWord.Disabled = True
#End If
            chkPassword.Checked = False
            chkPassword.Disabled = True
        End If
    End Sub

    Private Sub setNoFailCurrentPassword()

#If NewDesign And Not EngDesign Then
        Dim iHidNoFailCurrentPasswordLocal As Integer
        Dim iHidNoFailCurrentPasswordGeneral As Integer
        If hidNoFailCurrentPasswordLocal.Value <> "" Then
            iHidNoFailCurrentPasswordLocal = CInt(hidNoFailCurrentPasswordLocal.Value)
        Else
            iHidNoFailCurrentPasswordLocal = 0
        End If

        iHidNoFailCurrentPasswordLocal = iHidNoFailCurrentPasswordLocal + 1
        hidNoFailCurrentPasswordLocal.Value = iHidNoFailCurrentPasswordLocal


        If hidNoFailCurrentPasswordGeneral.Value <> "" Then
            iHidNoFailCurrentPasswordGeneral = CInt(hidNoFailCurrentPasswordGeneral.Value)
        Else
            iHidNoFailCurrentPasswordGeneral = 0
        End If


        If iHidNoFailCurrentPasswordLocal >= iHidNoFailCurrentPasswordGeneral Then

            Dim objUser As New UserConnect.UserService()
            objUser.Url = Application("UserWebService").ToString()

            setAllowChangePassword(False)

            objUser.UpdateAllowChangePassword("78EA0AF0-E7E7-11DF-9492-0800200C9A66", _
                                              User.Identity.Name, User.Identity.Name, 0)

        End If
#End If

    End Sub
End Class
