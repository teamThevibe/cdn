﻿Partial Public Class frmHDStart
    Inherits System.Web.UI.Page

    Private Class Sorting
        Public Shared Up As String = " ↑"
        Public Shared Down As String = " ↓"
        Public Shared Desc As String = " DESC"
        Public Shared Asc As String = " ASC"
        Public Shared Coma As String = ","
    End Class

    Private Class Status
        Public Shared Approved As String = "אושר"
        Public Shared Denied As String = "נדחה"
        Public Shared Cared As String = "בטיפול"
        Public Shared Paid As String = "שולם"
    End Class
    'Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
    '    'Wire up the event (MoodChanged) to the event handler (MoodChangedFromMasterPage)
    '    AddHandler Master.MoodChanged, AddressOf MoodChangedFromMasterPage
    'End Sub

    Dim iComeFromRepList As Integer

    Public Sub MoodChangedFromMasterPage()



        If iComeFromRepList = 1 Then

            iComeFromRepList = 0
            ShowDetails(False)
            ShowZakaut(True)
            ShowReload(False)
            Return

        End If

        If Not Session("MoodChangedFromMasterPage") Is Nothing Then
            If Session("MoodChangedFromMasterPage") = "1" Then




                If Me.InsuredID.Value = "" Then
                    ShowDetails(False)
                    ShowZakaut(True)
                    ShowReload(False)
                Else

                    If Me.FirstMame.Value = "" Then
                        ShowDetails(False)
                        ShowZakaut(True)
                        ShowReload(False)
                    Else

                        ShowDetails(True)
                        ShowZakaut(False)
                        ShowReload(True)
                        '*********************************
                        ''Next version 180214
                        '**********************************
                        '''''''''''''''''''''''''''Return
                        '*********************************
                    End If

                End If

            End If
        End If

        If IsTikMevutach() Then
            If (Me.InsuredID.Value = "" And Me.LastName.Value = "") Then
                txtError.Value = "17"
            Else

                ShowDetails(True)
                ShowZakaut(False)
                ShowReload(True)

            End If
        End If


        If HidbOldMevhutach.Value <> "" Then


            If Me.InsuredID.Value <> HidbOldMevhutach.Value Then
                ''Session("MoodChangedFromTikMevhutach") = 1
                HidComeMevhutach.Value = "1"
                HidComeMevhutachForHdstart.Value = "1"
                ShowDetails(False)
                ShowZakaut(True)
                ShowReload(False)

            Else
                If hidLiveBdikatZakhut.Value = "1" Then

                    ShowDetails(False)
                    ShowZakaut(True)
                    ShowReload(False)

                End If
            End If
        End If
        hidLiveBdikatZakhut.Value = "0"

    End Sub

    Private Property SortExpression() As String
        Get
            If (IsNothing(ViewState("SortExpression"))) Then
                ViewState("SortExpression") = "ConsultationDate DESC,FTooth ASC,TreatmentID ASC" ' default sorting
            End If
            Return CStr(ViewState("SortExpression"))
        End Get
        Set(ByVal value As String)

            If value = "cn" Then
                ViewState("SortExpression") = "EntryDate DESC,CareFinishDate DESC,FTooth ASC,TreatmentID ASC" ' default sorting
                Return
            End If
            If value = "cl" Then
                ViewState("SortExpression") = "EntryDate DESC,CareFinishDate DESC" ' default sorting
                Return
            End If

            Dim SortExpression As String = ""

            If Not ViewState("SortExpression") Is Nothing Then

                SortExpression = CStr(ViewState("SortExpression"))

            End If


            If SortExpression.IndexOf(value + Sorting.Asc) >= 0 Then
                SortExpression = value + Sorting.Desc + Sorting.Coma + SortExpression.Replace(value + Sorting.Asc, String.Empty)
            ElseIf SortExpression.IndexOf(value + Sorting.Desc) >= 0 Then
                SortExpression = value + Sorting.Asc + Sorting.Coma + SortExpression.Replace(value + Sorting.Desc, String.Empty)
            Else
                SortExpression = value + Sorting.Asc + Sorting.Coma + SortExpression
            End If
            SortExpression = SortExpression.Replace(Sorting.Coma + Sorting.Coma, Sorting.Coma)

            If SortExpression.EndsWith(Sorting.Coma) Then
                SortExpression = SortExpression.Substring(0, SortExpression.Length - 1)
            End If
            If Session("SortExpressionForHdStart") Is Nothing Then
                ViewState("SortExpression") = SortExpression

            Else
                ViewState("SortExpression") = Session("SortExpressionForHdStart")

            End If

        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        If Not Request.QueryString("FromLogin") Is Nothing Then
            dvClinicdata.Visible = False
        End If

        If HidReloadPageFromParent.Value = "1" Then
            Session("HidReloadPageFromParent") = "1"
            HidReloadPageFromParent.Value = "0"
            Session.Remove("HDInsuredID")
            Session.Remove("HDSHEM")
            Session.Remove("HDMISP")
            Session.Remove("HDPolGovTreatment")
            Session.Remove("sSaveDocNameId")
            HidSetMasacRhasi.Value = "2"
            MoodChangedFromMasterPage()
        End If

        If Me.HidSetMasacRhasi.Value = "1" Then
            ShowDetails(False)
            ShowZakaut(True)
            ShowReload(False)
            Me.HidSetMasacRhasi.Value = "1"
        End If

        If Session("User_Login_First_Time") = "1" Then
            Response.Redirect((New Utils).GetLinkForNextForm(Application("FORMUserPass")))
        End If

        If Not IsPostBack Then

            If Not Request.QueryString("SetMasacRhasi") Is Nothing Then
                If Request.QueryString("SetMasacRhasi").ToString = "1" Then
                    iComeFromRepList = 1
                    Me.HidSetMasacRhasi.Value = "1"
                End If
            End If

            If Not Request.QueryString("FromMenu") Is Nothing Then
                If Request.QueryString("FromMenu").ToString = "1" Then
                    Dim sPageActionValue = Session("PageActionValue")
                    If Not Session("PageActionValue") Is Nothing Then
                        If sPageActionValue.Length > 20 Then
                        End If
                    End If
                End If
            End If


            If Not Session("HDInsuredID") Is Nothing Then
                If Session("HDInsuredID").ToString <> "" Then
                    Me.InsuredID.Value = Session("HDInsuredID").ToString
                End If
            End If

            If Not Session("HDSHEM") Is Nothing Then
                If Session("HDSHEM").ToString <> "" Then
                    Me.FirstMame.Value = Session("HDSHEM").ToString
                End If
            End If

            If Not Session("HDMISP") Is Nothing Then
                If Session("HDMISP").ToString <> "" Then
                    Me.LastName.Value = Session("HDMISP").ToString
                End If
            End If

            If Not Session("HDPolGovTreatment") Is Nothing Then
                If Session("HDPolGovTreatment").ToString <> "" Then
                    Me.hidPolGovTreatment.Value = Session("HDPolGovTreatment").ToString
                End If
            End If

            Dim objUser As New UserConnect.UserService()
            objUser.Url = Application("UserWebService").ToString()

            Dim ds As DataSet = objUser.GetUser("784C13D4-4DA2-49FC-9CDD-1BB6B0E869CB", User.Identity.Name)
            ''''''''''''''''''''''''''''Dim ds As DataSet = objUser.SelectUserDetails("6AE69F56-4876-11E4-BA42-02D61D5D46B0", User.Identity.Name)


            'Dim Util As Utils = New Utils
            ClinicName.Value = Utils.Values.GetFirstTableFirstRowString(ds, "ClinicName")
            ClinicNumber.Value = Utils.Values.GetFirstTableFirstRowString(ds, "ClinicID")

            Dim Reports As New ReportConnect.ReportService()
            Reports.Url = Application("ReportWebService").ToString()
            Dim InsuredStatusDaysInterval As Short = 0
            Try
                InsuredStatusDaysInterval = Short.Parse(Reports.GetGeneralParameters("0F19E522-D376-46BA-8A4B-1BBEB68E5BE6", "InsuredStatusDaysInterval"))
            Catch ex As Exception
            End Try
            ToDate.Value = Date.Now.ToString("dd/MM/yyyy")
            FromDate.Value = Date.Now.AddDays(-InsuredStatusDaysInterval).ToString("dd/MM/yyyy")

            grdList_SortCommandFromLoad()

            If Not Session("HDSHEM") Is Nothing Then

                If Not Session("PageActionValue") Is Nothing Then

                    If Session("PageActionValue").ToString <> "" Then
                        If Not PageAction.Value.Length > 20 Then
                            PageAction.Value = Session("PageActionValue").ToString
                        End If


                        PageAction_ValueChanged(Nothing, Nothing)



                        If PageAction.Value.Split("$")(0).ToLower() = "cn" Then
                            HidTxtCnOrCl.Value = "cn"
                        Else
                            HidTxtCnOrCl.Value = "cl"
                        End If

                    Else 'If Session("PageActionValue").ToString <> "" Then

                        PageAction.Value = "cn" + "$" + DateTime.Now.ToLongTimeString()

                        PageAction_ValueChanged(Nothing, Nothing)

                    End If 'If Session("PageActionValue").ToString <> "" Then

                Else ' If Not Session("PageActionValue") Is Nothing Then

                    PageAction.Value = "cn" + "$" + DateTime.Now.ToLongTimeString()

                    PageAction_ValueChanged(Nothing, Nothing)

                End If ' If Not Session("PageActionValue") Is Nothing Then

            Else

                BuildEmptyTable()


            End If ' If Not Session("HDSHEM") Is Nothing Then

        Else


            If HidClearSession.Value = "1" Then
                HidClearSession.Value = "0"
                Session("SortExpressionForHdStart") = SortExpression
            Else
                Session.Remove("SortExpressionForHdStart")
            End If

            ''''''''''''''''''''''''' MoodChangedFromMasterPage()


        End If '  If Not IsPostBack Then

        HidbdikatZakhutStart.Value = "1"
        Dim sTitle As String = "בדיקת זכאות"
        HidbTikMevhutach.Value = ""

        If Not Request.QueryString("HidbTikMevhutach") Is Nothing Then
            If Request.QueryString("HidbTikMevhutach").ToString = "1" Then
                HidbTikMevhutach.Value = "1"
                sTitle = "תיק המבוטח"
                HidbdikatZakhutStart.Value = ""
            End If
        End If

        Dim sMainTitle As String = "מערכת הוד - " & sTitle
        CType(Master.FindControl("MainTitle"), Literal).Text = sMainTitle
        Page.Title = sMainTitle


    End Sub

    Private Sub PageAction_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles PageAction.ValueChanged

        If Session.IsNewSession Then
            Response.Redirect("Login.aspx")
        End If


        ' Dim bAccount As Boolean = False
        If Not PageAction.Value.Length > 20 Then
            Session("PageActionValue") = PageAction.Value
            ' Session("PageActionValueOrg") = PageAction.Value
        End If


        If PageAction.Value.Length > 20 Then ' NavigateOnDblClick
            'http://win7-yuriet/Distribution08/frmHdReportDailyRequests.aspx?SugDivuach=41&tz=18&DayForReport=16/12/2007
            Dim Parts As String() = Split(Utils.DecryptString(PageAction.Value), "$")
            'Parts(0): ReportType
            'Parts(1): InsuredID
            'Parts(2): EntryDate
            'Parts(3): RequestID
            'Parts(4): Reference

            'Dim Util As Utils = New Utils
            If Parts(0) <> "" Then


                If Parts(0) = 10 Then ''''''''''''''''''''''''''''''''''''''Parts(0) = 10 
                    'Session("PageActionValue") = Session("PageActionValueOrg")
                    'bAccount = True
                    Dim objTreatmentService As New TreatmentConnect.TreatmentService()
                    objTreatmentService.Url = Utils.Values.GetApplicationString("TreatmentWebService")
                    HidDRTaarixHafaqa.Value = ""
                    Dim sDayForReport As String = Parts(2).ToString.Replace("/", "")
                    Dim ds As DataSet = objTreatmentService.GetDataForHDReportDailyRequests( _
                                                                "3692025C-B925-407E-9A17-4BCBB3ECC7A8", _
                                                                User.Identity.Name, _
                                                                10, _
                                                                0, _
                                                                Val(Utils.Values.GetApplicationString("CompanyID")), _
                                                                sDayForReport, _
                                                                Parts(4))
                    Dim sHidDRTaarixHafaqaValue As String = Utils.Values.GetFirstTableFirstRowString(ds, "TaarichHafaqa")
                    If sHidDRTaarixHafaqaValue = "" Then
                        sHidDRTaarixHafaqaValue = "אין תאריך הפקה"
                    End If
                    HidDRTaarixHafaqa.Value = sHidDRTaarixHafaqaValue

                    Return
                Else
                    Dim objTreatmentService As New TreatmentConnect.TreatmentService()
                    objTreatmentService.Url = Utils.Values.GetApplicationString("TreatmentWebService")
                    Dim sDayForReport As String = Parts(2).ToString.Replace("/", "")
                    Dim ds As DataSet = objTreatmentService.GetDataForHDReportDailyRequests("3692025C-B925-407E-9A17-4BCBB3ECC7A8", _
                                                                            User.Identity.Name, _
                                                                            Val(Parts(0)), _
                                                                            Val(InsuredID.Value), _
                                                                            Val(Utils.Values.GetApplicationString("CompanyID")), _
                                                                            "", _
                                                                            Parts(4))
                    If Not ds Is Nothing Then
                        If ds.Tables.Count > 0 Then
                            If ds.Tables(0).Rows.Count > 0 Then

                                If Parts(2) <> "" Then
                                    Dim sDateForRep = Parts(2).Replace("/", "")
                                    Response.Redirect(String.Format("frmHdReportDailyRequests.aspx?SugDivuach={0}&tz={1}&DayForReport={2}&Asmaxta={3}&SourchWin={4}", Parts(0), Parts(1), sDateForRep, Parts(4), "0"))
                                Else
                                    txtError.Value = "10"
                                    ShowDetails(True)
                                    Return
                                End If
                            Else
                                txtError.Value = "12"
                                ShowDetails(True)
                                Return
                            End If
                        Else
                            ShowDetails(True)
                            txtError.Value = "12"
                            Return
                        End If
                    Else
                        ShowDetails(True)
                        txtError.Value = "12"
                        Return
                    End If

                End If
            End If
        End If


        If PageAction.Value.Split("$")(0).ToUpper() = PageAction.Value.Split("$")(0) Then ' upper case: RequestType changed!
            If PageAction.Value.Split("$")(0).ToLower() = "cn" Then
                SortExpression = "cn"
            Else
                SortExpression = "cl"
            End If

            PageAction.Value = PageAction.Value.ToLower()

            For Each dc As DataGridColumn In grdList.Columns
                '↑↓
                If TypeOf dc Is BoundColumn Then
                    dc.HeaderText = dc.HeaderText.Replace(Sorting.Down, String.Empty).Replace(Sorting.Up, String.Empty)
                End If
            Next
        End If

        If GetInsuredDetails() Then
            BindGrid()
        Else
            Me.FirstMame.Value = ""
            Me.LastName.Value = ""
            BuildEmptyTable()


        End If


    End Sub
  
    Private Sub BindGrid()

        Dim Reports As New ReportConnect.ReportService()
        Reports.Url = Application("ReportWebService").ToString()

        Dim RequestType As String
        If PageAction.Value.Split("$")(0).ToLower() = "cn" Then
            RequestType = "4"
            grdList.Columns.Item(1).Visible = False
            'grdList.Columns.Item(6).Visible = False
            grdList.Columns.Item(6).HeaderText = "ת. התיעצויות"
        Else
            RequestType = "0,9"
            grdList.Columns.Item(1).Visible = True
            grdList.Columns.Item(6).Visible = True
            grdList.Columns.Item(6).HeaderText = "ת. גמר טיפול"
        End If

        HidbOldMevhutach.Value = Val(InsuredID.Value)

        If grdList.Visible = False Then Return

        Dim ds As DataSet = Reports.GetInsuredStatus("84123EF3-5CE5-4CEE-B62C-6F468CF35C19", ClinicNumber.Value, Val(InsuredID.Value), Utils.GetYYYYMMDDString(FromDate.Value), Utils.GetYYYYMMDDString(ToDate.Value), RequestType, User.Identity.Name, Val(Application("CompanyID")))

        Dim bNoRowes As Boolean = False

        If Not ds Is Nothing Then
            If ds.Tables.Count > 0 Then

                setNewPatient(ds.Tables(0).Rows.Count, RequestType)

                If ds.Tables(0).Rows.Count > 0 Then

                    bNoRowes = True

                    Dim iCount As Integer = ds.Tables(0).Rows.Count
                    Dim iPageCount As Integer = (iCount - 1) \ grdList.PageSize
                    If grdList.CurrentPageIndex > iPageCount Then
                        grdList.CurrentPageIndex = iPageCount
                    End If

                    Dim dt As DataTable = ds.Tables(0)

                    Dim dv As DataView = New DataView(dt)
                    Dim sSortExpression As String
                    If Session("SortExpressionForHdStart") Is Nothing Then

                        dv.Sort = SortExpression
                        Session("SortExpressionForHdStart") = SortExpression
                    Else
                        sSortExpression = Session("SortExpressionForHdStart").ToString

                        dv.Sort = sSortExpression

                    End If


                    grdList.DataSource = dv
                    grdList.DataBind()
                    If iPageCount > 0 Then
                        grdList.PagerStyle.Visible = True
                    Else
                        grdList.PagerStyle.Visible = False
                    End If

                End If

            End If

        End If

        If (Not bNoRowes) Then
            BuildEmptyTable()
        End If




    End Sub

    Private Function GetInsuredDetails() As Boolean
        Dim bRet As Boolean = True
        Dim objBO As New BOConnection.BOService
        objBO.Url = Application("BOWebService")

        Dim ds As New DataSet
        If (Trim(InsuredID.Value) = "") Then
            txtError.Value = ""
            LastName.Value = ""
            FirstMame.Value = ""
            FamilyCover.Value = ""
            bRet = False
        Else

            ds = objBO.GetInsuredDetails("BB91B46E-024D-41F0-97C0-D58FE62388E9", Val(InsuredID.Value))

            If Not ds Is Nothing Then

                If ds.Tables.Count > 0 Then

                    If ds.Tables(0).Rows.Count = 0 Then

                        txtError.Value = "11"

                        Session("InsuredIDNotFound") = "1"

                        Session.Remove("HDInsuredID")

                        Session.Remove("HDSHEM")

                        Session.Remove("HDMISP")

                        Session.Remove("HDPolGovTreatment")

                    Else
                        Session.Remove("InsuredIDNotFound")
                        txtError.Value = ""
                    End If
                Else
                    txtError.Value = "11"
                End If
            Else
                txtError.Value = "11"
            End If



            Dim sChasanSherut As Char
            sChasanSherut = Utils.Values.GetFirstTableFirstRowString(ds, "MSL_QOD_HASAM_SHERUT")


            If sChasanSherut = "כ" Then
                txtError.Value = "13"

                Session.Remove("HDInsuredID")

                Session.Remove("HDSHEM")

                Session.Remove("HDMISP")

                Session.Remove("HDPolGovTreatment")


                bRet = False

            Else

                'Dim Util As Utils = New Utils
                FirstMame.Value = Utils.Values.GetFirstTableFirstRowString(ds, "SHEM")
                LastName.Value = Utils.Values.GetFirstTableFirstRowString(ds, "MISP")
                FamilyCover.Value = Utils.Values.GetFirstTableFirstRowString(ds, "MSL_TEUR_KISUY_MEVUTAH")
                hidPolGovTreatment.Value = Utils.Values.GetFirstTableFirstRowString(ds, "MSL_QOD_HOZER_SHINAIM")
                If txtError.Value <> "11" Then

                    Session("HDInsuredID") = Val(InsuredID.Value)
                    Session("HDSHEM") = FirstMame.Value
                    Session("HDMISP") = LastName.Value
                    Session("HDPolGovTreatment") = hidPolGovTreatment.Value

                End If 'If txtError.Value <> "11" Then

            End If 'If sChasanSherut = "ל" Then

        End If 'If (Trim(InsuredID.Value) = "") Then


        If bRet Then
            Me.MoodChangedFromMasterPage()
        End If

        Return bRet

    End Function

    Private Sub grdList_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdList.ItemDataBound

        Dim dgItem As DataGridItem = e.Item

        Select Case (dgItem.ItemType)
            Case ListItemType.Item, ListItemType.AlternatingItem
                Dim DescriptionCell = dgItem.Cells(3)
                If (DescriptionCell.Text.Length >= 30) Then
                    DescriptionCell.ToolTip = DescriptionCell.Text
                    DescriptionCell.Text = DescriptionCell.Text.Substring(0, 30) + "..."
                End If

                Dim StatusCell = dgItem.Cells(8)

                Dim Action As String = PageAction.Value.Split("$")(0).ToLower()



                ''''''''
                ''' T e m p - next version
                ''' ''''


                ' '' '' ''If Action = "cn" Then ' Consultation - התייעצויות
                ' '' '' ''    Select Case (dgItem.DataItem("Status").ToString())
                ' '' '' ''        Case Status.Approved ' "אושר"                           
                ' '' '' ''            StatusCell.Attributes.Add("onclick", NavigateOnDblClick(41, dgItem.DataItem))
                ' '' '' ''        Case Status.Denied ' "נדחה"
                ' '' '' ''            StatusCell.Attributes.Add("onclick", NavigateOnDblClick(41, dgItem.DataItem))
                ' '' '' ''        Case Status.Cared ' "בטיפול"
                ' '' '' ''            Dim RepID, UserID As Integer
                ' '' '' ''            PrepareData(dgItem.DataItem, RepID, UserID)
                ' '' '' ''            StatusCell.Attributes.Add("onclick", String.Format("ShowReport('{0}','{1}');", RepID, UserID))
                ' '' '' ''            'If Util.GetDataRowString(dgItem.DataItem, "RequestSource") = "7" Then
                ' '' '' ''            StatusCell.Attributes.Add("onclick", NavigateOnDblClick(557, dgItem.DataItem))
                ' '' '' ''            'Else
                ' '' '' ''            StatusCell.Attributes.Add("onclick", NavigateOnDblClick(510, dgItem.DataItem))
                ' '' '' ''            'End If
                ' '' '' ''        Case Else
                ' '' '' ''            StatusCell = Nothing
                ' '' '' ''    End Select
                ' '' '' ''Else ' Claim - תביעות
                ' '' '' ''    Select Case (dgItem.DataItem("Status").ToString())
                ' '' '' ''        Case Status.Approved ' "אושר"                           
                ' '' '' ''            StatusCell.Attributes.Add("onclick", NavigateOnDblClick(11, dgItem.DataItem))
                ' '' '' ''        Case Status.Denied ' "נדחה"
                ' '' '' ''            StatusCell.Attributes.Add("onclick", NavigateOnDblClick(11, dgItem.DataItem))
                ' '' '' ''        Case Status.Cared ' "בטיפול"
                ' '' '' ''            Dim RepID, UserID As Integer
                ' '' '' ''            PrepareData(dgItem.DataItem, RepID, UserID)
                ' '' '' ''            StatusCell.Attributes.Add("onclick", String.Format("ShowReport('{0}','{1}');", RepID, UserID))
                ' '' '' ''            'StatusCell.Attributes.Add("onclick", NavigateOnDblClick(500, dgItem.DataItem))
                ' '' '' ''        Case Status.Paid ' "שולם"
                ' '' '' ''            StatusCell.Attributes.Add("onclick", NavigateOnDblClickForShulam(10, dgItem.DataItem))
                ' '' '' ''        Case Else
                ' '' '' ''            StatusCell = Nothing
                ' '' '' ''    End Select
                ' '' '' ''End If
                ' '' '' ''If Not StatusCell Is Nothing Then
                ' '' '' ''    StatusCell.Attributes.Add("class", "link")
                ' '' '' ''End If




        End Select

    End Sub

    Private Function NavigateOnDblClick(ByVal ReportType As Integer, ByVal DataItem As DataRowView) As String

        Dim RequestID = Utils.Values.GetDataRowString(DataItem, "RequestID")
        Dim Reference = Utils.Values.GetDataRowString(DataItem, "Reference")
        Dim EntryDate = Utils.Values.GetDataRowString(DataItem, "EntryDate", "{0:dd/MM/yyyy}")
        Return String.Format("Navigate('{0}');", Utils.EncryptString(String.Format("{0}${1}${2}${3}${4}", ReportType, InsuredID.Value, EntryDate, RequestID, Reference), False))

    End Function

    Private Function NavigateOnDblClickForShulam(ByVal ReportType As Integer, ByVal DataItem As DataRowView) As String

        Dim RequestID = Utils.Values.GetDataRowString(DataItem, "RequestID")
        Dim Reference = Utils.Values.GetDataRowString(DataItem, "Reference")
        Dim EntryDate = Utils.Values.GetDataRowString(DataItem, "TaarichHafaqa", "{0:dd/MM/yyyy}")
        Return String.Format("Navigate('{0}');", Utils.EncryptString(String.Format("{0}${1}${2}${3}${4}", ReportType, InsuredID.Value, EntryDate, RequestID, Reference), False))

    End Function

    Private Function PrepareData(ByVal DataItem As DataRowView, ByRef RepID As Integer, ByRef UserID As Integer) As String

        Dim Reports As New ReportConnect.ReportService()
        Reports.Url = Application("ReportWebService").ToString()
        Dim ds As DataSet = Reports.GetReportByBoRepID("715C0D0D-2C81-48E2-85D0-17C9E62B3C39", Utils.Values.GetDataRowString(DataItem, "ConnectReference"))
        RepID = Utils.Values.GetFirstTableFirstRowInteger(ds, "RepID")

        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        ds = objUser.GetUser("784C13D4-4DA2-49FC-9CDD-1BB6B0E869CB", User.Identity.Name)
        UserID = Utils.Values.GetFirstTableFirstRowInteger(ds, "SysUserID")

    End Function

    Private Sub grdList_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles grdList.PageIndexChanged

        grdList.CurrentPageIndex = e.NewPageIndex
        BindGrid()

    End Sub

    Private Sub grdList_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles grdList.SortCommand

        SortExpression = e.SortExpression
        Session("eTabForSortExpressionForHdStart") = e.SortExpression
        For Each dc As DataGridColumn In grdList.Columns
            '↑↓
            If TypeOf dc Is BoundColumn Then
                If (dc.SortExpression = e.SortExpression) Then
                    If dc.HeaderText.IndexOf(Sorting.Up) >= 0 Then
                        dc.HeaderText = dc.HeaderText.Replace(Sorting.Up, Sorting.Down)
                    ElseIf dc.HeaderText.IndexOf(Sorting.Down) >= 0 Then
                        dc.HeaderText = dc.HeaderText.Replace(Sorting.Down, Sorting.Up)
                    Else
                        dc.HeaderText = dc.HeaderText + Sorting.Up
                    End If
                Else
                    dc.HeaderText = dc.HeaderText.Replace(Sorting.Down, String.Empty).Replace(Sorting.Up, String.Empty)
                End If
            End If
        Next

        BindGrid()

    End Sub

    Private Sub grdList_SortCommandFromLoad()
        If Session("eTabForSortExpressionForHdStart") Is Nothing Then
            Return
        Else
            SortExpression = Session("eTabForSortExpressionForHdStart").ToString
        End If


        For Each dc As DataGridColumn In grdList.Columns
            '↑↓
            If TypeOf dc Is BoundColumn Then
                If (dc.SortExpression = SortExpression) Then
                    If dc.HeaderText.IndexOf(Sorting.Up) >= 0 Then
                        dc.HeaderText = dc.HeaderText.Replace(Sorting.Up, Sorting.Down)
                    ElseIf dc.HeaderText.IndexOf(Sorting.Down) >= 0 Then
                        dc.HeaderText = dc.HeaderText.Replace(Sorting.Down, Sorting.Up)
                    Else
                        dc.HeaderText = dc.HeaderText + Sorting.Up
                    End If
                Else
                    dc.HeaderText = dc.HeaderText.Replace(Sorting.Down, String.Empty).Replace(Sorting.Up, String.Empty)
                End If
            End If
        Next

        BindGrid()

    End Sub

    Private Sub setNewPatient(ByVal iRows As Integer, ByVal _RequestType As String)




        If iRows > 0 Then
            HidbShowNewPatinet.Value = "0"
        Else


            Dim Reports As New ReportConnect.ReportService()
            Reports.Url = Application("ReportWebService").ToString()

            Dim ds As DataSet = Reports.GetInsuredStatus("84123EF3-5CE5-4CEE-B62C-6F468CF35C19", ClinicNumber.Value, Val(InsuredID.Value), System.DBNull.Value.ToString, System.DBNull.Value.ToString, _RequestType, User.Identity.Name, Val(Application("CompanyID")))

            If Not ds Is Nothing Then
                If ds.Tables.Count > 0 Then
                    If ds.Tables(0).Rows.Count > 0 Then

                        HidbShowNewPatinet.Value = "2"

                    Else

                        HidbShowNewPatinet.Value = "1"
                    End If
                Else
                    HidbShowNewPatinet.Value = "1"
                End If
            Else
                HidbShowNewPatinet.Value = "1"
            End If
        End If

    End Sub

    Private Function buildTableEmpty() As DataSet

        Dim dsReturn As New DataSet

        Dim dtReturn As DataTable = New DataTable

        Dim myDataColumn As DataColumn

        '1
        myDataColumn = New DataColumn()
        buildDataColumn(True, "Reference", myDataColumn)
        dtReturn.Columns.Add(myDataColumn)
        '2
        myDataColumn = New DataColumn()
        buildDataColumn(True, "RequestDescription", myDataColumn)
        dtReturn.Columns.Add(myDataColumn)
        '3
        myDataColumn = New DataColumn()
        buildDataColumn(False, "TreatmentID", myDataColumn)
        dtReturn.Columns.Add(myDataColumn)
        '4
        myDataColumn = New DataColumn()
        buildDataColumn(True, "TreatmentDescription", myDataColumn)
        dtReturn.Columns.Add(myDataColumn)
        '5
        myDataColumn = New DataColumn()
        buildDataColumn(False, "FTooth", myDataColumn)
        dtReturn.Columns.Add(myDataColumn)
        '6
        myDataColumn = New DataColumn()
        buildDataColumn(False, "ToTooth", myDataColumn)
        dtReturn.Columns.Add(myDataColumn)
        '7
        myDataColumn = New DataColumn()
        buildDataColumn(True, "CareFinishDate", myDataColumn)
        dtReturn.Columns.Add(myDataColumn)
        '8
        myDataColumn = New DataColumn()
        buildDataColumn(True, "EntryDate", myDataColumn)
        dtReturn.Columns.Add(myDataColumn)

        '9
        myDataColumn = New DataColumn()
        buildDataColumn(False, "Status", myDataColumn)
        dtReturn.Columns.Add(myDataColumn)

        Dim idx1 As Integer

        Dim drReturn As DataRow


        For idx1 = 0 To 7

            drReturn = dtReturn.NewRow()

            drReturn.Item("Reference") = ""
            drReturn.Item("RequestDescription") = ""
            drReturn.Item("TreatmentID") = System.DBNull.Value
            drReturn.Item("TreatmentDescription") = ""
            drReturn.Item("FTooth") = System.DBNull.Value
            drReturn.Item("ToTooth") = System.DBNull.Value
            drReturn.Item("CareFinishDate") = ""
            drReturn.Item("EntryDate") = ""
            drReturn.Item("Status") = System.DBNull.Value

            dtReturn.Rows.Add(drReturn)
        Next



        dsReturn.Tables.Add(dtReturn)


        Return dsReturn
    End Function

    Private Sub buildDataColumn(ByVal isString As Boolean, ByVal colName As String, ByRef retDc As DataColumn)

        If isString Then
            retDc.DataType = Type.[GetType]("System.String")
        Else
            retDc.DataType = Type.[GetType]("System.Int32")
        End If

        retDc.ColumnName = colName


    End Sub

    Private Sub BuildEmptyTable()
        Dim _ds As New DataSet

        _ds = buildTableEmpty()

        Dim dt As DataTable = _ds.Tables(0)

        Dim dv As DataView = New DataView(dt)


        grdList.DataSource = dv
        grdList.DataBind()
    End Sub

    Private Sub ShowDetails(ByVal bShowDetails As Boolean)
        tdReq.Visible = bShowDetails
        tdClaims.Visible = bShowDetails
        liFromDate.Visible = bShowDetails
        liToDate.Visible = bShowDetails
        grdList.Visible = bShowDetails

        If bShowDetails Then
            BindGrid()
        End If


        dvClinicdata.Visible = bShowDetails

    End Sub

    Private Sub ShowZakaut(ByVal bShowZakaut As Boolean)
        dvZakaut.Visible = bShowZakaut

    End Sub

    Private Sub ShowReload(ByVal bShowReload As Boolean)
        ReLoad.Visible = bShowReload

    End Sub

    Public Sub SetTikMevhutach()
        Me.HidbTikMevhutach.Value = "1"
    End Sub

    Private Function IsTikMevutach() As Boolean

        If Me.HidbTikMevhutach.Value = "1" Then
            Return True
        Else
            Return False
        End If

    End Function

    Public Function GetComeMevhutach() As Integer
        If HidComeMevhutach.Value <> "" Then
            Return 0
        Else
            Return HidComeMevhutach.Value
        End If
    End Function

    Public Function GetComeMevhutachForHdstart() As Integer
        Return Me.HidComeMevhutachForHdstart.Value
    End Function

    Public Sub SetComeMevhutach(ByVal iHidComeMevhutach As Integer)
        HidComeMevhutach.Value = iHidComeMevhutach
    End Sub

    Public Sub SetComeMevhutachForHdstart(ByVal iComeMevhutachForHdstart As Integer)
        HidComeMevhutachForHdstart.Value = iComeMevhutachForHdstart
    End Sub

    Public Sub SetBbdikatZakhutStart(ByVal iHidbdikatZakhutStart As Integer)
        HidbdikatZakhutStart.Value = iHidbdikatZakhutStart
    End Sub

    Public Sub SetShowZakaut()
        ShowDetails(False)
        ShowZakaut(True)
        ShowReload(False)
    End Sub

End Class
