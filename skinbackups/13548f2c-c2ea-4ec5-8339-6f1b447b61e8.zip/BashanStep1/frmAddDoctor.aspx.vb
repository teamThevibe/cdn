Public Class frmAddDoctor
    Inherits System.Web.UI.Page
    Protected WithEvents grdList As System.Web.UI.WebControls.DataGrid
    Protected WithEvents txtDoctorNo As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDoctorName As System.Web.UI.WebControls.TextBox
    Protected WithEvents cmdSave As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdNew As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdCancel As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents txtCurrentID As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtError As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtSpecialistLicense As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtStartWorkDate As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtEndWorkDate As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtLeaveReason As System.Web.UI.WebControls.TextBox
    Dim Utl As New Utils

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not IsPostBack Then
            txtError.Attributes("ConfirmText") = "?��� ����� �� ������"
            BindGrid()
        End If
    End Sub

    Private Sub BindGrid()
        Dim objList As New UserConnect.UserService()
        objList.Url = Application("UserWebService").ToString()
        grdList.DataSource = objList.GetDoctorList("03407803-DE6A-41AA-87DC-60D1D0329753", User.Identity.Name)
        grdList.DataBind()
    End Sub

    Private Sub cmdSave_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.ServerClick
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim sDoctorNo As String = Trim(txtDoctorNo.Text)
        Dim sDoctorName As String = Trim(txtDoctorName.Text)

        If Not Len(sDoctorNo) > 0 Or Not Len(sDoctorName) > 0 Then
            txtError.Value = "�� ������ ���� ����� ��� ���� ���� ������ �����"
            Return
        End If
        If DoctorIDExist(CInt(sDoctorNo)) Then
            txtError.Value = "���� ����� ������ ��� ����, ��� ���� ���� ���"
            txtDoctorNo.Text = ""
            Return
        End If


        Dim iSpecialistLicense As Integer = Val(Trim(txtSpecialistLicense.Text))
        Dim dStartWorkDate As Date = Utl.StringToDate(txtStartWorkDate.Text)
        Dim dEndWorkDate As Date = Utl.StringToDate(txtEndWorkDate.Text)
        Dim iLeaveReason As Integer = Val(Trim(txtLeaveReason.Text))
        If Not objUser.AddNewCaringDoctor("91F850A70-6AD6-470C-9AFF-CD9A645684C1", User.Identity.Name, sDoctorNo, sDoctorName, iSpecialistLicense, dStartWorkDate, dEndWorkDate, iLeaveReason, User.Identity.Name) Then
            txtError.Value = "���� ������ ������ �����"
        End If
        txtDoctorNo.Text = ""
        txtDoctorName.Text = ""
        txtSpecialistLicense.Text = ""
        txtStartWorkDate.Text = ""
        txtEndWorkDate.Text = ""
        txtLeaveReason.Text = ""
        BindGrid()
    End Sub

    Private Function DoctorIDExist(ByVal iDoctorID As Integer, Optional ByVal iRowID As Long = -1) As Boolean
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Return objUser.DoctorIDExist("B4B3D83D-7B35-4FA5-8EC6-34EF15A8C3F3", User.Identity.Name, iDoctorID, iRowID)
    End Function

    Private Sub grdList_EditCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdList.EditCommand
        grdList.EditItemIndex = e.Item.ItemIndex
        BindGrid()
    End Sub

    Private Sub grdList_CancelCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdList.CancelCommand
        grdList.EditItemIndex = -1
        BindGrid()
    End Sub

    Private Sub grdList_UpdateCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdList.UpdateCommand
        Dim CurrentTextBox As TextBox

        Dim iRowID As Integer = grdList.DataKeys(CInt(e.Item.ItemIndex))

        CurrentTextBox = CType(e.Item.FindControl("DocNo"), TextBox)   'e.Item.Cells(1).Controls(0)
        Dim sDoctorNo As String = Trim(CurrentTextBox.Text)
        If Len(sDoctorNo) > 6 Or Len(sDoctorNo) = 0 Then
            txtError.Value = "�� ������ ���� ����� ����"
            Return
        End If
        Dim iDoctorNo As Integer = Val(sDoctorNo)
        If iDoctorNo = 0 Then
            txtError.Value = "�� ������ ���� ����� ����"
            Return
        End If

        CurrentTextBox = CType(e.Item.FindControl("DocName"), TextBox)
        Dim sDoctorName As String = Trim(CurrentTextBox.Text)
        If Not Len(sDoctorName) > 0 Then
            txtError.Value = "���� ������ �� ���� "
            Return
        End If

        If DoctorIDExist(CInt(sDoctorNo), iRowID) Then
            txtError.Value = "���� ������� ������ ��� ���� ������" & vbNewLine & "�� ������ ���� ������ ������ �� ���� ���"
            Return
        End If

        CurrentTextBox = CType(e.Item.FindControl("SpecialistLicense"), TextBox)
        Dim iSpecialistLicense As Integer = Val(Trim(CurrentTextBox.Text))

        CurrentTextBox = CType(e.Item.FindControl("StartWorkDate"), TextBox)
        Dim dStartWorkDate As Date = Utl.StringToDate(CurrentTextBox.Text)


        CurrentTextBox = CType(e.Item.FindControl("EndWorkDate"), TextBox)
        Dim dEndWorkDate As Date = Utl.StringToDate(CurrentTextBox.Text)

        'CurrentTextBox = CType(e.Item.FindControl("LeaveReason"), TextBox)
        'Dim iLeaveReason As Integer = Val(Trim(CurrentTextBox.Text))
        Dim iLeaveReason As Integer
        iLeaveReason = 0

        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

        If objUser.UpdateCaringDoctorByID("91F850A70-6AD6-470C-9AFF-CD9A645684C2", iRowID, iDoctorNo, sDoctorName, iSpecialistLicense, dStartWorkDate, dEndWorkDate, iLeaveReason, User.Identity.Name) Then
            grdList.EditItemIndex = -1
            BindGrid()
        End If
    End Sub

    Protected Function FormatDateTime(ByRef dtViewDate As Object) As String
        If IsDBNull(dtViewDate) Then
            Return ""
        Else
            Return Format(dtViewDate, "dd/MM/yyyy")
        End If
    End Function


    Private Sub grdList_DeleteCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdList.DeleteCommand
        If Not IsDBNull(grdList.DataKeys(CInt(e.Item.ItemIndex))) Then
            Dim iRowID As Integer = grdList.DataKeys(CInt(e.Item.ItemIndex))
            If grdList.DataKeys.Count > 1 Or grdList.PageCount > 1 Then
                Dim objUser As New UserConnect.UserService()
                objUser.Url = Application("UserWebService").ToString()

                If objUser.DeleteDoctorByID("50824D86-4116-4883-AEEC-A850147021E0", iRowID, User.Identity.Name) Then
                    grdList.EditItemIndex = -1
                    BindGrid()
                End If
            Else
                txtError.Value = "��� ������ ����� ���� �����"
            End If
        Else
            txtError.Value = "����� �� �����"
        End If
    End Sub


    Private Sub grdList_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles grdList.PageIndexChanged
        grdList.CurrentPageIndex = e.NewPageIndex
        BindGrid()
    End Sub

    Protected Function EncodeField(ByRef objCode As Object) As String
        Dim strReturn As String = ""
        If Not IsDBNull(objCode) Then
            strReturn = CEncode.StringEncode(objCode.ToString())
        End If
        Return strReturn
    End Function

End Class
