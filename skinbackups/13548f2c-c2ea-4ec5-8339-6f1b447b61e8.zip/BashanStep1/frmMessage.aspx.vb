Public Class frmMessage
    Inherits System.Web.UI.Page


    Protected WithEvents cmdCancel As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdOk As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents dvMessage As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents txtTitle As System.Web.UI.HtmlControls.HtmlGenericControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If (Not IsPostBack) Then
            Dim sCode As String = Request.QueryString("Code") + ""
            If (sCode = "Ok") Then
                cmdCancel.Visible = False
            End If
            Dim sMessage As String = Request.QueryString("Mess") + ""
            dvMessage.InnerHtml = sMessage

            Dim sTitle As String = Request.QueryString("WinTitle") + ""

            txtTitle.InnerText = sTitle
        End If

        '�����(�����)
        '       <br><br>
        '       �� ����� ����� ��� ���� �����
        '       <br><br>
        '       <span style='color: red;'>����� �����</span>
    End Sub


    'Function hexEncode(ByVal str)
    '    Dim strEncoded, i
    '    strEncoded = ""
    '    For i = 1 To Len(str)
    '        strEncoded = strEncoded + "%" + Hex(Asc(Mid(str, i, 1))) + " "
    '    Next
    '    hexEncode = strEncoded
    'End Function

End Class
