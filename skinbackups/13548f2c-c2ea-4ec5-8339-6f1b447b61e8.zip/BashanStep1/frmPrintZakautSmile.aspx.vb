﻿Public Partial Class frmPrintZakautSmile
    Inherits System.Web.UI.Page

    Protected WithEvents lblClinicNumber As System.Web.UI.WebControls.Label
    Protected WithEvents lblInsuredID As System.Web.UI.WebControls.Label
    Protected WithEvents lblInsuredName As System.Web.UI.WebControls.Label
    Protected WithEvents lblInsuredFamily As System.Web.UI.WebControls.Label
    Protected WithEvents lblClinicName As System.Web.UI.WebControls.Label

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

End Class