﻿Imports System.Web.Security
Imports System.IO
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Diagnostics
Imports System.Web





Partial Public Class frmHDLogin
    Inherits System.Web.UI.Page

    Protected WithEvents txtUser As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtPass As System.Web.UI.HtmlControls.HtmlInputPassword
    'Protected WithEvents ExtraIdAnswer As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtError As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAppType As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents cmdOK As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdSendPassword As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdHelp As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents txtFormIdentity As System.Web.UI.HtmlControls.HtmlInputHidden
    'Protected WithEvents aIconLink As System.Web.UI.HtmlControls.HtmlAnchor
    'Protected WithEvents aIconLink2 As System.Web.UI.HtmlControls.HtmlAnchor
    Protected WithEvents lblMessage As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents lblMessageFrame As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents hidOS As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidBrowserNM As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidBrowserVer As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidUserAgent As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidWinName As System.Web.UI.HtmlControls.HtmlInputHidden
    'Protected WithEvents divRIcon As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents lstSystem As System.Web.UI.HtmlControls.HtmlSelect
    'Protected WithEvents trExtraID As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents tdUserError As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents tdLoginError As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents tdPasswordError As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents SiteInfo As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents trDivurTitle As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents trHodTitle As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents trDistTitle As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents trDoarTitle As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents trInPostTitle As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents trSuppTitle As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents cmdDoctorService As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents txtLoginIdentity As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtCountTest As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidPassword As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidExtraIdAnswer As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents divTest As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents txtTest As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents hidSaveUrl As System.Web.UI.HtmlControls.HtmlInputHidden

    Protected WithEvents hidSetDesign As System.Web.UI.HtmlControls.HtmlInputHidden

    Public DomainUser As String
    Private bIsLoginFromEmail As Boolean = False
    Public AutoConnect As Boolean = False

    Public Property RequestPasswordStep() As Integer
        Get
            If (IsNothing(ViewState("RequestPasswordStep"))) Then
                Return 0
            Else
                Return Val(ViewState("RequestPasswordStep"))
            End If
        End Get
        Set(ByVal value As Integer)
            ViewState("RequestPasswordStep") = value
        End Set
    End Property

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub GetEnvironment()
        hidUserAgent.Value = Request.Headers("User-Agent")
		Dim bAddUserAgent As Boolean = False
		Dim utilsObj As New Utils()
		utilsObj.CheckBrowser(hidUserAgent.Value, hidBrowserNM.Value, hidBrowserVer.Value, hidOS.Value, bAddUserAgent)


		If ((hidBrowserNM.Value = "Unknown") OrElse (hidBrowserVer.Value = "Unknown") OrElse (hidOS.Value = "Unknown") _
			 OrElse (hidBrowserNM.Value = "Empty") OrElse (hidBrowserVer.Value = "Empty") OrElse (hidOS.Value = "Empty")) Then
			bAddUserAgent = True		
		End If

        If bAddUserAgent Then
            hidBrowserNM.Value += "+Unknown" + hidUserAgent.Value
        End If
    End Sub

    Private Function checkLoginFromEmail() As Boolean
        If Request.QueryString("loginFromEmail") Is Nothing Then
            Return False
        Else
            Dim stParts As String()
            Dim stTicks As String
            Dim stPass As String
            Dim stName As String
            Dim stExtraIdAnswer As String
            Dim sTicket As String = Request.QueryString("loginFromEmail").ToString
            sTicket = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(sTicket))

            Dim stLinkDecripted As String = cryptComtec.RijndaelSimple.DencryptSimple(sTicket)

            stParts = Split(stLinkDecripted, "$")
            stTicks = stParts(0)
            stPass = stParts(1)
            stName = stParts(2)

            Dim objUser As New UserConnect.UserService()
            objUser.Url = Application("UserWebService").ToString()

            Dim iRemindPasswordWithLinkExpiration As Integer
            Dim sRemindPasswordWithLinkExpiration As String
            sRemindPasswordWithLinkExpiration = _
                    objUser.GetGeneralParameter("3FCAAB6E-4AAD-4231-A9F2-B9CCA67EE079", "RemindPasswordWithLinkExpiration")
            If (sRemindPasswordWithLinkExpiration <> "" And Not sRemindPasswordWithLinkExpiration = Nothing) Then
                iRemindPasswordWithLinkExpiration = Convert.ToInt32(sRemindPasswordWithLinkExpiration)
            Else
                Return False
            End If

            Dim dtExpirationccDateTime As DateTime = Convert.ToDateTime(stTicks).Date.AddHours(iRemindPasswordWithLinkExpiration)

            If Date.Compare(Date.Now().Date, dtExpirationccDateTime) > 0 Then
                Return False
            Else
                Session("PassLoginFromEmail") = stPass

                Me.txtUser.Value = stName
                Me.txtPass.Value = stPass

                Return True
            End If
        End If

    End Function

    Private Function MakeUserName() As String
        Dim stRowUserName As String = Request.ServerVariables("LOGON_USER")
        Dim iSlashPos As String = InStr(stRowUserName, "\")
        Dim stUserName As String

        If iSlashPos > 0 Then
            stUserName = Mid(stRowUserName, iSlashPos + 1)
        Else
            stUserName = stRowUserName
        End If

        Return stUserName

    End Function

    Private Sub CustomAuthentication()
        Dim strUserName As String = MakeUserName()

        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim strDate As String = ""
        Dim strTime As String = ""
        objUser.GetLastLoginDate("87EF4B7B-91C5-4399-B223-1F670D410191", strUserName, strDate, strTime)
        Session("UploadFileSize") = CStr(CType(objUser.GetUploadFileSize("CA76C311-D7D8-425E-BD0B-AE04E9C567AC", strUserName), Long) * 1024)
        Session("Last_Login_Date") = strDate
        Session("Last_Login_Time") = strTime
        Session("Show_Message") = ""
        Session("Report_List_Current_User") = ""
        Session("Message_Text") = ""
        Session("User_Login_First_Time") = ""
        Session("Allow_Yoetz") = ""
        Session("Allow_Tikshuv") = ""
        Session("Allow_UCC") = ""
        Session("Allow_ForeignWorkers_Claims") = ""
        If Application("App_Type").ToString.ToUpper = "DIST" Then
            If lstSystem.SelectedIndex > -1 Then
                strUserName = Trim(lstSystem.Items(lstSystem.SelectedIndex).Value) & strUserName
            End If
        End If
        Dim url As String
        Dim bIndependent As Boolean
        Dim bAllowClaims As Boolean
        Dim bWebInterfaceAllow As Boolean
        Dim bWebServiceAllow As Boolean
        Dim bAllowCheck As Boolean
        Dim bAllowReportGeneration As Boolean
        Dim bAllowAdvisorClaim As Boolean
        Dim bAllowHospitalClaim As Boolean
        Dim bAllowTechSupport As Boolean
        Dim bIsWorkerClaimAllow As Boolean
        Dim bIsAttachArchiveAllow As Boolean

        Dim iSiteType As Integer = Val(Application("SiteType"))

        Dim strUserID As String = objUser.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", strUserName)
        'Dim iOrganizationCode As Integer = 0
        'Dim sAgreementCode As String = ""
        Select Case objUser.CheckSmartCardUser("349784AD-FBFD-45f3-AF3A-96B7BB1E55DC", strUserName, Session.SessionID, iSiteType, Request.UserHostAddress, strUserName)
            Case 0
                Try
                    objUser.UpdateUserIP("3117568E-B76C-4041-B305-F6FF36EC32B7", Val(strUserID), Session.SessionID, Request.UserHostAddress)
                Catch
                End Try

                Session("Filter_From_Date") = ""
                Session("Filter_To_Date") = ""
                Session("Filter_Report_Type") = ""
                Session("Filter_On") = ""
                Session("Filter_Viewed") = ""
                Session("Filter_NotViewed") = ""
                Session("AS400_User") = ""
                'Dim url As String 'FormsAuthentication.GetRedirectUrl(strUserName, False)
                Select Case Application("App_Type").ToString().ToUpper()
                    Case "KUPA_INFO"
                        url = "KupaInfoMenu.aspx"
                    Case "INPOST"
                        url = "frmPostEntry.aspx"
                    Case "SUPP"


                        objUser.GetMushlamUserPermitions("D3A36FE0-57F8-44EE-8364-4F0A6B0DAA38", strUserName, bAllowClaims, bAllowCheck, bAllowReportGeneration, bAllowAdvisorClaim, bAllowHospitalClaim, bAllowTechSupport)
                        If bAllowCheck Then
                            Session("SUPP_Check") = "1"
                        Else
                            Session("SUPP_Check") = ""
                        End If
                        If bAllowClaims Then
                            Session("SUPP_AllowClaims") = "1"
                        Else
                            Session("SUPP_AllowClaims") = ""
                        End If
                        If bAllowReportGeneration Then
                            Session("SUPP_ReportGeneration") = "1"
                        Else
                            Session("SUPP_ReportGeneration") = ""
                        End If
                        If bAllowAdvisorClaim Then
                            Session("SUPP_AdvisorClaim") = "1"
                        Else
                            Session("SUPP_AdvisorClaim") = ""
                        End If
                        If bAllowHospitalClaim Then
                            Session("SUPP_HospitalClaim") = "1"
                        Else
                            Session("SUPP_HospitalClaim") = ""
                        End If

                        objUser.GetMushlamWorkerPermition("ABD02EC6-5084-4D46-8F72-8F120B5CA66E", strUserName, bIsWorkerClaimAllow)
                        If bIsWorkerClaimAllow Then
                            Session("SUPP_WORKER") = "1"
                        Else
                            Session("SUPP_WORKER") = ""
                        End If

                        objUser.GetArchiveViewPermition("E3441B09-D36C-4DFB-8F82-AD6B51F921E3", strUserName, bIsAttachArchiveAllow)
                        If bIsAttachArchiveAllow Then
                            Session("Allow_Attach_Archive") = "1"
                        Else
                            Session("Allow_Attach_Archive") = ""
                        End If

                        'Yoetz
                        Dim bIsYoetzAllow As Boolean
                        Dim bIsTikshuvAllow As Boolean
                        objUser.GetYoetzAndTikshuvPermition("A8D5D013-CD70-47A4-A645-EAB9B7059427", strUserName, bIsYoetzAllow, bIsTikshuvAllow)
                        If Application("YoetzEnabled") = "1" Then
                            If bIsYoetzAllow Then
                                Session("Allow_Yoetz") = "1"
                            Else
                                Session("Allow_Yoetz") = ""
                            End If
                        Else
                            Session("Allow_Yoetz") = ""
                        End If

                        'Tikshuv
                        If Application("TikshuvEnabled") = "1" Then
                            If bIsTikshuvAllow Then
                                Session("Allow_Tikshuv") = "1"
                            Else
                                Session("Allow_Tikshuv") = ""
                            End If
                        Else
                            Session("Allow_Tikshuv") = ""
                        End If

                        'Agreements
                        Dim bIsAgreementsAllow As Boolean = False
                        If Application("AgreementsEnabled") = "1" Then
                            bIsAgreementsAllow = objUser.GetAgreementsPermition("D61AD468-275E-409D-B209-BE3C3A4000FF", User.Identity.Name)
                        End If
                        If bIsAgreementsAllow Then
                            Session("Allow_Agreements") = "1"
                        Else
                            Session("Allow_Agreements") = ""
                        End If



                        If Application("UCCEnabled") = "1" Then
                            Dim bIsUCCUser As Boolean, bIsUCCManager As Boolean
                            objUser.GetUCCPermitions("6EE0B64A-FD8B-44A8-BD44-3B6D7A5E2585", strUserName, bIsUCCUser, bIsUCCManager)
                            If bIsUCCUser Then
                                Session("Allow_UCC") = "1"
                            End If
                        End If
                        If objUser.GetDoctorAbroadPermition("0E5F36C2-C2CB-4523-8225-869884532B32", strUserName) Then
                            Session("Allow_DoctorAbroad") = "1"
                        Else
                            Session("Allow_DoctorAbroad") = "0"
                        End If
                        Session("User_Password") = ""
                        url = Application("FORMClaimMenu").ToString
                    Case "DIVUR"
                        objUser.GetBashanUserPermitions("83EC08DB-E750-45BA-8F6D-B4B6BF76D018", strUserName, bIndependent, bAllowClaims, bWebInterfaceAllow, bWebServiceAllow)
                        If Not bWebInterfaceAllow Then
                            ShowError("אין הרשאות, אנא פנה למנהל המערכת")
                            Return
                        End If
                        If bIndependent Then
                            Session("BSHN_Independed") = "1"
                        Else
                            Session("BSHN_Independed") = ""
                        End If
                        If bAllowClaims Then
                            Session("BSHN_AllowClaims") = "1"
                        Else
                            Session("BSHN_AllowClaims") = ""
                        End If

                        url = UrlForDoctor()

                    Case Else
                        url = Application("FORMRepStat")
                End Select
                If Application("DispatchGroupEnabled") <> "1" Then
                    Session("Allow_GroupManage") = "0"
                Else
                    Dim bAllowGroupManage As Boolean = objUser.GetGroupManagerPermitions("E930148E-EC71-4FD7-A1A8-874E8915F383", strUserName)
                    ' Group type 1 - Send Group, 2 - Community Group, 3 - Activities Group
                    Dim dsGroups As DataSet = objUser.GetManagerGroups("194EF901-55E5-4FB7-AD69-4563C0C64C69", strUserName, 2)
                    Dim iGroupCount As Integer = 0

                    If dsGroups.Tables.Count > 0 AndAlso dsGroups.Tables(0).Rows.Count > 0 Then
                        iGroupCount = dsGroups.Tables(0).Rows.Count
                    End If

                    If bAllowGroupManage And iGroupCount > 0 Then
                        Session("Allow_GroupManage") = "1"
                    Else
                        Session("Allow_GroupManage") = "0"
                    End If
                End If
                'If url.ToUpper().LastIndexOf("/DEFAULT.ASPX") > 0 Then
                '    url = Request.ApplicationPath & "/frmRepStat.aspx"
                'End If
                FormsAuthentication.SetAuthCookie(strUserName, False)


                ''*******************

                If Not setCheckUserDetails(strUserName) Then
                    Return
                End If

                ''********************


                url = CheckPasswordExpiration(url)


                Response.Redirect(url)
            Case -2
                ShowError("שם משתמש מוקפא, אנא פנה למנהל המערכת")

            Case Else
                ShowError("זיהוי משתמש נכשל")
        End Select
    End Sub

    Private Sub ShowError(ByVal strMessage As String, Optional ByVal bSetDesign As Boolean = False)
        If bSetDesign Then
            hidSetDesign.Value = "1"
        End If
        txtError.Value = strMessage
    End Sub

    Private Function CheckDoctorID() As Integer
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        If (AutoConnect) Then
            Return objUser.CheckDoctorID("EB2F60ED-E277-42EA-9310-EDBB15B97445", DomainUser)
        Else
            Return objUser.CheckDoctorID("EB2F60ED-E277-42EA-9310-EDBB15B97445", txtUser.Value.Trim())
        End If


    End Function

    Private Function UrlForDoctor() As String
        Dim iCheckDoctorResult As Integer = 0

        If Application("CheckDoctorID") = "1" Then
            iCheckDoctorResult = CheckDoctorID()
        End If

        Session("CheckDoctorResult") = iCheckDoctorResult

        Select Case iCheckDoctorResult
            Case 0
                If (Application("AllowUrgentMessage")) Then 'AndAlso "1".Equals(Application("InsuredStatusAsMainScreen"))) Then
                    Return "frmHDUrgentMessage.aspx"
                Else
                    Return Application("FORMStart")
                End If
                'Case 1, 2, 6
                '    If Session("User_Login_First_Time") = "1" Then
                '        Return Application("FORMStart")
                '    End If
                '    If Application("InsuredStatusAsMainScreen") = "1" Then
                '        'Return "frmHDUpdateDoctor.aspx?Type=" & CStr(iCheckDoctorResult)
                '        'Return Utils.Navigation.GetURL("frmUserProp.aspx")
                '        Return "frmHDUserProp.aspx"
                '    Else
                '        'Return "frmUpdateDoctorList.aspx?Type=" & CStr(iCheckDoctorResult)
                '        Return "frmAddDoctor.aspx?Type=" & CStr(iCheckDoctorResult)
                '    End If
            Case Else
                If Application("InsuredStatusAsMainScreen") = "1" Then
                    Return "frmHDUserProp.aspx"
                Else
                    Return "frmAddDoctor.aspx?Type=" & iCheckDoctorResult.ToString()
                End If
        End Select

    End Function

    Private Function GetNewPassword() As String

        Dim password As String = String.Empty
        Dim randomGenerator As Random = New Random()
        For i As Integer = 1 To 5
            password += randomGenerator.Next(0, 9).ToString()
        Next
        Return password

    End Function

    Private Function UpdateNewPassword(ByVal sNewPassword As String, ByVal strUserName As String) As Boolean

        Dim UserService As New UserConnect.UserService()
        UserService.Url = Utils.Values.GetApplicationString("UserWebService")
        Return UserService.UpdatePasswordExpired("5561A874-D4D7-4E5C-AA3D-4EC0EBAA8B7F", strUserName, sNewPassword, 1, strUserName)

    End Function

    Private Function CheckPasswordExpiration(ByVal Url As String) As String
        Dim sURL As String = Url
        Dim strUserName As String = txtUser.Value.Trim()


        If Application("HasCB") = "1" Then
            If IsFirstLogin() Then
                Session("User_Login_First_Time") = 1
                Session("Expiration_NextPage") = sURL
                Return (New Utils).GetLinkForNextForm("frmUserInfo.aspx", strUserName)
            End If
        End If

        If Not (Application("PasswordUpdateTermination") = "TRUE") Then
            'Or (Application("ChangePwdOnFirstLogin") = "TRUE" And IsFirstLogin()) Then
            Dim iRestDays As Integer
            Dim iRestTimes As Integer
            Dim objUser As New UserConnect.UserService()
            objUser.Url = Application("UserWebService").ToString()

            Dim nExempt As Integer = objUser.IsUserExempt("499CF921-9632-4C93-949D-BB1A3166F363", strUserName)
            Dim sUserPropURL As String = Utils.Navigation.GetURL("frmUserProp.aspx")

            If (nExempt < 1) And sUserPropURL.StartsWith(sURL) Then
                Dim iExpirationLevel As Integer = objUser.GetExpirationLevel("829F6AC7-EAE3-4E9F-8EF5-4B30245AE7D8", strUserName, iRestDays, iRestTimes, strUserName)
                If iExpirationLevel > 0 Then
                    Session("ExpirationLevel") = iExpirationLevel
                    Session("Expiration_NextPage") = sURL
                    Session("ExpirationRestDays") = iRestDays
                    Session("ExpirationRestTimes") = iRestTimes

                    If "1".Equals(Application("InsuredStatusAsMainScreen")) Then
                        sURL = "frmHDExpirePwd.aspx"
                    Else
                        sURL = "frmExpirePwd.aspx"
                    End If


                End If
            End If
        End If
        Return sURL
    End Function

    Private Function CreateHtmlForReport(ByVal sSource) As String
        Return "<html><body><p align='right' dir='rtl'>" & sSource & "</p></body></html>"
    End Function

    Private Function IsFirstLogin() As Boolean
        IsFirstLogin = (Session("Last_Login_Date") = "")
    End Function

    Private Sub FreeDefferedUser(ByVal sUserName As String)
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        objUser.SetUserMustLoginByLinkField("60851C72-8FC7-45C9-A0C2-B8D394931A06", sUserName, 0)
    End Sub

    Private Sub CheckWindowName()
        If Session("winname") = "" Then
            If (hidWinName.Value <> "") Then
                Session("winname") = hidWinName.Value
            End If
        Else
            If hidWinName.Value <> Session("winname") Then
                Response.Redirect("frmInvalidOperation.aspx")
            End If
        End If
    End Sub

    Protected Overrides Sub OnError(ByVal e As System.EventArgs)
        Response.Clear()
        Dim strResult As String = "<html><head>"
        strResult += "<meta http-equiv='Cache-Control' content='no-cache'>" & vbCrLf
        strResult += "<meta http-equiv='Pragma' content='no-cache'>" & vbCrLf
        strResult += "<meta http-equiv='Expires' content='0'>" & vbCrLf
        strResult += "<meta http-equiv='Content-Type' content='text/html; charset=windows-1255'/></head><body dir=rtl>"
        strResult += "<DIV style='font-family:Arial;font-size:16pt;font-weight:bold;width:100%;text-align:center'>מבוצע כעת עדכון למערכת, נסה שוב מאוחר יותר</DIV><BR><DIV style='font-family:Arial;font-size:9pt'>" & txtFormIdentity.Value & "</DIV></body></html>"
        Response.Write(strResult)
        'Dim ex As Exception = Server.GetLastError
        'Response.Write(ex.Message)
        'Response.End()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        Session("UserRegLevel") = "1"


        Session.Remove("HDSHEM")
        Session.Remove("HDInsuredID")
        Session.Remove("HDMISP")
        Session.Remove("HDPolGovTreatment")





        Dim bCertificateAuthentication As Boolean = False
        Dim stTicket As String
        Dim stLink As String
        Dim Parts() As String

        If (Application("AutoConnect") = "1" And "" & Request.QueryString("USERticket") <> "") Then

            stTicket = "" & Request.QueryString("USERticket")

            stLink = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(stTicket))

            stLink = cryptComtec.RijndaelSimple.DencryptSimple(stLink)

            Parts = Split(stLink, "$")

            Dim timesent As DateTime = Parts(1)
            Dim timenow As DateTime = DateTime.Now.TimeOfDay.ToString()

            Dim res As Integer = DateDiff(DateInterval.Second, timesent, timenow)

            If (Parts(1) <> "" And res <= CInt(Application("Timeinterval"))) Then
                AutoConnect = True
            End If


        End If

        If Application("App_Type").ToString.ToUpper = "DIVUR" Then

            If (AutoConnect) Then



                Dim username As String = Parts(0)

                'Dim username As String = User.Identity.Name


                Dim objDomainUser As New UserConnect.UserService()
                objDomainUser.Url = Application("UserWebService").ToString()

                Dim drUserDomainUser As DataSet = objDomainUser.GetUserByDomainUser2("90EDDCF0-7437-4A59-BDCF-23C351BDEC8F", username)


                If Not IsNothing(drUserDomainUser) Then
                    DomainUser = drUserDomainUser.Tables(0).Rows(0).Item(0)
                    cmdOK_ServerClick(Me, e.Empty)
                Else
                    Response.Redirect("frmNoPermission.aspx")

                End If




            End If

        End If


        If Not IsPostBack Then

            GetEnvironment()
            bIsLoginFromEmail = checkLoginFromEmail()

            If bIsLoginFromEmail Then
                cmdOK_ServerClick(Nothing, Nothing)
            End If

            Dim strExternalLink As String = Request.QueryString("lnk") & ""
            Session("ExternalLink") = strExternalLink

            If strExternalLink <> "" Then
                Dim stLinkDecripted As String = cryptComtec.RijndaelSimple.DencryptSimple(strExternalLink)
                Dim stParts As String()
                stParts = Split(stLinkDecripted, "$")
                If stParts.Length > 1 Then
                    txtUser.Value = Trim(stParts(2))

                End If
            End If


            If Not Application("DoctorService") Is Nothing Then
                cmdDoctorService.Visible = True
                cmdDoctorService.Attributes.Add("onclick", "window.open('" & CType(Application("DoctorService"), String) & "')")

            Else
                cmdDoctorService.Visible = False
            End If


            SiteInfo.InnerHtml = Application("SiteInfo").ToString() & "&nbsp;"
            Dim iCertFlags As Integer = 0
            Try
                iCertFlags = Integer.Parse(Request.ServerVariables("CERT_FLAGS"))
            Catch
            End Try

            If Request.ServerVariables("LOGON_USER").Length > 0 AndAlso _
               CBool(iCertFlags And 1) AndAlso _
               Request.ServerVariables("CERT_COOKIE").Length > 0 Then

                bCertificateAuthentication = True
            End If

            'trExtraID.Visible = False

            Dim strMessage As String
            Dim bLoginMessageEnabled As Boolean
            Dim objUser As New UserConnect.UserService()
            objUser.Url = Application("UserWebService").ToString()

            bLoginMessageEnabled = objUser.IfLoginMessageEnabled("A92B8EED-535F-4F77-9CFB-D3A4B51CD3FD")
            If Application("HasCB") = "1" Then
                lblMessage.Visible = True
                strMessage = "ברוכים הבאים<br> "
                strMessage = strMessage & " הנך מתחבר למערכת מידע ממנה עולה מידע אישי רגיש. "
                strMessage = strMessage & " נא הקפד שאין סביבך אנשים שאינם מורשים לראות המידע. "
                strMessage = strMessage & "העברת מידע רגיש לבלתי מורשים מנוגדת לדבר "
                strMessage = strMessage & "החוק בנושא שמירת הפרטיות ולמדיניות אבטחת המידע בכללית.<br>"
                strMessage = strMessage & "בברכה,<br> הממונה על אבטחת המידע בכללית.	"
                lblMessage.InnerHtml = strMessage
            Else
                If bLoginMessageEnabled Then
                    strMessage = objUser.GetLoginMessage("CA8919FA-1862-43F7-8097-A96474DA77B5")
                    If Trim(strMessage) <> "" Then

                        lblMessage.InnerHtml = HttpUtility.HtmlDecode(strMessage)

                    Else
                        lblMessage.Visible = False
                        '#If FALSE Then
                        lblMessageFrame.Visible = False
                        '#End If

                    End If

                Else
                    lblMessage.Visible = False
                    '#If FALSE Then
                    lblMessageFrame.Visible = False
                    '#End If

                End If
            End If




            FormsAuthentication.SignOut()

            'aIconLink.HRef = Application("ClientSiteLink")
            If Application("HasHKL") = "1" Then
                'aIconLink2.HRef = Application("ClientSiteLink")
            Else
                'aIconLink2.Visible = False
            End If

            'If Application("RightLogo") = "1" Then

            '    divRIcon.Visible = True
            'Else

            '    divRIcon.Visible = False
            'End If
            cmdHelp.Visible = False
            Select Case Application("App_Type").ToString().ToUpper()
                Case "KUPA_INFO"
                    cmdHelp.Disabled = True
                    'divRIcon.Visible = True
                    'aIconLink.Visible = False

                    trDivurTitle.Visible = False
                    trHodTitle.Visible = False
                    trDistTitle.Visible = True
                    trDoarTitle.Visible = False
                    trInPostTitle.Visible = False
                    trSuppTitle.Visible = False


                Case "DIST"
                    'cmdHelp.Disabled = True
                    cmdSendPassword.Visible = False

                    trDivurTitle.Visible = False
                    trDistTitle.Visible = True
                    trDoarTitle.Visible = False
                    trInPostTitle.Visible = False
                    trSuppTitle.Visible = False

                    lstSystem.Items.Add(New ListItem("הראל", "TS"))
                    lstSystem.Items(0).Selected = True
                Case "DIVUR"
                    cmdHelp.Disabled = False

                    If Application("Smile") = "1" Then
                        trHodTitle.Visible = True
                        trDivurTitle.Visible = False
                    ElseIf Application("CompanyID") & "" = "3" Then
                        trHodTitle.Visible = True
                        trDivurTitle.Visible = False
                    Else
                        trHodTitle.Visible = False
                        trDivurTitle.Visible = True
                    End If

                    trDistTitle.Visible = False
                    trDoarTitle.Visible = False
                    trInPostTitle.Visible = False
                    trSuppTitle.Visible = False

                Case "DOAR"
                    cmdSendPassword.Visible = True

                    trDivurTitle.Visible = False
                    trHodTitle.Visible = False
                    trDistTitle.Visible = False
                    trDoarTitle.Visible = True
                    trInPostTitle.Visible = False
                    trSuppTitle.Visible = False

                Case "INPOST"
                    cmdSendPassword.Visible = True

                    trDivurTitle.Visible = False
                    trHodTitle.Visible = False
                    trDistTitle.Visible = False
                    trDoarTitle.Visible = False
                    trInPostTitle.Visible = True
                    trSuppTitle.Visible = False

                Case "CLAIM", "ENG"
                    cmdHelp.Disabled = False
                    If Application("AllowExtraID") = "1" Then
                        'trExtraID.Visible = True
                    End If


                    trDivurTitle.Visible = False
                    trHodTitle.Visible = False
                    trDistTitle.Visible = True
                    trDoarTitle.Visible = False
                    trInPostTitle.Visible = False
                    trSuppTitle.Visible = False

                Case "SUPP"
                    cmdSendPassword.Visible = True
                    'trExtraID.Visible = True


                    trDivurTitle.Visible = False
                    trHodTitle.Visible = False
                    trDistTitle.Visible = False
                    trDoarTitle.Visible = False
                    trInPostTitle.Visible = False
                    trSuppTitle.Visible = True

            End Select
        Else

        End If

        txtAppType.Value = Application("App_Type").ToString

        If bCertificateAuthentication Then
            CustomAuthentication()
        End If
    End Sub

    Private Function IsSentPasswordExpired(ByVal UserName As String) As Boolean

        Dim UserService As New UserConnect.UserService()
        UserService.Url = Utils.Values.GetApplicationString("UserWebService")
        Return UserService.GetSentPasswordStatus("482A3B7B-553A-4DCB-BA9A-669FDDB7AEA3", UserName)

    End Function

    Private Sub cmdOK_ServerClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOK.ServerClick

        CheckWindowName()


        Dim strUserName As String = txtUser.Value.Trim()
        Dim strPassword As String = txtPass.Value.Trim()
        Dim strExtraIdAnswer As String = ""
        Dim flagExtra As Boolean = False
        Dim iOrganizationCode As Integer = 0
        Dim sAgreementCode As String = ""
        Dim strExternalLink As String = Session("ExternalLink") & ""
        Dim strExternalUserName As String = ""
        Dim strExternalAction As String = ""
        Dim strExternalRepID As String = ""
        'Dim strExternalReportType As String = ""
        Dim bIsExternalCall As Boolean

        If (AutoConnect) Then
            strUserName = DomainUser
            strPassword = "99999"
        End If

        If IsSentPasswordExpired(strUserName) Then
            strPassword = "**********"
        End If

        Dim objReportService As New ReportConnect.ReportService()
        objReportService.Url = Application("ReportWebService").ToString()

        If strExternalLink <> "" Then
            Dim stLinkDecripted As String = cryptComtec.RijndaelSimple.DencryptSimple(strExternalLink)
            Dim stParts As String()
            stParts = Split(stLinkDecripted, "$")
            strExternalAction = UCase(stParts(1))
            strExternalUserName = Trim(stParts(2))
            If (strExternalAction = "V" Or strExternalAction = "R") And strExternalUserName <> "" Then
                bIsExternalCall = True
            End If
            If strExternalAction = "R" Then
                strExternalRepID = stParts(3)
                If Not IsNumeric(strExternalRepID) Then
                    bIsExternalCall = False
                End If
            End If
        End If

        'strExtraIdAnswer = ExtraIdAnswer.Value.Trim()

        If txtLoginIdentity.Value = "1" Then
            ' locked and locked period expired and password is right
            strPassword = hidPassword.Value
            strExtraIdAnswer = hidExtraIdAnswer.Value
        End If
        '

        If Len(strUserName) = 0 Then
            ShowError("שם משתמש חסר")
            Return
        End If

        If Len(strPassword) = 0 Then
            ShowError("חסרה סיסמה")
            Return
        End If

        If Regex.IsMatch(strUserName, "(\s)") Then
            ShowError("שם משתמש שגוי")
            Return
        End If

        If bIsExternalCall Then
            If UCase(strExternalUserName) <> UCase(strUserName) Then
                ShowError("שם משתמש שגוי")
                Return
            End If
        End If

        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

		Dim strUserID As String = objUser.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", strUserName)
		
		'If user doesn't  exists ...
		if (strUserID="") Then
		   ShowError("זיהוי משתמש נכשל")
		   Return
		End If
        Dim strDate As String = ""
        Dim strTime As String = ""
        Dim ExtraIdAnswerFromTable As String

        objUser.GetLastLoginDate("87EF4B7B-91C5-4399-B223-1F670D410191", strUserName, strDate, strTime)
        Session("UploadFileSize") = CStr(CType(objUser.GetUploadFileSize("CA76C311-D7D8-425E-BD0B-AE04E9C567AC", strUserName), Long) * 1024)
        Session("Last_Login_Date") = strDate
        Session("Last_Login_Time") = strTime
        Session("Show_Message") = ""
        Session("Report_List_Current_User") = ""
        Session("Message_Text") = ""
        Session("WebInterfaceAllow") = ""
        Session("User_Login_First_Time") = ""
        Session("Allow_Action_Type_Upload") = ""
        Session("Allow_Download_Files") = ""
        Session("Worker_Type") = ""
        Session("Allow_Yoetz") = ""
        Session("Allow_Tikshuv") = ""
        Session("Allow_Attach_Archive") = ""
        Session("Allow_UCC") = ""
        Session("Allow_ForeignWorkers_Claims") = ""
        Session("Login_User") = strUserName
        Session("Filter_Report_ID") = ""

        Dim url As String
        Dim bIndependent As Boolean
        Dim bAllowClaims As Boolean
        Dim bWebInterfaceAllow As Boolean
        Dim bWebServiceAllow As Boolean


        Dim iMaxLoginNum As Integer
        Dim strSiteType = Application("SiteType")

        iMaxLoginNum = objUser.GetMaxLoginNum("93FE06B2-C888-430E-9322-3572B81E94D5")
        Dim iCrntActiveSession As Integer
        iCrntActiveSession = objUser.GetActiveSessionsNum("D0914F22-78A5-46AE-9813-51B5E09C7A10", strUserName, Session.SessionID, Val(strSiteType))

        If iCrntActiveSession >= iMaxLoginNum Then
            ShowError("מספר כניסות של המשתמש גדול מן המותר")
            Return
        End If

        Dim iRet As Integer
        Dim strFileContent As String
        Dim iRepId As Integer
        Dim flag_Success As Integer
        Dim strTest As String
        Dim secretNumber, iCountTest As Integer
        Dim sCountTest As String

        If txtLoginIdentity.Value = "1" Then
            ' locked and locked period expired and password is right
            ' we test identity
            strTest = txtTest.Value
            secretNumber = CInt(Session("SecretNumber"))

            If strTest = CStr(secretNumber) Then
                ' test identity ok
                ' proceed with Login
                ' UnLock Account
                If objUser.ReleasePeriodLockUser("5037AD93-EC38-4002-8628-7C6E112A1514", strUserName, "Infobay", strUserName) Then
                    txtLoginIdentity.Value = ""
                    strPassword = hidPassword.Value
                    txtUser.Attributes.Item("readOnly") = "False"
                    txtPass.Attributes.Item("readOnly") = "False"
                    'ExtraIdAnswer.Attributes.Item("readOnly") = "False"
                    divTest.Style.Item("display") = "none"

                End If
            Else
                ' testIdentity fail
                sCountTest = txtCountTest.Value
                If sCountTest = "" Then
                    sCountTest = "0"
                End If
                iCountTest = CInt(sCountTest)
                iCountTest += 1
                txtCountTest.Value = iCountTest.ToString
                Return
            End If
        End If

	'Update tblUsers from as400
	If Not setCheckUserDetails(strUserName) Then
            Return
        End If
		
        Dim stTicket As String = Request.QueryString("ticket")
        If stTicket Is Nothing Then
            stTicket = ""
        End If

        If (AutoConnect) Then
            iRet = 0
        Else
            iRet = objUser.CheckPeriodLockUserWithReasons("09C0C442-72E0-44FE-B3FB-37FFC342939E", strUserName, strPassword, Session.SessionID, Val(strSiteType), Request.UserHostAddress, stTicket)
        End If

        If iRet = -2 Then
            Dim dsExp As DataSet = objUser.GetExpirationParameters("30305F5F-69A9-4637-AFDA-A6A195D8F2CB")
            Dim nDelayTime As Integer = 0

            If (dsExp.Tables.Count > 0) AndAlso (dsExp.Tables(0).Rows.Count > 0) Then
                nDelayTime = dsExp.Tables(0).Rows(0)("LockLoginFailPeriod")
            End If
            Dim sMessge As String
            sMessge = String.Format("גישתך למערכת נחסמה למשך {0} דקות", nDelayTime)
            ShowError(sMessge)
            Return
        ElseIf iRet = -3 Then
            ' locked and locked period expired and password is not right
            objUser.UpdateLockUser("EB2F60ED-E277-42EA-9310-EDBB15B97445", strUserName)
            Dim dsExp As DataSet = objUser.GetExpirationParameters("30305F5F-69A9-4637-AFDA-A6A195D8F2CB")
            Dim nDelayTime As Integer = 0

            If (dsExp.Tables.Count > 0) AndAlso (dsExp.Tables(0).Rows.Count > 0) Then
                nDelayTime = dsExp.Tables(0).Rows(0)("LockLoginFailPeriod")
            End If
            Dim sMessge = String.Format("גישתך למערכת נחסמה למשך {0} דקות", nDelayTime)
            ShowError(sMessge)
            Return
        ElseIf iRet = -10 Then
            ShowError("חשבון נעול")
            Return
        ElseIf iRet = -15 Or iRet = -16 Then
            ' -15 - user must login with link, but doesn't 
            ' -16  - something wrong with link
            ShowError("כניסה נכשלה")
            Return
        ElseIf iRet = -20 Then '- Denied=4
            ShowError("חשבון נעול בשל חוסר פעילות, " + vbCrLf + " נא פנה למנהל המערכת")
            Return
        ElseIf iRet = -22 Then 'Denied=8          
            Dim bShowDate As Boolean = True
            Dim dtEndInsuranceDate As DateTime
            Dim dsInsDate As DataSet = objUser.GetEndInsuranceDateForUser("F0AB1F5E-688E-47DA-8CD4-7E26EE42BACE", strUserName)
            If (dsInsDate.Tables.Count > 0) AndAlso (dsInsDate.Tables(0).Rows.Count > 0) Then
                If (dsInsDate.Tables(0).Rows(0)("EndInsuranceDate") Is DBNull.Value) Then
                    dtEndInsuranceDate = DateTime.Today
                    bShowDate = False
                Else
                    dtEndInsuranceDate = dsInsDate.Tables(0).Rows(0)("EndInsuranceDate")
                    bShowDate = (dtEndInsuranceDate > New DateTime(1900, 1, 1))
                End If
            Else
                dtEndInsuranceDate = DateTime.Today
                bShowDate = False
            End If
            If (bShowDate) Then
                Dim stEndInsuranceDate As String = dtEndInsuranceDate.ToString("dd/MM/yyyy")

                ShowError("ביטוח האחריות המקצועית שלך פג בתאריך  " + stEndInsuranceDate + vbCrLf + _
                          "למרות הודעותינו טרם שלחת אלינו ביטוח אחריות מקצועית בתוקף" + vbCrLf + _
                          "אי לכך לא נוכל לאפשר את המשך פעילותך איתנו" + vbCrLf + _
                          "נא לשלוח ביטוח אחריות מקצועית בתוקף לפקס מספר 03-7348603", True)
            Else
                ShowError("ביטוח האחריות המקצועית שלך פג" + vbCrLf + _
                    "למרות הודעותינו טרם שלחת אלינו ביטוח אחריות מקצועית בתוקף" + vbCrLf + _
                    "אי לכך לא נוכל לאפשר את המשך פעילותך איתנו" + vbCrLf + _
                    "נא לשלוח ביטוח אחריות מקצועית בתוקף לפקס מספר 03-7348603", True)
            End If

            Return

            '-20 - Denied=4
            ' -21 - EndInsuranceDate in the past but less than month - not here  
            ' -22 - Denied=8            
        ElseIf iRet > 0 Then
            ' locked and locked period expired and password is right
            hidPassword.Value = strPassword
            hidExtraIdAnswer.Value = strExtraIdAnswer
            txtUser.Attributes.Item("readOnly") = "True"
            txtPass.Attributes.Item("readOnly") = "True"
            'ExtraIdAnswer.Attributes.Item("readOnly") = "True"
            txtLoginIdentity.Value = "1"
            divTest.Style.Item("display") = "block"
            ShowError("")
            Return
        End If

        'Dim strUserID As String = objUser.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", strUserName)


        If strExtraIdAnswer <> ExtraIdAnswerFromTable Then
            ' I want the same result as if the password was wrong
            strPassword = "***" + strPassword + "***"
        End If

        'Add OS and Browser Info To CheckUserEx-->UpdateLastLogin
        Dim sOS As String = hidOS.Value
        Dim sBrowserNM As String = hidBrowserNM.Value
        Dim sBrowserVer As String = hidBrowserVer.Value

        Dim bSaveUrl As Boolean = False


        If stTicket <> "" Then 'here we should check with ExtraAnswer
            Dim bExtraAnswerOk = ((Not flagExtra) OrElse (strExtraIdAnswer = ExtraIdAnswerFromTable))
            If bExtraAnswerOk Then
                iRet = objUser.CheckUserEx("79D565C1-784C-4606-935B-68BA32141600", strUserName, strPassword, Session.SessionID, Val(strSiteType), Request.UserHostAddress, strUserName, stTicket, sOS, sBrowserNM, sBrowserVer)
            Else
                iRet = -18 'Extra Id not Ok
            End If
        Else
            If (AutoConnect) Then
                iRet = objUser.CheckUserEx2("9FAD6C4C-D3AC-4296-B1B1-36DD45CCF35F", strUserName, "", Session.SessionID, Val(strSiteType), Request.UserHostAddress, strUserName, stTicket, sOS, sBrowserNM, sBrowserVer)
            Else
                iRet = objUser.CheckUserExWithReasons("B2862692-9AA2-46C7-9D2B-15C06C9088D0", strUserName, strPassword, Session.SessionID, Val(strSiteType), Request.UserHostAddress, strUserName, stTicket, sOS, sBrowserNM, sBrowserVer)
            End If
        End If

        If iRet = -4 Then
            ' User does not exists
            Dim iCountErr As Integer = Val(Session("hidCountErr")) + 1
            Dim iNoFailPassword As Integer = objUser.GetNoFailPassword("79D565C1-784C-4606-935B-68BA32141600")
            Session("hidCountErr") = iCountErr.ToString
            If (iCountErr = iNoFailPassword + 1) Or ((iCountErr >= 1000) And (iCountErr Mod 1000) = 0) Then
                ' Count of consequtive fail of users more then allow
                Dim sRepContent As String = "מועד הפקה: " + DateTime.Now.ToString("dd/MM/yyy hh:mm") + "<br>"
                sRepContent += "משתמש שאינו קיים במערכת ניסה להיכנס לפחות " + iCountErr.ToString + " פעמים. מכתובת " + Request.UserHostAddress + "<br>"
                sRepContent += "השם האחרון שנקלט הוא " + txtUser.Value.Trim()

                strFileContent = CreateHtmlForReport(sRepContent)
                iRepId = objReportService.AddNewFileReport2User("CD48CB4B-CF9A-4E8E-98D2-D35E42DE9F8C", _
                "Infobay", "Infobay", "ניסיונות פריצה למערכת", 996, 0, strFileContent, 0, False, False, True, flag_Success, "I", txtUser.Value.Trim())
                Try
                    Dim sLogMessage As String = String.Format("Non-existing  User {0} tried to logon from IP {1}", strUserName, Request.UserHostAddress)
                    If Not EventLog.SourceExists("Application") Then
                        EventLog.CreateEventSource("Application", "Application")
                    End If
                    Dim myEventLog As New EventLog()
                    myEventLog.Source = "InfoBay"
                    myEventLog.WriteEntry(sLogMessage, EventLogEntryType.Warning, 12)
                Catch ex As Exception
                End Try
            End If
        ElseIf iRet = -22 Then
            '  Denied =8        
        ElseIf iRet = 21 Then
            ' EndInsuranceDate is Earlier now and later than moth ago
            Session("hidCountErr") = "0"
            Dim dtEndInsuranceDate As DateTime
            Dim dsInsDate As DataSet = objUser.GetEndInsuranceDateForUser("F0AB1F5E-688E-47DA-8CD4-7E26EE42BACE", strUserName)
            If (dsInsDate.Tables.Count > 0) AndAlso (dsInsDate.Tables(0).Rows.Count > 0) Then
                If (dsInsDate.Tables(0).Rows(0)("EndInsuranceDate") Is DBNull.Value) Then
                    dtEndInsuranceDate = DateTime.Today
                Else
                    dtEndInsuranceDate = dsInsDate.Tables(0).Rows(0)("EndInsuranceDate")
                End If
            Else
                dtEndInsuranceDate = DateTime.Today
            End If

            Dim stEndInsuranceDate As String = dtEndInsuranceDate.ToString("dd/MM/yyyy")
            ShowError("תוקף ביטוח האחריות המקצועית שלך פג בתאריך " + stEndInsuranceDate + vbCrLf + _
                      "נא לשלוח ביטוח אחריות מקצועית בתוקף לפקס שמספרו 03-7348603" + vbCrLf + _
                      "אם לא נקבל ביטוח אחריות מקצועית בתוקף  עד לתאריך " + dtEndInsuranceDate.AddMonths(1).ToString("dd/MM/yyyy") + _
                      " מערכת הוד תחסם אוטומטית ולא נוכל לאפשר את המשך פעילותך אתנו", True)
            iRet = 0
            bSaveUrl = True
        Else
            Session("hidCountErr") = "0"
        End If

        ' Delete (if exists) data for RequestBashanInWork
        ' Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        ' objTreatmentService.Url = Context.Application("TreatmentWebService").ToString()
        ' Dim DelRequestBashanInWork As Boolean = objTreatmentService.DelRequestBashanInWork("1BE727A9-81B3-44FF-968A-A68E73ED8B95", String.Empty, 0, strUserName)

        Select Case iRet
            Case 0
                Try
                    objUser.UpdateUserIP("3117568E-B76C-4041-B305-F6FF36EC32B7", Val(strUserID), Session.SessionID, Request.UserHostAddress)
                    'If Application("HasHani").ToString() = "1" Then
                    '    Session("CompanyLogo") = "pics/" & objUser.GetLogoName("17060B94-065E-4DB4-975D-A3988FFD63CC", strUserName)
                    'End If
                Catch
                End Try

                Session("Filter_From_Date") = ""
                Session("Filter_To_Date") = ""
                Session("Filter_Report_Type") = ""
                Session("Filter_On") = ""
                Session("Filter_Viewed") = ""
                Session("Filter_NotViewed") = ""
                Session("AS400_User") = ""

                objUser.GetBashanUserPermitions("83EC08DB-E750-45BA-8F6D-B4B6BF76D018", strUserName, bIndependent, bAllowClaims, bWebInterfaceAllow, bWebServiceAllow)
                If Not bWebInterfaceAllow Then

                    ShowError("אין הרשאות, אנא פנה למנהל המערכת")

                    Return
                End If
                Session("WebInterfaceAllow") = "1"
                If bIndependent Then
                    Session("BSHN_Independed") = "1"
                Else
                    Session("BSHN_Independed") = ""
                End If
                If bAllowClaims Then
                    Session("BSHN_AllowClaims") = "1"
                Else
                    Session("BSHN_AllowClaims") = ""
                End If
                If objUser.GetActionTypeUserPermitions("5FBAA090-A9ED-41B8-8769-381FCAFCB54C", strUserName) Then
                    Session("Allow_Action_Type_Upload") = "1"

                End If

                url = UrlForDoctor()
                If Application("DispatchGroupEnabled") <> "1" Then
                    Session("Allow_GroupManage") = "0"
                Else
                    Dim bAllowGroupManage As Boolean = objUser.GetGroupManagerPermitions("E930148E-EC71-4FD7-A1A8-874E8915F383", strUserName)
                    ' Group type 1 - Send Group, 2 - Community Group, 3 - Activities Group
                    Dim dsGroups As DataSet = objUser.GetManagerGroups("194EF901-55E5-4FB7-AD69-4563C0C64C69", strUserName, 2)
                    Dim iGroupCount As Integer = 0

                    If dsGroups.Tables.Count > 0 AndAlso dsGroups.Tables(0).Rows.Count > 0 Then
                        iGroupCount = dsGroups.Tables(0).Rows.Count
                    End If

                    If bAllowGroupManage And iGroupCount > 0 Then
                        Session("Allow_GroupManage") = "1"
                    Else
                        Session("Allow_GroupManage") = "0"
                    End If
                End If

                FormsAuthentication.SetAuthCookie(strUserName, False)



                ''*******************

             '   If Not setCheckUserDetails(strUserName) Then
             '       Return
             '   End If

                ''********************


                If (AutoConnect = False) Then
                    url = CheckPasswordExpiration(url)
                End If

                If (bSaveUrl) Then
                    hidSaveUrl.Value = url
                Else
                    If (url.IndexOf("?") > -1) Then
                        url = url + "&FromLogin=1"
                    Else
                        url = url + "?FromLogin=1"
                    End If
                    Response.Redirect(url)
                End If

            Case 100
                Try
                    objUser.UpdateUserIP("3117568E-B76C-4041-B305-F6FF36EC32B7", Val(strUserID), Session.SessionID, Request.UserHostAddress)
                Catch
                End Try

                Session("Filter_From_Date") = ""
                Session("Filter_To_Date") = ""
                Session("Filter_Report_Type") = ""
                Session("Filter_On") = ""
                Session("Filter_Viewed") = ""
                Session("Filter_NotViewed") = ""
                Session("AS400_User") = "1"

                objUser.GetBashanUserPermitions("83EC08DB-E750-45BA-8F6D-B4B6BF76D018", strUserName, bIndependent, bAllowClaims, bWebInterfaceAllow, bWebServiceAllow)
                If Not bWebInterfaceAllow Then
                    ShowError("אין הרשאות, אנא פנה למנהל המערכת")
                    Return
                End If

                Session("WebInterfaceAllow") = "1"
                If bIndependent Then
                    Session("BSHN_Independed") = "1"
                Else
                    Session("BSHN_Independed") = ""
                End If
                If bAllowClaims Then
                    Session("BSHN_AllowClaims") = "1"
                Else
                    Session("BSHN_AllowClaims") = ""
                End If
                If objUser.GetActionTypeUserPermitions("5FBAA090-A9ED-41B8-8769-381FCAFCB54C", strUserName) Then
                    Session("Allow_Action_Type_Upload") = "1"
                End If

                url = UrlForDoctor()
                FormsAuthentication.SetAuthCookie(strUserName, False)



                ''*******************

                If Not setCheckUserDetails(strUserName) Then
                    Return
                End If

                ''********************

                url = CheckPasswordExpiration(url)
                Response.Redirect(url)

            Case 10
                ' YT:
                If Application("HasForigenWorkers") = "1" Then
                    If objUser.GetForeignWorkersPermition("86A6813B-DA04-4C83-BEBE-DEF2C995C2B1", strUserName) Then
                        Session("Allow_ForeignWorkers_Claims") = "1"
                    End If
                End If

                Try
                    objUser.UpdateUserIP("3117568E-B76C-4041-B305-F6FF36EC32B7", Val(strUserID), Session.SessionID, Request.UserHostAddress)
                Catch
                End Try

                Session("Filter_From_Date") = ""
                Session("Filter_To_Date") = ""
                Session("Filter_Report_Type") = ""
                Session("Filter_On") = ""
                Session("Filter_Viewed") = ""
                Session("Filter_NotViewed") = ""
                Session("User_Prop_Caller") = Application("FORMLogin")
                Session("User_Login_First_Time") = "1"

                objUser.GetBashanUserPermitions("83EC08DB-E750-45BA-8F6D-B4B6BF76D018", strUserName, bIndependent, bAllowClaims, bWebInterfaceAllow, bWebServiceAllow)
                If Not bWebInterfaceAllow Then
                    ShowError("אין הרשאות, אנא פנה למנהל המערכת")
                    Return
                End If

                Session("WebInterfaceAllow") = "1"
                If bIndependent Then
                    Session("BSHN_Independed") = "1"
                Else
                    Session("BSHN_Independed") = ""
                End If
                If bAllowClaims Then
                    Session("BSHN_AllowClaims") = "1"
                Else
                    Session("BSHN_AllowClaims") = ""
                End If
                If objUser.GetActionTypeUserPermitions("5FBAA090-A9ED-41B8-8769-381FCAFCB54C", strUserName) Then
                    Session("Allow_Action_Type_Upload") = "1"
                End If

                url = UrlForDoctor()
                FormsAuthentication.SetAuthCookie(strUserName, False)

                ''*******************

                If Not setCheckUserDetails(strUserName) Then
                    Return
                End If

                ''********************

                url = CheckPasswordExpiration(url)
                Response.Redirect(url)

            Case -2, -20
                Dim dsExp As DataSet = objUser.GetExpirationParameters("30305F5F-69A9-4637-AFDA-A6A195D8F2CB")
                Dim nDelayTime As Integer = 0

                If (dsExp.Tables.Count > 0) AndAlso (dsExp.Tables(0).Rows.Count > 0) Then
                    nDelayTime = dsExp.Tables(0).Rows(0)("LockLoginFailPeriod")
                End If

                Dim sLogMessage As String = String.Format("User {0} was blocked for {1} minutes after consecutive errors in password", strUserName, nDelayTime)
                If Not EventLog.SourceExists("Application") Then
                    EventLog.CreateEventSource("Application", "Application")
                End If
                Try
                    Dim myEventLog As New EventLog()
                    myEventLog.Source = "InfoBay"
                    myEventLog.WriteEntry(sLogMessage, EventLogEntryType.Warning, 10)
                Catch
                End Try

                Dim sMessge = ""
                If (iRet = -2) Then
                    sMessge = String.Format("גישתך למערכת נחסמה. אנא פנה למנהל המערכת ")
                Else
                    sMessge = String.Format("גישתך למערכת נחסמה למשך {0} דקות", nDelayTime)
                End If
                ShowError(sMessge)

                ' cases 21,-22,-23 relevant for "DIVUR" only
            Case -22  'Denied=8  
                Dim bShowDate As Boolean = True
                Dim dtEndInsuranceDate As DateTime
                Dim dsInsDate As DataSet = objUser.GetEndInsuranceDateForUser("F0AB1F5E-688E-47DA-8CD4-7E26EE42BACE", strUserName)
                If (dsInsDate.Tables.Count > 0) AndAlso (dsInsDate.Tables(0).Rows.Count > 0) Then
                    If (dsInsDate.Tables(0).Rows(0)("EndInsuranceDate") Is DBNull.Value) Then
                        dtEndInsuranceDate = DateTime.Today
                        bShowDate = False
                    Else
                        dtEndInsuranceDate = dsInsDate.Tables(0).Rows(0)("EndInsuranceDate")
                        bShowDate = (dtEndInsuranceDate > New DateTime(1900, 1, 1))
                    End If
                Else
                    dtEndInsuranceDate = DateTime.Today
                    bShowDate = False
                End If
                If (bShowDate) Then
                    Dim stEndInsuranceDate As String = dtEndInsuranceDate.ToString("dd/MM/yyyy")

                    ShowError("ביטוח האחריות המקצועית שלך פג בתאריך  " + stEndInsuranceDate + vbCrLf + _
                              "למרות הודעותינו טרם שלחת אלינו ביטוח אחריות מקצועית בתוקף" + vbCrLf + _
                              "אי לכך לא נוכל לאפשר את המשך פעילותך איתנו" + vbCrLf + _
                              "נא לשלוח ביטוח אחריות מקצועית בתוקף לפקס מספר 03-7348603", True)
                Else
                    ShowError("ביטוח האחריות המקצועית שלך פג" + vbCrLf + _
                        "למרות הודעותינו טרם שלחת אלינו ביטוח אחריות מקצועית בתוקף" + vbCrLf + _
                        "אי לכך לא נוכל לאפשר את המשך פעילותך איתנו" + vbCrLf + _
                        "נא לשלוח ביטוח אחריות מקצועית בתוקף לפקס מספר 03-7348603", True)
                End If

                Return

                '-20 - Denied=4
                ' -21 - EndInsuranceDate in the past but less than month - not here  
                ' -22 - Denied=8   
            Case Else

                ShowError("זיהוי משתמש נכשל")

        End Select

    End Sub

    Private Sub cmdSendPassword_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSendPassword.ServerClick

        ShowError(String.Empty)

        Dim UserName As String = txtUser.Value.Trim()
        Dim Password As String = txtPass.Value.Trim()
        Dim Mobile As String = txtMobile.Value.Trim()
        Dim Captcha As String = txtTest.Value.Trim()

        txtMobile.Value = String.Empty
        txtTest.Value = String.Empty

        If Len(UserName) = 0 Or UserName = "שם משתמש" Then
            ShowError("הכנס שם משתמש")
            Return
        End If


        ''*******************

        If Not setCheckUserDetails(UserName) Then
            Return
        End If

        ''********************



        Select Case RequestPasswordStep

            Case 0
                txtLoginIdentity.Value = "1"

                txtUser.Disabled = True
                txtPass.Disabled = True
                cmdOK.Disabled = True
                cmdDoctorService.Disabled = True

                divTest.Style.Item("display") = "block"

                divTestRow1.Visible = True
                divTestRow2.Visible = True
                divTestRow3.Visible = True
                divTestRow4.Visible = False
                divTestRow5.Visible = False

                RequestPasswordStep = 1
                cmdSendPassword.Value = "המשך"
                Return

            Case 1
                If Captcha <> CStr(Session("SecretNumber")) Then
                    txtLoginIdentity.Value = "1"
                    ShowError("המספר שהוקש אינו תואם את המספר שבתמונה.")
                    Return
                End If

                txtLoginIdentity.Value = "1"

                txtUser.Disabled = True
                txtPass.Disabled = True
                cmdOK.Disabled = True
                cmdDoctorService.Disabled = True

                divTest.Style.Item("display") = "block"

                divTestRow1.Visible = False
                divTestRow2.Visible = False
                divTestRow3.Visible = False
                divTestRow4.Visible = True
                divTestRow5.Visible = True

                RequestPasswordStep = 2
                Return

            Case Else
                Dim ds As DataSet
                Dim Messge As String
                Dim DelayTime As Integer = 0

                Dim UserService As New UserConnect.UserService()
                UserService.Url = Utils.Values.GetApplicationString("UserWebService")

                ds = UserService.GetUser("784C13D4-4DA2-49FC-9CDD-1BB6B0E869CB", UserName)
                Dim UserMobile As String = Utils.Values.GetFirstTableFirstRowString(ds, "Mobile")
                Dim SysUserID As Integer = Utils.Values.GetFirstTableFirstRowInteger(ds, "SysUserID")

                txtUser.Disabled = False
                txtPass.Disabled = False
                cmdOK.Disabled = False
                cmdDoctorService.Disabled = False

                divTest.Style.Item("display") = "none"
                txtLoginIdentity.Value = "0"
                cmdSendPassword.Value = "שכחתי סיסמה"
                RequestPasswordStep = 0

                If (Utils.Navigation.GetURL("frmUserProp.aspx").ToLower().StartsWith("frmUserProp.aspx".ToLower())) Then ' Old design
                    If UserMobile.Trim().Length = 0 Then
                        ShowError("לא מוגדר לך טלפון נייד, נא פנה למנהל המערכת")
                        Return
                    End If
                    If Not UserMobile.EndsWith(Mobile) Then
                        ShowError("אין התאמה למספר הטלפון הנייד")
                        Return
                    End If
                Else
                    Dim dsExtra As DataSet = UserService.GetUserExtraData("D393D747-2C1F-49EB-956F-2083EA210108", UserName)
                    Dim status As Integer = 0
                    ' Надо проверить данные из AS400 - я запихнул их во вторую таблицу...
                    If Not dsExtra Is Nothing AndAlso dsExtra.Tables.Count > 1 Then
                        Dim dtExtra = dsExtra.Tables(1).Copy()
                        dsExtra = New DataSet()
                        dsExtra.Tables.Add(dtExtra)
                    End If
                    UserMobile = CheckMobile(dsExtra, Mobile, status)
                    If status = 1 Then
                        ShowError("לא מוגדר לך טלפון נייד, נא פנה למנהל המערכת")
                        Return
                    End If
                    If status = 2 Then
                        ShowError("אין התאמה למספר הטלפון הנייד")
                        Return
                    End If
                    If status = 3 Then
                        ' ShowError("מספר רופא/מרפאה אינו קיים במערכת")
                        'ShowError("לא ניתן להיכנס למערכת. נא לפנות אלינו באמצעות 'שירות לרופא בהסכם' ולציין שגיאה 1002")
                        Return
                    End If
                End If

                Dim UserStatus As Integer = UserService.CheckPeriodLockUser("79D565C1-784C-4606-935B-68BA32141600", UserName, Password, Session.SessionID, Val(Utils.Values.GetApplicationString("SiteType")), Request.UserHostAddress)

                If UserStatus = -2 Then
                    ds = UserService.GetExpirationParameters("30305F5F-69A9-4637-AFDA-A6A195D8F2CB")
                    DelayTime = Utils.Values.GetFirstTableFirstRowInteger(ds, "LockLoginFailPeriod")
                    Messge = String.Format("גישתך למערכת נחסמה למשך {0} דקות", DelayTime)
                    ShowError(Messge)
                    Return
                ElseIf UserStatus = -3 Then ' locked and locked period expired and password is not right
                    ds = UserService.GetExpirationParameters("30305F5F-69A9-4637-AFDA-A6A195D8F2CB")
                    DelayTime = Utils.Values.GetFirstTableFirstRowInteger(ds, "LockLoginFailPeriod")
                    Messge = String.Format("גישתך למערכת נחסמה למשך {0} דקות", DelayTime)
                    ShowError(Messge)
                    Return
                ElseIf UserStatus = -10 Then
                    ShowError("חשבון נעול")
                    Return
                End If

                Dim NewPassword As String = GetNewPassword()
                Try
                    If Not UpdateNewPassword(NewPassword, UserName) Then
                        Throw New Exception()
                    End If
                    If Not UserService.SendSMSPassword("23E1BB63-0A45-4D40-A4CA-30A18E61CBBF", 0, -SysUserID * 10, UserMobile.Trim(), NewPassword) Then
                        Throw New Exception()
                    End If
                    ShowError("סיסמא זמנית נשלחה לנייד שלך")
                Catch ex As Exception
                    ShowError("תקלה בעת שליחת סיסמה. נא פנה לאיש הקשר שלך בחברה")
                End Try

                Session("SecretNumber") = Nothing
        End Select

    End Sub

    Private Function CheckMobile(ByVal ds As DataSet, ByVal mobile As String, ByRef status As Integer) As String

        status = 0

        If Utils.Values.GetFirstTableRowsCount(ds) <= 0 Then
            status = 3
            Return String.Empty

        End If

        'Dim phone As String = _
        '    Utils.Values.GetFirstTableFirstRowString(ds, "HDBS_MOBILE") + _
        '    Utils.Values.GetFirstTableFirstRowString(ds, "HDBS_TELEFON") + _
        '    Utils.Values.GetFirstTableFirstRowString(ds, "HDBS_TELEFON_NOSAF1") + _
        '    Utils.Values.GetFirstTableFirstRowString(ds, "HDBS_TELEFON_NOSAF2") + _
        '    Utils.Values.GetFirstTableFirstRowString(ds, "RO_MOBILE") + _
        '    Utils.Values.GetFirstTableFirstRowString(ds, "RO_TELEFON") + _
        '    Utils.Values.GetFirstTableFirstRowString(ds, "RO_TELEFON_NOSAF1") + _
        '    Utils.Values.GetFirstTableFirstRowString(ds, "RO_TELEFON_NOSAF2")
        Dim phone As String = _
            Utils.Values.GetFirstTableFirstRowString(ds, "HDBS_MOBILE") + _
            Utils.Values.GetFirstTableFirstRowString(ds, "RO_MOBILE")

        If (phone.Length = 0) Then
            status = 1
            Return String.Empty
        End If

        'phone = _
        '    Utils.Values.GetFirstTableFirstRowString(ds, "HDBS_MOBILE") + _
        '    Utils.Values.GetFirstTableFirstRowString(ds, "RO_MOBILE")
        If (phone.EndsWith(mobile)) Then
            Return phone
        End If

        'phone = _
        '    Utils.Values.GetFirstTableFirstRowString(ds, "HDBS_TELEFON") + _
        '    Utils.Values.GetFirstTableFirstRowString(ds, "RO_TELEFON")
        'If (phone.EndsWith(mobile)) Then
        '    Return phone
        'End If

        'phone = _
        '    Utils.Values.GetFirstTableFirstRowString(ds, "HDBS_TELEFON_NOSAF1") + _
        '    Utils.Values.GetFirstTableFirstRowString(ds, "RO_TELEFON_NOSAF1")
        'If (phone.EndsWith(mobile)) Then
        '    Return phone
        'End If

        'phone = _
        '    Utils.Values.GetFirstTableFirstRowString(ds, "HDBS_TELEFON_NOSAF2") + _
        '    Utils.Values.GetFirstTableFirstRowString(ds, "RO_TELEFON_NOSAF2")
        'If (phone.EndsWith(mobile)) Then
        '    Return phone
        'End If

        status = 2
        Return String.Empty

    End Function

    Private Function setCheckUserDetails(ByVal _strUserName) As Boolean


        Dim BretCheckUserDetails As Boolean

        Dim iRetKodForMess As Integer

        BretCheckUserDetails = CheckUserDetails(_strUserName, iRetKodForMess)

        If Not BretCheckUserDetails Then
            If iRetKodForMess = eAs400CheckUserDetailsResults.eRetiredUserAgreement Then 'Denied


                ShowError("   עקב פרישתך מההסכם נחסמה כניסתך למערכת  ")

                '' '' ''ElseIf iRetKodForMess = eAs400CheckUserDetailsResults.eInvalidDoctorType Then 'Invalid doctor type

                '' '' ''    ShowError(" cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc  ")

            Else 'Nodate

                ShowError("   לא ניתן להיכנס למערכת. נא לפנות אלינו באמצעות 'שירות לרופא בהסכם' ולציין שגיאה  " + iRetKodForMess.ToString)
            End If

            Return False

        End If


        Return True


    End Function

    Private Function CheckUserDetails(ByVal _strUserName As String, ByRef _iRetKodForMess As Integer) As Boolean

        Dim sExceptionError As String
        Dim sCompanyName As String = "דקלה - אתר משתמש"
        If Application("CompanyID").ToString = "1" Then
            sCompanyName = " הראל - אתר משתמש"
        End If

        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

        Dim iRetAs400 As Integer

        Dim currRow As DataRow
        Dim sMessFromAs400 As String
        Dim iDoctorType As Integer
        Dim sClinicName As String
        Dim sdtEndAgreementDate As String
        Dim sdtEndAgreementDateOrg As String

        Dim sdtEndInsuranceDate As String
        Dim sdtEndInsuranceDateOrg As String

        Dim iRet As Integer
        Dim bRet As Boolean = False


        Dim dsUserInfo As DataSet

        _iRetKodForMess = eAs400CheckUserDetailsResults.eNoDataForUserInInfoBay

        If Not Application("CheckUserDetails") Is Nothing Then

            If Application("CheckUserDetails").ToString = "1" Or Application("CheckUserDetails").ToString = "" Then




                '***************************
                '  get clinic id
                '***************************
                Try

                    dsUserInfo = objUser.GetUser("784C13D4-4DA2-49FC-9CDD-1BB6B0E869CB", _strUserName)
                    ''''Dim ds As DataSet = objUser.GetUser("784C13D4-4DA2-49FC-9CDD-1BB6B0E869CB", _strUserName)

                Catch ex As Exception
                    _iRetKodForMess = eAs400CheckUserDetailsResults.eNoconnectToInfoBayDataBase
                End Try





                Try


                    If Not dsUserInfo Is Nothing Then

                        If dsUserInfo.Tables.Count > 0 Then

                            currRow = dsUserInfo.Tables(0).Rows(0)

                            If Not currRow("ClinicID") Is System.DBNull.Value Then

                                If Not CInt(currRow("ClinicID")) = 0 Then


                                    Dim iClinicId = Convert.ToInt32(currRow("ClinicID"))

                                    '***************************
                                    '  get As400 data
                                    '***************************

                                    Dim objBO As New BOConnection.BOService
                                    objBO.Url = Application("BOWebService")



                                    Dim dsAs400 As DataSet = objBO.CheckUserDetails("6CE4EB5E-47C3-11E4-8296-C6201D5D46B0", iClinicId, iRetAs400, sMessFromAs400)
                                    iRet = iRetAs400


                                    If iRet = eAs400CheckUserDetailsResults.eNoDataInAs400 Then
                                        _iRetKodForMess = eAs400CheckUserDetailsResults.eNoDataInForUserAs400
                                    End If
                                    'If iRet = eAs400CheckUserDetailsResults.eNoConnectToAs400 Or iRet = eAs400CheckUserDetailsResults.eNoDataInAs400 Then

                                    If iRet = eAs400CheckUserDetailsResults.eNoConnectToAs400 Then 'Or iRet = eAs400CheckUserDetailsResults.eNoDataInAs400 Then


                                        '***************************
                                        '  get TblUser
                                        '***************************






                                        If Not dsUserInfo Is Nothing Then

                                            If dsUserInfo.Tables.Count > 0 Then

                                                If dsUserInfo.Tables(0).Rows.Count > 0 Then

                                                    '' ''currRow = dsUserInfo.Tables(0).Rows(0)



                                                    '' ''iDoctorType = Convert.ToInt32(currRow("DoctorType"))

                                                    '' ''sClinicName = currRow("ClinicName").ToString

                                                    '' ''sdtEndAgreementDate = currRow("EndAgreementDate").ToString
                                                    '' ''sdtEndAgreementDateOrg = Mid(sdtEndAgreementDate, 7, 4) + Mid(sdtEndAgreementDate, 4, 2) + Left(sdtEndAgreementDate, 2)


                                                    '' ''sdtEndInsuranceDate = currRow("EndInsuranceDate").ToString
                                                    '' ''sdtEndInsuranceDateOrg = Mid(sdtEndInsuranceDate, 7, 4) + Mid(sdtEndInsuranceDate, 4, 2) + Left(sdtEndInsuranceDate, 2)

                                                    '' ''setUserDenied(sdtEndAgreementDate, _strUserName, iRet, _iRetKodForMess)

                                                Else

                                                    iRet = eAs400CheckUserDetailsResults.eNoDataInTblUsers
                                                End If
                                            Else
                                                iRet = eAs400CheckUserDetailsResults.eNoDataInTblUsers
                                            End If
                                        Else
                                            iRet = eAs400CheckUserDetailsResults.eNoDataInTblUsers
                                        End If

                                    End If 'If iRet = eAs400CheckUserDetailsResults.eNoConnectToAs400



                                    If iRet = eAs400CheckUserDetailsResults.eConnectSuccessToAs400 Then

                                        currRow = dsAs400.Tables(0).Rows(0)

                                        iDoctorType = Convert.ToInt32(currRow("RO_MAHUT_ROFE"))

                                        'If (iDoctorType > 4 Or iDoctorType < 1) Then


                                        '    iRet = eAs400CheckUserDetailsResults.eInvalidDoctorType
                                        '    _iRetKodForMess = eAs400CheckUserDetailsResults.eInvalidDoctorType
                                        'Else





                                        Dim utilsObj As New Utils()
                                        sClinicName = StrReverse(utilsObj.CleanInvalidXmlChars(Trim(currRow("RO_SHEM_ROFE").ToString)))

                                        sdtEndAgreementDate = currRow("RO_TAARIX_SIYUM_HESKEM").ToString
                                        sdtEndAgreementDateOrg = sdtEndAgreementDate
                                        sdtEndAgreementDate = Right(sdtEndAgreementDate, 2) & "/" & Mid(sdtEndAgreementDate, 5, 2) & "/" & Left(sdtEndAgreementDate, 4) & " " & "00:00:00"

                                        sdtEndInsuranceDate = currRow("RO_TAARIX_SIYUM_AHRAYUT").ToString
                                        sdtEndInsuranceDateOrg = sdtEndInsuranceDate

                                        If Not sdtEndAgreementDateOrg Is System.DBNull.Value Then

                                            If Not sdtEndAgreementDateOrg Is String.Empty Then

                                                If Not sdtEndAgreementDateOrg = "0" Then

                                                    setUserDenied(sdtEndAgreementDate, _strUserName, iRet, _iRetKodForMess)

                                                End If
                                            End If
                                        End If

                                        ''''''''''''''''''''''''End If

                                    End If 'If iRet = eAs400CheckUserDetailsResults.eConnectSuccessToAs400 Then








                                    'If iRet = eAs400CheckUserDetailsResults.eConnectSuccessToAs400 Or iRet = eAs400CheckUserDetailsResults.eNoDataInAs400 Then
                                    If iRet = eAs400CheckUserDetailsResults.eConnectSuccessToAs400 Or iRet = eAs400CheckUserDetailsResults.eNoConnectToAs400 Then
                                        '***************************
                                        '  Update User Details
                                        '***************************


                                        If iRet = eAs400CheckUserDetailsResults.eNoConnectToAs400 Then
                                            bRet = True
                                        Else
                                            bRet = objUser.UpdateUserDetailsFeomAs400("B6391042-4876-11E4-BE53-29D61D5D46B0", _strUserName, iClinicId, iDoctorType, sClinicName, sdtEndAgreementDateOrg, sdtEndInsuranceDateOrg)
                                        End If

                                        If bRet Then
                                            iRet = eAs400CheckUserDetailsResults.eProcessSuccess
                                        Else
                                            iRet = eAs400CheckUserDetailsResults.eUpdateTblUsersFailed
                                        End If

                                    End If


                                Else ' If Not CInt(currRow("ClinicID")) = 0 Then
                                    iRet = eAs400CheckUserDetailsResults.eNoClinicIdForUser
                                End If


                            Else ' If Not currRow("ClinicID") Is System.DBNull.Value Then
                                iRet = eAs400CheckUserDetailsResults.eNoClinicIdForUser
                            End If

                        Else ' If ds.Tables.Count > 0 Then
                            iRet = eAs400CheckUserDetailsResults.eNoDataForUser
                        End If

                    Else 'If Not ds Is Nothing Then
                        iRet = eAs400CheckUserDetailsResults.eNoDataForUser
                    End If


                Catch ex As Exception
                    iRet = eAs400CheckUserDetailsResults.eGeneralError
                    sExceptionError = ex.Message.ToString
                End Try



            Else 'If Application("CheckUserDetails").ToString = "0" Or Application("CheckUserDetails").ToString = "" Then
                iRet = eAs400CheckUserDetailsResults.eNoNeedForExamination
            End If


        Else 'If Not Application("CheckUserDetails") Is Nothing Then

            iRet = eAs400CheckUserDetailsResults.eNoNeedForExamination

        End If


        '******************************************************************
        '  add row to log table ( but not when No Need For Examination )
        '******************************************************************
        Dim sErrorMessLong As String
        Dim sErrorMess As String = ""
        Dim sErrorMessForEmail As String = ""

        Select Case iRet
            Case eAs400CheckUserDetailsResults.eNoNeedForExamination
            Case eAs400CheckUserDetailsResults.eNoClinicIdForUser
                sErrorMessLong = " user  " + _strUserName + " log into  " + sCompanyName + " failure :   " + "No clinicId for user"
                sErrorMess = "No clinicId for user"
            Case eAs400CheckUserDetailsResults.eNoDataForUser
                sErrorMessLong = " user  " + _strUserName + " log into  " + sCompanyName + " failure :   " + "No data for user in users table"
                sErrorMess = "No data for user in users table"
            Case eAs400CheckUserDetailsResults.eGeneralError
                sErrorMessLong = " user  " + _strUserName + " log into  " + sCompanyName + " failure :   " + sExceptionError
                sErrorMess = sExceptionError
            Case eAs400CheckUserDetailsResults.eNoConnectToAs400
                sErrorMessLong = " user  " + _strUserName + " log into  " + sCompanyName + "." + "connect  to As400 failed : " + sMessFromAs400
                sErrorMess = +"connect  to As400 failed : " + sMessFromAs400
            Case eAs400CheckUserDetailsResults.eConnectSuccessToAs400
                sErrorMessLong = " user  " + _strUserName + " log into  " + sCompanyName + "." + " connect  to As400 success : "
                sErrorMess = " connect  to As400 success : "
            Case eAs400CheckUserDetailsResults.eNoDataInAs400
                sErrorMessLong = " user  " + _strUserName + " log into  " + sCompanyName + " failure :   " + "  No data in As400  "
                sErrorMess = "  No data in As400  "
            Case eAs400CheckUserDetailsResults.eNoDataInTblUsers
                sErrorMessLong = " user  " + _strUserName + " log into  " + sCompanyName + " failure :   " + " No data in Users table "
                sErrorMess = " No data in Users table "
            Case eAs400CheckUserDetailsResults.eProcessSuccess
                sErrorMessLong = " user  " + _strUserName + " log into  " + sCompanyName + " success  "
                sErrorMess = " success  "
            Case eAs400CheckUserDetailsResults.eUpdateTblUsersFailed
                sErrorMessLong = " user  " + _strUserName + " log into  " + sCompanyName + " failure :   " + " Update TblUsers table failed "
                sErrorMess = " Update TblUsers table failed "
            Case eAs400CheckUserDetailsResults.eRetiredUserAgreement
                sErrorMessLong = " user  " + _strUserName + " log into  " + sCompanyName + " failure :   " + " User agreement terminated"
                sErrorMess = " User agreement terminated "
            Case eAs400CheckUserDetailsResults.eInvalidDoctorType
                sErrorMessLong = " user  " + _strUserName + " log into  " + sCompanyName + " failure :   " + " Invalid Doctor Type"
                sErrorMess = " Invalid Doctor Type "

            Case Else

        End Select

        If iRet = eAs400CheckUserDetailsResults.eNoNeedForExamination Or iRet = eAs400CheckUserDetailsResults.eProcessSuccess Then
            bRet = True

        Else

            bRet = False
        End If


        '************************************************
        ' Add row to tblUsersInfoLog table
        '************************************************


        If iRetAs400 = eAs400CheckUserDetailsResults.eNoConnectToAs400 Then '4
            objUser.AddUsersInfoLog("3A173DF2-48A5-11E4-A65B-E30B1E5D46B0", _strUserName, iRetAs400, " user  " + _strUserName + " log into  " + sCompanyName + " failure : " + sMessFromAs400)
        End If

        'If iRetAs400 = eAs400CheckUserDetailsResults.eConnectSuccessToAs400 Then '5
        '    objUser.AddUsersInfoLog("3A173DF2-48A5-11E4-A65B-E30B1E5D46B0", _strUserName, iRetAs400, sErrorMess)
        'End If

        If iRetAs400 = eAs400CheckUserDetailsResults.eNoDataInAs400 Then '6
            objUser.AddUsersInfoLog("3A173DF2-48A5-11E4-A65B-E30B1E5D46B0", _strUserName, iRetAs400, "No data for user in As400")
        End If

        If iRet = eAs400CheckUserDetailsResults.eNoClinicIdForUser Or _
           iRet = eAs400CheckUserDetailsResults.eNoDataForUser Or _
           iRet = eAs400CheckUserDetailsResults.eGeneralError Or _
           iRet = eAs400CheckUserDetailsResults.eNoDataInTblUsers Or _
           iRet = eAs400CheckUserDetailsResults.eProcessSuccess Or _
           iRet = eAs400CheckUserDetailsResults.eUpdateTblUsersFailed Or _
           iRet = eAs400CheckUserDetailsResults.eRetiredUserAgreement Or _
           iRet = eAs400CheckUserDetailsResults.eInvalidDoctorType Then

            objUser.AddUsersInfoLog("3A173DF2-48A5-11E4-A65B-E30B1E5D46B0", _strUserName, iRet, sErrorMessLong)

        End If






        '************************************************
        '  Send email to VBSUPPORT only when failure
        '************************************************




        If ((iRet <> eAs400CheckUserDetailsResults.eNoNeedForExamination And iRet <> eAs400CheckUserDetailsResults.eProcessSuccess) Or (iRetAs400 = eAs400CheckUserDetailsResults.eNoConnectToAs400)) Then

            Dim objReportsList As New ReportConnect.ReportService()
            objReportsList.Url = Application("ReportWebService").ToString()

            Dim sb As New StringBuilder()

            sb.Append("<HTML  style = 'alighn=right' dir =rtl>")

            sb.Append("<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH='300px' DIR=rtl align='right'>" & vbCrLf)

            sb.Append("<TR align='right'>" & vbCrLf)
            sb.Append(" <TD WIDTH='100px'>שלום רב </TD>" & vbCrLf)
            sb.Append("</TR>" & vbCrLf)


            sb.Append("<TR align='right'>" & vbCrLf)
            sb.Append(" <TD WIDTH='100px'>" & vbCrLf)
            sb.Append("בתאריך ").Append(Now.ToString("dd/MM/yyyy HH:mm:ss"))
            sb.Append(" </TD " & vbCrLf)
            sb.Append("</TR>" & vbCrLf)


            sb.Append("<TR align='right'>" & vbCrLf)
            sb.Append(" <TD WIDTH='100px'>" & vbCrLf)

            ' If iRetAs400 = eAs400CheckUserDetailsResults.eNoConnectToAs400 Then
            'sb.Append("   כניסה של המשתמש ")
            ' Else
            sb.Append("  נכשל ניסיון כניסה של המשתמש ")
            ' End If




            sb.Append("  ")
            sb.Append(_strUserName)
            sb.Append(" </TD " & vbCrLf)
            sb.Append("</TR>" & vbCrLf)


            sb.Append("<TR align='right'>" & vbCrLf)
            sb.Append(" <TD WIDTH='100px'>" & vbCrLf)
            sb.Append(" למערכת ")
            sb.Append(" " + sCompanyName + " ")

            Dim sUrl As String
            Dim sFullUrl = HttpContext.Current.Request.Url.AbsoluteUri
            Dim idxFullUrl As Integer

            idxFullUrl = sFullUrl.IndexOf("?")

            If (idxFullUrl > -1) Then
                sUrl = sFullUrl.Substring(0, idxFullUrl)
            Else
                sUrl = sFullUrl
            End If


            sb.Append("<a>" + sUrl + "</a>")
            sb.Append(" </TD " & vbCrLf)
            sb.Append("</TR>" & vbCrLf)

            sb.Append("<TR align='right'>" & vbCrLf)
            sb.Append(" <TD WIDTH='100px'>" & vbCrLf)

            'If iRetAs400 = eAs400CheckUserDetailsResults.eNoConnectToAs400 Then
            'sb.Append("")
            ' Else
            sb.Append(" סיבת הכישלון: ")
            ' End If




            Dim sMessToEmail As String = ""


            If iRetAs400 = eAs400CheckUserDetailsResults.eNoConnectToAs400 Then
                sMessToEmail = sMessToEmail + "connect  to As400 failed : " + sMessFromAs400

            End If


            If iRet = eAs400CheckUserDetailsResults.eNoClinicIdForUser Or _
               iRet = eAs400CheckUserDetailsResults.eNoDataForUser Or _
               iRet = eAs400CheckUserDetailsResults.eGeneralError Or _
               iRet = eAs400CheckUserDetailsResults.eNoDataInTblUsers Or _
               iRet = eAs400CheckUserDetailsResults.eNoDataInAs400 Or _
               iRet = eAs400CheckUserDetailsResults.eRetiredUserAgreement Or _
               iRet = eAs400CheckUserDetailsResults.eUpdateTblUsersFailed Or _
               iRet = eAs400CheckUserDetailsResults.eInvalidDoctorType Then

                If sMessToEmail = "" Then
                    sMessToEmail = sErrorMess
                Else
                    sMessToEmail = sMessToEmail + "  .  " + "<br>" + sErrorMess
                End If



            End If

            sb.Append(sMessToEmail)

            sb.Append(" </TD " & vbCrLf)
            sb.Append("</TR>" & vbCrLf)

            sb.Append("</HTML>")
            Dim sMsg As String = sb.ToString


            '''If iRetAs400 = eAs400CheckUserDetailsResults.eNoConnectToAs400 Then
            'objReportsList.SendAutoMail("53E9081B-A960-4029-A099-2E932ECBE31C", "  כניסה למערכת  " + sCompanyName, sMsg)

            objReportsList.SendAutoMail("53E9081B-A960-4029-A099-2E932ECBE31C", sCompanyName + " - " + "  כניסה למערכת נכשלה ", sMsg)

            'Else
            ' objReportsList.SendAutoMail("53E9081B-A960-4029-A099-2E932ECBE31C", "  כניסה למערכת  " + sCompanyName + "  נכשלה ", sMsg)

            ' End If




        End If



        Return bRet


    End Function

    Sub setUserDenied(ByVal _sdtEndAgreementDate As String, ByVal _strUserName As String, ByRef iRet As Integer, ByRef _iRetKodForMess As Integer)

        Dim _objUser As New UserConnect.UserService()
        _objUser.Url = Application("UserWebService").ToString()




        If Convert.ToDateTime(_sdtEndAgreementDate) <= Now() Then


            Dim sTenthMonth As String

            sTenthMonth = DateAdd("m", 1, DateSerial(Year(_sdtEndAgreementDate), Month(_sdtEndAgreementDate), 10))


            If Convert.ToDateTime(sTenthMonth) <= Now() Then

                iRet = eAs400CheckUserDetailsResults.eRetiredUserAgreement
                _iRetKodForMess = eAs400CheckUserDetailsResults.eRetiredUserAgreement


                Dim strUserID As String = _objUser.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", _strUserName)
                _objUser.UpdateUserDenied("DF933C3A-4EC8-11E4-B1EC-8D1D1D5D46B0", Convert.ToInt32(strUserID), 16)


            End If

        End If

    End Sub

    Enum eAs400CheckUserDetailsResults As Integer
        eNoNeedForExamination = 0
        eNoClinicIdForUser = 1
        eNoDataForUser = 2
        eGeneralError = 3
        eNoConnectToAs400 = 4
        eConnectSuccessToAs400 = 5
        eNoDataInAs400 = 6
        eNoDataInTblUsers = 7
        eProcessSuccess = 8
        eUpdateTblUsersFailed = 9
        eRetiredUserAgreement = 10
        eInvalidDoctorType = 11
        eNoDataForUserInInfoBay = 1001
        eNoDataInForUserAs400 = 1002
        eNoconnectToInfoBayDataBase = 1003
    End Enum

End Class
