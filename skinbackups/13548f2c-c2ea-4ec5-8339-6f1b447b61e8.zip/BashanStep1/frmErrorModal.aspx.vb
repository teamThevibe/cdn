﻿Imports System.Text

Partial Public Class frmErrorModal
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim str As String

        If Not IsPostBack Then
            Session("BackUrl") = ""
            str = "if(window.history.length > '0'){window.history.back();return;}"
            str += "else {window.close();}"

            Dim strMessage As String

			Dim sFieldBuffer As String
			Dim sFieldDesc As String
			'Dim sFieldDescAdd As String

            Dim sFieldValue As String
			Dim sFileName As String
			Dim sMsgVal As String = ""
            Dim encrypt As CEncryption.cEnryption = New CEncryption.cEnryption()

            Try
                Dim sMsg As String = Request.QueryString("sMsg") + ""
                If (sMsg <> "") Then
                    sMsg = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(sMsg))
                    sFieldDesc = cryptComtec.RijndaelSimple.DencryptSimple(sMsg)
                End If

                Dim sVal As String = Request.QueryString("sVal") + ""
                If (sVal <> "") Then
                    sVal = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(sVal))
					sFieldBuffer = cryptComtec.RijndaelSimple.DencryptSimple(sVal)
					If (sFieldBuffer.IndexOf("|") > -1) Then
						Dim sArr As String() = sFieldBuffer.Split("|")
						sFieldDesc = sArr(0)
						'If sFieldDesc.Length > 32 Then
						'	Dim iIndex As Integer = sFieldDesc.LastIndexOf("/")
						'	sFieldDescAdd = sFieldDesc.Substring(iIndex + 1)
						'	sFieldDesc = sFieldDesc.Substring(0, iIndex)
						'End If

						sMsgVal = sArr(1)

						If (sMsgVal <> "") Then
							sMsgVal = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(sMsgVal))
							If (Not IsNothing(Application(sMsgVal))) Then
								sFieldValue = "" + Application(sMsgVal).ToString()
								Application(sMsgVal) = Nothing
							End If
						End If

					End If
				End If


				Dim sFileInfo As String = Request.QueryString("FileInfo") + ""
				If (sFileInfo <> "") Then
					sFileInfo = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(sFileInfo))
					sFileName = cryptComtec.RijndaelSimple.DencryptSimple(sFileInfo)
				End If
			Catch ex As Exception
				Dim s As String = ex.Message
			End Try

            Dim s1 As Char = ""
            Dim sValidChars As String = ""

            If (sFileName = "") Then
                Dim sRegExp As String = Application("RegExpr")
                Dim iCount As Integer
                For iCount = 33 To 255
                    s1 = Chr(iCount)
                    If Char.IsLetterOrDigit(s1) Then
                        '   If ((iCount >= 48 And iCount <= 57) Or (iCount >= 65 And iCount <= 90) Or (iCount >= 97 And iCount <= 122) Or (iCount >= 208 And iCount <= 242) Or (iCount = 181) Or (iCount = 192)) Then

                    Else
                        ' s1 = Chr(iCount)
                        If System.Text.RegularExpressions.Regex.IsMatch(s1, sRegExp) Then
                            sValidChars += s1 + " "
                        End If
                    End If
                Next

#If EngDesign Then
            str = "Invalid input"

            If sFieldDesc > "" Then
                'Dim Sec As New SecurityService.SecurityService()
                'Sec.Url = Application("SecurityService")
                'sFieldDesc = Sec.GetWhiteListFieldDesc("97E08494-AEB2-4a98-B7ED-57F48C45A4F9", sFormName, sFieldName)
                str += " in field " & "'" & sFieldDesc & "'"
            End If
            str += "<br /><br /><br />"
            str += "Allowed characters: letters, digits" & "<br /><br />"
            str += sValidChars & ":and the following characters " & "<br />"
            ' ! @ + : $ * ? \ / _ [ ] | % . - ,"
            lblMessage.Text = str

            'ctlBanner.InnerText = objUser.GetBanner("83FEABF8-828B-489D-8DD0-EB5A3AB7994E")
#Else
                'str = "הקשת תו לא חוקי"
				If sFieldDesc > "" Then					
					str = "לא ניתן לבצע שמירה של הנתונים בשל ערך לא חוקי." + "<br />"
					str += "נא לפנות אלינו באמצעות ""שירות לרופא בהסכם"" " + "<br />" + "ולציין שגיאה 2001 ושדה"
					str += "<br />" + sFieldDesc
					If (sFieldValue <> "") Then
						str += "<br /><br />" + _
						 "המלל" + "<br />" + "'" + sFieldValue + "'" + "<br />" + "מכיל תווים לא חוקיים"
					End If
				ElseIf sFieldValue > "" Then
					str = "<br /><br />" + _
					   "המלל" + "<br />" + "'" + sFieldValue + "'" + "<br />" + "מכיל תווים לא חוקיים"
				Else
					str = "הקשת תו לא חוקי"
					str += "<br /><br /><br />"
					str += "תווים מותרים: אותיות עבריות, לועזיות, ספרות " & "<br /><br />"
					str += "והתווים הבאים: " & sValidChars & "<br />" ' ! @ + : $ * ? \ / _ [ ] | % . - ,"
				End If
                lblMessage.Text = str
#End If







            Else
                str = "<br /><br />" + _
                       "שם הקובץ" + "<br />" + "'" + CEncode.StringEncode(sFileName) + "'" + "<br />" + "מכיל תווים לא חוקיים"
                lblMessage.Text = str
                'lblMessage.Style.Add("text-align", "center")

            End If



        End If

    End Sub

End Class