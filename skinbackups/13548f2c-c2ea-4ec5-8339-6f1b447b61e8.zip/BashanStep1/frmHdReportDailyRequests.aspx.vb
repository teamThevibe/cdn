﻿Imports System.Globalization

Partial Public Class frmHDReportDailyRequests
    Inherits System.Web.UI.Page

    Dim objTreatmentService As New TreatmentConnect.TreatmentService()
    Dim objUser As New UserConnect.UserService()
    Public dcSum_TASHLUM_MEVUTAH As Decimal
    Public sSum_TASHLUM_MEVUTAH As String

    Public iCompanySign As Integer
    Private isSibatDhiyaRefuitExists As Boolean

    Public sTaarichZikuy As String
    Public sSumMesameret As String
    Public sSumMesakemet As String
    Public sSumRows As String
    Public sTitle As String
    Dim index As Integer = 0
    Dim sFirstValueForTz As String = ""

    Public sMisparBank As String
    Public sMisparShnif As String
    Public sMisparChsbonBank As String
    Public sMisparChsbon_Han As String
    Public sMisparTikNikuim As String

    Public dcAhuzNikuyMas As Decimal
    Public sAhuzNikuyMas As String

    Public sSum_TASHLUM_MEVUTAH_Nikuy As String
    Public sSum_TASHLUM_MEVUTAH_After_Nikuy As String





    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        DirectCast(Me.Master, HDMasterPage).SetUnSelected()




        Dim iSugDivuach As Integer = 0

        If Not Request.QueryString("SugDivuach") Is Nothing Then
            iSugDivuach = CInt(Request.QueryString("SugDivuach"))
        End If


        If iSugDivuach > 0 Then
        Else
            If HidSugDivuach.Value <> "" Then
                iSugDivuach = CInt(HidSugDivuach.Value)
            End If
        End If


        DirectCast(Me.Master, HDMasterPage).SetInterActive(iSugDivuach)

        iCompanySign = eCompanySign.eDikla

        If Not Application("CompanyID") Is Nothing Then
            If CInt(Application("CompanyID")) = eCompanySign.eHarel Then
                iCompanySign = eCompanySign.eHarel
            End If
        End If



        'If iCompanySign = eCompanySign.eDikla Then
        '    divRIcon.Visible = True
        '    divRIcon1.Visible = False
        'Else
        divRIcon.Visible = False
        divRIcon1.Visible = True

        'End If


        If Not IsPostBack Then


            If Not Request.QueryString("SourchWin") Is Nothing Then
                If Request.QueryString("SourchWin").ToString <> "" Then
                    If Request.QueryString("SourchWin").ToString = CType(eSourchWin.eHdStart, Integer).ToString() Then
                        HidSourchWin.Value = "frmHDStart.aspx"
                    End If
                End If
            End If


            If HidSourchWin.Value = "frmHDStart.aspx" Then

                HidDayForReport.Value = ""
            Else

                If Not Request.QueryString("DayForReport") Is Nothing Then
                    HidDayForReport.Value = Request.QueryString("DayForReport").ToString
                Else
                    HidDayForReport.Value = ""
                End If

            End If


            '''''''''''''''''''''''''''Me.HidSort.Value = "TZ ASC"
            Me.HidSort.Value = "DR_MISPAR_ZEHUT,DR_TAARIX_THILAT_TIPUL ASC,MisparPniya ASC,SpecialSort ASC"




            objUser.Url = Application("UserWebService").ToString()


            tdGridRowCount.Visible = False


            If Not Request.QueryString("SugDivuach") Is Nothing Then

                HidSugDivuach.Value = CInt(Request.QueryString("SugDivuach"))


                If Not Request.QueryString("Asmaxta") Is Nothing Then

                    HidAsmaxta.Value = Request.QueryString("Asmaxta").ToString
                Else

                    HidAsmaxta.Value = ""
                End If


                '-----------
                If HidSugDivuach.Value = CType(eSugDivuach.eRequests, Integer).ToString() Then
                    '-----------
                    If iCompanySign = eCompanySign.eDikla Then
                        Label1.Visible = False
                        'Label3.Visible = False
                        Label3.Visible = True
                    Else
                        Label1.Visible = True
                        Label3.Visible = True
                    End If


                    Label5.Visible = True

                    grdList.Visible = True
                    grdListAccount.Visible = False
                    grdListConsultations.Visible = False
                    tdDistTitle.InnerHtml = "סיכום פניות"
                    sTitle = "משוב תביעות יומי "

                    Session.Remove("TzForfrmHDReportDailyRequests")
                    BindGrid(Me.HidSort.Value)
                End If

                '-----------
                If HidSugDivuach.Value = CType(eSugDivuach.eConsultations, Integer).ToString() Then
                    '-----------

                    Me.HidSort.Value = "DR_MISPAR_ZEHUT,DR_TAARIX_THILAT_TIPUL ASC,MisparPniya ASC,SpecialSort ASC"



                    If Not Request.QueryString("tz") Is Nothing Then

                        HidInsuredID.Value = Request.QueryString("tz").ToString
                    Else
                        HidInsuredID.Value = ""
                    End If

                    '' '' '' ''If iCompanySign = eCompanySign.eDikla Then

                    '' '' '' ''    LabelDivSum.Text = "דקלה חברה לביטוח בע'מ"

                    '' '' '' ''Else

                    '' '' '' ''    LabelDivSum.Text = "הראל חברה לביטוח בע'מ"

                    '' '' '' ''End If

                    Dim CompanyDescription As String() = Application("CompanyDescription").ToString().Split(";")
                    If (IsAfterMerging()) Then
                        LabelDivSum.Text = CompanyDescription(CompanyDescription.Length - 1)
                    Else
                        LabelDivSum.Text = CompanyDescription(0)
                    End If


                    Label6.Visible = True

                    grdList.Visible = False
                    grdListAccount.Visible = False
                    grdListConsultations.Visible = True
                    tdDistTitle.InnerHtml = "סיכום התיעצויות"
                    sTitle = "משוב התייעצויות יומי "


                    BindgrdListConsultations(Me.HidSort.Value)
                End If

                '-----------
                If HidSugDivuach.Value = CType(eSugDivuach.eAccount, Integer).ToString() Then
                    '-----------




                    If iCompanySign = eCompanySign.eDikla Then
                        Label1.Visible = False
                        Label3.Visible = False
                    Else
                        Label1.Visible = True
                        Label3.Visible = False
                    End If


                    If iCompanySign = eCompanySign.eDikla Then
                        LabelTalach.Visible = False
                        LabelTalachDikla.Visible = True
                    Else
                        LabelTalach.Visible = True
                        LabelTalachDikla.Visible = False
                    End If

                    If iCompanySign = eCompanySign.eDikla Then
                        Label4.Visible = False
                        Label44.Visible = True
                    Else
                        Label4.Visible = True
                        Label44.Visible = False
                    End If

                    Label7.Visible = True

                    grdList.Visible = False
                    grdListConsultations.Visible = False
                    grdListAccount.Visible = True
                    tdDistTitle.InnerHtml = "סיכום חשבון לרופא"
                    sTitle = "סיכום חשבון לרופא"

                    Session.Remove("TzForfrmHDReportDailyRequests")
                    BindGridAccount(Me.HidSort.Value)
                End If

            End If


        Else

            '-----------
            If HidSugDivuach.Value = CType(eSugDivuach.eRequests, Integer).ToString() Then
                '-----------

                If iCompanySign = eCompanySign.eDikla Then
                    Label1.Visible = False
                    Label3.Visible = False
                Else
                    Label1.Visible = True
                    Label3.Visible = True
                End If

                Label5.Visible = True

                grdList.Visible = True
                grdListAccount.Visible = False
                grdListConsultations.Visible = False
                tdDistTitle.InnerHtml = "סיכום פניות"
                sTitle = "משוב תביעות יומי "

            End If

        End If

        Dim sMainTitle As String = "מערכת הוד - " & sTitle
        CType(Master.FindControl("MainTitle"), Literal).Text = sMainTitle
        Page.Title = sMainTitle

    End Sub




    Private Sub cmdBack_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdBack.ServerClick


        If HidSourchWin.Value <> "" Then
            Session.Remove("BackNewPageIndexForMoveFromPage")
            Dim sPageActionValue = Session("PageActionValue")
            If Not Session("PageActionValue") Is Nothing Then

                If sPageActionValue.Length > 20 Then

                End If

            End If

            Response.Redirect("frmHDStart.aspx?frmHDReportDailyRequests=1")

        Else
            If "1".Equals(Application("ShowInterActiveReport")) Then
                Session("BackNewPageIndexForMoveFromPage") = "1"
                Response.Redirect((New Utils).GetLinkForNextForm("frmHDRepList.aspx?HidGoToRepList=1"))

            Else
                Session("BackNewPageIndexForMoveFromPage") = "1"
                Response.Redirect((New Utils).GetLinkForNextForm(Application("FORMRepList")))

            End If

        End If

    End Sub

    Private Sub cmdReturn_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.ServerClick
        Response.Redirect("frmStart.aspx")
    End Sub

    Private Sub cboGridRowCount_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboGridRowCount.SelectedIndexChanged
        Dim iGridRowCount As Integer

        If cboGridRowCount.SelectedItem.Value <> "" Then
            iGridRowCount = CInt(cboGridRowCount.SelectedItem.Value)

            Dim objUser As New UserConnect.UserService()
            objUser.Url = Application("UserWebService").ToString()

            objUser.UpdateGridRowCount("5561A874-D4D7-4E5C-AA3D-4EC0EBAA8B7F", User.Identity.Name, iGridRowCount, User.Identity.Name)


            HidSugDivuach.Value = CInt(Request.QueryString("SugDivuach"))

            '-----------
            If HidSugDivuach.Value = CType(eSugDivuach.eRequests, Integer).ToString() Then
                '-----------


                If iGridRowCount > 0 Then
                    grdList.PageSize = iGridRowCount
                End If

                BindGrid(Me.HidSort.Value)
            End If

            '-----------
            If HidSugDivuach.Value = CType(eSugDivuach.eConsultations, Integer).ToString() Then
                '-----------

                If iGridRowCount > 0 Then
                    grdListConsultations.PageSize = iGridRowCount
                End If

                BindgrdListConsultations(Me.HidSort.Value)
            End If

            '-----------
            If HidSugDivuach.Value = CType(eSugDivuach.eAccount, Integer).ToString() Then
                '-----------


                If iGridRowCount > 0 Then
                    grdListAccount.PageSize = iGridRowCount
                End If

                BindGridAccount(Me.HidSort.Value)
            End If


        End If
    End Sub


    '******************************
    '    grdList
    '******************************
    Private Sub BindGrid(ByVal sSort As String)


        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim ds As New DataSet

        Dim sDayForReport As String = HidDayForReport.Value

        sDayForReport = sDayForReport.Replace("/", "")

        Dim sAsmachta As String = ""
        If HidSourchWin.Value = "frmHDStart.aspx" Then
            sAsmachta = HidAsmaxta.Value
        End If




        ds = objTreatmentService.GetDataForHDReportDailyRequests("3692025C-B925-407E-9A17-4BCBB3ECC7A8", GetSubUserName(), _
                                                                 CInt(HidSugDivuach.Value), 0, iCompanySign, sDayForReport, sAsmachta)

        If Not ds Is Nothing Then
            If ds.Tables.Count > 0 Then
                If ds.Tables(0).Rows.Count > 0 Then


                    Session("grdList") = ds

                    Dim sSibatDhiyaRefuit As String '= ds.Tables(0).Rows(0)("SibatDhiyaRefuit").ToString
                    Dim sKodDchiya As String '= ds.Tables(0).Rows(0)("KodDchiya").ToString

                    For Each dr As DataRow In ds.Tables(0).Rows
                        sSibatDhiyaRefuit = dr("SibatDhiyaRefuit").ToString
                        sKodDchiya = dr("KodDchiya").ToString
                        If sSibatDhiyaRefuit = "כ" And sKodDchiya = "ל" Then
                            Label2.Visible = True
                            Exit For
                        End If
                    Next

                    If sDayForReport = "0" Then
                        sDayForReport = "00000000"
                    End If
                    If sDayForReport = "" Then
                        sDayForReport = "00000000"
                    End If

                    sDayForReport = sDayForReport.Substring(0, 2) + "/" + sDayForReport.Substring(2, 2) + "/" + sDayForReport.Substring(4, 4)

                    HiDoctorId.Value = ds.Tables(1).Rows(0)("DoctorID").ToString
                    HiDoctorName.Value = ds.Tables(0).Rows(0)("ClinicName").ToString
                    tdDistTitle.InnerHtml = "משוב תביעות יומי"
                    tdDistTitle.InnerHtml = tdDistTitle.InnerHtml & " לרופא\ספק שמספרו  " + HiDoctorId.Value + _
                                                                " " + HiDoctorName.Value & "</br>" + _
                                                                " הופק בתאריך " & sDayForReport

                    If (Not IsAfterMerging()) Then
                        CType(Master.FindControl("Logo"), System.Web.UI.HtmlControls.HtmlImage).Src = String.Format("../HDpics/logo.png?key={0}", Now.Ticks)
                        CType(Master.FindControl("headerMerging"), System.Web.UI.HtmlControls.HtmlGenericControl).Style.Add("background", GetStyleColor(True))
                    End If


                    Try

                        dcSum_TASHLUM_MEVUTAH = Convert.ToDecimal(ds.Tables(0).Compute("Sum(SchumHechzer)", "True"))
                        sSum_TASHLUM_MEVUTAH = dcSum_TASHLUM_MEVUTAH.ToString()

                    Catch ex As Exception
                        sSum_TASHLUM_MEVUTAH = ""
                    End Try

                    ' '' ''sSum_TASHLUM_MEVUTAH = dcSum_TASHLUM_MEVUTAH.ToString("c")

                    Dim dv As DataView

                    dv = New DataView(ds.Tables(0), _
                           "", _
                           sSort, DataViewRowState.CurrentRows)

                    dv.Sort() = sSort




                    grdList.DataSource = dv

                    grdList.DataBind()

                Else
                    Me.HidErr.Value = ".אין נתונים לדוח דינמי זה. הנתונים נמצאים בדוח הסטטי"
                End If
            Else
                Me.HidErr.Value = ".אין נתונים לדוח דינמי זה. הנתונים נמצאים בדוח הסטטי"
            End If
        Else
            Me.HidErr.Value = ".אין נתונים לדוח דינמי זה. הנתונים נמצאים בדוח הסטטי"
        End If


    End Sub

    Private Function IsAfterMerging() As Boolean

        Dim DayForReport As DateTime
        If (Not DateTime.TryParseExact(HidDayForReport.Value, "dd/MM/yyyy", CultureInfo.CurrentCulture, DateTimeStyles.None, DayForReport)) Then
            Return False
        End If
        Dim MergingDate As DateTime
        If (Not DateTime.TryParseExact(Application("MergingDate"), "dd/MM/yyyy", CultureInfo.CurrentCulture, DateTimeStyles.None, MergingDate)) Then
            Return False
        End If

        If DayForReport >= MergingDate Then
            Return True
        End If

        Return False

    End Function

    Private Sub grdList_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles grdList.SortCommand
        Try
            Dim currentPage As Integer = Me.grdList.CurrentPageIndex
            Dim SortExpression As String = e.SortExpression.ToString()
            Dim SortValue As String = ""
            Select Case SortExpression
                'SortValue 
                Case "TZ ASC"
                    SortValue = "TZ ASC"
                    grdList.Columns(0).SortExpression = SortValue
                    Exit Select

                Case "FullName ASC"
                    SortValue = "FullName ASC"
                    grdList.Columns(1).SortExpression = SortValue
                    Exit Select

                Case Else

                    SortValue = "TZ ASC"
                    grdList.Columns(0).SortExpression = SortValue
                    Exit Select



            End Select

            HidSort.Value = SortValue

            Me.BindGrid(SortValue)

        Catch ex As Exception

            Throw ex

        End Try


    End Sub

    Private Sub datagrid_ItemCreated(ByVal sender As Object, ByVal e As DataGridItemEventArgs) Handles grdList.ItemCreated
        If e.Item.ItemType = ListItemType.Footer Then
            e.Item.Cells(5).ColumnSpan = 2
            e.Item.Cells.RemoveAt(4)
        End If
    End Sub

    Private Sub grdList_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles grdList.PageIndexChanged
        grdList.CurrentPageIndex = e.NewPageIndex
        BindGrid(Me.HidSort.Value)
    End Sub

    Private Sub grdList_ItemDataBound(ByVal sender As Object, ByVal e As DataGridItemEventArgs) Handles grdList.ItemDataBound


        Dim tblCell As TableCell
        Dim sSibatDchiya As String
        Dim ds As DataSet
        Dim dgItem As DataGridItem = e.Item
        Dim dgi As DataGridItem = DirectCast(e, DataGridItemEventArgs).Item
        Select Case (dgItem.ItemType)

            Case ListItemType.Item, ListItemType.AlternatingItem

                If Not Session("grdList") Is Nothing Then

                    ds = Session("grdList")

                    If ds.Tables.Count > 0 Then

                        If ds.Tables(0).Rows.Count > 0 Then

                            With ds.Tables(0).Rows(index)
                                Try

                                    Dim sTempValue As String

                                    Dim dr As DataRow = CType(dgItem.DataItem, System.Data.DataRowView).Row

                                    sTempValue = dr.Item("TZ").ToString() 'Datagrid1.DataKeys(dgItem.ItemIndex)

                                    sSibatDchiya = .Item("SibatDchiya")

                                    If sFirstValueForTz = sTempValue Then

                                        dgItem.Cells(0).Text = ""
                                        dgItem.Cells(1).Text = ""

                                    Else

                                        sFirstValueForTz = sTempValue
                                        dgItem.Cells(0).Text = dr.Item("TZ").ToString()
                                        dgItem.Cells(1).Text = dr.Item("FullName").ToString()
                                    End If



                                    Dim sTempAsmachtaValue As String
                                    Dim sAsmachtaValue As String

                                    sTempAsmachtaValue = Me.HidAsmaxta.Value
                                    sAsmachtaValue = dgItem.Cells(12).Text

                                    If sTempAsmachtaValue = sAsmachtaValue Then

                                        'dgItem.Cells(13).BackColor = Color.Aqua
                                        'dgItem.Cells(12).BackColor = Color.Aqua
                                        'dgItem.Cells(11).BackColor = Color.Aqua
                                        'dgItem.Cells(10).BackColor = Color.Aqua
                                        'dgItem.Cells(9).BackColor = Color.Aqua
                                        'dgItem.Cells(8).BackColor = Color.Aqua
                                        'dgItem.Cells(7).BackColor = Color.Aqua
                                        'dgItem.Cells(6).BackColor = Color.Aqua
                                        'dgItem.Cells(5).BackColor = Color.Aqua
                                        'dgItem.Cells(4).BackColor = Color.Aqua
                                        'dgItem.Cells(3).BackColor = Color.Aqua
                                        'dgItem.Cells(2).BackColor = Color.Aqua
                                        'dgItem.Cells(1).BackColor = Color.Aqua
                                        'dgItem.Cells(0).BackColor = Color.Aqua


                                    End If

                                    Dim spanShowReasonRequests As HtmlGenericControl = DirectCast(dgi.FindControl("spanShowReasonRequests"), HtmlGenericControl)

                                    If sSibatDchiya = "" Then
                                        spanShowReasonRequests.Visible = False
                                    Else
                                        spanShowReasonRequests.Visible = True ' spanShowReasonRequests.Attributes.Add("onclick", "ShowReason(this,'" + sSibatDchiya + "');")

                                    End If

                                Catch ex As Exception

                                End Try

                                index = index + 1

                            End With

                        End If

                    End If

                End If


        End Select
    End Sub




    '******************************
    '    grdListConsultations
    '******************************
    Private Sub BindgrdListConsultations(ByVal sSort As String)


        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim ds As New DataSet

        Dim iUserTz As Integer = Val(Me.HidInsuredID.Value)
        Dim sDayForReport As String = HidDayForReport.Value

        sDayForReport = sDayForReport.Replace("/", "")


        If sDayForReport = "0" Then
            sDayForReport = "00000000"
        End If
        If sDayForReport = "" Then
            sDayForReport = "00000000"
        End If

        Dim sAsmachta As String = ""
        If HidSourchWin.Value = "frmHDStart.aspx" Then
            sAsmachta = HidAsmaxta.Value
        End If
        ds = objTreatmentService.GetDataForHDReportDailyRequests("3692025C-B925-407E-9A17-4BCBB3ECC7A8", GetSubUserName(), _
                                                                 CInt(HidSugDivuach.Value), iUserTz, iCompanySign, sDayForReport, sAsmachta)

        If Not ds Is Nothing Then
            If ds.Tables.Count > 0 Then
                If ds.Tables(0).Rows.Count > 0 Then

                    If ds.Tables(0).Rows.Count = 1 Then
                        Label6.Visible = False
                    End If


                    sDayForReport = sDayForReport.Substring(0, 2) + "/" + sDayForReport.Substring(2, 2) + "/" + sDayForReport.Substring(4, 4)

                    Session("grdListConsultations") = ds

                    Dim sSibatDhiyaRefuit As String '= ds.Tables(0).Rows(0)("SibatDhiyaRefuit").ToString
                    Dim sKodDchiya As String '= ds.Tables(0).Rows(0)("KodDchiya").ToString

                    For Each dr As DataRow In ds.Tables(0).Rows


                        If dr("SibatDhiyaRefuit") Is System.DBNull.Value Or dr("KodDchiya") Is System.DBNull.Value Then
                            Continue For
                        End If


                        sSibatDhiyaRefuit = dr("SibatDhiyaRefuit").ToString
                        sKodDchiya = dr("KodDchiya").ToString
                        If sSibatDhiyaRefuit = "כ" And sKodDchiya = "ל" Then
                            Label2.Visible = True
                            Exit For
                        End If
                    Next

                    If sSibatDhiyaRefuit = "כ" And sKodDchiya = "ל" Then
                        Label2.Visible = True
                    End If

                    HiDoctorId.Value = ds.Tables(1).Rows(0)("DoctorID").ToString
                    'HiDoctorName.Value = ds.Tables(1).Rows(0)("ClinicName").ToString
                    HiDoctorName.Value = ds.Tables(0).Rows(0)("ClinicName").ToString


                    tdDistTitle.InnerHtml = "משוב התיעצויות יומי"
                    tdDistTitle.InnerHtml = tdDistTitle.InnerHtml & " לרופא\ספק שמספרו  " + HiDoctorId.Value + _
                        " " + HiDoctorName.Value + "</br>" + _
                    " הופק בתאריך " & sDayForReport & "</br>" + _
                    "  עבור " + _
                    ds.Tables(0).Rows(0)("FullName").ToString + " ת.ז. " + ds.Tables(0).Rows(0)("TZ").ToString

                    Session("TzForfrmHDReportDailyRequests") = ds.Tables(0).Rows(0)("TZ").ToString

                    tdDistTitle.InnerHtml = tdDistTitle.InnerHtml + "</br></br>"
                    tdDistTitle.InnerHtml = tdDistTitle.InnerHtml + " <font size=2px> תוקף האישור לטיפול משמר לחצי שנה, לטיפול אחר לשנה, או עד מועד הפרישה מהביטוח המוקדם מבין השניים." + "</br>" + _
                                             "אישור זה הינו סיכום הכיסוי הביטוחי ואינו מהווה בהכרח תכנית טיפולים רפואית מומלצת ." + "</br>" + _
                                             "אישור זה תקף למרפאה/רופא זה בלבד. </font>"
                    tdDistTitle.InnerHtml = tdDistTitle.InnerHtml + "</br></br>"


                    If (Not IsAfterMerging()) Then
                        CType(Master.FindControl("Logo"), System.Web.UI.HtmlControls.HtmlImage).Src = String.Format("../HDpics/logo.png?key={0}", Now.Ticks)
                        CType(Master.FindControl("headerMerging"), System.Web.UI.HtmlControls.HtmlGenericControl).Style.Add("background", GetStyleColor(True))
                    End If


                    Try

                        dcSum_TASHLUM_MEVUTAH = Convert.ToDecimal(ds.Tables(0).Compute("Sum(SchumHechzer)", "True"))
                        sSum_TASHLUM_MEVUTAH = dcSum_TASHLUM_MEVUTAH.ToString()


                    Catch ex As Exception
                        sSum_TASHLUM_MEVUTAH = ""
                    End Try



                    Dim dv As DataView

                    dv = New DataView(ds.Tables(0), _
                           "", _
                           sSort, DataViewRowState.CurrentRows)

                    dv.Sort() = sSort


                    grdListConsultations.DataSource = dv

                    grdListConsultations.DataBind()

                Else
                    Me.HidErr.Value = ".אין נתונים לדוח דינמי זה. הנתונים נמצאים בדוח הסטטי"
                End If
            Else
                Me.HidErr.Value = ".אין נתונים לדוח דינמי זה. הנתונים נמצאים בדוח הסטטי"
            End If
        Else
            Me.HidErr.Value = ".אין נתונים לדוח דינמי זה. הנתונים נמצאים בדוח הסטטי"
        End If


    End Sub

    Private Sub grdListConsultations_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles grdListConsultations.SortCommand
        Try
            Dim currentPage As Integer = Me.grdListConsultations.CurrentPageIndex
            Dim SortExpression As String = e.SortExpression.ToString()
            Dim SortValue As String = ""
            Select Case SortExpression
                'SortValue 
                Case "TZ ASC"
                    SortValue = "TZ ASC"
                    grdListConsultations.Columns(12).SortExpression = SortValue
                    Exit Select

                Case "FullName ASC"
                    SortValue = "FullName ASC"
                    grdListConsultations.Columns(11).SortExpression = SortValue
                    Exit Select

                Case Else

                    SortValue = "TZ ASC"
                    grdListConsultations.Columns(11).SortExpression = SortValue
                    Exit Select



            End Select

            HidSort.Value = SortValue

            Me.BindgrdListConsultations(SortValue)

        Catch ex As Exception

            Throw ex

        End Try


    End Sub

    Private Sub grdListConsultations_ItemCreated(ByVal sender As Object, ByVal e As DataGridItemEventArgs) Handles grdListConsultations.ItemCreated
        If e.Item.ItemType = ListItemType.Footer Then
            e.Item.Cells(4).ColumnSpan = 2
            e.Item.Cells.RemoveAt(3)
        End If
    End Sub

    Private Sub grdListConsultations_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles grdListConsultations.PageIndexChanged
        grdListConsultations.CurrentPageIndex = e.NewPageIndex
        BindgrdListConsultations(Me.HidSort.Value)
    End Sub

    Private Sub grdListConsultations_ItemDataBound(ByVal sender As Object, ByVal e As DataGridItemEventArgs) Handles grdListConsultations.ItemDataBound

        Dim sSibatDchiya As String
        Dim tblCell As TableCell
        Dim index As Integer
        Dim ds As DataSet
        Dim dgItem As DataGridItem = e.Item
        Dim dgi As DataGridItem = DirectCast(e, DataGridItemEventArgs).Item
        Select Case (dgItem.ItemType)

            Case ListItemType.Item, ListItemType.AlternatingItem

                If Not Session("grdListConsultations") Is Nothing Then

                    ds = Session("grdListConsultations")

                    If ds.Tables.Count > 0 Then

                        If ds.Tables(0).Rows.Count > 0 Then

                            With ds.Tables(0).Rows(index)
                                Try
                                    sSibatDchiya = .Item("SibatDchiya")

                                    Dim sTempAsmachtaValue As String
                                    Dim sAsmachtaValue As String

                                    sTempAsmachtaValue = Me.HidAsmaxta.Value
                                    sAsmachtaValue = dgItem.Cells(13).Text

                                    If sTempAsmachtaValue = sAsmachtaValue Then

                                        'dgItem.Cells(13).BackColor = Color.Aqua
                                        'dgItem.Cells(12).BackColor = Color.Aqua
                                        'dgItem.Cells(11).BackColor = Color.Aqua
                                        'dgItem.Cells(10).BackColor = Color.Aqua
                                        'dgItem.Cells(9).BackColor = Color.Aqua
                                        'dgItem.Cells(8).BackColor = Color.Aqua
                                        'dgItem.Cells(7).BackColor = Color.Aqua
                                        'dgItem.Cells(6).BackColor = Color.Aqua
                                        'dgItem.Cells(5).BackColor = Color.Aqua
                                        'dgItem.Cells(4).BackColor = Color.Aqua
                                        'dgItem.Cells(3).BackColor = Color.Aqua
                                        'dgItem.Cells(2).BackColor = Color.Aqua
                                        'dgItem.Cells(1).BackColor = Color.Aqua
                                        'dgItem.Cells(0).BackColor = Color.Aqua


                                    End If

                                Catch ex As Exception

                                End Try
                            End With


                            'Dim spanShowReason As HtmlGenericControl = DirectCast(dgi.FindControl("spanShowReason"), HtmlGenericControl)

                            'If sSibatDchiya = "" Then
                            '    spanShowReason.Visible = False
                            'Else
                            '    spanShowReason.Visible = True ' spanShowReasonRequests.Attributes.Add("onclick", "ShowReason(this,'" + sSibatDchiya + "');")

                            'End If

                        End If

                    End If

                End If


        End Select
    End Sub


    '******************************
    '    grdListAccount
    '******************************
    Private Sub BindGridAccount(ByVal sSort As String)


        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim ds As New DataSet


        Dim sDayForReport As String = HidDayForReport.Value

        sDayForReport = sDayForReport.Replace("/", "")

        If Not Session("GetDataForHDReportDailyRequests") Is Nothing Then
            ds = Session("GetDataForHDReportDailyRequests")
        Else
            ds = objTreatmentService.GetDataForHDReportDailyRequests("3692025C-B925-407E-9A17-4BCBB3ECC7A8", GetSubUserName(), _
                                                                     CInt(HidSugDivuach.Value), 0, iCompanySign, sDayForReport, "")
            Session("GetDataForHDReportDailyRequests") = ds
        End If



        If Not ds Is Nothing Then
            If ds.Tables.Count > 0 Then
                If ds.Tables(0).Rows.Count > 0 Then

                    Session("grdListAccount") = ds

                    Try


                        sSumMesameret = ds.Tables(0).Compute("sum(SchumHechzer)", "SUG_TIPUL = 1")



                    Catch ex As Exception
                        sSumMesameret = ""
                    End Try


                    Try


                        sSumMesakemet = ds.Tables(0).Compute("sum(SchumHechzer)", "SUG_TIPUL > 1")


                    Catch ex As Exception
                        sSumMesakemet = "0.00"
                    End Try
                    Dim sTaarichZikuyLocal = ds.Tables(0).Rows(0)("TaarichZikuy").ToString
                    sTaarichZikuy = Right(sTaarichZikuyLocal, 2) + "/" + Mid(sTaarichZikuyLocal, 5, 2) + "/" + Left(sTaarichZikuyLocal, 4)

                    sMisparBank = ds.Tables(0).Rows(0)("Bank").ToString
                    sMisparShnif = ds.Tables(0).Rows(0)("Shnif").ToString
                    sMisparChsbonBank = ds.Tables(0).Rows(0)("DR_HESHBON_BANQ").ToString
                    sMisparChsbon_Han = ds.Tables(0).Rows(0)("DR_HESHBON_HANHASH").ToString
                    sMisparTikNikuim = ds.Tables(0).Rows(0)("DR_TIQ_NIKUIM").ToString

                    dcAhuzNikuyMas = Convert.ToDecimal(ds.Tables(0).Rows(0)("DR_AHUZ_NIKUY_MAS"))
                    sAhuzNikuyMas = dcAhuzNikuyMas.ToString("##0.00")

                    sSumRows = ds.Tables(0).Rows.Count


                    Session("sSumMesameretForAccount") = sSumMesameret
                    Session("sSumMesakemetForAccount") = sSumMesakemet
                    Session("sTaarichZikuytForAccount") = sTaarichZikuy
                    Session("SumRowsForAccount") = sSumRows

                    sDayForReport = sDayForReport.Substring(0, 2) + "/" + sDayForReport.Substring(2, 2) + "/" + sDayForReport.Substring(4, 4)


                    HiDoctorId.Value = ds.Tables(1).Rows(0)("DoctorID").ToString
                    HiDoctorName.Value = ds.Tables(0).Rows(0)("ClinicName").ToString
                    tdDistTitle.InnerHtml = "סיכום חשבון"
                    tdDistTitle.InnerHtml = tdDistTitle.InnerHtml & " לרופא\ספק שמספרו  " + HiDoctorId.Value + _
                                            " " + HiDoctorName.Value & "</br>" + _
                    " הופק בתאריך " & sDayForReport


                    If (Not IsAfterMerging()) Then
                        CType(Master.FindControl("Logo"), System.Web.UI.HtmlControls.HtmlImage).Src = String.Format("../HDpics/logo.png?key={0}", Now.Ticks)
                        CType(Master.FindControl("headerMerging"), System.Web.UI.HtmlControls.HtmlGenericControl).Style.Add("background", GetStyleColor(True))
                    End If


                    If (Not ds.Tables(0).Rows(0)("SchumHechzer") Is System.DBNull.Value) Then
                        If (Not ds.Tables(0).Rows(0)("SchumHechzer").ToString = "") Then


                            Try




                                dcSum_TASHLUM_MEVUTAH = Convert.ToDecimal(ds.Tables(0).Compute("Sum(SchumHechzer)", "True"))
                                sSum_TASHLUM_MEVUTAH = dcSum_TASHLUM_MEVUTAH.ToString()


                            Catch ex As Exception
                                sSum_TASHLUM_MEVUTAH = ""
                            End Try


                        Else
                            sSum_TASHLUM_MEVUTAH = ""

                        End If
                    Else
                        sSum_TASHLUM_MEVUTAH = ""
                    End If



                    Dim dcSum_TASHLUM_MEVUTAH_Nikuy As Decimal
                    dcSum_TASHLUM_MEVUTAH_Nikuy = (dcSum_TASHLUM_MEVUTAH / 100) * dcAhuzNikuyMas
                    sSum_TASHLUM_MEVUTAH_Nikuy = dcSum_TASHLUM_MEVUTAH_Nikuy.ToString("##0.00")

                    Dim dcSum_TASHLUM_MEVUTAH_After_Nikuy As Decimal
                    dcSum_TASHLUM_MEVUTAH_After_Nikuy = dcSum_TASHLUM_MEVUTAH - dcSum_TASHLUM_MEVUTAH_Nikuy
                    sSum_TASHLUM_MEVUTAH_After_Nikuy = dcSum_TASHLUM_MEVUTAH_After_Nikuy.ToString("##0.00")



                    Dim dv As DataView



                    dv = New DataView(ds.Tables(0), _
                           "", _
                           sSort, DataViewRowState.CurrentRows)

                    dv.Sort() = sSort


                    grdListAccount.DataSource = dv

                    grdListAccount.DataBind()

                Else
                    Me.HidErr.Value = ".אין נתונים לדוח דינמי זה. הנתונים נמצאים בדוח הסטטי"
                End If
            Else
                Me.HidErr.Value = ".אין נתונים לדוח דינמי זה. הנתונים נמצאים בדוח הסטטי"
            End If
        Else
            Me.HidErr.Value = ".אין נתונים לדוח דינמי זה. הנתונים נמצאים בדוח הסטטי"
        End If


    End Sub

    Private Sub grdListAccount_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles grdListAccount.SortCommand
        Try
            Dim currentPage As Integer = Me.grdListAccount.CurrentPageIndex
            Dim SortExpression As String = e.SortExpression.ToString()
            Dim SortValue As String = ""
            Select Case SortExpression
                'SortValue 
                Case "TZ ASC"
                    SortValue = "TZ ASC"
                    grdListAccount.Columns(0).SortExpression = SortValue
                    Exit Select



                Case "FullName ASC"
                    SortValue = "FullName ASC"
                    grdListAccount.Columns(1).SortExpression = SortValue
                    Exit Select


                Case Else

                    SortValue = "TZ ASC"
                    grdListAccount.Columns(0).SortExpression = SortValue
                    Exit Select



            End Select

            HidSort.Value = SortValue

            Me.BindGridAccount(SortValue)

        Catch ex As Exception

            Throw ex

        End Try


    End Sub

    Private Sub grdListAccount_ItemCreated(ByVal sender As Object, ByVal e As DataGridItemEventArgs) Handles grdListAccount.ItemCreated
        If e.Item.ItemType = ListItemType.Footer Then
            e.Item.Cells(5).ColumnSpan = 2
            e.Item.Cells.RemoveAt(4)
        End If
    End Sub

    Private Sub grdListAccount_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles grdListAccount.PageIndexChanged
        grdListAccount.CurrentPageIndex = e.NewPageIndex
        BindGridAccount(Me.HidSort.Value)
    End Sub

    Private Sub grdListAccount_ItemDataBound(ByVal sender As Object, ByVal e As DataGridItemEventArgs) Handles grdListAccount.ItemDataBound

        Dim sSibatDchiya As String
        Dim tblCell As TableCell
        Dim index As Integer
        Dim ds As DataSet
        Dim dgItem As DataGridItem = e.Item
        Dim dgi As DataGridItem = DirectCast(e, DataGridItemEventArgs).Item
        Select Case (dgItem.ItemType)

            Case ListItemType.Item, ListItemType.AlternatingItem

                If Not Session("grdListAccount") Is Nothing Then

                    ds = Session("grdListAccount")

                    If ds.Tables.Count > 0 Then

                        If ds.Tables(0).Rows.Count > 0 Then

                            With ds.Tables(0).Rows(index)
                                Try

                                    Dim sTempValue As String

                                    sSibatDchiya = .Item("SibatDchiya")

                                    Dim dr As DataRow = CType(dgItem.DataItem, System.Data.DataRowView).Row
                                    sTempValue = dr.Item("TZ").ToString()

                                    If sFirstValueForTz = sTempValue Then

                                        dgItem.Cells(0).Text = ""
                                        dgItem.Cells(1).Text = ""

                                    Else

                                        sFirstValueForTz = sTempValue
                                        dgItem.Cells(0).Text = dr.Item("TZ").ToString()
                                        dgItem.Cells(1).Text = dr.Item("FullName").ToString
                                    End If


                                    'Dim spanShowReasonRequestsAccount As HtmlGenericControl = DirectCast(dgi.FindControl("spanShowReasonRequestsAccount"), HtmlGenericControl)


                                    'If sSibatDchiya = "" Then
                                    '    spanShowReasonRequestsAccount.Visible = False
                                    'Else
                                    '    spanShowReasonRequestsAccount.Visible = True ' spanShowReasonRequests.Attributes.Add("onclick", "ShowReason(this,'" + sSibatDchiya + "');")

                                    'End If


                                Catch ex As Exception

                                End Try

                                index = index + 1

                            End With

                        End If

                    End If

                End If


        End Select
    End Sub




    Protected Function SetSibatDchiya(ByRef objCode As Object, ByRef objCode1 As Object) As String
        Dim strReturn As String = ""
        If Not IsDBNull(objCode1) Then

            Select Case objCode1
                Case "No"
                    strReturn = "מכוסה"
                Case Else

                    If Not IsDBNull(objCode) Then

                        strReturn = objCode

                    End If


            End Select
        End If
        Return strReturn
    End Function

    Protected Function SetSibatDchiyaShort(ByRef objCode As Object, ByRef objCode1 As Object) As String
        Dim strReturn As String = "" ' "<u>נדחה</u>"
        If Not IsDBNull(objCode1) Then

            Select Case objCode1
                Case "No"
                    strReturn = "מכוסה"
                Case Else

                    '' '' '' '' ''If Not IsDBNull(objCode) Then


                    '' '' '' '' ''    If objCode.Length < 5 Then
                    '' '' '' '' ''        strReturn = objCode
                    '' '' '' '' ''    Else
                    '' '' '' '' ''        strReturn = "<u>נדחה</u>" 'objCode.Substring(0, 4) + "..."
                    '' '' '' '' ''    End If

                    '' '' '' '' ''End If

            End Select
        End If
        Return strReturn
    End Function




    Protected Function SetHisMitrape(ByRef objCodeSchumHechzer As Object, ByRef objCodeSibatDchiya As Object) As String

        Dim strReturn As String = ""

        If Not IsDBNull(objCodeSchumHechzer) Then

            If Not IsDBNull(objCodeSibatDchiya) And objCodeSibatDchiya <> "" Then

                'strReturn = "<u>" + objCodeSchumHechzer.ToString + "</u>"
                strReturn = objCodeSchumHechzer.ToString

            Else
                strReturn = objCodeSchumHechzer.ToString

            End If

        Else

            If Not IsDBNull(objCodeSibatDchiya) And objCodeSibatDchiya <> "" Then

                'strReturn = "<u>" + "סיבה" + "</u>"
                'strReturn = "סיבה"
                strReturn = ""

            Else
                strReturn = ""

            End If


        End If

        Return strReturn

    End Function

    Protected Function SetHisMitrapeTooTip(ByRef objCodeSchumHechzer As Object, ByRef objCodeSibatDchiya As Object) As String

        Dim strReturn As String = ""

        If Not IsDBNull(objCodeSchumHechzer) Then

            If Not IsDBNull(objCodeSibatDchiya) And objCodeSibatDchiya <> "" Then

                strReturn = objCodeSibatDchiya.ToString

            Else
                strReturn = ""

            End If

        Else

            If Not IsDBNull(objCodeSibatDchiya) And objCodeSibatDchiya <> "" Then

                strReturn = objCodeSibatDchiya.ToString

            Else
                strReturn = ""

            End If



        End If

        Return strReturn

    End Function



    Protected Function SetSchumHechzer(ByRef objCode As Object, ByRef objCodeSibatDchiya As Object, ByRef objCode1 As Object) As String
        Dim strReturn As String = "<u>נדחה</u>"
        If Not IsDBNull(objCode1) Then

            Select Case objCode1

                '*******************
                Case "No"
                    '*******************



                    If Not IsDBNull(objCode) Then

                        If CInt(objCode) < 0 Then
                            objCode = Math.Abs(Convert.ToDecimal(objCode)).ToString + "-"
                        End If


                        'strReturn = objCode
                        If IsDBNull(objCodeSibatDchiya) Or objCodeSibatDchiya = "" Then

                            '1. SchumHechzer without SibatDchiya




                            strReturn = objCode

                        Else

                            '2. SchumHechzer with SibatDchiya

                            strReturn = "<u>" + objCode.ToString + "</u>"

                        End If


                    Else


                        If IsDBNull(objCodeSibatDchiya) Or objCodeSibatDchiya = "" Then

                            '3. NO  SchumHechzer AND NO  SibatDchiya


                            strReturn = ""
                        Else

                            '4. NO  SchumHechzer AND THERE IS  SibatDchiya


                            strReturn = "<u>נדחה</u>"

                        End If



                    End If

                    '*******************
                Case Else
                    '*******************

                    If IsDBNull(objCodeSibatDchiya) Or objCodeSibatDchiya = "" Then

                        strReturn = ""

                    Else

                        strReturn = "<u>נדחה</u>"
                    End If




            End Select

        End If

        Return strReturn

    End Function

    Protected Function SetSchumHechzerForToolTip(ByRef objCode As Object, ByRef objCodeSibatDchiya As Object, ByRef objCode1 As Object) As String
        Dim strReturn As String = objCodeSibatDchiya.ToString
        If Not IsDBNull(objCode1) Then

            'Select Case objCode1
            '    Case "No"

            '        If Not IsDBNull(objCode) Then

            '            strReturn = ""

            '        End If


            '    Case Else
            '        strReturn = objCodeSibatDchiya.ToString


            'End Select





            Select Case objCode1

                '*******************
                Case "No"
                    '*******************



                    If Not IsDBNull(objCode) Then

                        'strReturn = objCode
                        If IsDBNull(objCodeSibatDchiya) Or objCodeSibatDchiya = "" Then

                            '1. SchumHechzer without SibatDchiya

                            strReturn = ""

                        Else

                            '2. SchumHechzer with SibatDchiya

                            strReturn = objCodeSibatDchiya.ToString

                        End If


                    Else


                        If IsDBNull(objCodeSibatDchiya) Or objCodeSibatDchiya = "" Then

                            '3. NO  SchumHechzer AND NO  SibatDchiya


                            strReturn = ""
                        Else

                            '4. NO  SchumHechzer AND THERE IS  SibatDchiya


                            strReturn = objCodeSibatDchiya.ToString

                        End If



                    End If

                    '*******************
                Case Else
                    '*******************

                    If IsDBNull(objCodeSibatDchiya) Or objCodeSibatDchiya = "" Then

                        strReturn = ""
                    Else

                        strReturn = objCodeSibatDchiya.ToString

                    End If




            End Select























        End If
        Return strReturn
    End Function







    Protected Function SibatDchiyaHityaachyut(ByRef objSibatDchiya As Object, ByRef objDr_Status_Pniya As Object) As String
        Dim strReturn As String = ""


        ''**********111*************

        If ((objDr_Status_Pniya = "מ") And _
            (objSibatDchiya = "")) Then

            strReturn = "מכוסה"

        End If

        ''**********222*************

        If ((objDr_Status_Pniya = "מ") And _
            (objSibatDchiya <> "")) Then

            strReturn = "<u>מכוסה</u>"

        End If

        ''**********333*************

        If ((objDr_Status_Pniya = "") And _
            (objSibatDchiya = "")) Then

            strReturn = ""

        End If

        ''***********444************
        If ((objDr_Status_Pniya = "") And _
              (objSibatDchiya <> "")) Then

            strReturn = "<u>" + "סיבה" + "</u>"

        End If


        ''**********555*************
        If ((objDr_Status_Pniya = "ל") And _
                        (objSibatDchiya = "")) Then

            strReturn = "נדחה"

        End If

        ''**********666*************
        If ((objDr_Status_Pniya = "ל") And _
            (objSibatDchiya <> "")) Then

            strReturn = "<u>נדחה</u>"

        End If


        Return strReturn

    End Function

    Protected Function SibatDchiyaHityaachyutToolTip(ByRef objSibatDchiya As Object, ByRef objDr_Status_Pniya As Object) As String

        Dim strReturn As String = ""


        ''**********111*************

        If ((objDr_Status_Pniya = "מ") And _
            (objSibatDchiya = "")) Then

            strReturn = ""

        End If

        ''**********222*************

        If ((objDr_Status_Pniya = "מ") And _
            (objSibatDchiya <> "")) Then

            strReturn = objSibatDchiya

        End If

        ''**********333*************

        If ((objDr_Status_Pniya = "") And _
            (objSibatDchiya = "")) Then

            strReturn = ""

        End If

        ''***********444************
        If ((objDr_Status_Pniya = "") And _
              (objSibatDchiya <> "")) Then

            strReturn = objSibatDchiya

        End If


        ''**********555*************
        If ((objDr_Status_Pniya = "ל") And _
                        (objSibatDchiya = "")) Then

            strReturn = ""

        End If

        ''**********666*************
        If ((objDr_Status_Pniya = "ל") And _
            (objSibatDchiya <> "")) Then

            strReturn = objSibatDchiya

        End If


        Return strReturn.Replace("'", "&rsquo;")
    End Function












    Protected Function SetSchumHechzerTviot(ByRef objSchumHechzerde As Object, ByRef objSibatDchiya As Object, ByRef objDr_Status_Pniya As Object) As String
        Dim strReturn As String = ""

        'If IsDBNull(objSchumHechzerde) Then
        '    objSchumHechzerde = ""
        'End If

        'If IsDBNull(objSibatDchiya) Then
        '    objSibatDchiya = ""
        'End If

        'If IsDBNull(objDr_Status_Pniya) Then
        '    objDr_Status_Pniya = ""
        'End If

        ''**********111*************

        If ((objDr_Status_Pniya = "" Or objDr_Status_Pniya = "מ") And _
            (IsDBNull(objSchumHechzerde)) And _
            (objSibatDchiya = "")) Then


            strReturn = ""


        End If

        ''**********222*************

        If ((objDr_Status_Pniya = "" Or objDr_Status_Pniya = "מ") And _
            (IsDBNull(objSchumHechzerde)) And _
            (objSibatDchiya <> "")) Then


            strReturn = "<u>סיבה</u>"


        End If

        ''**********333*************

        If ((objDr_Status_Pniya = "" Or objDr_Status_Pniya = "מ") And _
            (Not IsDBNull(objSchumHechzerde)) And _
            (objSibatDchiya = "")) Then

            If CInt(objSchumHechzerde) < 0 Then
                objSchumHechzerde = Math.Abs(Convert.ToDecimal(objSchumHechzerde)).ToString + "-"
            End If


            strReturn = objSchumHechzerde

        End If

        ''***********444************
        If ((objDr_Status_Pniya = "" Or objDr_Status_Pniya = "מ") And _
            (Not IsDBNull(objSchumHechzerde)) And _
            (objSibatDchiya <> "")) Then

            If CInt(objSchumHechzerde) < 0 Then
                objSchumHechzerde = Math.Abs(Convert.ToDecimal(objSchumHechzerde)).ToString + "-"
            End If


            strReturn = "<u>" + objSchumHechzerde.ToString + "</u>"

        End If


        ''**********555*************
        If ((objDr_Status_Pniya = "ל") And _
            (IsDBNull(objSchumHechzerde)) And _
            (objSibatDchiya = "")) Then

            strReturn = "נדחה"

        End If

        ''**********666*************
        If ((objDr_Status_Pniya = "ל") And _
            (IsDBNull(objSchumHechzerde)) And _
            (objSibatDchiya <> "")) Then

            strReturn = "<u>נדחה</u>"

        End If

        ''***********777************
        If ((objDr_Status_Pniya = "ל") And _
            (Not IsDBNull(objSchumHechzerde)) And _
            (objSibatDchiya = "")) Then

            If CInt(objSchumHechzerde) < 0 Then
                objSchumHechzerde = Math.Abs(Convert.ToDecimal(objSchumHechzerde)).ToString + "-"
            End If


            strReturn = objSchumHechzerde

        End If

        ''***********888************
        If ((objDr_Status_Pniya = "ל") And _
            (Not IsDBNull(objSchumHechzerde)) And _
            (objSibatDchiya <> "")) Then

            If CInt(objSchumHechzerde) < 0 Then
                objSchumHechzerde = Math.Abs(Convert.ToDecimal(objSchumHechzerde)).ToString + "-"
            End If


            strReturn = "<u>" + objSchumHechzerde + "</u>"

        End If



        Return strReturn

    End Function


    Protected Function SetShemTypul(ByRef objShemTypul As Object) As String

        Dim strReturn As String = ""
        Dim strReturn1 As String = ""

        If Not IsDBNull(objShemTypul) Then
            If objShemTypul <> "" Then
                strReturn = objShemTypul.ToString
                strReturn1 = strReturn.Replace("AB(AB", ")")
            End If
        End If

        Return strReturn1.Replace("'", "&rsquo;")

    End Function




    Protected Function SetSchumHechzerForToolTipTviot(ByRef objSchumHechzerde As Object, ByRef objSibatDchiya As Object, ByRef objDr_Status_Pniya As Object) As String

        Dim strReturn As String = ""

        'If IsDBNull(objSchumHechzerde) Then
        '    objSchumHechzerde = ""
        'End If

        'If IsDBNull(objSibatDchiya) Then
        '    objSibatDchiya = ""
        'End If

        'If IsDBNull(objDr_Status_Pniya) Then
        '    objDr_Status_Pniya = ""
        'End If

        ''**********111*************

        If ((objDr_Status_Pniya = "" Or objDr_Status_Pniya = "מ") And _
            (IsDBNull(objSchumHechzerde)) And _
            (objSibatDchiya = "")) Then


            strReturn = ""


        End If

        ''**********222*************

        If ((objDr_Status_Pniya = "" Or objDr_Status_Pniya = "מ") And _
            (IsDBNull(objSchumHechzerde)) And _
            (objSibatDchiya <> "")) Then


            strReturn = objSibatDchiya


        End If

        ''**********333*************

        If ((objDr_Status_Pniya = "" Or objDr_Status_Pniya = "מ") And _
            (Not IsDBNull(objSchumHechzerde)) And _
            (objSibatDchiya = "")) Then

            strReturn = ""

        End If

        ''***********444************
        If ((objDr_Status_Pniya = "" Or objDr_Status_Pniya = "מ") And _
            (Not IsDBNull(objSchumHechzerde)) And _
            (objSibatDchiya <> "")) Then

            strReturn = objSibatDchiya

        End If


        ''**********555*************
        If ((objDr_Status_Pniya = "ל") And _
            (IsDBNull(objSchumHechzerde)) And _
            (objSibatDchiya = "")) Then

            strReturn = ""

        End If

        ''**********666*************
        If ((objDr_Status_Pniya = "ל") And _
            (IsDBNull(objSchumHechzerde)) And _
            (objSibatDchiya <> "")) Then

            strReturn = objSibatDchiya

        End If

        ''***********777************
        If ((objDr_Status_Pniya = "ל") And _
            (Not IsDBNull(objSchumHechzerde)) And _
            (objSibatDchiya = "")) Then

            strReturn = ""

        End If

        ''***********888************
        If ((objDr_Status_Pniya = "ל") And _
            (Not IsDBNull(objSchumHechzerde)) And _
            (objSibatDchiya <> "")) Then

            strReturn = objSibatDchiya

        End If


        Return strReturn.Replace("'", "&rsquo;")

    End Function



    Protected Function SetKodTypul(ByRef objKodTypul As Object) As String
        Dim strReturn As String = ""


        If Not IsDBNull(objKodTypul) Then

            If objKodTypul <> "" Then
                strReturn = "<u>" + objKodTypul.ToString + "</u>"
            End If

        End If


        Return strReturn

    End Function

    Protected Function GetStyleColor(Optional ByVal isBackGround As Boolean = False) As String
        '  здесь должно быть три цвета... первый цвет - на что меняем (зеленый), второй цвет - цвет заголовков, третий цвет - верхняя полоса на master page
        Dim GreenStyle As String() = Application("GreenStyle").ToString().Split(";")

        If IsAfterMerging() Then
            Return GreenStyle(0)
        Else
            If isBackGround Then
                Return GreenStyle(2)
            Else
                Return GreenStyle(1)
            End If
        End If

    End Function

    Protected Function SetSibatHachlataShort(ByRef objCode As Object) As String
        Dim strReturn As String = ""
        If Not IsDBNull(objCode) Then

            If objCode.Length < 5 Then
                strReturn = objCode
            Else
                strReturn = objCode.Substring(0, 1) + "..."
            End If

        End If
        Return strReturn
    End Function

    Protected Function SetTextTreatmentDesctData(ByRef objCode As Object) As String

        Dim sTextHospitalDept As String
        Dim sTextHospitalDeptReturn As String
        sTextHospitalDept = objCode.ToString()

        If sTextHospitalDept.Length < 31 Then
            sTextHospitalDeptReturn = sTextHospitalDept
        Else
            sTextHospitalDeptReturn = sTextHospitalDept.Substring(0, 30) + "..."
        End If

        Return sTextHospitalDeptReturn


    End Function

    Protected Function SetSpaces() As String

        Dim sReturn As String
        Dim idx As Integer
        Dim iEnd As Integer
        Dim iSumMesakemetLength As Integer

        If sSumMesakemet = "" Then
            Return sReturn
        End If

        iSumMesakemetLength = sSumMesakemet.Length


        Select Case iSumMesakemetLength
            Case 2
                iEnd = 40
            Case 3
                iEnd = 38
            Case 4
                iEnd = 36
            Case 5
                iEnd = 34
            Case 6
                iEnd = 32
            Case 7
                iEnd = 30
            Case 8
                iEnd = 28
            Case 9
                iEnd = 26
            Case Else
                iEnd = 35
        End Select


        For idx = 0 To iEnd

            sReturn = sReturn + "&nbsp;"

        Next



        Return sReturn

    End Function

    Protected Function SetSpaces1() As String

        Dim sReturn As String
        Dim idx As Integer
        Dim iEnd As Integer
        Dim isAhuzNikuyMasLength As Integer

        If sAhuzNikuyMas = "" Then
            Return sReturn
        End If

        isAhuzNikuyMasLength = sAhuzNikuyMas.Length


        Select Case isAhuzNikuyMasLength
            Case 2
                iEnd = 40
            Case 3
                iEnd = 38
            Case 4
                iEnd = 36
            Case 5
                iEnd = 34
            Case 6
                iEnd = 32
            Case 7
                iEnd = 30
            Case 8
                iEnd = 28
            Case 9
                iEnd = 26
            Case Else
                iEnd = 35
        End Select


        For idx = 0 To iEnd

            sReturn = sReturn + "&nbsp;"

        Next



        Return sReturn

    End Function

    Protected Function SetTextTreatmentDescTitle(ByRef objCode As Object) As String

        Dim sTextHospitalDeptData As String
        Dim sTextHospitalDeptDataForReturn As String
        sTextHospitalDeptData = objCode.ToString()
        sTextHospitalDeptDataForReturn = sTextHospitalDeptData.Replace("'", "&quot;")

        Return sTextHospitalDeptDataForReturn

    End Function

    Public Function GetTitle() As String
        Return sTitle
    End Function


    Private Sub cmdReply_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReply.ServerClick
        If HidSourchWin.Value <> "" Then
            Response.Redirect("frmHDStart.aspx?frmHDReportDailyRequests=1")
        Else
            Response.Redirect("frmHDRepList.aspx")

        End If

    End Sub

    Enum eSugDivuach As Integer
        eRequests = 11
        eConsultations = 41
        eAccount = 10

    End Enum

    Enum eCompanySign As Integer
        eDikla = 0
        eHarel = 1

    End Enum

    Enum eSourchWin As Integer
        eHdStart = 0
        eOther = 1

    End Enum

    Function GetSubUserName() As String

        Dim strSubUserID As String = Session("SubUserIDForRepList")
        objUser.Url = Application("UserWebService").ToString()
        Dim strSubUserName As String = objUser.GetUserNameByID("C5C4C694-E524-41D3-8ECD-38CE8434FE4B", strSubUserID)
        Return strSubUserName

    End Function

End Class