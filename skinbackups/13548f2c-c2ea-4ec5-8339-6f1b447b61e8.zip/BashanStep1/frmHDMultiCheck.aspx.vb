﻿Public Partial Class frmHDMultiCheck
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' CType(Master.FindControl("MainTitle"), Literal).Text = "מערכת הוד - בדיקת זכאות מרוכזת"
        Dim sMainTitle As String = "מערכת הוד - " & Page.Title
        CType(Master.FindControl("MainTitle"), Literal).Text = sMainTitle
        Page.Title = sMainTitle

        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        If Not objUser.GetMultiCheckZakautPermition("4B29B2CF-68DB-4748-8725-0DBE5F74F371", User.Identity.Name) Then
            objUser.AddUserIllegalAction("24304391-6FDE-4237-A9B6-49630958EB26", User.Identity.Name, "frmMultiCheck")
            Utils.LogOut()
        End If
        If IsNothing(Session("Login_User")) OrElse Len(Session("Login_User")) = 0 Then
            Utils.LogOut()
        End If
        Session("HOD_MultiCheck_Reference") = ""
        Dim iFromCmdClean As Integer = 0
        If Not Request.QueryString("c") Is Nothing Then
            If Val(Request.QueryString("c").ToString) = 1 Then
                iFromCmdClean = 1
            End If
        End If

        hidHaveGovernmentTreatments.Value = Application("GovernmentTreatments").ToString()
        hidShowOldTreatments.Value = Application("ShowOldTreatments").ToString()

        If Not IsPostBack Then

            If Not Session("HDInsuredID") Is Nothing Then
                If Session("HDInsuredID").ToString <> "" Then
                    txtInsuredID.Value = Session("HDInsuredID").ToString
                End If
            End If

            If Not Session("HDSHEM") Is Nothing Then
                If Session("HDSHEM").ToString <> "" Then
                    txtInsuredName.Value = Session("HDSHEM").ToString
                End If
            End If

            If Not Session("HDMISP") Is Nothing Then
                If Session("HDMISP").ToString <> "" Then
                    txtInsuredFamily.Value = Session("HDMISP").ToString
                End If
            End If



            If Session("User_Login_First_Time") = "1" Then
                Response.Redirect("frmUserProp.aspx")
            End If
            If Application("Smile") = "1" Or Application("CompanyID").ToString = "3" Then
                'cmdCopy.Visible = False
                cmdNewReq.Visible = False
                cmdClean.Visible = False
                txtSkipCheck.Value = "1"

                '' !!!!!
                Session("TRequest_InsuredID") = "18"
                Session("TRequest_InsuredName") = "Abc"
                Session("TRequest_InsuredFamily") = "Dfg"

            End If
            If Session("BSHN_Independed") = "1" Then
                doctor.DoctorCare.Visible = False
                doctor.DoctorCareName.Visible = True
            Else
                doctor.DoctorCare.Visible = True
                doctor.DoctorCareName.Visible = False
            End If
            txtDoctorType.Value = CStr(objUser.GetUserDoctorType("C049B33B-243D-43C1-B2F5-AB4859F9EBD1", User.Identity.Name))
            FillDefaults(iFromCmdClean)
            FillNameAndId()
        End If
    End Sub

    Private Sub FillDefaults(ByVal iFromCmdClean As Integer)
        txtData.Value = ""
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

        Dim strDoctorCareName As String
        Dim strDoctorCareNumber As String
        Dim strClinicName As String
        Dim strClinicNumber As String
        If objTreatmentService.GetDoctorProperties("7EC6114A-62CD-4DC4-A940-1416BFB136D8", User.Identity.Name, strDoctorCareName, strDoctorCareNumber, strClinicName, strClinicNumber) Then
            If Session("BSHN_Independed") = "1" Then
                doctor.DoctorCareName.Text = strDoctorCareName
                doctor.DoctorCareNumber.Value = strDoctorCareNumber
            Else
                doctor.FillDoctorCare()
                If doctor.DoctorCare.Items.Count > 1 Then
                Else
                    doctor.DoctorCareNumber.Value = strDoctorCareNumber
                End If
                If iFromCmdClean = 1 Then



                    'txtInsuredID.Attributes.Add("readonly", "true")


                    Try
                        If IsNumeric(Session("MRequest_DoctorCare")) Then
                            doctor.DoctorCare.SelectedIndex = Val(Session("MRequest_DoctorCare"))
                            doctor.DoctorCareNumber.Value = Session("MRequest_DoctorCareName").ToString
                        End If
                    Finally
                        '
                    End Try
                End If
            End If
            doctor.ClinicName.Value = strClinicName
            doctor.ClinicNumber.Value = strClinicNumber
        End If
        Dim isSmileAgrementClinic As Boolean = False
        Dim iSmileAgrementClinicPlus As Integer = 0
        If Application("Smile") = "1" Then
            iSmileAgrementClinicPlus = objUser.CheckIfAgrementClinicPlus("2AFAE3F5-79B5-459E-B1F9-C460BD34672A", User.Identity.Name)
            If iSmileAgrementClinicPlus > 0 Then
                isSmileAgrementClinic = True
            End If
        End If
        Dim ds As DataSet
        If Session("Leumit_OnlyServiceBasket") = "1" Or isSmileAgrementClinic Then
            If iSmileAgrementClinicPlus = 2 Then
                ds = objTreatmentService.GetTreatmentTypesForServiceBasketPlus("9E01224E-7A57-4E50-A64F-857E4DB868CC")
            Else
                ds = objTreatmentService.GetTreatmentTypesForServiceBasket("3E1378D4-4A76-4F92-B0AF-CB3AFBA60DA4")
            End If
        ElseIf Session("Smile_OnlyServiceBasketNet") = "1" Then
            ds = objTreatmentService.GetTreatmentTypesForServiceBasketNet("2DABD6CC-E754-44EF-8EAD-2044986E91E0")
        Else
            ds = objTreatmentService.GetTreatmentTypes("1C39E920-093F-46B2-BEE7-A4D459A3F1CC")
        End If
        FillCareGroup(lstCareGroup0, ds, isSmileAgrementClinic)
        FillCareGroup(lstCareGroup1, ds, isSmileAgrementClinic)
        FillCareGroup(lstCareGroup2, ds, isSmileAgrementClinic)
        FillCareGroup(lstCareGroup3, ds, isSmileAgrementClinic)
        FillCareGroup(lstCareGroup4, ds, isSmileAgrementClinic)
        FillCareGroup(lstCareGroup5, ds, isSmileAgrementClinic)
        FillCareGroup(lstCareGroup6, ds, isSmileAgrementClinic)
        FillCareType()
        FillOccasion()
        FillToothRange()
    End Sub

    Private Sub FillCareGroup(ByRef cbo As HtmlSelect, ByRef ds As DataSet, ByVal isSmileAgrementClinic As Boolean)
        cbo.Items.Clear()
        cbo.Items.Add(New ListItem(" ", 0))
        If Application("Smile") = "1" And Application("Smile_Platinum_18_Supported") = "1" And Session("Smile_Platinum_18") = "1" And Not isSmileAgrementClinic Then
            cbo.Items.Add(New ListItem("משמר", 1))
        Else
            If Not ds Is Nothing Then
                Dim currRow As DataRow
                For Each currRow In ds.Tables(0).Rows
                    cbo.Items.Add(New ListItem(Trim(currRow("TreatmentType").ToString()), currRow("TreatmenTypetID").ToString()))
                Next
            End If
        End If
        cbo.SelectedIndex = 0
    End Sub

    Private Sub FillCareType()
        Dim bGovernmentTreatments As Boolean = CBool(Application("GovernmentTreatments").ToString())

        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim ds As DataSet, dsGov As DataSet
        Dim isSmileAgrementClinic As Boolean = False
        Dim iSmileAgrementClinicPlus As Integer = 0
        If Application("Smile") = "1" Then
            iSmileAgrementClinicPlus = objUser.CheckIfAgrementClinicPlus("2AFAE3F5-79B5-459E-B1F9-C460BD34672A", User.Identity.Name)
            If iSmileAgrementClinicPlus > 0 Then
                isSmileAgrementClinic = True
            End If
        End If
        If Session("Leumit_OnlyServiceBasket") = "1" Or isSmileAgrementClinic Then
            If iSmileAgrementClinicPlus = 2 Then
                ds = objTreatmentService.GetAllTreatmentTypesForServiceBasketPlus("D121D046-A065-4019-B2C7-02FB9B30CBCC")
            Else
                ds = objTreatmentService.GetAllTreatmentTypesForServiceBasket("47759429-F84B-4A22-B3C0-5287F4925220")
            End If
        ElseIf Session("Smile_OnlyServiceBasketNet") = "1" Then
            ds = objTreatmentService.GetAllTreatmentTypesForServiceBasketNet("DF3AC6C7-7339-49AC-86C5-0598A341F908")
            'ElseIf bGovernmentTreatments Then
            '    ds = objTreatmentService.GetAllTreatmentTypesMultiCheckGov("0D28AC92-0CA6-4ED5-8ECF-8C5E72025CEA")
        Else
            ds = objTreatmentService.GetAllTreatmentTypesMultiCheck("139AA870-2579-4f80-B875-FF909A50F55F")
        End If

        If bGovernmentTreatments Then
            dsGov = objTreatmentService.GetAllTreatmentTypesMultiCheckGov("0D28AC92-0CA6-4ED5-8ECF-8C5E72025CEA")
        End If

        Dim currRow As DataRow, objItem As ListItem
        lstCareType.Items.Clear()
        Dim bCheckType2 As Boolean = False
        If Application("Smile") = "1" And Application("Smile_Platinum_18_Supported") = "1" And Session("Smile_Platinum_18") = "1" And Not isSmileAgrementClinic Then
            bCheckType2 = True
        End If
        Dim bSmile As Boolean = CBool(Application("Smile") = "1")
        For Each currRow In ds.Tables(0).Rows
            If bCheckType2 And CType(currRow("TreatmentTypeID"), Integer) <> 1 Then
                '
            Else

                objItem = New ListItem(Trim(currRow("Treatment").ToString()), currRow("TreatmentID").ToString())

                objItem.Attributes.Add("CareGroup", currRow("TreatmentTypeID").ToString())
                objItem.Attributes.Add("AllowRange", currRow("AllowRange").ToString())
                If bSmile Then
                    objItem.Attributes.Add("SmileCode", currRow("SmileTreatmentID").ToString())
                Else
                    objItem.Attributes.Add("SmileCode", currRow("TreatmentID").ToString())
                End If
                lstCareType.Items.Add(objItem)
            End If
        Next

        If bGovernmentTreatments Then
            For Each currRow In dsGov.Tables(0).Rows
                If bCheckType2 And CType(currRow("TreatmentTypeID"), Integer) <> 1 Then
                    '
                Else
                    objItem = New ListItem(Trim(currRow("GovTreatmentDescription").ToString()), currRow("TreatmentID").ToString())

                    objItem.Attributes.Add("CareGroup", currRow("TreatmentTypeID").ToString())
                    objItem.Attributes.Add("AllowRange", currRow("AllowRange").ToString())

                    objItem.Attributes.Add("SmileCode", currRow("GovTreatmentID").ToString())
                    lstCareTypeGov.Items.Add(objItem)
                End If
            Next
        End If

    End Sub

    Private Sub FillOccasion()
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim ds As DataSet = objTreatmentService.GetCauses("CD6AEA9F-C78F-4942-A749-38C16DE0AA62", -1)
        Dim currRow As DataRow, objItem As ListItem
        lstOccasion.Items.Clear()
        For Each currRow In ds.Tables(0).Rows
            objItem = New ListItem(Trim(currRow("Cause").ToString()), currRow("CauseID").ToString())
            objItem.Attributes.Add("Treatment", currRow("TreatmentID").ToString())
            lstOccasion.Items.Add(objItem)
        Next
    End Sub

    Private Sub FillToothRange()
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim ds As DataSet = objTreatmentService.GetTeethRange("DAD91AA1-DE6F-4C28-8A11-CB0FF79BD302", -1)
        Dim currRow As DataRow, objItem As ListItem
        lstToothRange.Items.Clear()
        For Each currRow In ds.Tables(0).Rows
            objItem = New ListItem(Trim(currRow("ToTooth").ToString()), currRow("FromTooth").ToString())
            objItem.Attributes.Add("Treatment", currRow("TreatmentID").ToString())
            lstToothRange.Items.Add(objItem)
        Next
    End Sub



    Private Sub FillNameAndId()

        If Not Session("TRequest_InsuredID").ToString() = "" Then
            txtInsuredID.Value = Session("TRequest_InsuredID")
        End If

        If Not Session("TRequest_InsuredName").ToString() = "" Then
            txtInsuredName.Value = Session("TRequest_InsuredName")
        End If

        If Not Session("TRequest_InsuredFamily").ToString() = "" Then
            txtInsuredFamily.Value = Session("TRequest_InsuredFamily")
        End If





        If Application("Smile") = "1" Or Application("CompanyID").ToString = "3" Then
            ' Smile or Leumit
            txtInsuredID.Attributes.Remove("onblur")
            txtFName.Value = Session("TRequest_InsuredName")
            txtLName.Value = Session("TRequest_InsuredFamily")
            SetReadOnly(txtInsuredID)
            SetReadOnly(txtInsuredName)
            SetReadOnly(txtInsuredFamily)
        Else
            Session("TRequest_InsuredID") = ""
            Session("TRequest_InsuredName") = ""
            Session("TRequest_InsuredFamily") = ""
        End If
    End Sub

    Private Sub SetReadOnly(ByVal txtField As HtmlInputText)
        txtField.Attributes.Add("readonly", "true")
        txtField.Style.Add("background-Color", "#D6D3CE")
    End Sub

    Private Sub cmdClean_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClean.ServerClick
        If Session("BSHN_Independed") <> "1" Then
            Session("MRequest_DoctorCare") = CStr(doctor.DoctorCare.SelectedIndex)
            Session("MRequest_DoctorCareName") = CStr(doctor.DoctorCare.SelectedValue)
        Else
            Session("MRequest_DoctorCare") = "0"
            Session("MRequest_DoctorCareName") = doctor.DoctorCareNumber.Value
        End If

        Session("HDInsuredID") = Nothing
        Session("HDSHEM") = Nothing
        Session("HDMISP") = Nothing

        Response.Redirect("frmHDMultiCheck.aspx?c=1")
    End Sub

    Private Sub cmdCopy_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCopy.ServerClick
        Session("MRequest_Source") = "1"
        If Session("BSHN_Independed") <> "1" Then
            Session("MRequest_DoctorCare") = CStr(doctor.DoctorCare.SelectedIndex)
            Session("MRequest_DoctorCareName") = CStr(doctor.DoctorCare.SelectedValue)
        Else
            Session("MRequest_DoctorCare") = "0"
            Session("MRequest_DoctorCareName") = doctor.DoctorCareNumber.Value
        End If
        Session("MRequest_InsuredID") = txtInsuredID.Value
        Session("MRequest_InsuredName") = txtInsuredName.Value
        Session("MRequest_InsuredFamily") = txtInsuredFamily.Value
        If Application("Smile") = "1" Or Application("CompanyID").ToString = "3" Then
            Session("MRequest_RequestType") = "1"
        End If
        Response.Redirect("frmHDRequestt.aspx")
    End Sub

    Private Sub cmdNewReq_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdNewReq.ServerClick
        Response.Redirect("frmHDRequestt.aspx") ' todo
    End Sub

    'Private Sub cmdReply_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReply.ServerClick
    '    GetInsuredDetails()

    'End Sub


    'Private Sub GetInsuredDetails()

    '    Dim objBO As New BOConnection.BOService
    '    objBO.Url = Application("BOWebService")

    '    Dim ds As New DataSet
    '    If (txtInsuredID.Value = "") Then
    '        txtError.Value = ""
    '        Return
    '    End If
    '    ds = objBO.GetInsuredDetails("BB91B46E-024D-41F0-97C0-D58FE62388E9", Val(txtInsuredID.Value))


    '    If ds.Tables(0).Rows.Count = 0 Then
    '        txtError.Value = "11"

    '        Session.Remove("HDInsuredID")

    '        Session.Remove("HDSHEM")

    '        Session.Remove("HDMISP")

    '    Else
    '        txtError.Value = ""
    '    End If

    '    'Dim Util As Utils = New Utils
    '    txtInsuredName.Value = Utils.Values.GetFirstTableFirstRowString(ds, "SHEM")
    '    txtInsuredFamily.Value = Utils.Values.GetFirstTableFirstRowString(ds, "MISP")
    '    'FamilyCover.Value = Utils.Values.GetFirstTableFirstRowString(ds, "MSL_TEUR_KISUY_MEVUTAH")
    '    If txtError.Value <> "11" Then

    '        Session("HDInsuredID") = Val(Me.txtInsuredID.Value)
    '        Session("HDSHEM") = txtInsuredName.Value
    '        Session("HDMISP") = txtInsuredFamily.Value

    '    End If

    'End Sub


End Class