Imports System.IO

Public Class frmDownload
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Public ws As MTOMTrans
    Dim isExcel As String
    Dim isPDF As String
    Dim isUrgentMessage As String = ""

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If Not IsPostBack Then

            Dim strCurrentReportID As String = Request.QueryString("CurrentReportID")
            Dim strEnc As String = Request.QueryString("enc")
            Dim strSubUser As String = Request.QueryString("s")

            isExcel = Request.QueryString("isExcel")
            isPDF = Request.QueryString("isPDF")

            If Not Request.QueryString("isUrgentMessage") Is Nothing Then
                isUrgentMessage = Request.QueryString("isUrgentMessage")
            End If



            If IsNumeric(strCurrentReportID) Then

                Dim strTargetFileName As String
                Dim objReportsList As New ReportConnect.ReportService()
                objReportsList.Url = Application("ReportWebService").ToString()
                objReportsList.Timeout = 300000
                Dim strFileName As String = objReportsList.GetReportFileName("AE88E1B7-1337-4ECE-9A9B-5B45EBF52688", strCurrentReportID)
                Dim i As Integer = InStrRev(strFileName, "\")
                If i > 0 Then
                    strTargetFileName = Mid(strFileName, i + 1)
                Else
                    strTargetFileName = strFileName
                End If
                Dim objUser As New UserConnect.UserService()
                objUser.Url = Application("UserWebService").ToString()
                Dim strUserID As String = objUser.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", User.Identity.Name)
                If Not IsNumeric(strSubUser) Then
                    strSubUser = strUserID
                Else
                    If Val(strSubUser) = 0 Then
                        strSubUser = strUserID
                    End If
                End If

                '***********************************
                If strEnc = "1" Then
                    '***********************************

                    Dim Pwd As Byte() = GetFilePassword()
                    objReportsList.UpdateReportViewState("EB917314-AEB1-4F8D-A436-E7797568FD53", strCurrentReportID, CInt(strUserID), CInt(strSubUser), User.Identity.Name)
                    Dim arrBytes() As Byte = objReportsList.GetFileContent("BF113E37-F907-4D8A-B931-9AC41603C186", User.Identity.Name, strCurrentReportID)
                    If Not arrBytes Is Nothing Then
                        Response.Buffer = False
                        Response.Clear()
                        Response.Expires = -1

                        Dim tempArr() As Byte = objReportsList.DecryptFile("C6F53545-0596-4058-880D-74D869212A3A", arrBytes, Pwd)

                        If arrBytes.Length > 0 Then
                            If Me.isExcel = "1" Then
                                Response.AddHeader("content-disposition", "attachment; filename=" & Encode(strTargetFileName))
                                Me.setExcel(tempArr)
                            ElseIf isPDF = "1" Then
                                setPDF(arrBytes, strTargetFileName)
                            Else
                                Response.AddHeader("content-disposition", "attachment; filename=" & Encode(strTargetFileName))
                                Response.AddHeader("Content-Length", tempArr.Length)
                                Response.ContentType = "application/octet-stream; name=" & Encode(strTargetFileName) '"application/zip"  '"application/octet-stream"
                                Response.BinaryWrite(tempArr)
                            End If
                        Else
                            Response.AddHeader("Content-Length", arrBytes.Length)
                            Response.ContentType = "application/octet-stream; name=" & Encode(strTargetFileName)
                            Response.Write("")
                        End If
                        Response.End()
                    End If


                    '******************************     
                Else
                    '******************************     



                    objReportsList.UpdateReportViewState("EB917314-AEB1-4F8D-A436-E7797568FD53", strCurrentReportID, CInt(strUserID), CInt(strSubUser), User.Identity.Name)
                    Dim arrBytes() As Byte
                    Response.Buffer = False
                    Response.Clear()

                    '---------------------------
                    If isUrgentMessage = "1" Then
                        '---------------------------


                        Dim Pwd As Byte() = GetFilePassword()
                        objReportsList.UpdateReportViewState("EB917314-AEB1-4F8D-A436-E7797568FD53", strCurrentReportID, CInt(strUserID), CInt(strSubUser), User.Identity.Name)
                        arrBytes = objReportsList.GetFileContent("BF113E37-F907-4D8A-B931-9AC41603C186", User.Identity.Name, strCurrentReportID)
                        If Not arrBytes Is Nothing Then
                            Response.Buffer = False
                            Response.Clear()
                            Response.Expires = -1


                            If arrBytes.Length > 0 Then

                                SetFileForUrgentMessage(arrBytes, strFileName)

                            Else
                                Response.AddHeader("Content-Length", arrBytes.Length)
                                Response.ContentType = "application/octet-stream; name=" & Encode(strTargetFileName)
                                Response.Write("")
                            End If
                            Response.End()
                        End If

                        '---------------------------
                    Else
                        '---------------------------



                        '*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/
                        If Application("MTOM_Enabled") = "1" Then
                            '*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/


                            ws = New MTOMTrans()
                            Dim MyGuid As String = Guid.NewGuid().ToString()
                            Dim offset As Long = 0
                            Try
                                Using ftd As New MTOM_Library.FileTransferDownload
                                    ftd.WebService.Url = Application("MTOMTransURL")
                                    ftd.WebService.CookieContainer = ws.CookieContainer  '// copy the CookieContainer into the transfer object (for auth cookie, if relevant)
                                    ftd.WebService.PrepareForDownload("2D98FC22-7AD6-429B-A0EF-86C9613C44BB", User.Identity.Name, CInt(strCurrentReportID), -1)
                                    Dim iLength As Long = ftd.WebService.GetDownloadFileSize("8E188AF0-F679-4620-8D10-085B43151E04", User.Identity.Name, CInt(strCurrentReportID))
                                    ftd.Guid = MyGuid
                                    '    set up the chunking options
                                    If False Then
                                        ftd.AutoSetChunkSize = True
                                    Else
                                        Dim strBufferSZ As String = Application("MTOMBufferSize")
                                        ftd.AutoSetChunkSize = False
                                        If IsNumeric(strBufferSZ) Then
                                            ftd.ChunkSize = Val(strBufferSZ) * 1024  '// kb
                                        Else
                                            ftd.ChunkSize = 32 * 1024  '// kb
                                        End If
                                    End If
                                    '// set the remote file name and start the background worker
                                    ftd.ReportID = CInt(strCurrentReportID)
                                    ftd.strUserName = User.Identity.Name
                                    ftd.IncludeHashVerification = False

                                    If isPDF = "1" Then

                                        setPDF(ftd, strTargetFileName, iLength)


                                    Else
                                        Response.AddHeader("content-disposition", "attachment; filename=" & Encode(strTargetFileName))
                                        Response.ContentType = "application/octet-stream; name=" & Encode(strTargetFileName) '"application/zip"  '"application/octet-stream"
                                        Response.AddHeader("Content-Length", CStr(iLength))
                                        For Each chunk As Byte() In ftd
                                            Response.BinaryWrite(chunk)
                                            Response.Flush()
                                        Next
                                    End If
                                    ftd.WebService.EndDownloadProcess("820CF12C-3CA4-4D26-8CF7-5DB50D2D1D56", User.Identity.Name, CInt(strCurrentReportID))

                                End Using
                            Catch ex As Exception
                                Response.Write("")
                            End Try
                            '*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/
                        Else 'If Application("MTOM_Enabled") = "1" Then
                            '*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/

                            arrBytes = objReportsList.GetFileContent("BF113E37-F907-4D8A-B931-9AC41603C186", User.Identity.Name, CInt(strCurrentReportID))
                            If Not arrBytes Is Nothing Then

                                If Me.isExcel = "1" Then
                                    Me.setExcel(arrBytes)
                                ElseIf isPDF = "1" Then
                                    setPDF(arrBytes, strTargetFileName)
                                Else
                                    Dim strFN As String
                                    If InStr(LCase(Request.Browser.Browser), "firefox") > 0 Then
                                        strFN = Replace(strTargetFileName, " ", "_")
                                    ElseIf InStr(LCase(Request.Browser.Browser), "safari") > 0 Or InStr(LCase(Request.Browser.Browser), "opera") > 0 Then
                                        strFN = strTargetFileName
                                    Else
                                        strFN = ToHexString(strTargetFileName)
                                    End If
                                    Response.AddHeader("Content-Disposition", "attachment; filename=" & strFN & ";")
                                    Response.ContentType = "application/octet-stream" ' name=" & strFN
                                    Response.AddHeader("Content-Length", arrBytes.Length)
                                    If arrBytes.Length > 0 Then
                                        Response.BinaryWrite(arrBytes)
                                    Else
                                        Response.Write("")
                                    End If

                                End If

                            End If 'If Not arrBytes Is Nothing Then


                            '*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/
                        End If ' If Application("MTOM_Enabled") = "1" Then
                        '*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/

                        Response.End()

                        '---------------------------
                    End If
                    '---------------------------

                    '**************************
                End If 'If strEnc = "1" Then
                '**************************


            End If 'If IsNumeric(strCurrentReportID) Then


        End If 'If Not IsPostBack Then


    End Sub

    Public Function Encode(ByVal strString As String) As String
        Dim strResult As String = ""
        Dim i As Integer = 0
        Dim arrChar As Char() = strString.ToCharArray

        For i = 0 To arrChar.Length - 1

            If String.Compare(arrChar(i), "�") >= 0 And String.Compare(arrChar(i), "�") <= 0 Then
                strResult = strResult & GetUTF8Code(arrChar(i))
            Else
                strResult = strResult & arrChar(i)
            End If

        Next

        Return strResult
    End Function

    Private Function GetUTF8Code(ByVal crntChar As String) As String
        Select Case crntChar
            Case "�"
                Return "%D7%90"
            Case "�"
                Return "%D7%91"
            Case "�"
                Return "%D7%92"
            Case "�"
                Return "%D7%93"
            Case "�"
                Return "%D7%94"
            Case "�"
                Return "%D7%95"
            Case "�"
                Return "%D7%96"
            Case "�"
                Return "%D7%97"
            Case "�"
                Return "%D7%98"
            Case "�"
                Return "%D7%99"
            Case "�"
                Return "%D7%9A"
            Case "�"
                Return "%D7%9B"
            Case "�"
                Return "%D7%9C"
            Case "�"
                Return "%D7%9D"
            Case "�"
                Return "%D7%9E"
            Case "�"
                Return "%D7%9F"
            Case "�"
                Return "%D7%A0"
            Case "�"
                Return "%D7%A1"
            Case "�"
                Return "%D7%A2"
            Case "�"
                Return "%D7%A3"
            Case "�"
                Return "%D7%A4"
            Case "�"
                Return "%D7%A5"
            Case "�"
                Return "%D7%A6"
            Case "�"
                Return "%D7%A7"
            Case "�"
                Return "%D7%A8"
            Case "�"
                Return "%D7%A9"
            Case "�"
                Return "%D7%AA"
            Case Else
                Return crntChar
        End Select

    End Function

    Function GetFilePassword() As Byte()
        '--------------------------------------------------------
        ' Get FilePassword from table "tblUsers" for encrypting.
        '--------------------------------------------------------
        Dim strUserName As String = User.Identity.Name
        Dim strPassword As Byte()
        Dim FilePassword As Byte()
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        FilePassword = objUser.GetFilePassword("BC3C5D81-7DC0-40ff-9421-550C8ECB0B4B", strUserName)
        Return FilePassword
    End Function

    Function GetFlexpaperDIR() As String

        Dim DlexpaperDIR As String = ConfigurationSettings.AppSettings("flexpaperDIR")
        If DlexpaperDIR Is Nothing Then
            DlexpaperDIR = String.Empty
        End If
        Return DlexpaperDIR

    End Function

    Private Sub setPDF(ByVal ftd As MTOM_Library.FileTransferDownload, _
                       ByVal FileName As String, ByVal iLength As Long)


        Dim Offset As Long
        Dim FileContent() As Byte
        ReDim FileContent(iLength)

        For Each chunk As Byte() In ftd
            System.Buffer.BlockCopy(chunk, 0, FileContent, Offset, chunk.Length)
            Offset += chunk.Length
        Next

        Context.Response.ClearContent()

        Context.Response.AppendHeader("content-length", iLength.ToString())

        Context.Response.ContentType = getContentType(Context)

        Context.Response.BinaryWrite(FileContent)

        Context.Response.Flush()

        Context.Response.Close()

    End Sub

    Private Sub setPDF(ByVal _result As [Byte](), ByVal FileName As String)

        Dim FlexpaperDIR = GetFlexpaperDIR()
        If FlexpaperDIR <> String.Empty Then
            FileName = Guid.NewGuid.ToString("N") + FileName
            Dim sIniNamePath As String = FlexpaperDIR + FileName
            Dim sr As StreamWriter = New StreamWriter(sIniNamePath, False, System.Text.Encoding.Default)
            sr.Write(System.Text.Encoding.Default.GetString(_result))
            sr.Close()
        Else
            FileName = String.Empty ' show error message to user
        End If

        Response.Clear()
        Response.Write("<HTML><HEAD><TITLE></TITLE>")
        Response.Write("<meta http-equiv='Cache-Control' content='no-cache'>" & vbCrLf)
        Response.Write("<meta http-equiv='Pragma' content='no-cache'>" & vbCrLf)
        Response.Write("<meta http-equiv='Expires' content='0'>" & vbCrLf)
        Response.Write("<META http-equiv='Content-Type' content='text/html; charset=windows-1255'>")
        Response.Write("</HEAD>")
        Response.Write("<BODY>")
        Response.Write("<SCRIPT>")
        Response.Write(String.Format("window.parent.PDF('{0}')", FileName))
        Response.Write("</SCRIPT>")
        Response.Write("</BODY>")
        Response.Write("</HTML>")
        Response.End()

    End Sub

    Private Sub SetFileForUrgentMessage(ByVal _result As [Byte](), ByVal _strFileName As String)


        Dim resultLength As Long


        Context.Response.ClearContent()
        If _result Is Nothing Then
            resultLength = 0
        Else
            resultLength = _result.Length
        End If

        Context.Response.AppendHeader("content-length", resultLength.ToString())

        Context.Response.ContentType = getContentTypeForUrgentMessage(_strFileName)

        Context.Response.BinaryWrite(_result)

        Context.Response.Flush()

        Context.Response.Close()

    End Sub

    Private Sub setExcel(ByVal _result As [Byte]())

        Dim result As [Byte]()

        result = DirectCast(_result, [Byte]())

        Context.Response.ClearContent()

        Context.Response.AppendHeader("content-length", result.Length.ToString())

        Context.Response.Buffer = False

        Context.Response.ContentType = "application/vnd.ms-excel"

        Context.Response.Charset = "UTF-8"

        If result IsNot Nothing Then
            If result.Length = 0 Then

            Else
                Context.Response.BinaryWrite(result)
            End If
        End If

        Context.Response.Flush()

        Context.Response.[End]()

        Context.Response.Close()

    End Sub

    Private Shared Function StrToByteArray(ByVal str As String) As Byte()
        Dim encoding As New System.Text.UTF8Encoding()
        Return encoding.GetBytes(str)
    End Function

    Private Function ToHexString(ByVal strString As String) As String
        Dim arrChar As Char() = strString.ToCharArray
        Dim builder As New System.Text.StringBuilder()
        Dim i As Integer = 0
        For i = 0 To arrChar.Length - 1
            If NeedToEncode(arrChar(i)) Then
                builder.Append(ToHexString(arrChar(i)))
            Else
                builder.Append(arrChar(i))
            End If
        Next
        Return builder.ToString()
    End Function

    Private Function NeedToEncode(ByVal chr As Char) As Boolean
        Dim reservedChars As String = "$-_.+!*'(),@=&"


        If Asc(chr) > 127 Then
            Return True
        End If

        If Char.IsLetterOrDigit(chr) Or reservedChars.IndexOf(chr) >= 0 Then
            Return False
        End If

        Return True
    End Function

    Private Function ToHexString(ByVal chr As Char) As String
        Dim utf8 As New System.Text.UTF8Encoding
        Dim encodedBytes() As Byte = utf8.GetBytes(chr.ToString())
        Dim builder As New System.Text.StringBuilder()
        Dim i As Integer = 0
        For i = 0 To encodedBytes.Length - 1
            builder.AppendFormat("%{0}", Convert.ToString(encodedBytes(i), 16))
        Next
        Return builder.ToString()
    End Function

    Private Function getContentType(ByRef _context As HttpContext) As String
        Dim pdfFileName As String
        'Dim pdfFileName As String = _context.Session("PdfFileName").ToString()
        Dim contentType As String = ""
        '  pdfFileName = InfoUtil.GetFileExtensionOnly(pdfFileName)
        pdfFileName = ".PDF"
        Select Case pdfFileName.ToUpper().Trim()
            Case ".PDF"
                contentType = "application/pdf"
            Case ".XLS"
                contentType = "application/vnd.ms-excel"
            Case ".XLSX"
                contentType = "application/vnd.ms-excel"
            Case ".DOC"
                contentType = "application/msword"
            Case ".DOCX"
                contentType = "application/msword"
        End Select

        Return contentType
    End Function
    Private Function getContentTypeForUrgentMessage(ByVal pdfFileName As String) As String
        'Dim pdfFileName As String
        'Dim pdfFileName As String = _context.Session("PdfFileName").ToString()
        Dim contentType As String = ""
        pdfFileName = GetFileExtensionOnly(pdfFileName)
        'pdfFileName = ".PDF"
        Select Case pdfFileName.ToUpper().Trim()
            Case ".PDF"
                contentType = "application/pdf"
            Case ".XLS"
                contentType = "application/vnd.ms-excel"
            Case ".XLSX"
                contentType = "application/vnd.ms-excel"
            Case ".DOC"
                contentType = "application/msword"
            Case ".DOCX"
                contentType = "application/msword"
            Case ".PPT", ".PPS"
                contentType = "application/powerpoint" '//"application/vnd.ms-powerpoint"
            Case ".TIF", ".TIFF"
                contentType = "image/tiff"
            Case ".JPG", ".JPEG"
                contentType = "image/jpeg"
            Case ".HTM", ".HTML"
                contentType = "text/html"
        End Select

        Return contentType

    End Function
    Public Shared Function GetFileExtensionOnly(ByVal qualifiedName As String) As String
        Return System.IO.Path.GetExtension(qualifiedName)
    End Function
End Class
