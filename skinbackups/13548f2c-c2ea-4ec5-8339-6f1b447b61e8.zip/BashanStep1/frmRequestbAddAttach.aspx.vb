Imports System.IO

Public Class frmRequestbAddAttach
    Inherits System.Web.UI.Page
    Protected WithEvents hidReferenceID As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidAnswer As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidReturnValue As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidRequestType As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidReferenceIDFromRequest As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidRequestIDFromRequest As System.Web.UI.HtmlControls.HtmlInputHidden

    Protected WithEvents lstAttachmentType1 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstAttachmentType2 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstAttachmentType3 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstAttachmentType4 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstAttachmentType5 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstAttachmentType6 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstAttachmentType7 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstAttachmentType8 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstAttachmentType9 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstAttachmentType10 As System.Web.UI.WebControls.DropDownList

    Protected WithEvents fileToUpload1 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents fileToUpload2 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents fileToUpload3 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents fileToUpload4 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents fileToUpload5 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents fileToUpload6 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents fileToUpload7 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents fileToUpload8 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents fileToUpload9 As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents fileToUpload10 As System.Web.UI.HtmlControls.HtmlInputFile

    Protected WithEvents txtExistAttNo1 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistAttNo2 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistAttNo3 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistAttNo4 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistAttNo5 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistAttNo6 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistAttNo7 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistAttNo8 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistAttNo9 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistAttNo10 As System.Web.UI.HtmlControls.HtmlInputHidden

    Protected WithEvents txtExistRecNo1 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistRecNo2 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistRecNo3 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistRecNo4 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistRecNo5 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistRecNo6 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistRecNo7 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistRecNo8 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistRecNo9 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtExistRecNo10 As System.Web.UI.HtmlControls.HtmlInputHidden

    Protected WithEvents txtFileTitle1 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFileTitle2 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFileTitle3 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFileTitle4 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFileTitle5 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFileTitle6 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFileTitle7 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFileTitle8 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFileTitle9 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFileTitle10 As System.Web.UI.HtmlControls.HtmlInputText

    Dim LOGON32_LOGON_INTERACTIVE As Integer = 2
    Dim LOGON32_PROVIDER_DEFAULT As Integer = 0
    Protected WithEvents txtAttachTypesCombo1 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAttachTypesCombo2 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAttachTypesCombo3 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAttachTypesCombo4 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAttachTypesCombo5 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAttachTypesCombo6 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAttachTypesCombo7 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAttachTypesCombo8 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAttachTypesCombo9 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAttachTypesCombo10 As System.Web.UI.HtmlControls.HtmlInputHidden

    Protected WithEvents hidGovTreatmentID As System.Web.UI.HtmlControls.HtmlInputHidden

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If IsPostBack Then
            Dim iMaxSize As Integer
            If IsNumeric(Session("UploadFileSize").ToString()) Then
                iMaxSize = CInt(Session("UploadFileSize").ToString())
                If iMaxSize = 0 Then
                    hidAnswer.Value = "���� ���� ����� �� ���� " & " 0K! "
                    hidReturnValue.Value = 0
                    Return
                End If
            Else
                hidReturnValue.Value = "-1"
                Return
            End If
            Dim iRetValue As Integer = CheckAllFiles(iMaxSize)
            If iRetValue = 2 Then
                hidAnswer.Value = "���� ���� ����� �� ���� " & CStr(iMaxSize / 1024) & "K!" & "  �� ����� ������� ����  "
                iRetValue = 0
            ElseIf iRetValue = 1 Then
                hidAnswer.Value = "���� �� ����"
                iRetValue = 0
            Else
                iRetValue = 1
                If iRetValue > 0 Then
                    Dim iXRayAttach As Integer
                    If CheckXrayAttach() Then
                        iXRayAttach = 1
                    Else
                        iXRayAttach = 0
                    End If
                    Dim strReferenceID As String = hidReferenceIDFromRequest.Value
                    Dim iRequestID As Integer = CInt(hidRequestIDFromRequest.Value)
                    If (strReferenceID <> "") And (iRequestID > 0) Then
                        Dim iExtError As Integer = 0
                        If iXRayAttach > 0 Then
                            Dim objTreatmentService As New TreatmentConnect.TreatmentService()
                            objTreatmentService.Url = Application("TreatmentWebService").ToString()
                            iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType1"), objTreatmentService, fileToUpload1, txtExistAttNo1, txtExistRecNo1, iExtError)
                            If iRetValue > 0 Then
                                iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType2"), objTreatmentService, fileToUpload2, txtExistAttNo2, txtExistRecNo2, iExtError)
                            End If
                            If iRetValue > 0 Then
                                iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType3"), objTreatmentService, fileToUpload3, txtExistAttNo3, txtExistRecNo3, iExtError)
                            End If
                            If iRetValue > 0 Then
                                iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType4"), objTreatmentService, fileToUpload4, txtExistAttNo4, txtExistRecNo4, iExtError)
                            End If
                            If iRetValue > 0 Then
                                iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType5"), objTreatmentService, fileToUpload5, txtExistAttNo5, txtExistRecNo5, iExtError)
                            End If
                            If iRetValue > 0 Then
                                iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType6"), objTreatmentService, fileToUpload6, txtExistAttNo6, txtExistRecNo6, iExtError)
                            End If
                            If iRetValue > 0 Then
                                iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType7"), objTreatmentService, fileToUpload7, txtExistAttNo7, txtExistRecNo7, iExtError)
                            End If
                            If iRetValue > 0 Then
                                iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType8"), objTreatmentService, fileToUpload8, txtExistAttNo8, txtExistRecNo8, iExtError)
                            End If
                            If iRetValue > 0 Then
                                iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType9"), objTreatmentService, fileToUpload9, txtExistAttNo9, txtExistRecNo9, iExtError)
                            End If
                            If iRetValue > 0 Then
                                iRetValue = ProcessRow(strReferenceID, Request.Form.Item("lstAttachmentType10"), objTreatmentService, fileToUpload10, txtExistAttNo10, txtExistRecNo10, iExtError)
                            End If
                        End If
                        If iRetValue > 0 And iXRayAttach > 0 Then
                            hidAnswer.Value = "���� ������ ������ ����� ������� ����� ������"
                        ElseIf iRetValue > 0 And iXRayAttach = 0 Then
                            hidAnswer.Value = "�� ����� �� ����"
                        Else
                            If iExtError > 0 Then
                                hidAnswer.Value = "����� ����� ���� ����"
                            Else
                                hidAnswer.Value = "���� ��� ����� ����� �����, ��� ��� ����� ������"
                            End If
                        End If
                    Else
                        hidAnswer.Value = "���� ��� ����� ����� �����, ��� ��� ����� ������"
                        iRetValue = 0
                    End If
                End If
            End If
            hidReturnValue.Value = iRetValue
        Else
            lstAttachmentType1.Items.Add(New ListItem("���...", 0))
            lstAttachmentType2.Items.Add(New ListItem("���...", 0))
            lstAttachmentType3.Items.Add(New ListItem("���...", 0))
            lstAttachmentType4.Items.Add(New ListItem("���...", 0))
            lstAttachmentType5.Items.Add(New ListItem("���...", 0))
            lstAttachmentType6.Items.Add(New ListItem("���...", 0))
            lstAttachmentType7.Items.Add(New ListItem("���...", 0))
            lstAttachmentType8.Items.Add(New ListItem("���...", 0))
            lstAttachmentType9.Items.Add(New ListItem("���...", 0))
            lstAttachmentType10.Items.Add(New ListItem("���...", 0))
        End If
    End Sub

    Private Function ProcessRow(ByVal strReferenceID As String, ByVal strComboSelectedValue As String, ByRef objTreatmentService As TreatmentConnect.TreatmentService, ByRef ctlFile As HtmlInputFile, ByRef ctlHidden1 As HtmlInputHidden, ByRef ctlHidden2 As HtmlInputHidden, ByRef iExtError As Integer) As Integer
        Dim iPhotoType As Integer = CInt(strComboSelectedValue)
        Dim iRetValue As Integer = 0
        iExtError = 0
        If Not ctlFile.PostedFile Is Nothing AndAlso Trim(ctlFile.PostedFile.FileName) <> "" Then
            Dim ioReader As New BinaryReader(ctlFile.PostedFile.InputStream)
            ioReader.BaseStream.Seek(0, SeekOrigin.Begin)
            Dim arrFileContent(ioReader.BaseStream.Length - 1) As Byte
            ioReader.Read(arrFileContent, 0, ioReader.BaseStream.Length)
            If CheckFileHeader(arrFileContent) > 0 Then
                Dim strFileName As String = ctlFile.PostedFile.FileName
                Dim iPt As Integer = InStrRev(strFileName, "\")
                If iPt > 0 Then
                    strFileName = Mid(strFileName, iPt + 1)
                End If
                If objTreatmentService.ArchiveAttachment("C7F043B7-8717-430D-A7B6-8A2EBDE30741", strReferenceID, iPhotoType, strFileName, arrFileContent) Then
                    iRetValue = 1
                End If
            Else
                iExtError = 1
            End If
        ElseIf (Trim(ctlHidden1.Value) <> "" And Trim(ctlHidden2.Value) <> "") Then
            Dim iRecordNo As Integer = CInt(ctlHidden2.Value)
            Dim iAttachNo As Integer = CInt(ctlHidden1.Value)
            If iRecordNo = 0 Then
                iRetValue = 1
            Else
                If objTreatmentService.CopyAttachment("DCAB5DEB-D32B-4B1B-9156-2A47D9ADAC96", iRecordNo, iAttachNo, strReferenceID) Then
                    iRetValue = 1
                End If
            End If
        Else
            iRetValue = 2
        End If
        Return iRetValue
    End Function

    Private Function CheckAllFiles(ByVal iMaxSize As Integer) As Integer
        Dim iRetValue As Integer
        iRetValue = CheckFileSize(fileToUpload1, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload2, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload3, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload4, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload5, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload6, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload7, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload8, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload9, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        iRetValue = CheckFileSize(fileToUpload10, iMaxSize)
        If iRetValue > 0 Then
            Return iRetValue
        End If
        Return 0
    End Function

    Private Function CheckFileSize(ByRef ctlFile As HtmlInputFile, ByVal iMaxSize As Integer) As Integer
        Dim iRetValue As Integer = 0
        If Trim(ctlFile.PostedFile.FileName) <> "" Then
            If ctlFile.PostedFile.ContentLength = 0 Then
                iRetValue = 1
            ElseIf ctlFile.PostedFile.ContentLength > iMaxSize Then
                iRetValue = 2
            End If
        End If
        Return iRetValue
    End Function

    Private Function CheckXrayAttach() As Boolean
        Dim bRetValue As Boolean = False
        bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType1"), fileToUpload1, txtExistAttNo1, txtExistRecNo1)
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType2"), fileToUpload2, txtExistAttNo2, txtExistRecNo2)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType3"), fileToUpload3, txtExistAttNo3, txtExistRecNo3)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType4"), fileToUpload4, txtExistAttNo4, txtExistRecNo4)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType5"), fileToUpload5, txtExistAttNo5, txtExistRecNo5)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType6"), fileToUpload6, txtExistAttNo6, txtExistRecNo6)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType7"), fileToUpload7, txtExistAttNo7, txtExistRecNo7)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType8"), fileToUpload8, txtExistAttNo8, txtExistRecNo8)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType9"), fileToUpload9, txtExistAttNo9, txtExistRecNo9)
        End If
        If Not bRetValue Then
            bRetValue = CheckXrayAttachOneRow(Request.Form.Item("lstAttachmentType10"), fileToUpload10, txtExistAttNo10, txtExistRecNo10)
        End If
        Return bRetValue
    End Function

    Private Function CheckXrayAttachOneRow(ByVal strComboSelectedValue As String, ByRef ctlFile As HtmlInputFile, ByRef ctlHidden1 As HtmlInputHidden, ByRef ctlHidden2 As HtmlInputHidden) As Boolean
        Dim bRetValue As Boolean = False
        Dim i As Integer = CInt(strComboSelectedValue)
        If i > 0 Then
            If (IsNumeric(ctlHidden1.Value) And IsNumeric(ctlHidden2.Value)) Then
                Dim iRecordNo As Integer = CInt(ctlHidden2.Value)
                If iRecordNo > 0 Then
                    bRetValue = True
                End If
            ElseIf Trim(ctlFile.PostedFile.FileName) <> "" Then
                bRetValue = True
            End If
        End If
        Return bRetValue
    End Function

    Private Function CheckFileHeader(ByRef byContent As Byte()) As Integer
        Dim iRetValue As Integer = 0
        If Application("CheckJpgHeader") = "1" Then
            Dim strJPEGStart As String = "255216"
            Dim strTIFFStartIntel As String = "7373"
            Dim strTIFFStartMotorola As String = "7777"
            Try
                Dim strHeader As String = byContent(0).ToString() & byContent(1).ToString()
                If strJPEGStart = strHeader Then
                    iRetValue = 1
                ElseIf strTIFFStartIntel = strHeader Or strTIFFStartMotorola = strHeader Then
                    iRetValue = 2
                End If
            Catch ex As Exception
                iRetValue = -1
            End Try
        Else
            iRetValue = 1
        End If
        Return iRetValue
    End Function
End Class
