Imports System.Web.Security
Imports System.Drawing
Imports System.Text.RegularExpressions

Public Class frmRepList
    Inherits System.Web.UI.Page
#If NewDesign And Not EngDesign Then
    Protected Uc_Jcalander1 As Uc_Jcalander
    Protected WithEvents ArrowWhiteToLeftExcel As System.Web.UI.HtmlControls.HtmlTableCell

#End If


    Protected WithEvents cmdReturnMenu As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdPrint As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents lstUsers As System.Web.UI.WebControls.DropDownList
    Protected WithEvents grdList As System.Web.UI.WebControls.DataGrid
    Protected WithEvents grdListNew As System.Web.UI.WebControls.DataGrid
    Protected WithEvents gridOccasional As System.Web.UI.WebControls.DataGrid
    Protected WithEvents cmdHelp As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdLogout As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdReportProp As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdUserProp As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdDelete As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdReturn As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdReturnConsultation As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdExit As System.Web.UI.HtmlControls.HtmlInputButton


    Protected WithEvents cmdReportClaims As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents txtReportID As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtReportType As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents chkFilter As System.Web.UI.HtmlControls.HtmlInputCheckBox
#If NewDesign And Not EngDesign Then
    Protected WithEvents ChkCalander As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents setFilterByCalander As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents txtDateForCal As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents HdShowCal As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents cmdExcel As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents HidPermissionForExcel As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidAutoOpen As System.Web.UI.HtmlControls.HtmlInputHidden
#End If
    Protected WithEvents chkIfPrint As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents txtDateFrom As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtDateTo As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents cmdApplyFilter As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents chkViewed As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents chkNotViewed As System.Web.UI.HtmlControls.HtmlInputCheckBox
#If NewDesign And Not EngDesign Then
    Protected WithEvents chkViewedOccasional As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents chkNotViewedOccasional As System.Web.UI.HtmlControls.HtmlInputCheckBox
#End If
    Protected WithEvents txtError As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAppType As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents lblMessage As System.Web.UI.WebControls.Label
    Protected WithEvents lblReportType As System.Web.UI.WebControls.Label
    Protected WithEvents lblBOUserID As System.Web.UI.WebControls.Label
    Protected WithEvents lblClinic As System.Web.UI.WebControls.Label
    Protected WithEvents txtReportSource As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents ctlTitle As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents tdDistTitle As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents txtTableType As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtInshuredID As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtOccasionalID As System.Web.UI.HtmlControls.HtmlInputText

    Protected WithEvents txtName As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtFNameOccasional As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtLNameOccasional As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtPhoneOccasional As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtMailOccasional As System.Web.UI.HtmlControls.HtmlInputText
#If NewDesign And Not EngDesign Then
    Protected WithEvents txtDateFromOccasional As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtDateToOccasional As System.Web.UI.HtmlControls.HtmlInputHidden
#End If
#If Not NewDesign And Not EngDesign Then
    Protected WithEvents hidShowInterActiveReport As System.Web.UI.HtmlControls.HtmlInputHidden

    Protected WithEvents tdClinicTitle As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents tdUsers As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents tdTitleClinic2 As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents trTitleRow1 As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents trTitleRow2 As System.Web.UI.HtmlControls.HtmlTableRow
    Protected WithEvents hidInshuredIDSearch As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents cmdHdReportDailyConsultations As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdHdReportDailyRequests As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdHdReportDailyAccount As System.Web.UI.HtmlControls.HtmlInputButton
#End If
    Protected WithEvents txtFormIdentity As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents aIconLink As System.Web.UI.HtmlControls.HtmlAnchor
    Protected WithEvents txtServerDate As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents divRIcon As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents spnChkTitle As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents cboGridRowCount As System.Web.UI.WebControls.DropDownList
    Protected WithEvents tdGridRowCount As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents hidMaxRequestRepDays As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents tdResultRowCount As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents hidArrayChks As System.Web.UI.HtmlControls.HtmlInputHidden
#If NewDesign Then
    Protected WithEvents tdRightPic As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents imgRightPic As System.Web.UI.HtmlControls.HtmlImage
    Protected WithEvents imgLeftPic As System.Web.UI.HtmlControls.HtmlImage
    Protected WithEvents cmdRepRequests As System.Web.UI.HtmlControls.HtmlInputButton

    Protected WithEvents lblDoctorName As System.Web.UI.WebControls.Label
    Protected WithEvents txtDoctorID As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtClinicID As System.Web.UI.HtmlControls.HtmlInputHidden

    Protected WithEvents hidMaxRowCountForPrint As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidPrintActivity As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtSortField As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtHasCB As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidClaimApp As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected tdPrintAll As System.Web.UI.HtmlControls.HtmlTableCell
#End If

#If NewDesign And Not EngDesign Then
    Protected WithEvents txtFromUserName As System.Web.UI.HtmlControls.HtmlInputText
    'Protected WithEvents txtRepName As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents hidIsTechSupport As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidAfterTechUpdate As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents grdStatus As System.Web.UI.WebControls.DataGrid
    Protected WithEvents txtLastUpdateUserName As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtSupplierID As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents hidStatusCodes As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents lstRepName As System.Web.UI.WebControls.DropDownList
    Protected UC_ExportData1 As UC_ExportData
    Protected WithEvents dgForExcel As System.Web.UI.WebControls.DataGrid

#End If

    Protected igRepIDSupportRequests As Integer
    Dim g_fAllowUserSelect As Boolean
    Dim arrChksSize As Integer = 300
    Dim arrChksValues(299) As String
    Dim filterFlag As Boolean = False
    Protected WithEvents sp1 As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents txtKoteret As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents aIconLink2 As System.Web.UI.HtmlControls.HtmlAnchor
    Protected WithEvents SearchByRepName As System.Web.UI.HtmlControls.HtmlInputHidden
    Dim bShowFilterMessage As Boolean = False

    Private Const col_grdList_ReferenceNo As Integer = 0
    Private Const col_grdList_Icons As Integer = 1
    Private Const col_grdList_Bruto As Integer = 2
    Private Const col_grdList_ValidDate As Integer = 3
    Private Const col_grdList_ViewDate As Integer = 4
    Private Const col_grdList_EntryDate As Integer = 5
    Private Const col_grdList_FinishDate As Integer = 6
    Private Const col_grdList_ToTooth As Integer = 7
    Private Const col_grdList_FTooth As Integer = 8
    Private Const col_grdList_TreatmentDesc As Integer = 9
    Private Const col_grdList_Treatment As Integer = 10
    Private Const col_grdList_RequestTyp As Integer = 11
    Private Const col_grdList_Reference As Integer = 12
    Private Const col_grdList_CheckType As Integer = 13
    Private Const col_grdList_LName As Integer = 14
    Private Const col_grdList_FName As Integer = 15
    Private Const col_grdList_InsuredID As Integer = 16
    Private Const col_grdList_RepName As Integer = 17

    Public frmRequestURL As String = Utils.Navigation.GetURL("frmRequestt.aspx")

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.

        InitializeComponent()
#If NewDesign And Not EngDesign Then
        InitializeDelegates()
#End If
    End Sub

#End Region

#If NewDesign And Not EngDesign Then
    Private Sub InitializeDelegates()
        AddHandler Me.UC_ExportData1.ButtonClick, AddressOf ButtonClick
    End Sub
#End If

#If NewDesign And Not EngDesign Then


    Private Sub ButtonClick(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        '/Ilia
        Dim a_dataGrid As DataGrid() = New DataGrid(0) {}
        BindGridExcel()
        a_dataGrid(0) = Me.dgForExcel

        If e.CommandName = "Excel" Then
            Me.UC_ExportData1.ExportExcel(a_dataGrid, setExcelTitle())
        End If

    End Sub
    Private Function setExcelTitle() As String
        Dim strRet As String = ""
        Dim strExcelData As New System.Text.StringBuilder()

        strExcelData.Append("<table border=1>").Append(vbNewLine)

        strExcelData.Append("<tr style='font-family:Arial;font-size:12pt;font-weight:bold;text-align : center'>")
        strExcelData.Append("   <TD>&nbsp;</TD>")
        strExcelData.Append("   <TD>&nbsp;</TD>")
        strExcelData.Append("   <TD colspan=3>").Append("����� ����� �-").Append(lstUsers.SelectedItem.Text).Append(lblBOUserID.Text).Append("</TD>")
        strExcelData.Append("</tr>")
        strExcelData.Append("</table>" & vbNewLine)

        Return strExcelData.ToString()
    End Function


#End If

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Session("ExternalLink") = ""

        Dim bAllowUserMultyReportsPermition As Boolean

        'If Not CrossCheck() Then
        '    Session("BackUrl") = "frmRepList.aspx"
        '    Response.Redirect("frmError.aspx")
        '    Return
        'End If

#If NewDesign And Not EngDesign Then

        Me.HdShowCal.Value = Application("ShowCal") & ""

        Me.Uc_Jcalander1.LastChoiceMonth = Me.txtDateForCal.Value


#End If


        ReDim arrChksValues(arrChksSize - 1)

        If Application("App_Type").ToString().ToLower() = "doar" Then
#If NewDesign Then
            tdPrintAll.Style.Item("display") = "block"
            cmdPrint.Style.Item("display") = "none"
#Else
            cmdPrint.Visible = True
#End If
        Else
#If NewDesign And Not EngDesign Then
            tdPrintAll.Visible = False
#End If
        End If

        If Application("IsPool") & "" = "1" Then
            cmdUserProp.Visible = False
        End If

#If Not NewDesign Then

        If Application("ShowInterActiveReport").ToString = "1" then
          Me.hidShowInterActiveReport.Value = "1"
        else
           Me.hidShowInterActiveReport.Value = "0"
        End If

        If Application("SearchByRepName").ToString = "1" Then
            Me.SearchByRepName.Value = "1"
        Else
            Me.SearchByRepName.Value = "0"
        End If
#End If

        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()


#If NewDesign And Not EngDesign Then

        bAllowUserMultyReportsPermition = objUser.GetExcelMultyReportsPermition("CF8763B0-D8F4-11DE-8A39-0800200C9A66", User.Identity.Name)

#End If



        Dim iGridRowCount As Integer
        Dim strAllowUserSelect As String
        'Chk Prm
        If Application("App_Type").ToString.ToUpper() = "SUPP" Then
            If Session("SUPP_AllowClaims") <> "1" And Session("SUPP_AllowClaims") <> "1" And Session("SUPP_HospitalClaim") <> "1" And Session("SUPP_ReportGeneration") <> "1" Then
                objUser.AddUserIllegalAction("24304391-6FDE-4237-A9B6-49630958EB26", User.Identity.Name, "frmRepList")
                Response.Redirect(Application("FORMLogin"))
            End If
        Else
            If Session("WebInterfaceAllow") <> "1" Then
                objUser.AddUserIllegalAction("24304391-6FDE-4237-A9B6-49630958EB26", User.Identity.Name, "frmRepList")
                Response.Redirect(Application("FORMLogin"))
            End If
        End If


        'Get Clinic
        iGridRowCount = objUser.GetGridRowCount("9CDE451A-D418-40EC-9588-64CA4592AC55", User.Identity.Name)

        'If Application("App_Type").ToString = "dist" Then
        '    If Not Session("GridRowCount") Is Nothing Then
        '        iGridRowCount = Session("GridRowCount")
        '    End If
        'End If

        tdGridRowCount.Visible = False

#If NewDesign And Not EngDesign Then
        If Application("HasCB") = "1" Then
            txtHasCB.Value = "1"
        Else
            txtHasCB.Value = "0"
        End If

        If Application("HasHani").ToString() = "1" Then
            cmdExit.Visible = False
        End If
        If Application("IsDorAlon") = "1" Then
            hidClaimApp.Value = "1"
        ElseIf Application("IsPool") = "1" Then
            hidClaimApp.Value = "2"
        End If

#End If
#If NewDesign Then
        If LCase(Application("App_Type").ToString) = "claim" Then
            If Session("Allow_Action_Type_Upload") <> "1" Then
                cmdExit.Visible = False
            End If
        End If
#End If

        Select Case Application("App_Type").ToString().ToLower()
            Case "dist", "claim", "supp", "eng", "doar"
                'If LCase(Application("App_Type").ToString) = "dist" Or LCase(Application("App_Type").ToString) = "claim" Or LCase(Application("App_Type").ToString) = "supp" Or LCase(Application("App_Type").ToString) = "divur" Or LCase(Application("App_Type").ToString) = "eng" Then

            Case "divur"
                grdListNew.PagerStyle.HorizontalAlign = HorizontalAlign.Right
                tdGridRowCount.Visible = True
                If Not IsPostBack Then
                    Dim arrValues() As Integer = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15}
                    cboGridRowCount.DataSource = arrValues
                    cboGridRowCount.DataBind()
                    cboGridRowCount.SelectedIndex = iGridRowCount - 1
                    'If Not Session("GridRowCount") Is Nothing Then
                    '    iGridRowCount = Session("GridRowCount")
                    'End If

                End If
                'End If
        End Select

        If Application("App_Type").ToString = "dist" Then
            g_fAllowUserSelect = False
        Else
            strAllowUserSelect = objUser.GetUserSelectPermition("5CF99E07-9412-400C-89C9-6391758C6098", User.Identity.Name)

            If strAllowUserSelect <> "" Then
                If strAllowUserSelect = "1" Then
                    g_fAllowUserSelect = True
                Else
                    g_fAllowUserSelect = False
                End If
            Else
                g_fAllowUserSelect = True
                'If Application("App_Type").ToString = "dist" Then
                '    g_fAllowUserSelect = False
                'Else
                '    g_fAllowUserSelect = True
                'End If
            End If
        End If

        If Not g_fAllowUserSelect Then
            lstUsers.Visible = False
        Else
            lstUsers.Visible = True
        End If

        If Not IsPostBack Then
            aIconLink.HRef = Application("ClientSiteLink")
#If NewDesign Then
            If Application("HasHani").ToString() = "1" Then
                imgLeftPic.Src = Session("CompanyLogo")
            End If
#End If
            If Application("RightLogo") = "1" Then
#If NewDesign Then

                tdRightPic.Attributes("background") = "pics/BannerTopRightTransp.gif"
                imgRightPic.Attributes("src") = "pics/BannerTopRightTransp.gif"
#End If
                divRIcon.Visible = True
            Else
#If NewDesign Then
                tdRightPic.Attributes("background") = "pics/BannerTopRightPic.gif"
                imgRightPic.Attributes("src") = "pics/BannerTopRightPic.gif"
#End If
                divRIcon.Visible = False
            End If

            If Application("App_Type").ToString.ToUpper() = "SUPP" Then
#If NewDesign Then
                tdRightPic.Attributes("background") = "pics/BannerTopRightPic.gif"
                imgRightPic.Attributes("src") = "pics/BannerTopRightPic.gif"
#End If
                divRIcon.Visible = False
            End If

            txtServerDate.Value = Format(DateTime.Today, "dd/MM/yyyy")
            If Session("User_Login_First_Time") = "1" Then
#If NewDesign And Not EngDesign Then
                If Application("HasCB") = "1" Or Application("HasHani").ToString() = "1" Then
                    'Response.Redirect("frmUserInfo.aspx")
                    Response.Redirect((New Utils).GetLinkForNextForm("frmUserInfo.aspx"))
                Else
                    Response.Redirect("frmUserProp.aspx")
                End If
#Else
                Response.Redirect("frmUserProp.aspx")
#End If
            End If
#If Not NewDesign Then
            lblMessage.Text = CEncode.StringEncode(Session("Message_Text"))
#Else
#If Not EngDesign Then
            If Application("HasCB") = "1" Then
                lblMessage.Text = Session("Message_Text")
            Else
                lblMessage.Visible = False
            End If
#End If
#End If
            If Session("Filter_On") = "1" Then
#If Not NewDesign Then
                If Session("Filter_InsuredID") <> "" Then
                    txtInshuredID.Value = Session("Filter_InsuredID")
                End If
#End If
                If Session("Filter_From_Date") <> "" Then
                    txtDateFrom.Value = Session("Filter_From_Date")
#If NewDesign And Not EngDesign Then
                    txtDateFromOccasional.Value = Session("Filter_From_Date")
#End If
                Else
                    txtDateFrom.Value = "00000000"
#If NewDesign And Not EngDesign Then
                    txtDateFromOccasional.Value = "00000000"
#End If
                End If
                If Session("Filter_To_Date") <> "" Then
                    txtDateTo.Value = Session("Filter_To_Date")
#If NewDesign And Not EngDesign Then
                    txtDateToOccasional.Value = Session("Filter_To_Date")
#End If
                Else
                    txtDateTo.Value = "00000000"
#If NewDesign And Not EngDesign Then
                    txtDateToOccasional.Value = "00000000"
#End If
                End If
                chkFilter.Checked = True
                If Session("Filter_Viewed") <> "" Then
                    chkViewed.Checked = True
#If NewDesign And Not EngDesign Then
                    chkViewedOccasional.Checked = True
#End If
                Else
                    chkViewed.Checked = False
#If NewDesign And Not EngDesign Then
                    chkViewedOccasional.Checked = False
#End If
                End If
                If Session("Filter_NotViewed") <> "" Then
                    chkNotViewed.Checked = True
#If NewDesign And Not EngDesign Then
                    chkNotViewedOccasional.Checked = True
#End If
                Else
                    chkNotViewed.Checked = False
#If NewDesign And Not EngDesign Then
                    chkNotViewedOccasional.Checked = False
#End If
                End If

            Else
#If Not NewDesign Then
                If Application("SearchByRepName").ToString = "1" Then
                    txtKoteret.Value = ""
                End If
#End If
                chkViewed.Checked = True
                chkNotViewed.Checked = True
#If NewDesign And Not EngDesign Then
                chkViewedOccasional.Checked = True
                chkNotViewedOccasional.Checked = True
                txtDateFromOccasional.Value = "00000000"
                txtDateToOccasional.Value = "00000000"

#End If
                txtDateFrom.Value = "00000000"
                txtDateTo.Value = "00000000"
            End If
            Dim col As BoundColumn
            Dim colExcel As BoundColumn

#If NewDesign Then
#If EngDesign Then
            'col = CType(grdList.Columns(12), BoundColumn)
            'colExcel = CType(dgForExcel.Columns(11), BoundColumn)
#Else
            col = CType(grdList.Columns(13), BoundColumn)
            colExcel = CType(dgForExcel.Columns(12), BoundColumn)
#End If
#Else
            col = CType(grdList.Columns(10), BoundColumn)
            'colExcel = CType(dgForExcel.Columns(9), BoundColumn)
#End If
            If LCase(Application("App_Type").ToString) = "supp" Then
                col.DataField = "ClaimNumber"
#If NewDesign Then

                colExcel.DataField = "ClaimNumber"
#End If
            Else
                col.DataField = ""
#If NewDesign Then
                colExcel.DataField = ""
#End If
            End If
            If Application("App_Type").ToString = "dist" Then
                If Session("Allow_Action_Type_Upload") = "1" Then
                    cmdReturnMenu.Visible = True
                Else
                    cmdReturnMenu.Visible = False
                End If
#If EngDesign Then
                ctlTitle.InnerText = "Information File List"
#Else
                ctlTitle.InnerText = "����� ���� ����"
#End If

                'cmdHelp.Disabled = True
                lstUsers.Visible = False
                lblBOUserID.Visible = False
                lblClinic.Visible = False
#If EngDesign Then
                tdDistTitle.InnerText = "Information File List"
#Else
                tdDistTitle.InnerText = "����� ���� ����"
#End If
                tdDistTitle.Width = "100%"
                tdDistTitle.Style("text-align") = "center"
#If EngDesign Then
                grdList.Columns(15).HeaderText = "Information File Type"
                'dgForExcel.Columns(14).HeaderText = "Information File Type"
#Else
#If NewDesign Then
                grdList.Columns(18).HeaderText = "��� ���� ����"
                dgForExcel.Columns(17).HeaderText = "��� ���� ����"
#Else
                grdList.Columns(15).HeaderText = "�����"
                'dgForExcel.Columns(14).HeaderText = "�����"
#End If
#End If
#If NewDesign Then
#If EngDesign Then
                grdList.Columns(16).Visible = True
                'dgForExcel.Columns(15).Visible = True
#Else
                grdList.Columns(17).Visible = True
                dgForExcel.Columns(16).Visible = True
#End If
#Else
                grdList.Columns(14).Visible = True
                'dgForExcel.Columns(13).Visible = True
#End If
            Else
#If EngDesign Then
                ctlTitle.InnerText = "Report List"
#Else
                ctlTitle.InnerText = "����� �����"
#End If
                If LCase(Application("App_Type").ToString) = "divur" Then
                    'tdDistTitle.Width = "30%"
#If Not NewDesign And Not EngDesign Then
                    'tdClinicTitle.Width = "40%"
#End If
                    tdDistTitle.InnerText = ""
                Else
                    tdDistTitle.Style("text-align") = "left"
                End If
                'cmdHelp.Disabled = False
#If NewDesign And Not EngDesign Then
                grdList.Columns(2).Visible = False
                dgForExcel.Columns(2).Visible = False
#Else
                grdList.Columns(1).Visible = False
                'dgForExcel.Columns(1).Visible = False
#End If
#If EngDesign Then
                grdList.Columns(15).HeaderText = "Report Name"
                'dgForExcel.Columns(14).HeaderText = "Report Name"
#Else
#If NewDesign Then
                grdList.Columns(18).HeaderText = "<span title='���� ������ �� ���� ����� ����� ����'>�� ���</span>"
                dgForExcel.Columns(17).HeaderText = "�� ���"
#Else
                grdList.Columns(15).HeaderText = "�����"
                'dgForExcel.Columns(14).HeaderText = "�����"

#End If
#End If
                If Application("App_Type").ToString().ToLower() = "doar" Then
#If NewDesign Then
                    cmdExit.Value = "�����"
                    cmdExit.Attributes("onclick") = "window.close();return;"
#Else
                    cmdReturnMenu.Value = "�����"
                    cmdReturnMenu.Attributes("onclick") = "window.close();return;"
#End If
                End If

                If Application("App_Type").ToString().ToLower() = "claim" Then
                    If Session("Allow_Action_Type_Upload") = "1" Then
                        cmdReturnMenu.Visible = True
                    Else
                        cmdReturnMenu.Visible = False
                    End If
                End If
                BindUsers()
            End If
#If Not EngDesign Then
            Dim strClinicId As String = ""
            Dim strClinicName As String = ""
            Dim strCrntUser = CEncode.StringEncode(objUser.GetUserNameByID("C5C4C694-E524-41D3-8ECD-38CE8434FE4B", Val(lstUsers.SelectedItem.Value)))
            If strCrntUser = "" Then
                strCrntUser = User.Identity.Name
            End If
            Session("CrntUser") = strCrntUser
            objUser.GetClinicAndDoctor("F2D2C32E-6BA0-42C0-BD3C-1E16726B709D", strCrntUser, strClinicId, strClinicName)
            ''''''''''''''''''''objUser.GetHDClinicIdAndClinicName("BE25C36A-51E8-11E4-B3E7-C79B1D5D46B0", strCrntUser, strClinicId, strClinicName)


#If NewDesign Then

            If strClinicId <> "" Then
                If strClinicId <> "" Then
                    txtClinicID.Value = strClinicId
                Else
                    txtClinicID.Value = "0"
                End If
            Else
                txtClinicID.Value = "0"
            End If
#Else
            lblClinic.Text = strClinicName
#If Not EngDesign Then
            tdTitleClinic2.InnerText = strClinicName
#End If
#End If
#End If
            Dim objSysTables As New ReportConnect.ReportService()
            objSysTables.Url = Application("ReportWebService").ToString()
            Dim iTableType As Integer
            Dim iReportType As Integer
            Dim iDrawerUsage As Integer

            If IsNumeric(Session("Report_List_ReportType")) Then
                iReportType = CInt(Session("Report_List_ReportType"))
                If iReportType <> 0 Then
                    '#If NewDesign And Not EngDesign Then
#If Not EngDesign Then
                    txtReportType.Value = iReportType.ToString().Trim
#End If

#If EngDesign Then
                    lblReportType.Text = "Report Type:" & " " & objSysTables.GetReportTypeName("56697E9B-C6F6-45A5-9BFA-AA3647AB62F0", iReportType)
#Else
                    If LCase(Application("App_Type").ToString) = "divur" Then
                        lblReportType.Text = objSysTables.GetReportTypeName("56697E9B-C6F6-45A5-9BFA-AA3647AB62F0", iReportType)
                    Else
                        lblReportType.Text = "����:" & " " & objSysTables.GetReportTypeName("56697E9B-C6F6-45A5-9BFA-AA3647AB62F0", iReportType)
                    End If
#End If
                    iTableType = objSysTables.GetReportTableType("936C27EF-1292-4EE3-9A38-5FD2F124FC14", iReportType)

                    iDrawerUsage = objSysTables.GetReportDrawerUsage("2C0B75D2-5826-108E-9D19-5654572E1C86", iReportType)
#If NewDesign And Not EngDesign Then

                    Me.UC_ExportData1.cmdExcelVisible = False
                    Me.ArrowWhiteToLeftExcel.Visible = False


                    Dim bShowRepListInExcelFormat As Boolean = False

                    bShowRepListInExcelFormat = _
                    objSysTables.getReportTypeMultyReportsPermition("EA4A86D0-F38B-11DE-8A39-0800200C9A66", iReportType)

                    If bShowRepListInExcelFormat And bAllowUserMultyReportsPermition Then
                        Me.UC_ExportData1.cmdExcelVisible = True
                        Me.ArrowWhiteToLeftExcel.Visible = True
                    End If

                    If iDrawerUsage = 25 Then
                        hidIsTechSupport.Value = "1"
                        FillSubjects()

                        If Session("Filter_On") = "1" Then
                            SetComboValue(lstRepName, Session("Filter_ReportType"))
                            txtFromUserName.Value = Session("Filter_FromUserName")
                            txtLastUpdateUserName.Value = Session("Filter_LastUpdateUserName")
                            txtSupplierID.Value = Session("Filter_SupplierID")
                            hidStatusCodes.Value = Session("Filter_StatusCode")
                        Else
                            txtFromUserName.Value = ""
                            txtLastUpdateUserName.Value = ""
                            txtSupplierID.Value = ""
                            hidStatusCodes.Value = ""
                        End If

                    Else
                        hidIsTechSupport.Value = "0"
                    End If
#End If
                    If LCase(Application("App_Type").ToString) = "supp" Or LCase(Application("App_Type").ToString) = "divur" Then
                        Dim MaxRequestRepDays As Integer = objSysTables.GetMaxRequestRepDays("142D997D-42C5-4BC8-ADA4-4D9A95A94F0A")
                        If MaxRequestRepDays > 0 And MaxRequestRepDays < 366 Then
                            hidMaxRequestRepDays.Value = MaxRequestRepDays
                        Else
                            hidMaxRequestRepDays.Value = 30
                        End If
                    End If

                    If LCase(Application("App_Type").ToString) = "supp" Then

#If NewDesign And Not EngDesign Then

                        Dim MaxRowCountForPrint As Integer
                        MaxRowCountForPrint = objSysTables.GetMaxRowCountForPrint("AC162846-2DB8-4F7B-8511-4600F1F8C6D7", iReportType)
                        If MaxRowCountForPrint <> -1 And MaxRowCountForPrint < 301 Then
                            hidMaxRowCountForPrint.Value = MaxRowCountForPrint
                        Else
                            hidMaxRowCountForPrint.Value = 30
                        End If

                        Dim flagPrint As Boolean = objSysTables.GetPrintAbility("996D0561-C6F8-4EE8-89E2-2F6E28A45635", iReportType)
                        If flagPrint Then
                            hidPrintActivity.Value = "1"
                        Else
                            hidPrintActivity.Value = "0"
                        End If


#End If
                    End If
                Else
                    lblReportType.Text = ""
                    iTableType = 0
                End If
            Else
                lblReportType.Text = ""
                iTableType = 0
            End If
#If Not NewDesign And Not EngDesign Then
            cmdHdReportDailyConsultations.Visible = False
            cmdHdReportDailyRequests.Visible = False
            cmdHdReportDailyAccount.Visible = False

#End If


            If Application("App_Type").ToString = "divur" And ((iReportType = 500) Or (iReportType = 510)) Then
                cmdReportClaims.Visible = True
                '#If EngDesign Then
                '                spnChkTitle.InnerText = "Filter, Search and Summary Report"
                '#Else
                '                spnChkTitle.InnerText = "�����, ����� ���� �����"
                '#End If
            ElseIf Application("App_Type").ToString = "divur" And iReportType = 41 Then
#If Not NewDesign And Not EngDesign Then

                If Application("ShowInterActiveReport").ToString = "1" Then

                    cmdHdReportDailyConsultations.Visible = True

                End If

#End If

                ElseIf Application("App_Type").ToString = "divur" And iReportType = 11 Then
#If Not NewDesign And Not EngDesign Then

                If Application("ShowInterActiveReport").ToString = "1" Then


                    cmdHdReportDailyRequests.Visible = True

                End If

#End If


                ElseIf Application("App_Type").ToString = "divur" And iReportType = 10 Then
#If Not NewDesign And Not EngDesign Then

                If Application("ShowInterActiveReport").ToString = "1" Then


                    cmdHdReportDailyAccount.Visible = True

                End If
#End If





                ElseIf Application("App_Type").ToString = "supp" And iReportType = 90001 Then
                    cmdReportClaims.Visible = False
                    '#If EngDesign Then
                    '                spnChkTitle.InnerText = "Filter, Search and Summary Report"
                    '#Else
                    '                spnChkTitle.InnerText = "�����, ����� ���� �����"
                    '#End If
                ElseIf Application("App_Type").ToString = "supp" And iReportType = 90000 Then
                    cmdReportClaims.Visible = False
                    '#If EngDesign Then
                    '                spnChkTitle.InnerText = "Filter and Search"
                    '#Else
                    '                spnChkTitle.InnerText = "����� ������"
                    '#End If

                ElseIf Application("App_Type").ToString = "supp" And iReportType = 90013 Then

                    cmdReportClaims.Visible = False
                    '#If EngDesign Then
                    '                spnChkTitle.InnerText = "Filter"
                    '#Else
                    '                spnChkTitle.InnerText = "�����, ����� ������ ������"
                    '#End If
                Else
                    cmdReportClaims.Visible = False
                    '#If EngDesign Then
                    '                spnChkTitle.InnerText = "Filter"
                    '#Else
                    '                spnChkTitle.InnerText = "�����"
                    '#End If
                End If

#If EngDesign Then
                    spnChkTitle.InnerText = "Filter"
#End If


                Select Case iTableType
                    Case 0, 14
                        If iTableType = 14 Then
                            grdList.Columns(3).Visible = True
                        End If
                        If Session("Filter_InsuredID") <> "" Or Session("Filter_InsuredName") <> "" Then
                            If Application("App_Type").ToString = "supp" Then
#If NewDesign Then
#If EngDesign Then
                            grdList.Columns(2).Visible = False
                            grdList.Columns(11).Visible = False
                            grdList.Columns(13).Visible = True
                            grdList.Columns(14).Visible = True
                            grdList.Columns(15).Visible = True
                            grdList.Columns(18).Visible = False
                            grdList.Columns(19).Visible = False
                            grdList.Columns(20).Visible = False
                            grdList.Columns(21).Visible = False
                            grdList.Columns(22).Visible = False

                            'With dgForExcel
                            '    .Columns(2).Visible = False
                            '    .Columns(10).Visible = False
                            '    .Columns(12).Visible = True
                            '    .Columns(13).Visible = True
                            '    .Columns(14).Visible = True
                            '    .Columns(17).Visible = False
                            '    .Columns(18).Visible = False
                            '    .Columns(19).Visible = False
                            '    .Columns(20).Visible = False
                            '    .Columns(21).Visible = False
                            'End With


#Else

                            grdList.Columns(4).Visible = False
                            grdList.Columns(12).Visible = False
                            grdList.Columns(14).Visible = True
                            grdList.Columns(15).Visible = True
                            grdList.Columns(16).Visible = True
                            'grdList.Columns(19).Visible = False
                            'grdList.Columns(20).Visible = False
                            'grdList.Columns(21).Visible = False
                            'grdList.Columns(22).Visible = False
                            'grdList.Columns(23).Visible = False
                            'grdList.Columns(24).Visible = False
                            grdList.Columns(19).Visible = False

                            With dgForExcel
                                .Columns(3).Visible = False
                                .Columns(11).Visible = False
                                .Columns(13).Visible = True
                                .Columns(14).Visible = True
                                .Columns(15).Visible = True
                                .Columns(18).Visible = False
                            End With

#End If
#Else
                                grdList.Columns(2).Visible = False
                                grdList.Columns(9).Visible = False
                                grdList.Columns(11).Visible = True
                                grdList.Columns(12).Visible = True
                                grdList.Columns(13).Visible = True
                                ''grdList.Columns(18).Visible = False
                                ''grdList.Columns(19).Visible = False
                                ''grdList.Columns(20).Visible = False
                                ''grdList.Columns(21).Visible = False
                                ''grdList.Columns(22).Visible = False
                                ''grdList.Columns(23).Visible = False
                                ''grdList.Columns(24).Visible = False
                                'With dgForExcel
                                '    .Columns(2).Visible = False
                                '    .Columns(8).Visible = False
                                '    .Columns(10).Visible = True
                                '    .Columns(11).Visible = True
                                '    .Columns(12).Visible = True
                                'End With
#End If
                            End If
                        End If
                    Case 1
#If NewDesign Then
#If EngDesign Then
                    grdList.Columns(8).Visible = True
                    grdList.Columns(9).Visible = True
                    grdList.Columns(10).Visible = True
                    grdList.Columns(15).Visible = True
                    grdList.Columns(18).Visible = False
                    grdList.Columns(19).Visible = False
                    grdList.Columns(20).Visible = False
                    grdList.Columns(21).Visible = False
                    grdList.Columns(22).Visible = False
                    grdList.Columns(23).Visible = False
                    grdList.Columns(24).Visible = False
                    'With dgForExcel
                    '    .Columns(7).Visible = True
                    '    .Columns(8).Visible = True
                    '    .Columns(9).Visible = True
                    '    .Columns(14).Visible = True
                    '    .Columns(17).Visible = False
                    '    .Columns(18).Visible = False
                    '    .Columns(19).Visible = False
                    '    .Columns(20).Visible = False
                    '    .Columns(21).Visible = False
                    '    .Columns(22).Visible = False
                    '    .Columns(23).Visible = False
                    'End With
#Else
                    grdList.Columns(9).Visible = True
                    grdList.Columns(10).Visible = True
                    grdList.Columns(11).Visible = True
                    grdList.Columns(16).Visible = True
                    'grdList.Columns(19).Visible = False
                    'grdList.Columns(20).Visible = False
                    'grdList.Columns(21).Visible = False
                    'grdList.Columns(22).Visible = False
                    'grdList.Columns(23).Visible = False
                    'grdList.Columns(24).Visible = False
                    grdList.Columns(19).Visible = False
                    With dgForExcel
                        .Columns(8).Visible = True
                        .Columns(9).Visible = True
                        .Columns(10).Visible = True
                        .Columns(15).Visible = True
                        .Columns(18).Visible = False
                    End With
#End If
#Else
                        grdList.Columns(6).Visible = True
                        grdList.Columns(7).Visible = True
                        grdList.Columns(8).Visible = True
                        grdList.Columns(13).Visible = True
                        ''grdList.Columns(18).Visible = False
                        ''grdList.Columns(19).Visible = False
                        ''grdList.Columns(20).Visible = False
                        ''grdList.Columns(21).Visible = False
                        ''grdList.Columns(22).Visible = False
                        ''grdList.Columns(23).Visible = False
                        ''grdList.Columns(24).Visible = False

                        'With dgForExcel
                        '    .Columns(5).Visible = True
                        '    .Columns(6).Visible = True
                        '    .Columns(7).Visible = True
                        '    .Columns(12).Visible = True
                        'End With
#End If
                    Case 2
#If NewDesign Then
#If EngDesign Then
                    grdList.Columns(2).Visible = False
                    grdList.Columns(11).Visible = True
                    grdList.Columns(13).Visible = True
                    grdList.Columns(14).Visible = True
                    grdList.Columns(15).Visible = True
                    If Application("App_Type").ToString = "divur" Or LCase(Application("App_Type").ToString) = "kupa_info" Then
                        grdList.Columns(12).Visible = False
                    Else
                        grdList.Columns(12).Visible = True
                    End If

                    ' With dgForExcel
                    '    .Columns(2).Visible = False
                    '    .Columns(10).Visible = True
                    '    .Columns(12).Visible = True
                    '    .Columns(13).Visible = True
                    '    .Columns(14).Visible = True
                    '    If Application("App_Type").ToString = "divur" Or LCase(Application("App_Type").ToString) = "kupa_info" Then
                    '        .Columns(11).Visible = False
                    '    Else
                    '        .Columns(11).Visible = True
                    '    End If
                    'End With



#Else
                    grdList.Columns(4).Visible = False
                    grdList.Columns(12).Visible = True
                    grdList.Columns(14).Visible = True
                    grdList.Columns(15).Visible = True
                    grdList.Columns(16).Visible = True
                    If Application("App_Type").ToString = "divur" Or LCase(Application("App_Type").ToString) = "kupa_info" Then
                        grdList.Columns(13).Visible = False
                    Else
                        grdList.Columns(13).Visible = True
                    End If

                    With dgForExcel
                        .Columns(3).Visible = False
                        .Columns(11).Visible = True
                        .Columns(13).Visible = True
                        .Columns(14).Visible = True
                        .Columns(15).Visible = True
                        If Application("App_Type").ToString = "divur" Or LCase(Application("App_Type").ToString) = "kupa_info" Then
                            .Columns(12).Visible = False
                        Else
                            .Columns(12).Visible = True
                        End If
                    End With

#End If
#Else
                        grdList.Columns(2).Visible = False
                        grdList.Columns(9).Visible = True
                        grdList.Columns(11).Visible = True
                        grdList.Columns(12).Visible = True
                        grdList.Columns(13).Visible = True

                        If Application("App_Type").ToString = "divur" Or LCase(Application("App_Type").ToString) = "kupa_info" Then
                            grdList.Columns(10).Visible = False
                        Else
                            grdList.Columns(10).Visible = True
                        End If

                        If iReportType = 557 Then   ' ConnectRef
                            grdList.Columns(9).Visible = False
                            grdList.Columns(15).Visible = False
                        End If

                        'grdList.Columns(18).Visible = False
                        'grdList.Columns(19).Visible = False
                        'grdList.Columns(20).Visible = False
                        'grdList.Columns(21).Visible = False
                        'grdList.Columns(22).Visible = False
                        'grdList.Columns(23).Visible = False
                        'grdList.Columns(24).Visible = False

                        ' With dgForExcel
                        '    .Columns(2).Visible = False
                        '    .Columns(8).Visible = True
                        '    .Columns(10).Visible = True
                        '    .Columns(11).Visible = True
                        '    .Columns(12).Visible = True
                        '    If Application("App_Type").ToString = "divur" Or LCase(Application("App_Type").ToString) = "kupa_info" Then
                        '    .Columns(9).Visible = False
                        '    Else
                        '    .Columns(9).Visible = True
                        '    End If
                        '    If iReportType = 557 Then   ' ConnectRef
                        '        .Columns(8).Visible = False
                        '        .Columns(14).Visible = False
                        '    End If
                        'End With

#End If
                    Case 3
#If NewDesign Then
#If EngDesign Then
                    grdList.Columns(2).Visible = True
                    grdList.Columns(11).Visible = False
                    grdList.Columns(13).Visible = True
                    grdList.Columns(14).Visible = True
                    grdList.Columns(15).Visible = True

                    'With dgForExcel
                    '    .Columns(2).Visible = True
                    '    .Columns(10).Visible = False
                    '    .Columns(12).Visible = True
                    '    .Columns(13).Visible = True
                    '    .Columns(14).Visible = True
                    'End With
#Else
                    grdList.Columns(4).Visible = True
                    grdList.Columns(12).Visible = False
                    grdList.Columns(14).Visible = True
                    grdList.Columns(15).Visible = True
                    grdList.Columns(16).Visible = True

                    With dgForExcel
                        .Columns(3).Visible = True
                        .Columns(11).Visible = False
                        .Columns(13).Visible = True
                        .Columns(14).Visible = True
                        .Columns(15).Visible = True
                    End With


#End If
#Else
                        grdList.Columns(2).Visible = True
                        grdList.Columns(9).Visible = False
                        grdList.Columns(11).Visible = True
                        grdList.Columns(12).Visible = True
                        grdList.Columns(13).Visible = True
                        'grdList.Columns(18).Visible = False
                        'grdList.Columns(19).Visible = False
                        'grdList.Columns(20).Visible = False
                        'grdList.Columns(21).Visible = False
                        'grdList.Columns(22).Visible = False
                        'grdList.Columns(23).Visible = False
                        'grdList.Columns(24).Visible = False

                        'With dgForExcel
                        '    .Columns(2).Visible = True
                        '    .Columns(8).Visible = False
                        '    .Columns(10).Visible = True
                        '    .Columns(11).Visible = True
                        '    .Columns(12).Visible = True
                        'End With


#End If
                    Case 4
#If NewDesign Then
#If EngDesign Then
                    grdList.Columns(2).Visible = True
                    grdList.Columns(9).Visible = True
                    grdList.Columns(10).Visible = True
                    grdList.Columns(11).Visible = False
                    grdList.Columns(13).Visible = True
                    grdList.Columns(15).Visible = True

                    'With dgForExcel
                    '    .Columns(2).Visible = True
                    '    .Columns(8).Visible = True
                    '    .Columns(9).Visible = True
                    '    .Columns(10).Visible = False
                    '    .Columns(12).Visible = True
                    '    .Columns(14).Visible = True
                    'End With


#Else
                    grdList.Columns(4).Visible = True
                    grdList.Columns(10).Visible = True
                    grdList.Columns(11).Visible = True
                    grdList.Columns(12).Visible = False
                    grdList.Columns(14).Visible = True
                    grdList.Columns(16).Visible = True

                    With dgForExcel
                        .Columns(3).Visible = True
                        .Columns(9).Visible = True
                        .Columns(10).Visible = True
                        .Columns(11).Visible = False
                        .Columns(13).Visible = True
                        .Columns(15).Visible = True
                    End With


#End If
#Else
                        grdList.Columns(2).Visible = True
                        grdList.Columns(7).Visible = False
                        grdList.Columns(8).Visible = True
                        grdList.Columns(9).Visible = False
                        grdList.Columns(11).Visible = True
                        grdList.Columns(12).Visible = True
                        grdList.Columns(13).Visible = True
                        'grdList.Columns(18).Visible = False
                        'grdList.Columns(19).Visible = False
                        'grdList.Columns(20).Visible = False
                        'grdList.Columns(21).Visible = False
                        'grdList.Columns(22).Visible = False
                        'grdList.Columns(23).Visible = False
                        'grdList.Columns(24).Visible = False

                        ' With dgForExcel
                        '    .Columns(2).Visible = True
                        '    .Columns(6).Visible = False
                        '    .Columns(7).Visible = True
                        '    .Columns(8).Visible = False
                        '    .Columns(10).Visible = True
                        '    .Columns(11).Visible = True
                        '    .Columns(12).Visible = True
                        'End With

#End If
                    Case 11
#If NewDesign Then
#If EngDesign Then
                    grdList.Columns(2).Visible = True
                    grdList.Columns(6).Visible = True
                    grdList.Columns(7).Visible = True
                    col = CType(grdList.Columns(7), BoundColumn)
                    col.DataField = "DocName"
                    grdList.Columns(11).Visible = False
                    grdList.Columns(12).Visible = True
                    grdList.Columns(13).Visible = True
                    grdList.Columns(14).Visible = True
                    grdList.Columns(15).Visible = True

                    'With dgForExcel
                    '    .Columns(2).Visible = True
                    '    .Columns(5).Visible = True
                    '    .Columns(6).Visible = True
                    '    col = CType(grdList.Columns(7), BoundColumn)
                    '    col.DataField = "DocName"
                    '    .Columns(10).Visible = False
                    '    .Columns(11).Visible = True
                    '    .Columns(12).Visible = True
                    '    .Columns(13).Visible = True
                    '    .Columns(14).Visible = True
                    'End With



#Else
                    grdList.Columns(4).Visible = True
                    grdList.Columns(7).Visible = True
                    grdList.Columns(8).Visible = True
                    col = CType(grdList.Columns(8), BoundColumn)
                    col.DataField = "DocName"
                    grdList.Columns(12).Visible = False
                    grdList.Columns(13).Visible = True
                    grdList.Columns(14).Visible = True
                    grdList.Columns(15).Visible = True
                    grdList.Columns(16).Visible = True
                    With dgForExcel
                        .Columns(3).Visible = True
                        .Columns(6).Visible = True
                        .Columns(7).Visible = True
                        col = CType(grdList.Columns(8), BoundColumn)
                        col.DataField = "DocName"
                        .Columns(11).Visible = False
                        .Columns(12).Visible = True
                        .Columns(13).Visible = True
                        .Columns(14).Visible = True
                        .Columns(15).Visible = True
                    End With



#End If
#Else
                        grdList.Columns(2).Visible = True
                        grdList.Columns(9).Visible = False
                        grdList.Columns(10).Visible = False
                        grdList.Columns(11).Visible = True
                        grdList.Columns(12).Visible = True
                        grdList.Columns(13).Visible = True
                        'grdList.Columns(18).Visible = False
                        'grdList.Columns(19).Visible = False
                        ' grdList.Columns(20).Visible = False
                        'grdList.Columns(21).Visible = False
                        'grdList.Columns(22).Visible = False
                        'grdList.Columns(23).Visible = False
                        'grdList.Columns(24).Visible = False
                        'With dgForExcel
                        '    .Columns(2).Visible = True
                        '    .Columns(8).Visible = False
                        '    .Columns(9).Visible = False
                        '    .Columns(10).Visible = True
                        '    .Columns(11).Visible = True
                        '    .Columns(12).Visible = True
                        'End With


#End If

                    Case 12 'Tech. Support
#If NewDesign Then
#If EngDesign Then
                    grdList.Columns(2).Visible = False  'Valid Date
                    grdList.Columns(4).Visible = True 'Creation date
                    grdList.Columns(4).HeaderText = "����� ����"
                    grdList.Columns(6).Visible = False  'Care Date
                    grdList.Columns(7).Visible = False
                    col = CType(grdList.Columns(9), BoundColumn) 'Last Name
                    col.DataField = "LName"
                    grdList.Columns(9).Visible = True
                    col = CType(grdList.Columns(10), BoundColumn) 'First Name
                    col.DataField = "FName"
                    grdList.Columns(10).Visible = True
                    grdList.Columns(11).Visible = False
                    grdList.Columns(12).Visible = False
                    grdList.Columns(13).Visible = True 'Reference
                    grdList.Columns(14).Visible = False
                    grdList.Columns(15).HeaderText = "�� �����"
                    col = CType(grdList.Columns(15), BoundColumn)
                    col.DataField = "FromUserName"
                    grdList.Columns(15).Visible = True
                    grdList.Columns(17).HeaderText = "���� �����"
                    grdList.Columns(18).Visible = True
                    grdList.Columns(19).Visible = True
                    grdList.Columns(20).Visible = True
                    grdList.Columns(21).Visible = True
                    grdList.Columns(22).Visible = True

                    'With dgForExcel
                    '    .Columns(2).Visible = False  'Valid Date
                    '    .Columns(3).Visible = True 'Creation date
                    '    .Columns(3).HeaderText = "����� ����"
                    '    .Columns(5).Visible = False  'Care Date
                    '    .Columns(6).Visible = False
                    '    col = CType(grdList.Columns(9), BoundColumn) 'Last Name
                    '    col.DataField = "LName"
                    '    .Columns(8).Visible = True
                    '    col = CType(grdList.Columns(10), BoundColumn) 'First Name
                    '    col.DataField = "FName"
                    '    .Columns(9).Visible = True
                    '    .Columns(10).Visible = False
                    '    .Columns(11).Visible = False
                    '    .Columns(12).Visible = True 'Reference
                    '    .Columns(13).Visible = False
                    '    .Columns(14).HeaderText = "�� �����"
                    '    col = CType(grdList.Columns(15), BoundColumn)
                    '    col.DataField = "FromUserName"
                    '    .Columns(14).Visible = True
                    '    .Columns(16).HeaderText = "���� �����"
                    '    .Columns(17).Visible = True
                    '    .Columns(18).Visible = True
                    '    .Columns(19).Visible = True
                    '    .Columns(20).Visible = True
                    '    .Columns(21).Visible = True
                    'End With
#Else
                    'GridColumnsForTechSupport()
                    FillGridStatus()
#End If
#End If
                End Select
                txtTableType.Value = iTableType.ToString()

                If Application("App_Type").ToString = "supp" Then
                    grdList.Columns(12).Visible = False
                    'dgForExcel.Columns(11).Visible = False
                End If

                If iGridRowCount > 0 Then
#If NewDesign And Not EngDesign Then

                If Val(txtTableType.Value) <> 13 Then
                    grdList.PageSize = iGridRowCount
                Else
                    gridOccasional.PageSize = iGridRowCount
                End If
#Else
                    If Application("App_Type").ToString = "divur" Then
                        grdListNew.PageSize = iGridRowCount
                    Else
                        grdList.PageSize = iGridRowCount
                    End If

#End If
                End If
                If Application("Paging") = "1" Then
#If NewDesign And Not EngDesign Then
                If Val(txtTableType.Value) <> 13 Then
                    grdList.AllowCustomPaging = True
                Else
                    gridOccasional.AllowCustomPaging = True
                End If
#Else
                    If Application("App_Type").ToString = "divur" Then
                        grdListNew.AllowCustomPaging = True
                    Else
                        grdList.AllowCustomPaging = True
                    End If
#End If
                End If

#If NewDesign And Not EngDesign Then
            If Application("Report2PDFConversion") = "1" Then
                grdList.Columns(0).Visible = objSysTables.IsRepTypePDFConversionSupported("79C19447-02E0-4098-8A20-DDE830B26FF5", iReportType)
            Else
                grdList.Columns(0).Visible = False
            End If
#End If

#If NewDesign And Not EngDesign Then

            If Val(txtTableType.Value) <> 13 Then
                gridOccasional.Visible = False
                grdList.Visible = True
            Else
                gridOccasional.Visible = True
                grdList.Visible = False
            End If
#Else
                If Application("App_Type").ToString = "divur" Then
                    grdList.Visible = False
                    grdListNew.Visible = True
                Else
                    grdList.Visible = True
                    grdListNew.Visible = False
                End If
#End If

                BindGrid()
        End If
#If NewDesign And Not EngDesign Then
        If hidAfterTechUpdate.Value = "1" Then
            BindGrid()
        End If
        hidAfterTechUpdate.Value = "0"
#End If

#If NewDesign And Not EngDesign Then
        Uc_Jcalander1.SubUserId = lstUsers.SelectedItem.Value

        Me.UC_ExportData1.Visible = True

        If Not IsPostBack And Session("Filter_On") = "1" And IsNumeric(Session("Filter_Report_ID")) Then
            hidAutoOpen.Value = "1"
        Else
            hidAutoOpen.Value = ""
        End If
#End If

#If Not NewDesign And Not EngDesign Then
        If Not IsPostBack Then
            cmdReturnConsultation.Visible = False

            If Session("From_Consultation") = "1" Or Session("From_Consultation") = "2" Then
                If Session("From_Consultation") = "1" Then
                    Session("BackUrl") = Utils.Navigation.GetURL("frmRequestt.aspx")
                End If
                If Session("From_Consultation") = "2" Then
                    Session("BackUrl") = "frmTRequestt.aspx"
                End If
                Session("From_Consultation") = ""
                cmdReturnConsultation.Visible = True
                cmdReturnMenu.Disabled = True
                cmdReturn.Disabled = True
                cmdUserProp.Disabled = True
            End If
        End If

#End If

    End Sub

    Private Sub cboGridRowCount_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboGridRowCount.SelectedIndexChanged
        Dim iGridRowCount As Integer

        If cboGridRowCount.SelectedItem.Value <> "" Then
            iGridRowCount = CInt(cboGridRowCount.SelectedItem.Value)

            Dim objUser As New UserConnect.UserService()
            objUser.Url = Application("UserWebService").ToString()
            ' Session("GridRowCount") = iGridRowCount
            objUser.UpdateGridRowCount("5561A874-D4D7-4E5C-AA3D-4EC0EBAA8B7F", User.Identity.Name, iGridRowCount, User.Identity.Name)

            If Val(txtTableType.Value) <> 13 Then
                If iGridRowCount > 0 Then
                    grdList.PageSize = iGridRowCount
                End If
                grdList.CurrentPageIndex = 0
            Else
                If iGridRowCount > 0 Then
                    gridOccasional.PageSize = iGridRowCount
                End If
                gridOccasional.CurrentPageIndex = 0
            End If

            BindGrid()
        End If
    End Sub
    Private Sub BindGridExcel()
        Dim objReportsList As New ReportConnect.ReportService()
        objReportsList.Url = Application("ReportWebService").ToString()
        Dim iReportType As Integer
        Dim strFromDate As String
        Dim strToDate As String
        Dim bViewed As Boolean
        Dim bNotViewed As Boolean
        Dim strInsuredID As String, strName As String
        Dim iTableType As Integer

        Dim dsAdd As DataSet
        Dim iCountMore As Integer = 0
        Dim MaxRecNo As Integer = 200
        Dim bPaging As Boolean = IIf(Application("Paging") = "1", True, False)
        Dim strKoteret As String


        If IsNumeric(Session("Report_List_ReportType")) Then
            iReportType = CInt(Session("Report_List_ReportType"))
            iTableType = CInt(txtTableType.Value)
        Else
            iReportType = 0
            iTableType = 0
        End If
        If chkFilter.Checked Then
            strFromDate = Trim(txtDateFrom.Value)
            strToDate = Trim(txtDateTo.Value)
            bViewed = chkViewed.Checked
            bNotViewed = chkNotViewed.Checked
#If Not NewDesign Then
            	        If Application("SearchByRepName").ToString = "1" Then
            	            strKoteret = Me.txtKoteret.Value
            	        End If
#End If
            If iTableType > 0 Then
                strInsuredID = txtInshuredID.Value
                strName = txtName.Value
            Else
                If Application("App_Type").ToString = "supp" Then
                    strInsuredID = Session("Filter_InsuredID")
                    strName = Session("Filter_InsuredName")
                Else
                    strInsuredID = ""
                    strName = ""
                End If
            End If
        Else

#If NewDesign And Not EngDesign Then
            If Me.txtDateForCal.Value <> "" And _
               Me.txtDateForCal.Value <> "NULL" And _
               Me.ChkCalander.Checked Then
                strFromDate = Me.txtDateForCal.Value
                Me.Uc_Jcalander1.LastChoiceMonth = strFromDate
                strToDate = strFromDate
                ''''Me.txtDateForCal.Value = ""
            Else
                strFromDate = "00000000"
                strToDate = "00000000"
            End If
#Else
            strFromDate = "00000000"
            strToDate = "00000000"
#End If

            bViewed = True
            bNotViewed = True
            strInsuredID = ""
            strName = ""
        End If
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim strUserID As String = objUser.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", User.Identity.Name)
        Dim ds As DataSet
        Dim dsExcel As DataSet
        If Not g_fAllowUserSelect Then
            '/ds = objReportsList.GetDistributionList("5D1B3748-06E2-4DF8-AA9A-E1E94ED19B98", strUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
            dsExcel = objReportsList.GetDistributionList("5D1B3748-06E2-4DF8-AA9A-E1E94ED19B98", strUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
        Else
            Dim strSubUserID As String = lstUsers.SelectedItem.Value




            If Application("App_Type").ToString().ToLower() = "divur" Or Application("App_Type").ToString().ToLower() = "kupa_info" Then
                If iTableType = 2 Then
                    dsExcel = objReportsList.GetReportsListExt("B23B098A-BFEB-47E3-98FF-70C23D884F1A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                ElseIf iTableType = 11 Then
                    dsExcel = objReportsList.GetReportsList11Type("A201017E-2BC3-4376-A110-8B1B9183C2A2", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, -1, strKoteret)
                Else
                    dsExcel = objReportsList.GetReportsList("7A9C96B4-DB38-4780-AA37-CA714783D55A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                End If
            ElseIf Application("App_Type").ToString().ToLower() = "doar" Then
                dsExcel = objReportsList.GetReportsList("7A9C96B4-DB38-4780-AA37-CA714783D55A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
            Else
                Select Case iTableType
                    Case 2
                        dsExcel = objReportsList.GetReportsListExtMushlam("B23B098A-BFEB-47E3-98FF-70C23D884F1A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                    Case 3
                        dsExcel = objReportsList.GetReportsListExtMushlam("B23B098A-BFEB-47E3-98FF-70C23D884F1A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                    Case 4
                        dsExcel = objReportsList.GetReportsListCB("EEF4EE5A-69C2-4EDA-9D5D-8FA3055DA777", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                    Case 11
                        Dim DoctorID As Integer = -1
#If NewDesign Then
                        Dim sDoctorID As String = Trim(txtDoctorID.Value)
                        If sDoctorID <> "" Then
                            If IsNumeric(sDoctorID) Then
                                DoctorID = CInt(sDoctorID)
                            End If
                        End If

#End If
                        If Application("App_Type").ToString().ToUpper() = "SUPP" Then
                            dsExcel = objReportsList.GetReportsList11TypeMushlam("BEB34FC7-0FCE-40DF-9546-DF903B284FFE", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, DoctorID, strKoteret)
                        Else
                            dsExcel = objReportsList.GetReportsList11Type("A201017E-2BC3-4376-A110-8B1B9183C2A2", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, DoctorID, strKoteret)
                        End If

                    Case 12
#If NewDesign And Not EngDesign Then
                        Dim sUserName As String = txtFromUserName.Value
                        Dim sName As String = ""
                        Dim sRepName As String = ""
                        Dim iRepNameID As String = lstRepName.SelectedItem.Value

                        GridColumnsForTechSupportForExcel()

                        If iRepNameID > 0 Then
                            sRepName = lstRepName.SelectedItem.Text
                        End If
                        dsExcel = objReportsList.GetReportsListTechSupport("QG9C96B4-DB38-4780-AA37-CA714783D55A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, sUserName, sName, 0, 999, 0, sRepName, hidStatusCodes.Value, txtLastUpdateUserName.Value, Val(txtSupplierID.Value))
#End If
                    Case Else
                        Dim col As BoundColumn
                        Dim colExcel As BoundColumn
#If NewDesign Then
#If EngDesign Then
                        col = CType(grdList.Columns(12), BoundColumn)
                        'colExcel = CType(dgForExcel.Columns(11), BoundColumn)
#Else
                        col = CType(grdList.Columns(13), BoundColumn)
                        colExcel = CType(dgForExcel.Columns(12), BoundColumn)
#End If
#Else
                        col = CType(grdList.Columns(10), BoundColumn)
                        'colExcel = CType(dgForExcel.Columns(9), BoundColumn)

#End If
                        col.DataField = ""
#If NewDesign Then
                        colExcel.DataField = ""
#End If
                        If Session("Filter_InsuredID") <> "" Or Session("Filter_InsuredName") <> "" Then
                            dsExcel = objReportsList.GetReportsListExtMushlam("B23B098A-BFEB-47E3-98FF-70C23D884F1A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                            'Dim iCountMoreAdd As Integer = 0
                            'dsAdd = objReportsList.GetReportsList11TypeMushlam("BEB34FC7-0FCE-40DF-9546-DF903B284FFE", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, -1, strKoteret)
                            'If ds.Tables(0).Rows.Count = MaxRecNo Or iCountMore > 0 Then
                            '    iCountMoreAdd = objReportsList.GetReportsList11TypeMushlamCount("7020D5E2-E8E8-4BE2-BFDB-4D7844A2D81C", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, -1, strKoteret)
                            '    iCountMore = iCountMore + iCountMoreAdd
                            'End If
                        Else
                            If Application("App_Type").ToString.ToUpper = "CLAIM" Or Application("App_Type").ToString.ToUpper = "SUPP" Then
#If NewDesign And Not EngDesign Then
                                If Application("HasCB") = "1" Then
                                    'ds = objReportsList.GetReportsList("7A9C96B4-DB38-4780-AA37-CA714783D55A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, "")
                                    '/ds = objReportsList.GetReportsListCB("EEF4EE5A-69C2-4EDA-9D5D-8FA3055DA777", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, "")
                                    dsExcel = objReportsList.GetReportsListCB("EEF4EE5A-69C2-4EDA-9D5D-8FA3055DA777", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, "")
                                Else
                                    dsExcel = objReportsList.GetReportsListForPermit("7A9C96B4-DB38-4780-AA37-CA714783D55A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                                End If
#Else
                            #If NewDesign Then
                                dsExcel = objReportsList.GetReportsListForPermit("7A9C96B4-DB38-4780-AA37-CA714783D55A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, "")
                            #Else
                                dsExcel = objReportsList.GetReportsList("7A9C96B4-DB38-4780-AA37-CA714783D55A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                            #End If
#End If
                            Else
                                dsExcel = objReportsList.GetReportsList("7A9C96B4-DB38-4780-AA37-CA714783D55A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                            End If

                        End If
                End Select
                'End If
            End If
#If NewDesign And Not EngDesign Then
            dgForExcel.DataSource = dsExcel
#End If
        End If

        txtAppType.Value = Application("App_Type").ToString

#If NewDesign And Not EngDesign Then
        AddDataColumn(dsExcel.Tables(0), "CareDate")
        dgForExcel.DataBind()
#End If
    End Sub

    Private Sub BindGrid()
        If Application("App_Type").ToString().ToLower() = "divur" Then
            ShowNewGridByReportType()
            BindGridNew()

        Else
            If Val(txtTableType.Value) <> 13 Then
                BindGridMain()
            Else
                'BindGridOccasional()
            End If
        End If

    End Sub

    Private Sub ShowNewGridByReportType()
        Dim iReportType As Integer = Val(txtReportType.Value)
        Dim i As Integer
		Dim iSearchByRepNameValue As Integer = 0
		Dim iSearchByInsuredID As Integer = 0

        For i = 0 To 16
            grdListNew.Columns(i).Visible = False
        Next

        Select Case iReportType
            Case 555, 557 ' ����� ����� ��� �� , ����� ���� �������� 
                grdListNew.Columns(col_grdList_InsuredID).Visible = True
                grdListNew.Columns(col_grdList_FName).Visible = True
                grdListNew.Columns(col_grdList_LName).Visible = True
                grdListNew.Columns(col_grdList_Reference).Visible = True
                grdListNew.Columns(col_grdList_EntryDate).Visible = True
                grdListNew.Columns(col_grdList_ViewDate).Visible = True
            Case 510 ' ����� ���� ��������  �����
                grdListNew.Columns(col_grdList_InsuredID).Visible = True
                grdListNew.Columns(col_grdList_FName).Visible = True
                grdListNew.Columns(col_grdList_LName).Visible = True
                grdListNew.Columns(col_grdList_Reference).Visible = True
                grdListNew.Columns(col_grdList_Treatment).Visible = True
                grdListNew.Columns(col_grdList_TreatmentDesc).Visible = True
                grdListNew.Columns(col_grdList_FTooth).Visible = True
                grdListNew.Columns(col_grdList_ToTooth).Visible = True
                grdListNew.Columns(col_grdList_EntryDate).Visible = True
                grdListNew.Columns(col_grdList_ViewDate).Visible = True
            Case 500 ' ����� ���� ����� / ���� 
                grdListNew.Columns(col_grdList_InsuredID).Visible = True
                grdListNew.Columns(col_grdList_FName).Visible = True
                grdListNew.Columns(col_grdList_LName).Visible = True
                grdListNew.Columns(col_grdList_Reference).Visible = True
                grdListNew.Columns(col_grdList_RequestTyp).Visible = True
                grdListNew.Columns(col_grdList_Treatment).Visible = True
                grdListNew.Columns(col_grdList_TreatmentDesc).Visible = True
                grdListNew.Columns(col_grdList_FTooth).Visible = True
                grdListNew.Columns(col_grdList_ToTooth).Visible = True
                grdListNew.Columns(col_grdList_FinishDate).Visible = True
                grdListNew.Columns(col_grdList_EntryDate).Visible = True
                grdListNew.Columns(col_grdList_ViewDate).Visible = True

                If Application("ShowInterActiveReport").ToString() = "1" Then

                    grdListNew.Columns(col_grdList_ReferenceNo).Visible = True


                End If

            Case 556 ' ����� ��� �� ����������
                grdListNew.Columns(col_grdList_InsuredID).Visible = True
                grdListNew.Columns(col_grdList_FName).Visible = True
                grdListNew.Columns(col_grdList_LName).Visible = True
                grdListNew.Columns(col_grdList_CheckType).Visible = True
                grdListNew.Columns(col_grdList_Reference).Visible = True
                grdListNew.Columns(col_grdList_EntryDate).Visible = True
                grdListNew.Columns(col_grdList_ViewDate).Visible = True
            Case 588 '����� ����� ������ �������
                grdListNew.Columns(col_grdList_InsuredID).Visible = True
                grdListNew.Columns(col_grdList_FName).Visible = True
                grdListNew.Columns(col_grdList_LName).Visible = True
                grdListNew.Columns(col_grdList_Reference).Visible = True
                grdListNew.Columns(col_grdList_EntryDate).Visible = True
                grdListNew.Columns(col_grdList_ViewDate).Visible = True
            Case 888 ' ���� ��� ������
                grdListNew.Columns(col_grdList_InsuredID).Visible = True
                grdListNew.Columns(col_grdList_FName).Visible = True
                grdListNew.Columns(col_grdList_LName).Visible = True
                grdListNew.Columns(col_grdList_Reference).Visible = True
                grdListNew.Columns(col_grdList_EntryDate).Visible = True
                grdListNew.Columns(col_grdList_ViewDate).Visible = True
            Case 45, 50, 41 ' ���� ����� ���������', ������, ���� ���������� ����
                grdListNew.Columns(col_grdList_InsuredID).Visible = True
                grdListNew.Columns(col_grdList_FName).Visible = True
                grdListNew.Columns(col_grdList_LName).Visible = True
                grdListNew.Columns(col_grdList_EntryDate).Visible = True
                grdListNew.Columns(col_grdList_EntryDate).HeaderText = "����� �����"
                grdListNew.Columns(col_grdList_ViewDate).Visible = True
				iSearchByInsuredID = 1
            Case 11 ' ���� ������ ���� 
                grdListNew.Columns(col_grdList_EntryDate).Visible = True
                grdListNew.Columns(col_grdList_EntryDate).HeaderText = "����� �����"
                grdListNew.Columns(col_grdList_ViewDate).Visible = True
            Case 10 ' ����� ����� ����� 			
                grdListNew.Columns(col_grdList_Bruto).Visible = True
                grdListNew.Columns(col_grdList_EntryDate).Visible = True
                grdListNew.Columns(col_grdList_EntryDate).HeaderText = "����� �����"
                grdListNew.Columns(col_grdList_ViewDate).Visible = True
            Case 70 ' ���� ���� ������ 			
                grdListNew.Columns(col_grdList_EntryDate).Visible = True
                grdListNew.Columns(col_grdList_EntryDate).HeaderText = "����� �����"
                grdListNew.Columns(col_grdList_ViewDate).Visible = True

            Case 900, 1011 ' ������ �����, �����
                grdListNew.Columns(col_grdList_EntryDate).Visible = True
                grdListNew.Columns(col_grdList_EntryDate).HeaderText = "����� �����"
                grdListNew.Columns(col_grdList_ViewDate).Visible = True
                grdListNew.Columns(col_grdList_RepName).Visible = True
				iSearchByRepNameValue = 1
            Case Else
                grdListNew.Columns(col_grdList_EntryDate).Visible = True
                grdListNew.Columns(col_grdList_EntryDate).HeaderText = "����� �����"
                grdListNew.Columns(col_grdList_ViewDate).Visible = True

        End Select
#If Not NewDesign Then
        If Application("SearchByRepName").ToString = "1" Then
            Me.SearchByRepName.Value = CStr(iSearchByRepNameValue)
        Else
             Me.SearchByRepName.Value = "0"
        End If
#If Not EngDesign Then		
		hidInshuredIDSearch.Value = CStr(iSearchByInsuredID)
#End If
#End If
    End Sub

    Private Sub BindGridMain()
        Dim objReportsList As New ReportConnect.ReportService()
        objReportsList.Url = Application("ReportWebService").ToString()
        Dim iReportType As Integer
        Dim strFromDate As String
        Dim strToDate As String
        Dim bViewed As Boolean
        Dim bNotViewed As Boolean
        Dim strInsuredID As String, strName As String
        Dim iTableType As Integer

        Dim dsAdd As DataSet
        Dim iCountMore As Integer = 0
        Dim MaxRecNo As Integer = 200
        Dim bPaging As Boolean = IIf(Application("Paging") = "1", True, False)
        Dim strKoteret As String
        Dim iRepID As Integer = 0

        If IsNumeric(Session("Report_List_ReportType")) Then
            iReportType = CInt(Session("Report_List_ReportType"))
            iTableType = CInt(txtTableType.Value)
        Else
            iReportType = 0
            iTableType = 0
        End If
        If chkFilter.Checked Then
            If IsNumeric(Session("Filter_Report_ID")) Then
                iRepID = CInt(Session("Filter_Report_ID"))
            End If
            strFromDate = Trim(txtDateFrom.Value)
            strToDate = Trim(txtDateTo.Value)
            bViewed = chkViewed.Checked
            bNotViewed = chkNotViewed.Checked
#If Not NewDesign Then
            If Application("SearchByRepName").ToString = "1" Then
                strKoteret = Me.txtKoteret.Value
            End If
#End If
            If iTableType > 0 Then
                strInsuredID = txtInshuredID.Value
                strName = txtName.Value
            Else
                If Application("App_Type").ToString = "supp" Then
                    strInsuredID = Session("Filter_InsuredID")
                    strName = Session("Filter_InsuredName")
                Else
                    strInsuredID = ""
                    strName = ""
                End If
            End If
        Else

#If NewDesign And Not EngDesign Then
            If Me.txtDateForCal.Value <> "" And _
               Me.txtDateForCal.Value <> "NULL" And _
               Me.ChkCalander.Checked Then
                strFromDate = Me.txtDateForCal.Value
                Me.Uc_Jcalander1.LastChoiceMonth = strFromDate
                strToDate = strFromDate
                ''''Me.txtDateForCal.Value = ""
            Else
                strFromDate = "00000000"
                strToDate = "00000000"
            End If
#Else
            strFromDate = "00000000"
            strToDate = "00000000"
#End If

            bViewed = True
            bNotViewed = True
            strInsuredID = ""
            strName = ""
        End If
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim strUserID As String = objUser.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", User.Identity.Name)
        Dim ds As DataSet

        If Not g_fAllowUserSelect Then
            ds = objReportsList.GetDistributionList("5D1B3748-06E2-4DF8-AA9A-E1E94ED19B98", strUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
        Else
            Dim strSubUserID As String = lstUsers.SelectedItem.Value


#If NewDesign And Not EngDesign Then
            Uc_Jcalander1.SubUserId = lstUsers.SelectedItem.Value
#End If



            If Application("App_Type").ToString().ToLower() = "divur" Or Application("App_Type").ToString().ToLower() = "kupa_info" Then
                If iTableType = 2 Then
                    If bPaging Then
                        ds = objReportsList.GetReportsListExtPaging("9E265C99-FC7E-45BA-B758-DB4711CBA5B8", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, grdList.PageSize, grdList.CurrentPageIndex, strKoteret)
                    Else
                        ds = objReportsList.GetReportsListExt("B23B098A-BFEB-47E3-98FF-70C23D884F1A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                    End If

                    If ds.Tables(0).Rows.Count = MaxRecNo Then
                        iCountMore = objReportsList.GetReportsListExtCount("90ED5175-FD86-40B9-8FDD-E8483BCEA6B9", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                    End If
                ElseIf iTableType = 11 Then
                    If bPaging Then
                        ds = objReportsList.GetReportsList11TypePaging("2E11F64D-0F19-4C23-967F-464A0E8D9872", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, -1, grdList.PageSize, grdList.CurrentPageIndex, strKoteret)
                    Else
                        ds = objReportsList.GetReportsList11Type("A201017E-2BC3-4376-A110-8B1B9183C2A2", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, -1, strKoteret)
                    End If

                    If ds.Tables(0).Rows.Count = MaxRecNo Then
                        iCountMore = objReportsList.GetReportsList11TypeCount("17073C2D-6940-4F3B-B8CF-15D8949FCAC9", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, -1, strKoteret)
                    End If
                Else
                    If bPaging Then
                        ds = objReportsList.GetReportsListPaging("642BC9D6-70D6-436A-81DE-883CDC6E1295", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, grdList.PageSize, grdList.CurrentPageIndex, strKoteret)
                    Else
                        ds = objReportsList.GetReportsList("7A9C96B4-DB38-4780-AA37-CA714783D55A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                    End If

                    If ds.Tables(0).Rows.Count = MaxRecNo Then
                        iCountMore = objReportsList.GetReportsListCount("52EF9746-374B-404D-977F-0576E92AC4DF", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                    End If
                End If
            ElseIf Application("App_Type").ToString().ToLower() = "doar" Then
                If strSubUserID = "0" Then
                    ds = objReportsList.GetDoarReportsList("8FB372FE-D9D0-49BA-91DE-DC2610B654B2", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName)
                Else
                    ds = objReportsList.GetReportsList("7A9C96B4-DB38-4780-AA37-CA714783D55A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                End If

                bPaging = False
            Else
                Select Case iTableType
                    Case 2
                        If bPaging Then
                            ds = objReportsList.GetReportsListExtMushlamPaging("7740538A-9EF8-417F-B647-B56239A161A8", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, grdList.PageSize, grdList.CurrentPageIndex, strKoteret)
                        Else
                            ds = objReportsList.GetReportsListExtMushlam("B23B098A-BFEB-47E3-98FF-70C23D884F1A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                        End If

                        If ds.Tables(0).Rows.Count = MaxRecNo Then
                            iCountMore = objReportsList.GetReportsListExtMushlamCount("8B555A15-B7E6-4F81-87CB-51012E323695", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                        End If
                    Case 3
                        If bPaging Then
                            ds = objReportsList.GetReportsListExtMushlamPaging("7740538A-9EF8-417F-B647-B56239A161A8", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, grdList.PageSize, grdList.CurrentPageIndex, strKoteret)
                        Else
                            ds = objReportsList.GetReportsListExtMushlam("B23B098A-BFEB-47E3-98FF-70C23D884F1A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                        End If

                        If ds.Tables(0).Rows.Count = MaxRecNo Then
                            iCountMore = objReportsList.GetReportsListExtMushlamCount("8B555A15-B7E6-4F81-87CB-51012E323695", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                        End If
                    Case 4
                        ds = objReportsList.GetReportsListCB("EEF4EE5A-69C2-4EDA-9D5D-8FA3055DA777", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                    Case 11
                        Dim DoctorID As Integer = -1
#If NewDesign Then
                        Dim sDoctorID As String = Trim(txtDoctorID.Value)
                        If sDoctorID <> "" Then
                            If IsNumeric(sDoctorID) Then
                                DoctorID = CInt(sDoctorID)
                            End If
                        End If

#End If
                        If Application("App_Type").ToString().ToUpper() = "SUPP" Then
                            If bPaging Then
                                ds = objReportsList.GetReportsList11TypeMushlamPaging("373597AB-64FC-4bb0-9099-A795A038D167", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, DoctorID, grdList.PageSize, grdList.CurrentPageIndex, strKoteret)
                            Else
                                ds = objReportsList.GetReportsList11TypeMushlam("BEB34FC7-0FCE-40DF-9546-DF903B284FFE", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, DoctorID, strKoteret)
                            End If

                            If ds.Tables(0).Rows.Count = MaxRecNo Then
                                iCountMore = objReportsList.GetReportsList11TypeMushlamCount("7020D5E2-E8E8-4BE2-BFDB-4D7844A2D81C", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, DoctorID, strKoteret)
                            End If
                        Else
                            If bPaging Then
                                ds = objReportsList.GetReportsList11TypePaging("2E11F64D-0F19-4c23-967F-464A0E8D9872", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, DoctorID, grdList.PageSize, grdList.CurrentPageIndex, strKoteret)
                            Else
                                ds = objReportsList.GetReportsList11Type("A201017E-2BC3-4376-A110-8B1B9183C2A2", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, DoctorID, strKoteret)
                            End If

                            If ds.Tables(0).Rows.Count = MaxRecNo Then
                                iCountMore = objReportsList.GetReportsList11TypeCount("17073C2D-6940-4F3B-B8CF-15D8949FCAC9", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, DoctorID, strKoteret)
                            End If
                        End If

                    Case 12
#If NewDesign And Not EngDesign Then
                        Dim sUserName As String = txtFromUserName.Value
                        Dim sName As String = ""
                        Dim sRepName As String = ""
                        Dim iRepNameID As String = lstRepName.SelectedItem.Value
                        If iRepNameID > 0 Then
                            sRepName = lstRepName.SelectedItem.Text
                        End If
                        GridColumnsForTechSupport()

                        FillStatusCodes()
                        If bPaging Then
                            ds = objReportsList.GetReportsListTechSupport("QG9C96B4-DB38-4780-AA37-CA714783D55A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, sUserName, sName, 0, grdList.PageSize, grdList.CurrentPageIndex, sRepName, hidStatusCodes.Value, txtLastUpdateUserName.Value, Val(txtSupplierID.Value))
                        Else
                            ds = objReportsList.GetReportsListTechSupport("QG9C96B4-DB38-4780-AA37-CA714783D55A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, sUserName, sName, 0, 999, 0, sRepName, hidStatusCodes.Value, txtLastUpdateUserName.Value, Val(txtSupplierID.Value))
                        End If

                        If ds.Tables(0).Rows.Count = MaxRecNo Then
                            iCountMore = objReportsList.GetReportsListTechSupportCount("QG9C96B4-DB38-4780-AA37-CA714783D55A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, sUserName, sName, 0, sRepName, hidStatusCodes.Value, txtLastUpdateUserName.Value, Val(txtSupplierID.Value))
                        End If

#End If
                    Case Else
                        Dim col As BoundColumn
#If NewDesign Then
#If EngDesign Then
                            col = CType(grdList.Columns(12), BoundColumn)
#Else
                        col = CType(grdList.Columns(13), BoundColumn)
#End If
#Else
                        col = CType(grdList.Columns(10), BoundColumn)
#End If
                        col.DataField = ""
                        If Session("Filter_InsuredID") <> "" Or Session("Filter_InsuredName") <> "" Then
                            If bPaging Then
                                ds = objReportsList.GetReportsListExtMushlamPaging("7740538A-9EF8-417F-B647-B56239A161A8", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, grdList.PageSize, grdList.CurrentPageIndex, strKoteret)
                            Else
                                ds = objReportsList.GetReportsListExtMushlam("B23B098A-BFEB-47E3-98FF-70C23D884F1A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                            End If

                            If ds.Tables(0).Rows.Count = MaxRecNo Then
                                iCountMore = objReportsList.GetReportsListExtMushlamCount("8B555A15-B7E6-4F81-87CB-51012E323695", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                            End If

                            Dim iCountMoreAdd As Integer = 0
                            dsAdd = objReportsList.GetReportsList11TypeMushlam("BEB34FC7-0FCE-40DF-9546-DF903B284FFE", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, -1, strKoteret)
                            If ds.Tables(0).Rows.Count = MaxRecNo Or iCountMore > 0 Then
                                iCountMoreAdd = objReportsList.GetReportsList11TypeMushlamCount("7020D5E2-E8E8-4BE2-BFDB-4D7844A2D81C", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, -1, strKoteret)
                                iCountMore = iCountMore + iCountMoreAdd
                            End If


                        Else
                            If iRepID > 0 Then
                                ds = objReportsList.GetReportListItem("D4D69A20-7F17-4DE0-824C-A416F67E06E8", strUserID, strSubUserID, iRepID)
                                bPaging = False
                            Else
                                If Application("App_Type").ToString.ToUpper = "CLAIM" Or Application("App_Type").ToString.ToUpper = "SUPP" Then
#If NewDesign And Not EngDesign Then
                                    If Application("HasCB") = "1" Then
                                        'ds = objReportsList.GetReportsList("7A9C96B4-DB38-4780-AA37-CA714783D55A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, "")
                                        ds = objReportsList.GetReportsListCB("EEF4EE5A-69C2-4EDA-9D5D-8FA3055DA777", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, "")

                                        'If ds.Tables(0).Rows.Count = MaxRecNo Then
                                        'iCountMore = objReportsList.GetReportsListCount("52EF9746-374B-404D-977F-0576E92AC4DF", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, "")
                                        'End If
                                    Else

                                        If bPaging Then
                                            ds = objReportsList.GetReportsListForPermitPaging("8D044BC1-991F-4983-93C5-C1579534E0CF", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, grdList.PageSize, grdList.CurrentPageIndex, strKoteret)
                                        Else
                                            ds = objReportsList.GetReportsListForPermit("7A9C96B4-DB38-4780-AA37-CA714783D55A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                                        End If

                                        If ds.Tables(0).Rows.Count = MaxRecNo Then
                                            iCountMore = objReportsList.GetReportsListForPermitCount("BBCCAD25-3A7B-4101-8DF1-B7A0C83440B3", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                                        End If
                                    End If
#Else
#If NewDesign Then
                                    If bPaging Then
                                        ds = objReportsList.GetReportsListForPermitPaging("8D044BC1-991F-4983-93C5-C1579534E0CF", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, grdList.PageSize, grdList.CurrentPageIndex, "")
                                    Else
                                        ds = objReportsList.GetReportsListForPermit("7A9C96B4-DB38-4780-AA37-CA714783D55A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, "")
                                    End If

                                    If ds.Tables(0).Rows.Count = MaxRecNo Then
                                        iCountMore = objReportsList.GetReportsListForPermitCount("BBCCAD25-3A7B-4101-8DF1-B7A0C83440B3", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, "")
                                    End If
#Else
                                    If bPaging Then
                                        ds = objReportsList.GetReportsListPaging("642BC9D6-70D6-436A-81DE-883CDC6E1295", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, grdList.PageSize, grdList.CurrentPageIndex, strKoteret)
                                    Else
                                        ds = objReportsList.GetReportsList("7A9C96B4-DB38-4780-AA37-CA714783D55A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                                    End If

                                    If ds.Tables(0).Rows.Count = MaxRecNo Then
                                        iCountMore = objReportsList.GetReportsListCount("52EF9746-374B-404D-977F-0576E92AC4DF", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                                    End If
#End If
#End If
                                Else
                                    If bPaging Then
                                        ds = objReportsList.GetReportsListPaging("642BC9D6-70D6-436A-81DE-883CDC6E1295", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, grdList.PageSize, grdList.CurrentPageIndex, strKoteret)
                                    Else
                                        ds = objReportsList.GetReportsList("7A9C96B4-DB38-4780-AA37-CA714783D55A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                                    End If

                                    If ds.Tables(0).Rows.Count = MaxRecNo Then
                                        iCountMore = objReportsList.GetReportsListCount("52EF9746-374B-404D-977F-0576E92AC4DF", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                                    End If
                                End If
                            End If
                        End If
                End Select
                'End If
            End If


#If Not NewDesign Then
            If Application("App_Type").ToString = "divur" Then
                Select Case iReportType
                    Case 11
                        grdList.Columns(0).Visible = False
                        grdList.Columns(1).Visible = False
                        grdList.Columns(4).Visible = False
                        grdList.Columns(6).Visible = False
                        grdList.Columns(7).Visible = False
                        grdList.Columns(8).Visible = False
                        grdList.Columns(9).Visible = False
                        grdList.Columns(10).Visible = False
                        grdList.Columns(11).Visible = False
                        grdList.Columns(12).Visible = False
                        grdList.Columns(13).Visible = False
                        grdList.Columns(14).Visible = False
                        grdList.Columns(15).Visible = False
                        grdList.Columns(18).Visible = False
                        grdList.Columns(19).Visible = False
                        grdList.Columns(20).Visible = False
                        grdList.Columns(21).Visible = False
                        grdList.Columns(22).Visible = False

                        'With dgForExcel
                        '    .Columns(0).Visible = False
                        '    .Columns(1).Visible = False
                        '    .Columns(3).Visible = False
                        '    .Columns(5).Visible = False
                        '    .Columns(6).Visible = False
                        '    .Columns(7).Visible = False
                        '    .Columns(8).Visible = False
                        '    .Columns(9).Visible = False
                        '    .Columns(10).Visible = False
                        '    .Columns(11).Visible = False
                        '    .Columns(12).Visible = False
                        '    .Columns(13).Visible = False
                        '    .Columns(14).Visible = False
                        '    .Columns(17).Visible = False
                        '    .Columns(18).Visible = False
                        '    .Columns(19).Visible = False
                        '    .Columns(20).Visible = False
                        '    .Columns(21).Visible = False
                        'End With
                    Case 41
                        grdList.Columns(0).Visible = False
                        grdList.Columns(1).Visible = False
                        grdList.Columns(4).Visible = False
                        grdList.Columns(6).Visible = False
                        grdList.Columns(9).Visible = False
                        grdList.Columns(10).Visible = False
                        grdList.Columns(11).Visible = False
                        grdList.Columns(12).Visible = False
                        grdList.Columns(14).Visible = False
                        grdList.Columns(15).Visible = False
                        grdList.Columns(18).Visible = False
                        grdList.Columns(19).Visible = False
                        grdList.Columns(20).Visible = False
                        grdList.Columns(21).Visible = False
                        grdList.Columns(22).Visible = False
                        'With dgForExcel
                        '    .Columns(0).Visible = False
                        '    .Columns(1).Visible = False
                        '    .Columns(3).Visible = False
                        '    .Columns(5).Visible = False
                        '    .Columns(8).Visible = False
                        '    .Columns(9).Visible = False
                        '    .Columns(10).Visible = False
                        '    .Columns(11).Visible = False
                        '    .Columns(13).Visible = False
                        '    .Columns(14).Visible = False
                        '    .Columns(17).Visible = False
                        '    .Columns(18).Visible = False
                        '    .Columns(19).Visible = False
                        '    .Columns(20).Visible = False
                        '    .Columns(21).Visible = False
                        'End With
                End Select

            End If
#End If
        End If

        txtAppType.Value = Application("App_Type").ToString

        Dim iCount As Integer = 0

        If bPaging Then
            If ds.Tables.Count > 0 AndAlso ds.Tables(0).Rows.Count > 0 Then
                iCount = Val(ds.Tables(0).Rows(0)("TotalRows").ToString())
            Else
                iCount = 0
            End If
            grdList.VirtualItemCount = iCount
        Else
            iCount = ds.Tables(0).Rows.Count
        End If

        Dim iPageCount As Integer = (iCount - 1) \ grdList.PageSize

#If NewDesign And Not EngDesign Then
        AddDataColumn(ds.Tables(0), "CareDate")

        If txtSortField.Value = "" Then
            If iTableType = 11 Then
                txtSortField.Value = "CareDate DESC"
                'ElseIf Application("App_Type").ToString.ToUpper = "SUPP" Then
                '    txtSortField.Value = "RepID DESC"
                'ElseIf hidIsTechSupport.Value = "1" Then
                '    txtSortField.Value = "RepID DESC"
            Else
                txtSortField.Value = "RepID DESC"
            End If
        End If

#If NewDesign And Not EngDesign Then
        Select Case iTableType
            Case 15
                GridColumnsTable15()
        End Select
#End If

        Dim dt As DataTable = ds.Tables(0)
        If Not dt.Columns.Contains("Status") Then
            dt.Columns.Add("Status")
        End If

        If Not dt.Columns.Contains("Remarks") Then
            dt.Columns.Add("Remarks")
        End If

        If Not dt.Columns.Contains("UpdateDate") Then
            dt.Columns.Add("UpdateDate")
        End If

        If Not dt.Columns.Contains("UpdateUserName") Then
            dt.Columns.Add("UpdateUserName")
        End If

        If Not dsAdd Is Nothing Then
            dt = UnionDistinct(dt, dsAdd.Tables(0), "RepID")
        End If

        If bPaging Then
            If ds.Tables.Count > 0 AndAlso ds.Tables(0).Rows.Count > 0 Then
                iCount = Val(ds.Tables(0).Rows(0)("TotalRows").ToString())
            Else
                iCount = 0
            End If

        Else
            iCount = dt.Rows.Count()
        End If

        iPageCount = (iCount - 1) \ grdList.PageSize

        Dim dv As DataView = New DataView()
        With dv
            .Table = dt
            .AllowDelete = False
            .AllowEdit = True
            .AllowNew = False
            .Sort = txtSortField.Value
        End With
        grdList.DataSource = dv
#Else
        grdList.DataSource = ds
#End If

        If iPageCount > -1 Then
            If grdList.CurrentPageIndex > iPageCount Then
                grdList.CurrentPageIndex = iPageCount
            End If
        Else
            grdList.CurrentPageIndex = 0
        End If

        'grdList.DataSource.Tables(0).Col

        grdList.DataBind()

        If Application("App_Type").ToString.ToUpper() = "SUPP" Or Application("App_Type").ToString.ToUpper = "DIVUR" Then
            Dim sCountMore As String
            If iCountMore > MaxRecNo Then
                sCountMore = "&nbsp;" & "��" & "&quot;" & "� " & iCountMore
                If chkFilter.Checked Then
                    sCountMore += " ����� ����� ����� ������  "
                End If
                tdResultRowCount.InnerHtml = "����� " & iCount & " �����" & "; " & sCountMore
            ElseIf iCount = 1 Then
                tdResultRowCount.InnerHtml = "����� ���� " & iCount
                If chkFilter.Checked Then
                    tdResultRowCount.InnerHtml += " ����� ����� ������ "
                End If
            Else
                tdResultRowCount.InnerHtml = "����� " & iCount & " ����� "
                If chkFilter.Checked Then
                    tdResultRowCount.InnerHtml += "  ������ ����� ������ "
                End If

            End If

            '  If iTableType = 11 Then
#If NewDesign And Not EngDesign Then


            If hidPrintActivity.Value = "1" Then

                FillArrayChecks(ds)

            End If
#End If

            ' End If

        End If


        If iPageCount > 0 Then

            grdList.PagerStyle.Visible = True
        Else
            grdList.PagerStyle.Visible = False
        End If

        If iCount = 0 And Not chkFilter.Checked Then
            chkFilter.Disabled = True
            chkFilter.Style.Remove("Cursor")
            chkFilter.Style.Add("Cursor", "default")

#If NewDesign And Not EngDesign Then
            ChkCalander.Disabled = True
            ChkCalander.Checked = False
            ChkCalander.Style.Remove("Cursor")
            ChkCalander.Style.Add("Cursor", "default")
#End If

        Else
            chkFilter.Disabled = False
            chkFilter.Style.Remove("Cursor")
            chkFilter.Style.Add("Cursor", "hand")

#If NewDesign And Not EngDesign Then
            ChkCalander.Disabled = False
            ChkCalander.Style.Remove("Cursor")
            ChkCalander.Style.Add("Cursor", "hand")
#End If
        End If

#If NewDesign And Not EngDesign Then
        If (ds.Tables.Count > 1) Then
            If (ds.Tables(1).Rows.Count > 0) Then

                Dim sReportPermissionForExcel As String = ds.Tables(1).Rows(0)("ReportPermissionForExcel").ToString()

                Dim sExcelExchangePermition As String = "0"
                If Not Session("Excel_Exchange_Permition") = Nothing Then
                    sExcelExchangePermition = Session("Excel_Exchange_Permition").ToString
                End If

                If sReportPermissionForExcel = "1" And sExcelExchangePermition = "1" Then

                    HidPermissionForExcel.Value = "1"


                Else
                    HidPermissionForExcel.Value = "0"

                End If
            Else
                HidPermissionForExcel.Value = "0"
            End If
        Else
            HidPermissionForExcel.Value = "0"
        End If
#End If

    End Sub

    Private Sub BindGridNew()
        Dim objReportsList As New ReportConnect.ReportService()
        objReportsList.Url = Application("ReportWebService").ToString()
        Dim iReportType As Integer
        Dim strFromDate As String
        Dim strToDate As String
        Dim bViewed As Boolean
        Dim bNotViewed As Boolean
        Dim strInsuredID As String, strName As String
        Dim iTableType As Integer

        Dim dsAdd As DataSet
        Dim iCountMore As Integer = 0
        Dim MaxRecNo As Integer = 200
        Dim bPaging As Boolean = IIf(Application("Paging") = "1", True, False)
        Dim strKoteret As String
        Dim iRepID As Integer = 0

        If IsNumeric(Session("Report_List_ReportType")) Then
            iReportType = CInt(Session("Report_List_ReportType"))
            iTableType = Val(txtTableType.Value)
        Else
            iReportType = 0
            iTableType = 0
        End If
        If chkFilter.Checked Then
            If IsNumeric(Session("Filter_Report_ID")) Then
                iRepID = CInt(Session("Filter_Report_ID"))
            End If
            strFromDate = Trim(txtDateFrom.Value)
            strToDate = Trim(txtDateTo.Value)
            bViewed = chkViewed.Checked
            bNotViewed = chkNotViewed.Checked
#If Not NewDesign Then
            If Application("SearchByRepName").ToString = "1" Then
                strKoteret = Me.txtKoteret.Value
            End If
#End If
            ' ''If iTableType > 0 Then
            ' ''    strInsuredID = txtInshuredID.Value
            ' ''    strName = txtName.Value
            ' ''Else
            ' ''    If Application("App_Type").ToString = "supp" Then
            ' ''        strInsuredID = Session("Filter_InsuredID")
            ' ''        strName = Session("Filter_InsuredName")
            ' ''    Else
            ' ''        strInsuredID = ""
            ' ''        strName = ""
            ' ''    End If
            ' ''End If
            strInsuredID = txtInshuredID.Value
            strName = txtName.Value
        Else

#If NewDesign And Not EngDesign Then
            If Me.txtDateForCal.Value <> "" And _
               Me.txtDateForCal.Value <> "NULL" And _
               Me.ChkCalander.Checked Then
                strFromDate = Me.txtDateForCal.Value
                Me.Uc_Jcalander1.LastChoiceMonth = strFromDate
                strToDate = strFromDate
                ''''Me.txtDateForCal.Value = ""
            Else
                strFromDate = "00000000"
                strToDate = "00000000"
            End If
#Else
            strFromDate = "00000000"
            strToDate = "00000000"
#End If

            bViewed = True
            bNotViewed = True
            strInsuredID = ""
            strName = ""
        End If

        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim strUserID As String = objUser.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", User.Identity.Name)
        Dim ds As DataSet


        Dim strSubUserID As String = lstUsers.SelectedItem.Value


#If NewDesign And Not EngDesign Then
            Uc_Jcalander1.SubUserId = lstUsers.SelectedItem.Value
#End If



        If Application("App_Type").ToString().ToLower() = "divur" Then
            If iTableType = 2 Then
                If bPaging Then
                    ds = objReportsList.GetReportsListExtPaging("9E265C99-FC7E-45BA-B758-DB4711CBA5B8", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, grdListNew.PageSize, grdListNew.CurrentPageIndex, strKoteret)
                Else
                    ds = objReportsList.GetReportsListExt("B23B098A-BFEB-47E3-98FF-70C23D884F1A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                End If

                If ds.Tables(0).Rows.Count = MaxRecNo Then
                    iCountMore = objReportsList.GetReportsListExtCount("90ED5175-FD86-40B9-8FDD-E8483BCEA6B9", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                End If
            ElseIf iTableType = 11 Then
                If bPaging Then
                    ds = objReportsList.GetReportsList11TypePaging("2E11F64D-0F19-4C23-967F-464A0E8D9872", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, -1, grdListNew.PageSize, grdListNew.CurrentPageIndex, strKoteret)
                Else
                    ds = objReportsList.GetReportsList11Type("A201017E-2BC3-4376-A110-8B1B9183C2A2", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, -1, strKoteret)
                End If

                If ds.Tables(0).Rows.Count = MaxRecNo Then
                    iCountMore = objReportsList.GetReportsList11TypeCount("17073C2D-6940-4F3B-B8CF-15D8949FCAC9", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, -1, strKoteret)
                End If
            Else
                If bPaging Then
                    ds = objReportsList.GetReportsListPaging("642BC9D6-70D6-436A-81DE-883CDC6E1295", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, grdListNew.PageSize, grdListNew.CurrentPageIndex, strKoteret)
                Else
                    ds = objReportsList.GetReportsList("7A9C96B4-DB38-4780-AA37-CA714783D55A", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                End If

                If ds.Tables(0).Rows.Count = MaxRecNo Then
                    iCountMore = objReportsList.GetReportsListCount("52EF9746-374B-404D-977F-0576E92AC4DF", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName, strKoteret)
                End If
            End If
        End If

        txtAppType.Value = Application("App_Type").ToString

        Dim iCount As Integer = 0

        If bPaging Then
            If ds.Tables.Count > 0 AndAlso ds.Tables(0).Rows.Count > 0 Then
                iCount = Val(ds.Tables(0).Rows(0)("TotalRows").ToString())
            Else
                iCount = 0
            End If
            grdListNew.VirtualItemCount = iCount
        Else
            iCount = ds.Tables(0).Rows.Count
        End If

        Dim iPageCount As Integer = (iCount - 1) \ grdListNew.PageSize

#If NewDesign And Not EngDesign Then
        AddDataColumn(ds.Tables(0), "CareDate")

        If txtSortField.Value = "" Then
            If iTableType = 11 Then
                txtSortField.Value = "CareDate DESC"
                'ElseIf Application("App_Type").ToString.ToUpper = "SUPP" Then
                '    txtSortField.Value = "RepID DESC"
                'ElseIf hidIsTechSupport.Value = "1" Then
                '    txtSortField.Value = "RepID DESC"
            Else
                txtSortField.Value = "RepID DESC"
            End If
        End If
#End If

        If Not ds.Tables(0).Columns.Contains("FinishDate") Then
            ds.Tables(0).Columns.Add("FinishDate")
        End If

        If Not ds.Tables(0).Columns.Contains("GrossAmount") Then
            ds.Tables(0).Columns.Add("GrossAmount")
        End If
        If Not ds.Tables(0).Columns.Contains("ToTooth") Then
            ds.Tables(0).Columns.Add("ToTooth")
        End If
        If Not ds.Tables(0).Columns.Contains("FTooth") Then
            ds.Tables(0).Columns.Add("FTooth")
        End If
        If Not ds.Tables(0).Columns.Contains("TreatmentDesc") Then
            ds.Tables(0).Columns.Add("TreatmentDesc")
        End If
        If Not ds.Tables(0).Columns.Contains("Treatment") Then
            ds.Tables(0).Columns.Add("Treatment")
        End If

        grdListNew.DataSource = ds

        If iPageCount > -1 Then
            If grdListNew.CurrentPageIndex > iPageCount Then
                grdListNew.CurrentPageIndex = iPageCount
            End If
        Else
            grdListNew.CurrentPageIndex = 0
        End If

        'grdList.DataSource.Tables(0).Col

        grdListNew.DataBind()

        If Application("App_Type").ToString.ToUpper = "DIVUR" Then
            Dim sCountMore As String
            If iCountMore > MaxRecNo Then
                sCountMore = "&nbsp;" & "��" & "&quot;" & "� " & iCountMore
                If chkFilter.Checked Then
                    sCountMore += " ����� ����� ����� ������  "
                End If
                tdResultRowCount.InnerHtml = "����� " & iCount & " �����" & "; " & sCountMore
            ElseIf iCount = 1 Then
                tdResultRowCount.InnerHtml = "����� ���� " & iCount
                If chkFilter.Checked Then
                    tdResultRowCount.InnerHtml += " ����� ����� ������ "
                End If
            Else
                tdResultRowCount.InnerHtml = "����� " & iCount & " ����� "
                If chkFilter.Checked Then
                    tdResultRowCount.InnerHtml += "  ������ ����� ������ "
                End If

            End If

            '  If iTableType = 11 Then
#If NewDesign And Not EngDesign Then


            If hidPrintActivity.Value = "1" Then

                FillArrayChecks(ds)

            End If
#End If

            ' End If

        End If


        If iPageCount > 0 Then

            grdListNew.PagerStyle.Visible = True
        Else
            grdListNew.PagerStyle.Visible = False
        End If

        If iCount = 0 And Not chkFilter.Checked Then
            chkFilter.Disabled = True
            chkFilter.Style.Remove("Cursor")
            chkFilter.Style.Add("Cursor", "default")

#If NewDesign And Not EngDesign Then
            ChkCalander.Disabled = True
            ChkCalander.Checked = False
            ChkCalander.Style.Remove("Cursor")
            ChkCalander.Style.Add("Cursor", "default")
#End If

        Else
            chkFilter.Disabled = False
            chkFilter.Style.Remove("Cursor")
            chkFilter.Style.Add("Cursor", "hand")

#If NewDesign And Not EngDesign Then
            ChkCalander.Disabled = False
            ChkCalander.Style.Remove("Cursor")
            ChkCalander.Style.Add("Cursor", "hand")
#End If
        End If

#If NewDesign And Not EngDesign Then
        If (ds.Tables.Count > 1) Then
            If (ds.Tables(1).Rows.Count > 0) Then

                Dim sReportPermissionForExcel As String = ds.Tables(1).Rows(0)("ReportPermissionForExcel").ToString()

                Dim sExcelExchangePermition As String = "0"
                If Not Session("Excel_Exchange_Permition") = Nothing Then
                    sExcelExchangePermition = Session("Excel_Exchange_Permition").ToString
                End If

                If sReportPermissionForExcel = "1" And sExcelExchangePermition = "1" Then

                    HidPermissionForExcel.Value = "1"


                Else
                    HidPermissionForExcel.Value = "0"

                End If
            Else
                HidPermissionForExcel.Value = "0"
            End If
        Else
            HidPermissionForExcel.Value = "0"
        End If
#End If

    End Sub


    Private Sub BindGridOccasional()
        Dim objReportsList As New ReportConnect.ReportService()
        objReportsList.Url = Application("ReportWebService").ToString()
        Dim iReportType As Integer
        Dim strFromDate As String
        Dim strToDate As String
        Dim bViewed As Boolean
        Dim bNotViewed As Boolean
        Dim strInsuredID As String, strName As String
        Dim strPhone As String, strMail As String
        Dim iTableType As Integer

        Dim dsAdd As DataSet
        Dim iCountMore As Integer = 0
        Dim MaxRecNo As Integer = 200
        Dim bPaging As Boolean = IIf(Application("Paging") = "1", True, False)
        Dim strKoteret As String


        If IsNumeric(Session("Report_List_ReportType")) Then
            iReportType = CInt(Session("Report_List_ReportType"))
            iTableType = CInt(txtTableType.Value)
        Else
            iReportType = 0
            iTableType = 0
        End If
        If chkFilter.Checked Then
#If NewDesign And Not EngDesign Then
            strFromDate = Trim(txtDateFromOccasional.Value)
            strToDate = Trim(txtDateToOccasional.Value)
            bViewed = chkViewedOccasional.Checked
            bNotViewed = chkNotViewedOccasional.Checked
#End If
            strInsuredID = txtOccasionalID.Value
            strName = txtFNameOccasional.Value.Trim & " " & txtLNameOccasional.Value.Trim
            strPhone = txtPhoneOccasional.Value
            strMail = txtMailOccasional.Value


        Else

#If NewDesign And Not EngDesign Then
            If Me.txtDateForCal.Value <> "" And _
               Me.txtDateForCal.Value <> "NULL" And _
               Me.ChkCalander.Checked Then
                strFromDate = Me.txtDateForCal.Value
                Me.Uc_Jcalander1.LastChoiceMonth = strFromDate
                strToDate = strFromDate
                ''''Me.txtDateForCal.Value = ""
            Else
                strFromDate = "00000000"
                strToDate = "00000000"
            End If
#Else
            strFromDate = "00000000"
            strToDate = "00000000"
#End If

            bViewed = True
            bNotViewed = True
            strInsuredID = ""
            strName = ""
            strPhone = ""
            strMail = ""
        End If
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim strUserID As String = objUser.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", User.Identity.Name)
        Dim ds As DataSet
        Dim strSubUserID As String = lstUsers.SelectedItem.Value

        ds = objReportsList.GetReportsListOccasionalPaging("B6279A79-BBEF-4791-9AFB-0E716FC3F156", strUserID, strSubUserID, iReportType, strFromDate, strToDate, bViewed, bNotViewed, strInsuredID, strName.Trim, strPhone, strMail, gridOccasional.PageSize, gridOccasional.CurrentPageIndex, strKoteret)


        txtAppType.Value = Application("App_Type").ToString

        Dim iCount As Integer = 0

        If bPaging Then
            If ds.Tables.Count > 0 AndAlso ds.Tables(0).Rows.Count > 0 Then
                iCount = Val(ds.Tables(0).Rows(0)("TotalRows").ToString())
            Else
                iCount = 0
            End If
            gridOccasional.VirtualItemCount = iCount
        Else
            iCount = ds.Tables(0).Rows.Count
        End If

        Dim iPageCount As Integer = (iCount - 1) \ gridOccasional.PageSize

        If bPaging Then
            If ds.Tables.Count > 0 AndAlso ds.Tables(0).Rows.Count > 0 Then
                iCount = Val(ds.Tables(0).Rows(0)("TotalRows").ToString())
            Else
                iCount = 0
            End If

        Else
            iCount = ds.Tables(0).Rows.Count
        End If

        iPageCount = (iCount - 1) \ gridOccasional.PageSize

        gridOccasional.DataSource = ds


        If iPageCount > -1 Then
            If gridOccasional.CurrentPageIndex > iPageCount Then
                gridOccasional.CurrentPageIndex = iPageCount
            End If
        Else
            gridOccasional.CurrentPageIndex = 0
        End If

        'gridOccasional.DataSource.Tables(0).Col

        gridOccasional.DataBind()

        If Application("App_Type").ToString.ToUpper() = "SUPP" Or Application("App_Type").ToString.ToUpper = "DIVUR" Then
            Dim sCountMore As String
            If iCountMore > MaxRecNo Then
                sCountMore = "&nbsp;" & "��" & "&quot;" & "� " & iCountMore
                If chkFilter.Checked Then
                    sCountMore += " ����� ����� ����� ������  "
                End If
                tdResultRowCount.InnerHtml = "����� " & iCount & " �����" & "; " & sCountMore
            ElseIf iCount = 1 Then
                tdResultRowCount.InnerHtml = "����� ���� " & iCount
                If chkFilter.Checked Then
                    tdResultRowCount.InnerHtml += " ����� ����� ������ "
                End If
            Else
                tdResultRowCount.InnerHtml = "����� " & iCount & " ����� "
                If chkFilter.Checked Then
                    tdResultRowCount.InnerHtml += "  ������ ����� ������ "
                End If

            End If

            '  If iTableType = 11 Then
#If NewDesign And Not EngDesign Then


            If hidPrintActivity.Value = "1" Then

                FillArrayChecks(ds)

            End If
#End If

            ' End If

        End If


        If iPageCount > 0 Then

            gridOccasional.PagerStyle.Visible = True
        Else
            gridOccasional.PagerStyle.Visible = False
        End If

        If iCount = 0 And Not chkFilter.Checked Then
            chkFilter.Disabled = True
            chkFilter.Style.Remove("Cursor")
            chkFilter.Style.Add("Cursor", "default")

#If NewDesign And Not EngDesign Then
            ChkCalander.Disabled = True
            ChkCalander.Checked = False
            ChkCalander.Style.Remove("Cursor")
            ChkCalander.Style.Add("Cursor", "default")
#End If

        Else
            chkFilter.Disabled = False
            chkFilter.Style.Remove("Cursor")
            chkFilter.Style.Add("Cursor", "hand")

#If NewDesign And Not EngDesign Then
            ChkCalander.Disabled = False
            ChkCalander.Style.Remove("Cursor")
            ChkCalander.Style.Add("Cursor", "hand")
#End If
        End If

#If NewDesign And Not EngDesign Then
        If (ds.Tables.Count > 1) Then
            If (ds.Tables(1).Rows.Count > 0) Then

                Dim sReportPermissionForExcel As String = ds.Tables(1).Rows(0)("ReportPermissionForExcel").ToString()

                Dim sExcelExchangePermition As String = "0"
                If Not Session("Excel_Exchange_Permition") = Nothing Then
                    sExcelExchangePermition = Session("Excel_Exchange_Permition").ToString
                End If

                If sReportPermissionForExcel = "1" And sExcelExchangePermition = "1" Then

                    HidPermissionForExcel.Value = "1"


                Else
                    HidPermissionForExcel.Value = "0"

                End If
            Else
                HidPermissionForExcel.Value = "0"
            End If
        Else
            HidPermissionForExcel.Value = "0"
        End If
#End If

    End Sub

    Sub FillArrayChecks(ByVal ds As DataSet)


        Dim dr As DataRow
        Dim i As Integer = 0
        Dim k As Integer


        'If hidArrayChks.Value = "" Then

        If Not IsPostBack Or filterFlag = True Then

            For Each dr In ds.Tables(0).Rows
                If i < arrChksSize Then
                    arrChksValues(i) = dr("RepID").ToString() + ";" + "1"
                End If
                i = i + 1
            Next
            If i < arrChksSize Then
                For k = i To arrChksSize - 1
                    arrChksValues(k) = "0"
                Next
            End If
#If NewDesign Then

            For k = 0 To arrChksValues.Length - 1
                If k = 0 Then
                    hidArrayChks.Value = arrChksValues(k)
                Else
                    hidArrayChks.Value = hidArrayChks.Value + "," + arrChksValues(k)

                End If

            Next
#End If

        End If

        filterFlag = False

        ' End If


    End Sub

    Private Sub BindUsers()
        Dim strCurrentUser As String = Session("Report_List_Current_User")
        Dim strUserID As String
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        If Len(strCurrentUser) > 0 Then
            strUserID = strCurrentUser
        Else
            strUserID = objUser.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", User.Identity.Name)
        End If

        Dim ds As Data.DataSet = objUser.GetSubUsers("6A2B8CB2-B464-4C16-A415-933DABD1FD10", User.Identity.Name)
        If String.Compare(Application("App_Type").ToString, "doar", True) = 0 Then
            lstUsers.Items.Add(New ListItem("����", "0"))
            Dim currRow As DataRow
            Dim txtValue As String, User1stLetter As String
            Dim oRegEx As Regex
            For Each currRow In ds.Tables(0).Rows
                If oRegEx.IsMatch(Trim(currRow("FullName").ToString()), "^[a-z]", RegexOptions.IgnoreCase) _
                  Or oRegEx.IsMatch(Trim(currRow("FullName").ToString()), "[a-z]$", RegexOptions.IgnoreCase) Then
                    txtValue = String.Concat(currRow("UserName").ToString(), " ) ", currRow("FullName").ToString(), " ) ")
                Else
                    txtValue = String.Concat(currRow("FullName").ToString(), " ( ", currRow("UserName").ToString(), " ) ")
                End If
                lstUsers.Items.Add(New ListItem(txtValue, currRow("SysUserID").ToString()))
            Next
        Else 'for all others
            lstUsers.DataTextField = "FullName"
            lstUsers.DataValueField = "SysUserID"
            lstUsers.DataSource = ds
            lstUsers.DataBind()
        End If

        Dim li As ListItem = lstUsers.Items.FindByValue(strUserID)
        If Not li Is Nothing Then
            li.Selected = True
        Else
            Try
                li = lstUsers.Items(0)
                li.Selected = True
            Catch ex As Exception
            End Try
        End If
		
        If Not li Is Nothing Then
            Dim strSelectedUserID As String = li.Value
            Dim stBoUserID As String = ""

            If strSelectedUserID <> "0" Then
                stBoUserID = objUser.GetBOUserID("EA533B72-A5A0-453E-94C9-FE210305AFA6", strSelectedUserID)
            End If

            If Len(stBoUserID) > 0 Then
                lblBOUserID.ForeColor = Color.Black
#If EngDesign Then
                lblBOUserID.Text = "Back Office User ID: " & stBoUserID
#Else
                lblBOUserID.Text = " ����� ����� ������ �������: " & stBoUserID
#End If
            Else
                lblBOUserID.ForeColor = Color.Black
#If EngDesign Then
                lblBOUserID.Text = "(Local User)"
#Else
                lblBOUserID.Text = "(����� �����)"
#End If
            End If
        End If
#If Not NewDesign And Not EngDesign Then
		If LCase(Application("App_Type").ToString) = "divur" Then
			If lstUsers.Items.Count < 2 Then
				tdUsers.Style("display") = "none"
				trTitleRow1.Style("display") = "none"
                trTitleRow2.Style("display") = "block"
			End If
		End If
#End If

        Session("SubUserID") = lstUsers.SelectedItem.Value

    End Sub

    Private Function XSSCheck(ByVal regExpr As String, ByVal inputValue As String) As Boolean
        Dim result As Boolean = True
        If InStr(1, inputValue, "--") > 0 Then
            Return False
        End If
        If Trim(regExpr) <> "" And Trim(inputValue) <> "" Then
            result = System.Text.RegularExpressions.Regex.IsMatch(inputValue, regExpr)
        End If
        Return result
    End Function

    Private Function CrossCheck() As Boolean
        Dim regExpr As String = Application("RegExpr")
        Dim element As String

        Dim intElement As Integer
        Dim strKey As String
        Dim flag As Boolean = True

        For Each element In Request.Form

            If Left(element, 2) <> "__" Then
                If Not XSSCheck(regExpr, Request.Form(element)) Then
                    flag = False
                    Return flag
                End If
            End If

        Next

        For Each element In Request.QueryString

            If Left(element, 2) <> "__" Then

                If Not XSSCheck(regExpr, Request.QueryString(element)) Then
                    flag = False
                    Return flag
                End If

            End If

        Next
        Return flag
    End Function

    Private Sub lstUsers_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstUsers.SelectedIndexChanged
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim strUserID As String = lstUsers.SelectedItem.Value
        Session("Report_List_Current_User") = strUserID
        If strUserID = "0" Then
            lblBOUserID.Text = ""
            lblClinic.Text = ""
        Else
            Dim stBoUserID As String = objUser.GetBOUserID("EA533B72-A5A0-453E-94C9-FE210305AFA6", strUserID)
            If Len(stBoUserID) > 0 Then
                lblBOUserID.ForeColor = Color.Black
#If EngDesign Then
                lblBOUserID.Text = " Back Office User ID: " & stBoUserID
#Else
                lblBOUserID.Text = " ����� ����� ������ �������: " & stBoUserID
#End If
            Else
                lblBOUserID.ForeColor = Color.Black
#If EngDesign Then
                lblBOUserID.Text = "(Local User)"
#Else
                lblBOUserID.Text = "(����� �����)"
#End If
            End If
        End If


#If Not EngDesign Then
        Dim strClinicId As String
        Dim strClinicName As String
        'Dim strCrntUser As String = Session("CrntUser").ToString()
        'If strCrntUser = "" Then
        '    strCrntUser = User.Identity.Name
        'End If

        Dim strCrntUser = objUser.GetUserNameByID("C5C4C694-E524-41D3-8ECD-38CE8434FE4B", Val(lstUsers.SelectedItem.Value))
        Session("CrntUser") = strCrntUser
        objUser.GetClinicAndDoctor("F2D2C32E-6BA0-42C0-BD3C-1E16726B709D", strCrntUser, strClinicId, strClinicName)
        '''''''''''''''''''''''''''''''objUser.GetHDClinicIdAndClinicName("BE25C36A-51E8-11E4-B3E7-C79B1D5D46B0", strCrntUser, strClinicId, strClinicName)


#If NewDesign Then
        If strClinicId <> "" Then
            If strClinicId <> "" Then
                txtClinicID.Value = strClinicId
            Else
                txtClinicID.Value = "0"
            End If
        Else
            txtClinicID.Value = "0"
        End If

        If hidIsTechSupport.Value = "1" Then
            chkFilter.Checked = False
            lstRepName.SelectedIndex = 0
            txtFromUserName.Value = ""
            txtLastUpdateUserName.Value = ""
            txtSupplierID.Value = ""
            ClearStatusCodes()
        End If
#Else
        lblClinic.Text = strClinicName
#If Not EngDesign Then
        tdTitleClinic2.InnerText = strClinicName
#End If
#End If




#End If

        If LCase(Application("App_Type").ToString) = "divur" Then
            grdListNew.CurrentPageIndex = 0
        Else
            If Val(txtTableType.Value) <> 13 Then
                grdList.CurrentPageIndex = 0
            Else
                gridOccasional.CurrentPageIndex = 0
            End If

        End If

        Session("SubUserID") = lstUsers.SelectedItem.Value

        BindGrid()
    End Sub

    Private Sub grdList_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdList.ItemDataBound
        Dim dgItem As DataGridItem = e.Item
        Dim htmCtrl As System.Web.UI.HtmlControls.HtmlGenericControl
        Dim htmCtrlChk As System.Web.UI.HtmlControls.HtmlInputCheckBox
        Dim CtrlAtt As String, tmp1 As String, strRepSrc As String, strReference As String, strBundle As String
        Dim tblCell As TableCell
        Dim index As Integer
        Dim BundleDisplayOriginal As String = String.Empty
        Dim RepIDSupportRequests As String = String.Empty

        Select Case (dgItem.ItemType)
            Case ListItemType.Item, ListItemType.AlternatingItem

                If txtTableType.Value = "14" Then
                    Dim spanSourceRepID As HtmlGenericControl = DirectCast(dgItem.FindControl("spanSourceRepID"), HtmlGenericControl)
                    If Not IsDBNull(dgItem.DataItem("RepIDSupportRequests")) Then
                        RepIDSupportRequests = dgItem.DataItem("RepIDSupportRequests").ToString()
                        spanSourceRepID.InnerText = RepIDSupportRequests
                    End If
                    If Not IsDBNull(dgItem.DataItem("BundleDisplayOriginal")) Then
                        BundleDisplayOriginal = dgItem.DataItem("BundleDisplayOriginal").ToString()
                    End If
                    If Not IsDBNull(dgItem.DataItem("RepIDOriginal")) Then
                        spanSourceRepID.Attributes.Add("onclick", "ShowReport('0','" + dgItem.DataItem("RepIDOriginal").ToString() + "','" + RepIDSupportRequests + "','" + BundleDisplayOriginal + "');")
                    End If
                End If

                tblCell = dgItem.Cells(0)
                Dim l As Label = tblCell.FindControl("lblSign")
                tmp1 = l.ClientID
                htmCtrlChk = tblCell.FindControl("chkIfPrint")

                tblCell = dgItem.Cells(1)
                htmCtrl = tblCell.FindControl("keyvalue")
                CtrlAtt = htmCtrl.Attributes("key")
                strRepSrc = htmCtrl.Attributes("repsrc")
                strReference = htmCtrl.Attributes("ref1")
                strBundle = htmCtrl.Attributes("bundle")

                Try
                    If Application("Paging").ToString = "1" Then
                        index = dgItem.ItemIndex()
                    Else
                        index = grdList.PageSize * grdList.CurrentPageIndex + dgItem.ItemIndex()
                    End If
                Catch ex As Exception
                    index = grdList.PageSize * grdList.CurrentPageIndex + dgItem.ItemIndex()
                End Try

                ' Msh 10/07
                'dgItem.Attributes.Add("onclick", "SelectMe('" + CtrlAtt + "','" + strRepSrc + "', this, '" + tmp1 + "');")

                Dim bIsTechSupport As Boolean = False

#If NewDesign And Not EngDesign Then
                If hidIsTechSupport.Value = "1" Then
                    bIsTechSupport = True
                End If
#End If

                If Application("Paging").ToString = "1" Then
                    index = dgItem.ItemIndex()
                Else
                    index = grdList.PageSize * grdList.CurrentPageIndex + dgItem.ItemIndex()
                End If

                tblCell = dgItem.Cells(11)
#If NewDesign And Not EngDesign Then
                Dim dv As DataView = grdList.DataSource
#End If
                Dim strRepID As String = "", strRepIDOrg As String = "", strUpdatedByUser As String = ""


                dgItem.Attributes.Add("onclick", "SelectMe('" + CtrlAtt + "','" + strRepSrc + "', this, '" + tmp1 + "'" + ",'" + strReference + "','" + strBundle + "'" + ");")
                If LCase(Application("App_Type").ToString) = "doar" Then
                    If lstUsers.SelectedItem.Value <> "0" Then
                        dgItem.Attributes.Add("ondblclick", "ShowReport('0');")
                    End If
                ElseIf bIsTechSupport Then
#If NewDesign And Not EngDesign Then

                    Try
                        strRepID = dv.Table.Rows(index)("RepID").ToString()
                        strRepIDOrg = dv.Table.Rows(index)("RepIDOrg").ToString()
                    Catch ex As Exception
                        strRepID = ""
                        strRepIDOrg = ""
                    End Try
                    If strRepID <> "" And strRepIDOrg <> "" And strRepID <> strRepIDOrg Then
                        '''''''''''''''''''''''hidIsTechSupport.Value = "0"
                        dgItem.Attributes.Add("ondblclick", "ShowReport('0');")
                    Else
                        dgItem.Attributes.Add("ondblclick", "document.all.cmdReportProp.click();")
                    End If

                    strUpdatedByUser = dv.Table.Rows(index)("UpdatedByUser").ToString()
                    Dim tblCell1 As TableCell

                    If strUpdatedByUser = "1" Then
                        tblCell1 = dgItem.Cells(20)
                        tblCell1.Style.Add("font-weight", "bold")
                    End If
#End If
                Else

                    If Me.txtReportType.Value = "600" Then

                        Dim iRepIDSupportRequests As Integer

                        If (dgItem.DataItem("RepIDSupportRequests") Is Nothing Or _
                            dgItem.DataItem("RepIDSupportRequests") Is System.DBNull.Value) Then

                            iRepIDSupportRequests = igRepIDSupportRequests
                        Else
                            iRepIDSupportRequests = Convert.ToInt32(dgItem.DataItem("RepIDSupportRequests"))
                            igRepIDSupportRequests = iRepIDSupportRequests
                        End If

                        dgItem.Attributes.Add("ondblclick", "ShowReport('0','-1'," + _
                                              iRepIDSupportRequests.ToString() + ");")
                    Else
                        dgItem.Attributes.Add("ondblclick", "ShowReport('0');")
                    End If
                End If
#If NewDesign And Not EngDesign Then
                dgItem.Attributes.Add("onmouseover", "rowMouseOver(this);")
                tblCell = dgItem.Cells(dgItem.Cells.Count - 1)
				tblCell.Attributes.Add("title", "��� ��� ������ ���� �����")

                With dv.Table.Rows(index)
                    If txtTableType.Value = "11" Then
                        If .Item("ClaimNumber") = 0 Then
                            tblCell.Text = CheckReason(.Item("Reference"))
                        End If
                    End If

                End With


                If hidPrintActivity.Value = "1" Then

                    'index = grdList.PageSize * grdList.CurrentPageIndex + dgItem.ItemIndex()
                    htmCtrlChk.Attributes.Item("rowID") = index

                    Dim j As Integer

                    If hidArrayChks.Value <> "" Then

                        arrChksValues = hidArrayChks.Value.Split(",")

                        If htmCtrlChk.Attributes.Item("print") = "true" Then

                            j = htmCtrlChk.Attributes.Item("rowID")
                            If j < arrChksSize Then

                                arrChksValues(j) = htmCtrlChk.Attributes.Item("repID") + ";" + "1"

                            End If

                        End If

                    End If

                End If

                With dv.Table.Rows(index)
                    Try
                        If IsDBNull(.Item("ViewDate")) Then
                            dgItem.Style.Add("font-weight", "bold")
                        End If
                    Catch ex As Exception

                    End Try
                End With
#End If
        End Select
    End Sub

    Private Sub grdListNew_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdListNew.ItemDataBound
        Dim dgItem As DataGridItem = e.Item
        Dim htmCtrl As System.Web.UI.HtmlControls.HtmlGenericControl
        Dim htmCtrlChk As System.Web.UI.HtmlControls.HtmlInputCheckBox
        Dim CtrlAtt As String, tmp1 As String, strRepSrc As String, strReference As String, strBundle As String
        Dim tblCell As TableCell
        Dim index As Integer
        Dim BundleDisplayOriginal As String = String.Empty
        Dim RepIDSupportRequests As String = String.Empty

        Select Case (dgItem.ItemType)
            Case ListItemType.Item, ListItemType.AlternatingItem



                tblCell = dgItem.Cells(0)
                Dim l As Label = tblCell.FindControl("lblSign")
                tmp1 = l.ClientID
                htmCtrlChk = tblCell.FindControl("chkIfPrint")

                tblCell = dgItem.Cells(1)
                htmCtrl = tblCell.FindControl("keyvalue")
                CtrlAtt = htmCtrl.Attributes("key")
                strRepSrc = htmCtrl.Attributes("repsrc")
                strReference = htmCtrl.Attributes("ref1")
                strBundle = htmCtrl.Attributes("bundle")

                If (Application("GovernmentTreatments").ToString() = "1") Then
                    If dgItem.Cells(col_grdList_Treatment).Visible = True And Not IsDBNull(dgItem.DataItem("GovTreatment")) AndAlso dgItem.DataItem("GovTreatment") <> String.Empty Then
                        dgItem.Cells(col_grdList_Treatment).Text = dgItem.DataItem("GovTreatment")
                    End If
                    If dgItem.Cells(col_grdList_TreatmentDesc).Visible = True And Not IsDBNull(dgItem.DataItem("GovTreatmentDesc")) AndAlso dgItem.DataItem("GovTreatmentDesc") <> String.Empty Then
                        dgItem.Cells(col_grdList_TreatmentDesc).Text = dgItem.DataItem("GovTreatmentDesc")
                    End If
                End If

                Try
                    If Application("Paging").ToString = "1" Then
                        index = dgItem.ItemIndex()
                    Else
                        index = grdList.PageSize * grdList.CurrentPageIndex + dgItem.ItemIndex()
                    End If
                Catch ex As Exception
                    index = grdList.PageSize * grdList.CurrentPageIndex + dgItem.ItemIndex()
                End Try


                Dim bIsTechSupport As Boolean = False

#If NewDesign And Not EngDesign Then
                If hidIsTechSupport.Value = "1" Then
                    bIsTechSupport = True
                End If
#End If

                If Application("Paging").ToString = "1" Then
                    index = dgItem.ItemIndex()
                Else
                    index = grdList.PageSize * grdList.CurrentPageIndex + dgItem.ItemIndex()
                End If

                Dim strRepID As String = "", strRepIDOrg As String = "", strUpdatedByUser As String = ""

                Dim sInsuredID As String = "0"
                If Not e.Item.DataItem("InsuredID") Is Nothing Then
                    If Not e.Item.DataItem("InsuredID") Is System.DBNull.Value Then
                        sInsuredID = e.Item.DataItem("InsuredID")
                    End If
                End If

                Dim sValidDate As String = ""
                If Not e.Item.DataItem("ValidDate") Is Nothing Then
                    If Not e.Item.DataItem("ValidDate") Is System.DBNull.Value Then
                        sValidDate = e.Item.DataItem("ValidDate")
                    End If
                End If


                dgItem.Attributes.Add("onclick", "SelectMe('" + CtrlAtt + "','" + strRepSrc + "', this, '" + tmp1 + "'" + ",'" + strReference + "','" + strBundle + "'" + ");" + "  setInsuredID('" + sInsuredID + "','" + sValidDate + "');")
                dgItem.Attributes.Add("ondblclick", "ShowReport('0');")



        End Select
    End Sub

    Private Sub gridOccasional_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles gridOccasional.ItemDataBound
        Dim dgItem As DataGridItem = e.Item
        Dim htmCtrl As System.Web.UI.HtmlControls.HtmlGenericControl
        Dim htmCtrlChk As System.Web.UI.HtmlControls.HtmlInputCheckBox
        Dim CtrlAtt As String, tmp1 As String, strRepSrc As String, strReference As String, strBundle As String
        Dim tblCell As TableCell
        Dim index As Integer

        Select Case (dgItem.ItemType)
            Case ListItemType.Item, ListItemType.AlternatingItem
                tblCell = dgItem.Cells(0)
                Dim l As Label = tblCell.FindControl("lblSign")
                tmp1 = l.ClientID
                htmCtrlChk = tblCell.FindControl("chkIfPrint")

                tblCell = dgItem.Cells(1)
                htmCtrl = tblCell.FindControl("keyvalue")
                CtrlAtt = htmCtrl.Attributes("key")
                strRepSrc = htmCtrl.Attributes("repsrc")
                strReference = htmCtrl.Attributes("ref1")
                strBundle = htmCtrl.Attributes("bundle")

                Try
                    If Application("Paging").ToString = "1" Then
                        index = dgItem.ItemIndex()
                    Else
                        index = gridOccasional.PageSize * gridOccasional.CurrentPageIndex + dgItem.ItemIndex()
                    End If
                Catch ex As Exception
                    index = gridOccasional.PageSize * gridOccasional.CurrentPageIndex + dgItem.ItemIndex()
                End Try


                If Application("Paging").ToString = "1" Then
                    index = dgItem.ItemIndex()
                Else
                    index = gridOccasional.PageSize * gridOccasional.CurrentPageIndex + dgItem.ItemIndex()
                End If


                Dim ds As DataSet = gridOccasional.DataSource
                Dim strRepID As String = "", strRepIDOrg As String = ""


                dgItem.Attributes.Add("onclick", "SelectMe('" + CtrlAtt + "','" + strRepSrc + "', this, '" + tmp1 + "'" + ",'" + strReference + "','" + strBundle + "'" + ");")
                dgItem.Attributes.Add("ondblclick", "ShowReport('0');")

                dgItem.Attributes.Add("onmouseover", "rowMouseOver(this);")

#If NewDesign And Not EngDesign Then

                'If hidPrintActivity.Value = "1" Then

                '    'index = gridOccasional.PageSize * gridOccasional.CurrentPageIndex + dgItem.ItemIndex()
                '    htmCtrlChk.Attributes.Item("rowID") = index

                '    Dim j As Integer

                '    If hidArrayChks.Value <> "" Then

                '        arrChksValues = hidArrayChks.Value.Split(",")

                '        If htmCtrlChk.Attributes.Item("print") = "true" Then

                '            j = htmCtrlChk.Attributes.Item("rowID")
                '            If j < arrChksSize Then

                '                arrChksValues(j) = htmCtrlChk.Attributes.Item("repID") + ";" + "1"

                '            End If

                '        End If

                '    End If

                'End If

                With ds.Tables(0).Rows(index)
                    Try
                        If IsDBNull(.Item("ViewDate")) Then
                            dgItem.Style.Add("font-weight", "bold")
                        End If
                    Catch ex As Exception

                    End Try
                End With
#End If
        End Select
    End Sub

    Private Sub grdList_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles grdList.PageIndexChanged
        grdList.CurrentPageIndex = e.NewPageIndex
        BindGrid()
    End Sub

    Private Sub grdListNew_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles grdListNew.PageIndexChanged
        grdListNew.CurrentPageIndex = e.NewPageIndex
        BindGridNew()
    End Sub

    Private Sub gridOccasional_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles gridOccasional.PageIndexChanged
        gridOccasional.CurrentPageIndex = e.NewPageIndex
        BindGrid()
    End Sub

    Private Sub cmdUserProp_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUserProp.ServerClick
        Session("User_Prop_Caller") = "frmRepList.aspx"
#If NewDesign And Not EngDesign Then
        If Application("HasCB") = "1" Or Application("HasHani").ToString() = "1" Then
            'Response.Redirect("frmUserInfo.aspx")
            Response.Redirect((New Utils).GetLinkForNextForm("frmUserInfo.aspx"))
        Else
            Response.Redirect("frmUserProp.aspx")
        End If
#Else
        Response.Redirect("frmUserProp.aspx")
#End If
    End Sub

    Private Sub cmdLogout_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdLogout.ServerClick
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        objUser.UpdateLastLogout("DD947C22-CFCA-4BD4-A2CD-B9C916B39B28", Session.SessionID, Val(Application("SiteType")))

        FormsAuthentication.SignOut()
        If Application("HKLLDP") <> "" Then
            Response.Redirect("LoginHKL.aspx?out=1")
        Else
            Response.Redirect(Application("FORMLogin"))
        End If
    End Sub

    Protected Function BindImageisCopy(ByRef ObjIsCopy As Object) As String

        Dim iIsCopy As Integer = 0

        If IsNumeric(ObjIsCopy.ToString()) Then

            iIsCopy = CInt(ObjIsCopy)

        End If

        If iIsCopy = 1 Then
            Return "pics/admin_settings_content-types.png"
        End If

        Return "pics/Transparentb.gif"

    End Function

    Protected Function BindImage(ByRef dtViewDate As Object, ByRef objShared As Object, ByRef objSigned As Object) As String
        Dim iShared As Integer = 0
        Dim iSigned As Integer = 0
        If IsNumeric(objShared.ToString()) Then
            iShared = CInt(objShared)
        End If
        If IsNumeric(objSigned.ToString()) Then
            iSigned = CInt(objSigned)
        End If
        If IsDBNull(dtViewDate) Then
            If iShared = 1 Then
                Return "pics/envelope_people_close.gif"
            Else
                If iSigned = 1 Then
                    Return "pics/envelope_close_signed.gif"
                Else
                    Return "pics/envelope_close.gif"
                End If
            End If
        Else
            If iShared = 1 Then
                Return "pics/envelope_people_open.gif"
            Else
                If iSigned = 1 Then
                    Return "pics/envelope_open_signed.gif"
                Else
                    Return "pics/envelope_open.gif"
                End If
            End If
        End If
    End Function

    Protected Function BindImageBundle(ByRef dtViewDate As Object, ByRef objShared As Object, ByRef objSigned As Object, ByRef objBundle As Object) As String
        Dim iShared As Integer = 0
        Dim iSigned As Integer = 0
        Dim iBundle As Integer = 1
        If IsNumeric(objShared.ToString()) Then
            iShared = CInt(objShared)
        End If
        If IsNumeric(objSigned.ToString()) Then
            iSigned = CInt(objSigned)
        End If
        If IsNumeric(objBundle.ToString()) Then
            iBundle = CInt(objBundle)
        End If
        If IsDBNull(dtViewDate) Then
            If iShared = 1 Then
                If iBundle > 1 Then
                    Return "pics/bundle_people_close.gif"
                Else
                    Return "pics/envelope_people_close.gif"
                End If
            Else
                If iSigned = 1 Then
                    If iBundle > 1 Then
                        Return "pics/bundle_close_signed.gif"
                    Else
                        Return "pics/envelope_close_signed.gif"
                    End If
                Else
                    If iBundle > 1 Then
                        Return "pics/bundle_close.gif"
                    Else
                        Return "pics/envelope_close.gif"
                    End If
                End If
            End If
        Else
            If iShared = 1 Then
                Return "pics/envelope_people_open.gif"
            Else
                If iSigned = 1 Then
                    Return "pics/envelope_open_signed.gif"
                Else
                    Return "pics/envelope_open.gif"
                End If
            End If
        End If
    End Function

    Protected Function BindImageFileDownload(ByRef objEncrypted As Object) As String

        Dim iEncrypted As Integer = 0

        If IsNumeric(objEncrypted.ToString()) Then
            iEncrypted = CInt(objEncrypted)
        End If

        If iEncrypted = 1 Then
            Return "pics/manul.gif"
        Else
            Return "pics/Transparentb.gif"
        End If


    End Function

    Protected Function BindImageExclamation(ByRef dtViewDate As Object, ByRef objNotice As Object) As String
        Dim iNotice As Integer = 0
        If IsDBNull(dtViewDate) Then
            If IsNumeric(objNotice.ToString()) Then
                iNotice = CInt(objNotice)
            End If
        End If
        If iNotice = 1 Then
            Return "pics/Exclamation.gif"
        Else
            Return "pics/Transparentb.gif"
        End If
    End Function

    Protected Function FormatDateTime2(ByRef dtViewDate As Object) As String
        If IsDBNull(dtViewDate) Then
            Return ""
        Else
            Return Format(dtViewDate, "dd/MM/yyyy")
        End If
    End Function

    Protected Function FormatDateTime(ByRef dtViewDate As Object) As String
        If IsDBNull(dtViewDate) Then
            Return ""
        Else
            Return Format(dtViewDate, "dd/MM/yyyy")
        End If
    End Function


    Protected Function GetRepSrc(ByVal strDefaultAction As String, ByVal strActionType As String) As String
        If LCase(Application("App_Type").ToString()) = "divur" Or LCase(Application("App_Type").ToString()) = "supp" Or LCase(Application("App_Type").ToString()) = "doar" Then
            Return strActionType
        Else
            Return strDefaultAction
        End If
    End Function

    'Private Sub cmdDelete_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDelete.ServerClick
    '    Dim iReportID As Integer = txtReportID.Value
    '    Dim objReportsList As New Posting.localhost1.ReportService()
    '    If objReportsList.DeleteReport(iReportID) Then
    '        txtError.Value = "������� ������ ������"
    '    Else
    '        txtError.Value = "Error!"
    '    End If
    'End Sub

    Private Sub cmdReturn_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturn.ServerClick
        Session("Filter_On") = ""

        Session("Filter_To_Date") = ""
        Session("Filter_From_Date") = ""
        Session("MRequest_Source") = "1"
        Session("Filter_InsuredID") = ""
        Session("Report_List_ReportType") = ""

        Session("MRequest_DoctorCare") = ""
        Session("MRequest_DoctorCareName") = ""

        Session("MRequest_InsuredID") = ""
        Session("MRequest_InsuredName") = ""
        Session("MRequest_InsuredFamily") = ""
        Session("MRequest_LName") = ""
        Session("MRequest_FName") = ""
        Session("MRequest_RequestType") = ""

        Session("From_Consultation") = ""
        'Response.Redirect(Application("FORMRepStat"))

        Response.Redirect((New Utils).GetLinkForNextForm(Utils.Navigation.GetURL(Application("FORMRepStat"))))

    End Sub

    Private Sub cmdApplyFilter_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdApplyFilter.ServerClick
        Session("Filter_Report_ID") = ""

        If Val(txtTableType.Value) <> 13 Then
            grdList.CurrentPageIndex = 0
        Else
            gridOccasional.CurrentPageIndex = 0
        End If

        filterFlag = True
#If NewDesign And Not EngDesign Then
        If hidIsTechSupport.Value = "1" Then
            If chkFilter.Checked Then
                Session("Filter_On") = "1"
                Session("Filter_From_Date") = txtDateFrom.Value
                Session("Filter_To_Date") = txtDateTo.Value

                'Session("Filter_Report_Type") = iReportType
                'Session("Report_List_ReportType") = Session("Filter_Report_Type")
                'If Application("App_Type").ToString <> "dist" Then
                '    Session("Report_List_Current_User") = lstUsers.SelectedItem.Value
                'End If
                If chkViewed.Checked Then
                    Session("Filter_Viewed") = "1"
                Else
                    Session("Filter_Viewed") = ""
                End If
                If chkNotViewed.Checked Then
                    Session("Filter_NotViewed") = "1"
                Else
                    Session("Filter_NotViewed") = ""
                End If

                Session("Filter_ReportType") = lstRepName.SelectedItem.Value
                Session("Filter_FromUserName") = txtFromUserName.Value
                Session("Filter_LastUpdateUserName") = txtLastUpdateUserName.Value
                Session("Filter_SupplierID") = txtSupplierID.Value
                FillStatusCodes()
                Session("Filter_StatusCode") = hidStatusCodes.Value
            Else
                Session("Filter_On") = ""
                Session("Filter_From_Date") = ""
                Session("Filter_To_Date") = ""
                Session("Filter_Viewed") = ""
                Session("Filter_NotViewed") = ""
                Session("Filter_ReportType") = ""
                Session("Filter_FromUserName") = ""
                Session("Filter_LastUpdateUserName") = ""
                Session("Filter_SupplierID") = ""
                Session("Filter_StatusCode") = ""
            End If
        End If
#Else
        Session("Filter_On") = ""
        Session("Filter_From_Date") = ""
        Session("Filter_To_Date") = ""
        Session("Filter_Viewed") = ""
        Session("Filter_NotViewed") = ""
        Session("Filter_ReportType") = ""
        Session("Filter_FromUserName") = ""
        Session("Filter_LastUpdateUserName") = ""
        Session("Filter_SupplierID") = ""
        Session("Filter_StatusCode") = ""
#End If


        BindGrid()
    End Sub

    Private Sub cmdReportProp_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReportProp.ServerClick
        Dim bIsTechSupport As Boolean = False

#If NewDesign And Not EngDesign Then
        If hidIsTechSupport.Value = "1" Then
            bIsTechSupport = True
        End If
#End If

        If IsNumeric(txtReportID.Value) Then
            Dim iReportID As Integer = txtReportID.Value
            Dim objUser As New UserConnect.UserService()
            objUser.Url = Application("UserWebService").ToString()
            Dim strUserID As String = objUser.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", User.Identity.Name)
            Dim objReportsList As New ReportConnect.ReportService()
            objReportsList.Url = Application("ReportWebService").ToString()
            If Application("App_Type").ToString = "dist" Then
                'objReportsList.UpdateReportViewState("EB917314-AEB1-4F8D-A436-E7797568FD53", iReportID, CInt(strUserID), CInt(strUserID), User.Identity.Name)
                BindGrid()
            Else
                'objReportsList.UpdateReportViewState("EB917314-AEB1-4F8D-A436-E7797568FD53", iReportID, CInt(strUserID), CInt(lstUsers.SelectedItem.Value), User.Identity.Name)

                If bIsTechSupport And Trim(lstUsers.SelectedItem.Text.ToUpper) = "INFOBAY" Then
                    Dim sLockedByUser As String = objReportsList.GetSupportRequestLockUser("SC0B75D2-5826-108E-9D19-5654572E1C86", CInt(txtReportID.Value))
                    If sLockedByUser <> "" And sLockedByUser.ToLower() <> User.Identity.Name.ToLower() Then

                        txtError.Value = sLockedByUser.ToLower() & " ���� " & txtReportID.Value.ToString & " ���� ������ �''� ����� "

                        BindGrid()
                    Else
                        Session("TechSupport_RepID") = txtReportID.Value
                        Session("TechSupport_SubUserID") = lstUsers.SelectedItem.Value
                        Session("HdclicksForGoBack") = "2"
                        Response.Redirect(Application("FORMfrmTechSupportRequest"))
                    End If

                Else
                    BindGrid()
                End If
            End If
        End If
    End Sub

#If NewDesign And Not EngDesign Then
    Private Sub setFilterByCalander_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles setFilterByCalander.ServerClick
        If Val(txtTableType.Value) <> 13 Then
            grdList.CurrentPageIndex = 0
        Else
            gridOccasional.CurrentPageIndex = 0
        End If


        Me.BindGrid()

    End Sub
#End If

    Private Sub cmdReturnMenu_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturnMenu.ServerClick
        Session("Filter_On") = ""
        Session("Filter_On") = ""

        Session("Filter_To_Date") = ""
        Session("Filter_From_Date") = ""
        Session("MRequest_Source") = "1"
        Session("Filter_InsuredID") = ""
        Session("Report_List_ReportType") = ""

        Session("MRequest_DoctorCare") = ""
        Session("MRequest_DoctorCareName") = ""

        Session("MRequest_InsuredID") = ""
        Session("MRequest_InsuredName") = ""
        Session("MRequest_InsuredFamily") = ""
        Session("MRequest_LName") = ""
        Session("MRequest_FName") = ""
        Session("MRequest_RequestType") = ""

        Session("From_Consultation") = ""
        Select Case Application("App_Type").ToString().ToUpper()
            Case "KUPA_INFO"
                Response.Redirect("KupaInfoMenu.aspx")
            Case "SUPP"
                Response.Redirect(Application("FORMClaimMenu").ToString)
            Case "DIVUR"
                Response.Redirect(Application("FORMStart"))
            Case Else
                If Application("HasCB") = "1" Then
                    'Response.Redirect("frmCBMenu.aspx")
                    Response.Redirect((New Utils).GetLinkForNextForm("frmCBMenu.aspx"))
                Else
                    Response.Redirect("frmStart.aspx")
                End If
        End Select
    End Sub

    Protected Function FormatRequestTyp(ByRef iRequestTyp As Object) As String
        If IsDBNull(iRequestTyp) Then
            Return ""
        Else
#If EngDesign Then
            Select Case CType(iRequestTyp, Integer)
                Case 0
                    Return "�����"
                Case 4
                    Return "��������"
                Case 9
                    Return "�����"
                Case Else
                    Return ""
            End Select
#Else
            Dim iReportType As Integer = 0
            If IsNumeric(Session("Report_List_ReportType")) Then
                iReportType = CInt(Session("Report_List_ReportType"))
            End If
            Select Case CType(iRequestTyp, Integer)
                Case 0
                    If iReportType = 556 Then
                        Return "����� �������"
                    Else
                        Return "�����"
                    End If
                Case 1
                    If iReportType = 556 Then
                        Return "����� ����"
                    Else
                        Return ""
                    End If
                Case 4
                    Return "��������"
                Case 9
                    Return "�����"
                Case Else
                    Return ""
            End Select
#End If

        End If
    End Function




    '    Protected Overrides Sub OnError(ByVal e As System.EventArgs)
    '        Response.Clear()
    '        Dim strResult As String = "<html><head><meta http-equiv='Content-Type' content='text/html; charset=windows-1255'/></head><body dir=rtl>"
    '        strResult += "<DIV style='font-family:Arial;font-size:16pt;font-weight:bold;width:100%;text-align:center'>����� ��� ����� ������, ��� ��� ����� ����</DIV><BR><DIV style='font-family:Arial;font-size:9pt'>" & txtFormIdentity.Value & "</DIV></body></html>"
    '        Response.Write(strResult)
    '        'Dim ex As Exception = Server.GetLastError
    '        'Response.Write(ex.Message)
    '        Response.End()
    '    End Sub

    Private Sub cmdReportClaims_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReportClaims.ServerClick
        Session("Request_Report_From_Date") = txtDateFrom.Value
        Session("Request_Report_To_Date") = txtDateTo.Value
        If chkViewed.Checked Then
            Session("Request_Report_Viewed") = "1"
        Else
            Session("Request_Report_Viewed") = ""
        End If
        If chkNotViewed.Checked Then
            Session("Request_Report_NotViewed") = "1"
        Else
            Session("Request_Report_NotViewed") = ""
        End If
        Session("Request_Report_InsuredID") = Trim(txtInshuredID.Value)
        Session("Request_Report_Name") = Trim(txtName.Value)
        Response.Redirect("frmRequestReport.aspx?StartDate=" + txtDateFrom.Value + "&EndDate=" + txtDateTo.Value)


    End Sub

    '#If NewDesign Then
    '    Private Sub cmdRepRequests_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRepRequests.ServerClick
    '        'UserID
    '        Dim objUser As New UserConnect.UserService()
    '        objUser.Url = Application("UserWebService").ToString()
    '        Dim strUserID As String = objUser.GetUserID("C45AACFE-4E19-4341-8A07-21AF88830954", User.Identity.Name)

    '        'SubUserID
    '        Dim strSubUserID As String = lstUsers.SelectedItem.Value

    '        Session("Request_Report_From_Date") = txtDateFrom.Value
    '        Session("Request_Report_To_Date") = txtDateTo.Value
    '        If chkViewed.Checked Then
    '            Session("Request_Report_Viewed") = "1"
    '        Else
    '            Session("Request_Report_Viewed") = ""
    '        End If
    '        If chkNotViewed.Checked Then
    '            Session("Request_Report_NotViewed") = "1"
    '        Else
    '            Session("Request_Report_NotViewed") = ""
    '        End If
    '        Session("Request_Report_InsuredID") = Trim(txtInshuredID.Value)
    '        Session("Request_Report_InsuredName") = Trim(txtName.Value)
    '        Session("Request_Report_DoctorID") = Trim(txtDoctorID.Value)
    '        Session("Request_Report_ClinicID") = Trim(txtClinicID.Value)
    '        Session("Request_Report_UserID") = CInt(strUserID)
    '        Session("Request_Report_SubUserID") = CInt(strSubUserID)
    '        Response.Redirect("frmRequestsForHospitals.aspx")

    '    End Sub
    '#End If

#If NewDesign And Not EngDesign Then
    Private Sub grdList_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles grdList.SortCommand
        Dim dataGrid As DataGrid = source
        Dim strSort = dataGrid.Attributes("SortExpression")
        Dim strASC = dataGrid.Attributes("SortASC")

        dataGrid.Attributes("SortExpression") = e.SortExpression
        dataGrid.Attributes("SortASC") = "Yes"

        If e.SortExpression = strSort Then
            If strASC = "Yes" Then
                dataGrid.Attributes("SortASC") = "No"
            Else
                dataGrid.Attributes("SortASC") = "Yes"
            End If
        End If

        txtSortField.Value = dataGrid.Attributes("SortExpression")
        If dataGrid.Attributes("SortASC") = "No" Then
            txtSortField.Value &= " DESC"
        End If

        dataGrid.CurrentPageIndex = 0



        BindGrid()

    End Sub

    Private Sub gridOccasional_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles gridOccasional.SortCommand
        Dim dataGrid As DataGrid = source
        Dim strSort = dataGrid.Attributes("SortExpression")
        Dim strASC = dataGrid.Attributes("SortASC")

        dataGrid.Attributes("SortExpression") = e.SortExpression
        dataGrid.Attributes("SortASC") = "Yes"

        If e.SortExpression = strSort Then
            If strASC = "Yes" Then
                dataGrid.Attributes("SortASC") = "No"
            Else
                dataGrid.Attributes("SortASC") = "Yes"
            End If
        End If

        txtSortField.Value = dataGrid.Attributes("SortExpression")
        If dataGrid.Attributes("SortASC") = "No" Then
            txtSortField.Value &= " DESC"
        End If

        gridOccasional.CurrentPageIndex = 0



        BindGrid()

    End Sub

    Protected Function CheckReason(ByVal strReferenceID As String) As String

        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        Dim objSupplierConnect As New SupplierConnect.RequestClaim()
        objSupplierConnect.Url = Application("SupplierWebService").ToString()

        Dim ds As DataSet
        If Not Session("Worker_Type") = "1" Then
            ds = objSupplierConnect.GetReasonForRepList("5682BC12-8791-446F-97F4-C5BB7223276F", strReferenceID)
        Else
            ds = objSupplierConnect.GetReasonForRepListForWorker("5682BC12-8791-446F-97F4-C5BB7223276F", strReferenceID)
        End If

        Dim MyType As String = "0"

        If ds.Tables(0).Rows.Count > 0 Then
            Dim currRow As DataRow
            currRow = ds.Tables(0).Rows(0)
            If Not IsDBNull(CType(currRow("RemarkCode"), Integer)) Then
                MyType = "����"
            Else
                MyType = "0"
            End If

        End If

        Return MyType

    End Function


    Sub AddDataColumn(ByVal pTbl As DataTable, ByVal sColName As String)
        Dim dc As DataColumn

        For Each dc In pTbl.Columns
            If dc.ColumnName = sColName Then
                Exit Sub
            End If
        Next

        dc = New DataColumn()
        dc.DataType = Type.GetType("System.DateTime")
        dc.ColumnName = sColName

        pTbl.Columns.Add(dc)
    End Sub

#End If

#If NewDesign And Not EngDesign Then
    Private Sub cmdExit_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdExit.ServerClick
        Session("Filter_On") = ""

        Select Case Application("App_Type").ToString().ToUpper()
            Case "KUPA_INFO"
                Response.Redirect("KupaInfoMenu.aspx")
            Case "SUPP"                
                Response.Redirect(Application("FORMClaimMenu").ToString)
            Case "DIVUR"
                Response.Redirect("frmStart.aspx")
            Case Else
                If Application("HasCB") = "1" Then
                    'Response.Redirect("frmCBMenu.aspx")
                    Response.Redirect((New Utils).GetLinkForNextForm("frmCBMenu.aspx"))
                ElseIf (Application("IsDorAlon") = "1") Then
                    Response.Redirect("frmAlonMenu.aspx")
                Else
                    Response.Redirect("frmStart.aspx")
                End If
        End Select

    End Sub
#End If


    Function UnionDistinct(ByVal dt1 As DataTable, ByVal dt2 As DataTable, ByVal sPKName As String) As DataTable
        Dim dc1 As DataColumn
        Dim dc2 As DataColumn
        Dim rw1 As DataRow
        Dim rw2 As DataRow
        Dim rwRes As DataRow
        Dim dtRes As DataTable

        ''Change place of DataTables => dt1 must be biger than dt2
        'If dt1.Columns.Count < dt2.Columns.Count Then
        '    dtRes = dt2
        '    dt2 = dt1
        '    dt1 = dtRes
        'End If

        ''Add columns to dt2 
        'If dt1.Columns.Count > dt2.Columns.Count Then
        '    For Each dc1 In dt1.Columns
        '        Dim bColFound As Boolean = False
        '        For Each dc2 In dt2.Columns
        '            If dc2.ColumnName = dc1.ColumnName Then
        '                bColFound = True
        '                Exit For
        '            End If
        '        Next
        '        If Not bColFound Then
        '            Dim dc As New DataColumn()
        '            dc.DataType = dc1.DataType.GetType
        '            dc.ColumnName = dc1.ColumnName
        '            dt2.Columns.Add(dc)
        '        End If
        '    Next
        'End If

        '''!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        'now: dt1.Columns.Count < dt2.Columns.Count  'ik 27/09/2006 
        '''!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

        'create dtRes, add columns to dtRes from dt1 
        dtRes = New DataTable("RepRows")
        For Each dc1 In dt1.Columns
            Dim dc As New DataColumn()
            'dc.DataType = dc1.DataType.GetType
            dc.DataType = dc1.DataType.GetType(dc1.DataType.FullName)
            dc.ColumnName = dc1.ColumnName
            dtRes.Columns.Add(dc)
        Next


        'Add all rows from dt1 to dtRes
        For Each rw1 In dt1.Rows
            dtRes.ImportRow(rw1)
        Next

        'Add missing rows (with other PK) from dt2 to dtRes
        For Each rw2 In dt2.Rows
            Dim bRowFound As Boolean = False
            For Each rwRes In dtRes.Rows
                If rwRes(sPKName) = rw2(sPKName) Then
                    bRowFound = True
                    Exit For
                End If
            Next
            If Not bRowFound Then
                dtRes.ImportRow(rw2)
            End If
        Next

        Return dtRes
    End Function

    Protected Function FormatRemarks(ByRef objCode As Object) As String
        Dim strReturn As String = ""
        Try
            If Not IsDBNull(objCode) Then
                strReturn = objCode.ToString()
            End If
        Catch ex As Exception
        End Try

        Return strReturn
    End Function

    Protected Function FormatStatus(ByRef objCode As Object) As String
        Dim strReturn As String = ""
        Try
            If Not IsDBNull(objCode) Then
                strReturn = objCode.ToString()
            End If
        Catch ex As Exception
        End Try

        Return strReturn
    End Function

    Protected Function FormatPDF(ByRef objRepID As Object) As String
        If IsDBNull(objRepID) Then
            Return ""
        Else
            If CType(objRepID, Integer) > 0 Then
                Dim str34 As String = Chr(34).ToString()
                Return "<INPUT class='ButtonPDF' onclick='ShowPDF(" & str34 & objRepID.ToString() & str34 & ");' type='button' title='pdf-����� �'>"
            Else
                Return ""
            End If
        End If
    End Function

    Protected Function EncodeField(ByRef objCode As Object) As String
        Dim strReturn As String = ""
        If Not IsDBNull(objCode) Then
            strReturn = CEncode.StringEncode(objCode.ToString())
        End If
        Return strReturn
    End Function

#If NewDesign And Not EngDesign Then
    Sub GridColumnsForTechSupportForExcel()
        Dim colForExcel As BoundColumn

        '/Ilia 
        ClearAllGridColumns(dgForExcel)

        'Save the first column!
        Dim FirstColForExcel As TemplateColumn = dgForExcel.Columns(dgForExcel.Columns.Count - 1)

        dgForExcel.Columns.Remove(FirstColForExcel)

        'Inverse order!!!
        '11
        colForExcel = CreateBoundColumn("����� ���� ������", "ViewDate", "{0:dd/MM/yyyy}")
        dgForExcel.Columns.Add(colForExcel)
        '10
        colForExcel = CreateBoundColumn("���� �����", "UpdateUserName", "")
        dgForExcel.Columns.Add(colForExcel)
        '09
        colForExcel = CreateBoundColumn("�����", "Status", "")
        dgForExcel.Columns.Add(colForExcel)
        '08
        colForExcel = CreateBoundColumn("���� ����", "RepName", "")
        dgForExcel.Columns.Add(colForExcel)
        '07
        colForExcel = CreateBoundColumn("�� �����", "LName", "")
        dgForExcel.Columns.Add(colForExcel)
        '06
        colForExcel = CreateBoundColumn("�� ����", "FName", "")
        dgForExcel.Columns.Add(colForExcel)
        '05
        colForExcel = CreateBoundColumn("�� ���", "SupplierName", "")
        dgForExcel.Columns.Add(colForExcel)
        '04
        colForExcel = CreateBoundColumn("��� ���", "SupplierID", "")
        dgForExcel.Columns.Add(colForExcel)
        '03
        colForExcel = CreateBoundColumn("�� �����", "FromUserName", "")
        dgForExcel.Columns.Add(colForExcel)
        '02
        'colForExcel = CreateBoundColumn("����� ����", "CreationDate", "{0:dd/MM/yyyy HH:mm:ss }")
        colForExcel = CreateBoundColumn("����� ����", "InputDate", "{0:dd/MM/yyyy HH:mm}")
        dgForExcel.Columns.Add(colForExcel)
        '01
        colForExcel = CreateBoundColumn("���� ����", "Reference", "")
        dgForExcel.Columns.Add(colForExcel)
        '00

        dgForExcel.Columns.Add(FirstColForExcel)
    End Sub
#End If

    Sub GridColumnsForTechSupport()
        Dim col As BoundColumn

        'Unvisible All Columns
        ClearAllGridColumns(grdList)

        'Save the first column!
        Dim FirstCol As TemplateColumn = grdList.Columns(grdList.Columns.Count - 1)

        grdList.Columns.Remove(FirstCol)

        'Inverse order!!!
        '11
        col = CreateBoundColumn("����� ���� ������", "ViewDate", "{0:dd/MM/yyyy}")
        grdList.Columns.Add(col)

        '10
        col = CreateBoundColumn("���� �����", "UpdateUserName", "")
        grdList.Columns.Add(col)

        '09
        col = CreateBoundColumn("�����", "Status", "")
        grdList.Columns.Add(col)

        '08
        col = CreateBoundColumn("���� ����", "RepName", "")
        grdList.Columns.Add(col)

        '07
        col = CreateBoundColumn("�� �����", "LName", "")
        grdList.Columns.Add(col)

        '06
        col = CreateBoundColumn("�� ����", "FName", "")
        grdList.Columns.Add(col)

        '05
        col = CreateBoundColumn("�� ���", "SupplierName", "")
        grdList.Columns.Add(col)

        '04
        col = CreateBoundColumn("��� ���", "SupplierID", "")
        grdList.Columns.Add(col)

        '03
        col = CreateBoundColumn("�� �����", "FromUserName", "")
        grdList.Columns.Add(col)

        '02
        'col = CreateBoundColumn("����� ����", "CreationDate", "{0:dd/MM/yyyy HH:mm:ss }")
        col = CreateBoundColumn("����� ����", "InputDate", "{0:dd/MM/yyyy HH:mm}")
        grdList.Columns.Add(col)

        '01
        col = CreateBoundColumn("���� ����", "Reference", "")
        grdList.Columns.Add(col)

        '00
        grdList.Columns.Add(FirstCol)

    End Sub

    Sub GridColumnsTable15()
#If NewDesign And Not EngDesign Then
        Dim col As BoundColumn

        'Unvisible All Columns
        ClearAllGridColumns(grdList)

        'Save the first column!
        Dim FirstCol As TemplateColumn = grdList.Columns(grdList.Columns.Count - 1)

        grdList.Columns.Remove(FirstCol)
        '05
        col = CreateBoundColumn("���� ����", "FileSize", "{0:#,##0.0;} KB")
        grdList.Columns.Add(col)

        '04
        col = CreateBoundColumn("����� �����", "InputDate", "{0:dd/MM/yyyy HH:mm}")
        grdList.Columns.Add(col)

        '03
        col = CreateBoundColumn("����� ���� ������", "ViewDate", "{0:dd/MM/yyyy}")
        grdList.Columns.Add(col)

        '02
        col = CreateBoundColumn("�� ���", "RepName", "")
        grdList.Columns.Add(col)

        '01
        grdList.Columns.Add(FirstCol)


#End If

    End Sub


    Function CreateBoundColumn(ByVal sHeaderText As String, ByVal sDataField As String, ByVal sDataFormatString As String) As BoundColumn
        Dim col As New BoundColumn()
        col.HeaderText = sHeaderText
        col.DataField = sDataField
        col.SortExpression = sDataField
        If sDataFormatString <> "" Then
            col.DataFormatString = sDataFormatString
        End If
        col.Visible = True

        Return col
    End Function

    Sub ClearAllGridColumns(ByRef grd As DataGrid)
        Dim col As Object
        Dim i As Integer

        'Clear All columns exept the last and the first
        For i = 2 To grd.Columns.Count - 2
            Try
                col = grd.Columns(i)
                col.HeaderText = ""
                col.Visible = False
            Catch ex As Exception
                'resume next
            End Try
        Next
    End Sub



    Sub FillGridStatus()
#If NewDesign And Not EngDesign Then
        Dim objRep As New ReportConnect.ReportService()
        objRep.Url = Application("ReportWebService").ToString()
        Dim ds As Data.DataSet = objRep.GetStatusesSelectedManually("E75BF20C-7F79-4C8A-B54A-2E78F18CFA04")

        grdStatus.DataSource = ds
        grdStatus.DataBind()

#End If
    End Sub


#If NewDesign And Not EngDesign Then
    Private Sub grdStatus_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdStatus.ItemDataBound
        Dim dgItem As DataGridItem = e.Item
        Dim htmCtrlChk As System.Web.UI.HtmlControls.HtmlInputCheckBox
        Dim tblCell As TableCell
        Dim sStatusParam() As String = hidStatusCodes.Value.Split(";")
        Dim i As Integer

        Select Case (dgItem.ItemType)
            Case ListItemType.Item, ListItemType.AlternatingItem
                tblCell = dgItem.Cells(0)
                htmCtrlChk = tblCell.FindControl("chkItem")

                If hidStatusCodes.Value = "" Then
                    If grdStatus.DataKeys(dgItem.ItemIndex) = 99 And Trim(lstUsers.SelectedItem.Text.ToUpper) = "INFOBAY" Then
                        htmCtrlChk.Checked = False
                    Else
                        htmCtrlChk.Checked = True
                    End If
                Else
                    For i = 0 To sStatusParam.Length - 1
                        If grdStatus.DataKeys(dgItem.ItemIndex) = IIf(sStatusParam(i) = "", -1, Val(sStatusParam(i))) Then
                            htmCtrlChk.Checked = True
                        End If
                    Next
                End If

        End Select
    End Sub
#End If

    Sub FillStatusCodes()
#If NewDesign And Not EngDesign Then

        hidStatusCodes.Value = ""
        Dim htmCtrlChk As System.Web.UI.HtmlControls.HtmlInputCheckBox
        Dim dgItem As DataGridItem
        For Each dgItem In grdStatus.Items
            htmCtrlChk = dgItem.FindControl("chkItem")
            If htmCtrlChk.Checked Then
                hidStatusCodes.Value = hidStatusCodes.Value & grdStatus.DataKeys(dgItem.ItemIndex) & ";"
            End If
        Next
#End If
    End Sub

    Sub ClearStatusCodes()
#If NewDesign And Not EngDesign Then

        hidStatusCodes.Value = ""
        Dim htmCtrlChk As System.Web.UI.HtmlControls.HtmlInputCheckBox
        Dim dgItem As DataGridItem
        For Each dgItem In grdStatus.Items
            htmCtrlChk = dgItem.FindControl("chkItem")
            htmCtrlChk.Checked = True
            If grdStatus.DataKeys(dgItem.ItemIndex) = 99 And Trim(lstUsers.SelectedItem.Text.ToUpper) = "INFOBAY" Then
                htmCtrlChk.Checked = False
            Else
                htmCtrlChk.Checked = True
            End If
        Next
#End If
    End Sub

#If NewDesign And Not EngDesign Then
    Sub FillSubjects()
        Try
            Dim objReport As New ReportConnect.ReportService()
            objReport.Url = Application("ReportWebService").ToString()

            Dim ds As Data.DataSet = objReport.GetCodeTable("87E9B530-B567-46B0-A9C7-8AF1579E7424", 3)

            lstRepName.Items.Add(New ListItem(" ��� ", 0))
            Dim currRow As DataRow
            For Each currRow In ds.Tables(0).Rows
                lstRepName.Items.Add(New ListItem(Trim(currRow("FieldDesc").ToString()), currRow("FieldCode").ToString()))
            Next

        Catch ex As Exception


        End Try
    End Sub

#End If

    Private Sub gridOccasional_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles gridOccasional.PreRender
        Dim dgItem As DataGridItem
        Dim dgCell As TableCell
        dgItem = New DataGridItem(0, 0, ListItemType.Header)
        dgCell = New TableCell()
        dgCell.ColumnSpan = 1
        dgCell.Text = "����� ����"
        dgItem.Cells.Add(dgCell)

        dgCell = New TableCell()
        dgCell.ColumnSpan = 7
        dgCell.Text = "����� �����"
        dgItem.Cells.Add(dgCell)

        dgCell = New TableCell()
        dgCell.ColumnSpan = 3
        dgCell.Text = "���� ������"
        dgItem.Cells.Add(dgCell)

        gridOccasional.Controls(0).Controls.AddAt(0, dgItem)
        If gridOccasional.PagerStyle.Visible Then
            gridOccasional.Controls(0).Controls(1).Visible = False
        End If
    End Sub

    Private Sub SetComboValue(ByRef cbo As DropDownList, ByVal strValue As String)
        cbo.SelectedIndex = -1
        Dim li As ListItem = cbo.Items.FindByValue(strValue)
        If Not li Is Nothing Then
            li.Selected = True
        Else
            cbo.SelectedIndex = 0
        End If
    End Sub

    Protected Function setLongFileName(ByRef objFileName As Object, ByRef objLongFileName As Object) As String
        Dim strReturn As String = ""
        Try
            If Not IsDBNull(objLongFileName) Then
                strReturn = objLongFileName.ToString()
            Else
                strReturn = objFileName.ToString()
            End If
        Catch ex As Exception
			'
        End Try
        Return strReturn
    End Function

    Private Sub cmdReturnConsultaion_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReturnConsultation.ServerClick
        Session("Back_Consultation") = "1"
        Response.Redirect(Session("BackUrl"))
    End Sub
End Class
