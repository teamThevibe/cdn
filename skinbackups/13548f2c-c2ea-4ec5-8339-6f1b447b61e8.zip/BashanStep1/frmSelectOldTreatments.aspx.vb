﻿Public Partial Class frmSelectOldTreatments
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim ds As DataSet
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        txtConsultation.Value = Val(Request.QueryString("Consultation"))


        If Not IsPostBack Then
            ds = objTreatmentService.GetTreatmentTypes("1C39E920-093F-46B2-BEE7-A4D459A3F1CC")
            BindCombo("TreatmentType", "TreatmenTypetID", lstCareGroup, ds)
        End If

    End Sub



    Private Sub BindCombo(ByVal strTextField As String, ByVal strValueField As String, ByRef cbo As DropDownList, ByRef ds As Data.DataSet)
        Dim currRow As DataRow
        cbo.Items.Add(New ListItem("בחר...", 0))
        For Each currRow In ds.Tables(0).Rows
            cbo.Items.Add(New ListItem(currRow(strTextField).ToString(), currRow(strValueField).ToString()))
        Next
    End Sub

End Class