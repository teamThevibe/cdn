﻿Imports System.Text.RegularExpressions
Partial Public Class frmLMCheck
    Inherits System.Web.UI.Page

    Enum eDeclarationType As Integer
        eMedicalSecrecy = 400
        eInsurance = 410
        eCollection1 = 421
        eCollection3 = 423
        eCollection9 = 429
    End Enum

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()
        hidCorrectDetails.Value = "0"
        If Application("CompanyID").ToString() <> "3" Then
            objUser.AddUserIllegalAction("24304391-6FDE-4237-A9B6-49630958EB26", User.Identity.Name, "frmCheckSM")
            Response.Redirect("Login.aspx")
        End If

        If IsNothing(Session("Login_User")) OrElse Len(Session("Login_User")) = 0 Then
            Response.Redirect("Login.aspx")
        End If

        If Not IsPostBack Then
            If Session("User_Login_First_Time") = "1" Then
                Response.Redirect("frmUserProp.aspx")
            End If
            If Application("RightLogo") = "1" Then
                divRIcon.Visible = True
            Else
                divRIcon.Visible = False
            End If
            Dim objTreatmentService As New TreatmentConnect.TreatmentService()
            objTreatmentService.Url = Application("TreatmentWebService").ToString()
            Dim strDoctorCareName As String
            Dim strDoctorCareNumber As String
            Dim strClinicName As String
            Dim strClinicNumber As String
            If objTreatmentService.GetDoctorProperties("7EC6114A-62CD-4DC4-A940-1416BFB136D8", User.Identity.Name, strDoctorCareName, strDoctorCareNumber, strClinicName, strClinicNumber) Then
                txtClinicName.Text = strClinicName
                txtClinicNumber.Text = strClinicNumber
            End If

            Dim ds As DataSet = objUser.GetUser("784C13D4-4DA2-49FC-9CDD-1BB6B0E869CB", User.Identity.Name)
            Dim dr As DataRow = ds.Tables(0).Rows(0)
            Dim iDoctorType As Integer = IIf(dr("DoctorType") Is DBNull.Value, 0, dr("DoctorType"))
            hidDoctorType.Value = iDoctorType

            txtTimeout.Value = Trim(Application("ClaimTimeout").ToString()) & "000"
            txtClaimEnabled.Value = Session("BSHN_AllowClaims")
            If Session("BSHN_AllowClaims") = "1" Then
                cmdClaim.Visible = True
            Else
                cmdClaim.Visible = False
            End If
            cmdZakaut.Visible = objUser.GetBashanZakautPermitions("8CE02069-9F79-4D39-A07C-5DDE5BD7C3D9", User.Identity.Name)
            cmdPrioRequest.Visible = objUser.GetPriodontRequestPermitions("1DDDF20C-5DC6-4656-A2CB-2D83B7CC13D9", User.Identity.Name)
            cmdConsultation.Visible = objUser.GetConsultationPermitions("AB699114-1C1D-4EB7-8186-033B5306E799", User.Identity.Name)
            cmdMRequest.Visible = objUser.GetMouthRequestPermitions("AC616A4E-9E4B-4B27-BB73-B4A8AC31A63E", User.Identity.Name)

            If Session("Leumit_InsuredID") <> "" Then
                txtInsuredID.Value = Session("Leumit_InsuredID") & ""
                txtInsuredFamily.Value = Session("Leumit_InsuredFamily") & ""
                txtInsuredName.Value = Session("Leumit_InsuredName") & ""
                hidClinicID.Value = Session("Leumit_ClinicID") & ""
                hidDeclarationOK.Value = Session("Leumit_DeclarationOK")
                hidOnlyServiceBasket.Value = Session("Leumit_OnlyServiceBasket") & ""
                hidInfant.Value = Session("Leumit_Infant") & ""
                hidCollectionProblem.Value = Session("Leumit_CollectionProblem") & ""
                hidToOpenCreditCard.Value = ""
                CheckFirstVisit()
            End If
        Else
            If txtInsuredID.Value <> "" Then
                ShowButtons()
            End If
        End If
    End Sub

    Sub CheckFirstVisit()
        Dim objReport As New ReportConnect.ReportService
        objReport.Url = Application("ReportWebService").ToString()
        If Not objReport.IsRequestsExist("3072A680-ADCB-11DE-8A39-0800200C9A66", Session("Leumit_CrntInsuredID"), hidClinicID.Value) Then
            hidFirstVisit.Value = "1"
        End If
    End Sub

    Sub ShowButtons()
        divDeclaration.Style("display") = "none"
        divButtons.Style("display") = "block"
        trGeneralButtons.Style("display") = "block"
    End Sub


    Private Function CheckWhiteList(ByVal strToCheck As String) As String
        Dim strResult As String = ""
        Dim i As Integer = 0
        Dim strTmp As String
        Dim regexWhiteList As Regex = Application("WhiteList")

        If Not regexWhiteList.IsMatch(strToCheck) Then
            For i = 0 To strToCheck.Length - 1
                strTmp = strToCheck(i).ToString()
                If regexWhiteList.IsMatch(strTmp) Then
                    strResult = strResult & strTmp
                End If
            Next
        Else
            strResult = strToCheck
        End If

        Return strResult
    End Function

    Sub ClearForm()
        MyBase.ViewState.Clear()
        txtInsuredID.Value = ""
        txtInsuredFamily.Value = ""
        txtInsuredName.Value = ""
        txtAnswer.InnerText = ""

        hidDeclarationPrinted.Value = ""
        hidDeclarationOK.Value = ""
        hidFirstVisit.Value = ""
        hidMedicalSecrecyChecked.Value = ""
        hidInsuranceChecked.Value = ""
        hidCollectionChecked.Value = ""
        chkCollection.Checked = False
        chkCollection.Disabled = False
        chkMedicalSecrecy.Checked = False
        chkMedicalSecrecy.Disabled = False
        chkInsurance.Checked = False
        chkInsurance.Disabled = False

        hidToOpenCreditCard.Value = ""

        Session("Leumit_CrntInsuredID") = ""
		System.Diagnostics.Trace.WriteLine(Format("dd.MM.yyyy HH:mm:ss", DateTime.Now) & " User: " & User.Identity.Name & " frmLMCheck.ClearForm.140: InsuredID = ''")
        Session("Leumit_InsuredID") = ""
        Session("Leumit_InsuredFamily") = ""
        Session("Leumit_InsuredName") = ""
        Session("Leumit_ClinicID") = ""

        Session("Leumit_DeclarationOK") = ""
        Session("Leumit_OnlyServiceBasket") = ""
        Session("Leumit_Infant") = ""
        Session("Leumit_CollectionProblem") = ""

        Session("Leumit_PayerID") = ""
        Session("Leumit_PayerFName") = ""
        Session("Leumit_PayerLName") = ""

        Session("Leumit_AlternativePayerID") = ""
        Session("Leumit_AlternativePayerFName") = ""
        Session("Leumit_AlternativePayerLName") = ""
        Session("Leumit_AlternativeCreditCompany") = ""
        Session("Leumit_AlternativeCardID") = ""
        Session("Leumit_PaymentsNumber") = ""

        ClearInsuredInSession("MRequest")
        ClearInsuredInSession("TRequest")
        ClearInsuredInSession("MRequest")

        cmdDeclarationOK.Disabled = False
    End Sub




    Private Sub cmdClaim_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClaim.ServerClick
        Session("winname") = "" '!!!
        CheckWindowName()
        Session("MRequest_RequestType") = "1"
        Session("MRequest_Source") = "1"
        FillInsuredInSession("MRequest")
        Response.Redirect(Utils.Navigation.GetURL("frmRequestt.aspx"))
    End Sub

    Private Sub cmdConsultation_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdConsultation.ServerClick
		CheckWindowName()
        FillInsuredInSession("TRequest")
        If (Application("MilkTeeth") = "1") Then
            Response.Redirect("frmTRequesttExt.aspx")
        Else
            Response.Redirect("frmTRequestt.aspx")
        End If

    End Sub

    Private Sub cmdPrioRequest_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPrioRequest.ServerClick
		CheckWindowName()
        FillInsuredInSession("TRequest")
        Response.Redirect("frmPRequestt.aspx")
    End Sub

    Private Sub cmdZakaut_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdZakaut.ServerClick
		CheckWindowName()
        FillInsuredInSession("MRequest")
        Response.Redirect("frmZakaut.aspx")
    End Sub
	
    Private Sub cmbAlternativeCreditCard_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbAlternativeCreditCard.ServerClick
		CheckWindowName()
        FillInsuredInSession("Leumit")
        Response.Redirect("frmLMCreditCard.aspx")
    End Sub

    Sub ShowError(ByVal txtError As String)
        txtAnswer.InnerText = txtError
    End Sub

    Private Sub cmdMRequest_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdMRequest.ServerClick
		CheckWindowName()
        FillInsuredInSession("MRequest")
        Session("MRequest_LName") = Left(txtInsuredFamily.Value, 2)
        Session("MRequest_FName") = Left(txtInsuredName.Value, 2)
        Session("MRequest_Source") = "2"

        Response.Redirect("frmMRequestt.aspx")
    End Sub

    Sub ClearInsuredInSession(ByVal sPrefix As String)
        Session(sPrefix & "_InsuredID") = Trim(txtInsuredID.Value)
        Session(sPrefix & "_InsuredName") = Trim(txtInsuredName.Value)
        Session(sPrefix & "_InsuredFamily") = Trim(txtInsuredFamily.Value)

    End Sub


    Sub FillInsuredInSession(ByVal sPrefix As String)
        Session(sPrefix & "_InsuredID") = Trim(txtInsuredID.Value)
        Session(sPrefix & "_InsuredName") = Trim(txtInsuredName.Value)
        Session(sPrefix & "_InsuredFamily") = Trim(txtInsuredFamily.Value)

        Session("Leumit_DeclarationOK") = "1"
    End Sub

    Private Sub cmdDeclarationOK_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDeclarationOK.ServerClick
		CheckWindowName()
        Dim sAttchTypes As String
        Dim bOK As Boolean = False

        Dim objTreat As New TreatmentConnect.TreatmentService()
        objTreat.Url = Application("TreatmentWebService").ToString()

        If hidInsuredPrefix.Value = "1" And chkCollection.Checked And hidCollectionChecked.Value <> "1" Then
            sAttchTypes = sAttchTypes & IIf(sAttchTypes <> "", ",", "") & eDeclarationType.eCollection1
        ElseIf hidInsuredPrefix.Value = "3" And chkCollection.Checked And hidCollectionChecked.Value <> "1" Then
            sAttchTypes = sAttchTypes & IIf(sAttchTypes <> "", ",", "") & eDeclarationType.eCollection3
        End If

        If chkMedicalSecrecy.Checked And hidMedicalSecrecyChecked.Value <> "1" Then
            sAttchTypes = sAttchTypes & IIf(sAttchTypes <> "", ",", "") & eDeclarationType.eMedicalSecrecy
        End If

        If chkInsurance.Checked And hidInsuranceChecked.Value <> "1" Then
            sAttchTypes = sAttchTypes & IIf(sAttchTypes <> "", ",", "") & eDeclarationType.eInsurance
        End If

        If sAttchTypes <> "" Then
            Dim iInsuredID As Integer

            iInsuredID = Val(Session("Leumit_CrntInsuredID"))
            If iInsuredID > 0 Then
                bOK = objTreat.ArchiveInsuredDeclaration("0CE979F2-8BD2-4954-BF32-64176EAABD25", User.Identity.Name, sAttchTypes, Session("Leumit_CrntInsuredID"), txtInsuredName.Value, txtInsuredFamily.Value)
            Else
                bOK = False
            End If
        End If

        If bOK And hidInsuredPrefix.Value = 9 And Not chkCollection.Checked Then
            hidDeclarationOK.Value = ""

            Dim sID As String = txtInsuredID.Value
            Dim sName As String = txtInsuredName.Value
            Dim sFamily As String = txtInsuredFamily.Value
            ClearForm()
            txtInsuredID.Value = Session("Leumit_CrntInsuredID")
            txtInsuredName.Value = sName
            txtInsuredFamily.Value = sFamily
            txtError.Value = "תנאי לאישור ביצוע טיפולים הוא קבלת טופס הרשאה"
        ElseIf hidInsuredPrefix.Value = 9 And hidMedicalSecrecyChecked.Value = "1" And Not chkCollection.Checked Then
            hidDeclarationOK.Value = ""
            ClearForm()
            txtError.Value = "תנאי לאישור ביצוע טיפולים הוא קבלת טופס הרשאה"
        ElseIf bOK Then
            hidDeclarationOK.Value = "1"
            CheckFirstVisit()
        Else
            hidDeclarationOK.Value = ""
            ClearForm()
            txtError.Value = "בעיה בשמירת הצהרות בארכיון"
        End If


    End Sub
	
    Private Sub CheckWindowName()
        Session("winname") = ""  ' !!!! Temporary
        If Session("winname") = "" Then
            If (hidWinName.Value <> "") Then
                Session("winname") = hidWinName.Value
            End If
        Else
            If hidWinName.Value <> Session("winname") Then
                Response.Redirect("frmInvalidOperation.aspx")
            End If
        End If
    End Sub
End Class
