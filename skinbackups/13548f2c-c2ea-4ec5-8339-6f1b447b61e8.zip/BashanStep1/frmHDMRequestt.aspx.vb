
Public Class frmHDMRequestt
    Inherits System.Web.UI.Page

    Protected WithEvents Doctor As Distribution.HDDoctor

    Protected WithEvents lstRequestType As System.Web.UI.WebControls.DropDownList

    Protected WithEvents cmdNew As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdReply As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdSend As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdNewReq As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents cmdCopy As System.Web.UI.HtmlControls.HtmlInputButton
    Protected WithEvents chkPan As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents chkStatus As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents chkFace As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents tdPageTitle As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents txtError As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtLName As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtFName As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtDateFrom As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtMaxClaimSum As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtTeethMode As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtToday As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtDoctorType As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents tdMouth As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents tdSmoke As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents tdMouthGood As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents tdMouthMedium As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents tdMouthBad As System.Web.UI.HtmlControls.HtmlTableCell
    Protected WithEvents spnDoctorRemark As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents spnRemarks As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents txtInsuredID As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtInsuredName As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtInsuredFamily As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtAnswer As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents txtNote As System.Web.UI.HtmlControls.HtmlTextArea
    Protected WithEvents txtInvoiceID As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtSum As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtClaimID As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txt11 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt12 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt13 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt14 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt15 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt16 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt17 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt18 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt21 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt22 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt23 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt24 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt25 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt26 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt27 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt28 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt31 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt32 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt33 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt34 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt35 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt36 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt37 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt38 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt41 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt42 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt43 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt44 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt45 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt46 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt47 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txt48 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAV0 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAV1 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAV2 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAV3 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAV4 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAV5 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAV6 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAV7 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAV8 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAV9 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAV10 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAV11 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAV12 As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtAVM As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtSkipCheck As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtCompanyID As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents tblMlkTeeth As System.Web.UI.HtmlControls.HtmlTable
    Protected WithEvents txtAgeRange As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidWinName As System.Web.UI.HtmlControls.HtmlInputHidden

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'CType(Master.FindControl("MainTitle"), Literal).Text = "����� ��� - ����� ��� ��"
        Dim sMainTitle As String = "����� ��� - " & Page.Title
        CType(Master.FindControl("MainTitle"), Literal).Text = sMainTitle
        Page.Title = sMainTitle

        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

        Dim bAllowMouthRequest As Boolean = objUser.GetMouthRequestPermitions("AC616A4E-9E4B-4B27-BB73-B4A8AC31A63E", User.Identity.Name)

        If Not bAllowMouthRequest Then
            objUser.AddUserIllegalAction("24304391-6FDE-4237-A9B6-49630958EB26", User.Identity.Name, "frmMRequestt")
            Utils.LogOut()
        End If
        If IsNothing(Session("Login_User")) OrElse Len(Session("Login_User")) = 0 Then
            Utils.LogOut()
        End If

        If Not IsPostBack Then



            If Not Session("HDInsuredID") Is Nothing Then
                If Session("HDInsuredID").ToString <> "" Then
                    txtInsuredID.Value = Session("HDInsuredID").ToString
                End If
            End If

            If Not Session("HDSHEM") Is Nothing Then
                If Session("HDSHEM").ToString <> "" Then
                    txtInsuredName.Value = Session("HDSHEM").ToString
                End If
            End If

            If Not Session("HDMISP") Is Nothing Then
                If Session("HDMISP").ToString <> "" Then
                    txtInsuredFamily.Value = Session("HDMISP").ToString
                End If
            End If






            If Session("User_Login_First_Time") = "1" Then
                Response.Redirect("frmUserProp.aspx")
            End If
            If Application("TeethMode").ToString() = "1" Then
                tdPageTitle.InnerText = "����� ��� �� (��� �������� �������)"
                txtTeethMode.Value = "1"
            End If
            txtCompanyID.Value = Application("CompanyID").ToString
            txtDoctorType.Value = CStr(objUser.GetUserDoctorType("C049B33B-243D-43C1-B2F5-AB4859F9EBD1", User.Identity.Name))
            ''''''''''''''''''''''''''''txtDoctorType.Value = CStr(objUser.GetHDUserDoctorType("0B776BB2-51E1-11E4-8E10-7F911D5D46B0", User.Identity.Name))
            If Session("BSHN_Independed") = "1" Then
                Doctor.DoctorCare.Visible = False
                Doctor.DoctorCareName.Visible = True
            Else
                Doctor.DoctorCare.Visible = True
                Doctor.DoctorCareName.Visible = False
            End If
            txtToday.Value = Format(DateTime.Today, "ddMMyyyy")
            FillDefaults()
            If Session("MRequest_Source") = "2" Then
                txtInsuredID.Value = Session("MRequest_InsuredID")
                If Session("BSHN_Independed") <> "1" Then
                    Try
                        If IsNumeric(Session("MRequest_DoctorCare")) Then
                            Doctor.DoctorCare.SelectedIndex = Val(Session("MRequest_DoctorCare"))
                            Doctor.DoctorCareNumber.Value = Session("MRequest_DoctorCareName").ToString
                        End If
                    Catch ex As Exception
                        '
                    End Try
                End If
                txtInsuredName.Value = Session("MRequest_InsuredName")
                txtInsuredFamily.Value = Session("MRequest_InsuredFamily")
                txtLName.Value = Session("MRequest_LName")
                txtFName.Value = Session("MRequest_FName")
                Session("MRequest_Source") = ""
            End If

        End If
    End Sub

    Sub SetReadOnly(ByVal txtField As HtmlInputText)
        txtField.Attributes.Add("readonly", "true")
        txtField.Style.Add("background-Color", "#D6D3CE")
    End Sub

    Private Sub FillDefaults()
        Dim strEmptyTooth As String = "0;0;0;0;0;0;0;0;0;0;0;0;0;0;"
        txt11.Value = strEmptyTooth
        txt12.Value = strEmptyTooth
        txt13.Value = strEmptyTooth
        txt14.Value = strEmptyTooth
        txt15.Value = strEmptyTooth
        txt16.Value = strEmptyTooth
        txt17.Value = strEmptyTooth
        txt18.Value = strEmptyTooth
        txt21.Value = strEmptyTooth
        txt22.Value = strEmptyTooth
        txt23.Value = strEmptyTooth
        txt24.Value = strEmptyTooth
        txt25.Value = strEmptyTooth
        txt26.Value = strEmptyTooth
        txt27.Value = strEmptyTooth
        txt28.Value = strEmptyTooth
        txt31.Value = strEmptyTooth
        txt32.Value = strEmptyTooth
        txt33.Value = strEmptyTooth
        txt34.Value = strEmptyTooth
        txt35.Value = strEmptyTooth
        txt36.Value = strEmptyTooth
        txt37.Value = strEmptyTooth
        txt38.Value = strEmptyTooth
        txt41.Value = strEmptyTooth
        txt42.Value = strEmptyTooth
        txt43.Value = strEmptyTooth
        txt44.Value = strEmptyTooth
        txt45.Value = strEmptyTooth
        txt46.Value = strEmptyTooth
        txt47.Value = strEmptyTooth
        txt48.Value = strEmptyTooth
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        txtMaxClaimSum.Value = objTreatmentService.GetMaxClaimSum("D2D2CC74-A3CE-4420-B6CE-073F25E8E70A")
        Dim strDoctorCareName As String
        Dim strDoctorCareNumber As String
        Dim strClinicName As String
        Dim strClinicNumber As String

        If objTreatmentService.GetDoctorProperties("7EC6114A-62CD-4DC4-A940-1416BFB136D8", User.Identity.Name, strDoctorCareName, strDoctorCareNumber, strClinicName, strClinicNumber) Then
            ''''''''''''''''''''''''''''If objTreatmentService.GetHdDoctorProperties("C4AEB905-6C91-4FC8-93BE-1486B99518E57", User.Identity.Name, strDoctorCareName, strDoctorCareNumber, strClinicName, strClinicNumber) Then

            If Session("BSHN_Independed") = "1" Then
                Doctor.DoctorCareName.Text = strDoctorCareName
                Doctor.DoctorCareNumber.Value = strDoctorCareNumber
            Else
                Doctor.FillDoctorCare()
                If Doctor.DoctorCare.Items.Count > 1 Then
                Else
                    Doctor.DoctorCareNumber.Value = strDoctorCareNumber
                End If
            End If

            'Dim objUser As New UserConnect.UserService()
            ' objUser.Url = Application("UserWebService").ToString()

            'If objUser.GetHDClinicIdAndClinicName("BE25C36A-51E8-11E4-B3E7-C79B1D5D46B0", User.Identity.Name, strClinicName, strClinicNumber) Then
            Doctor.ClinicName.Value = strClinicName
            Doctor.ClinicNumber.Value = strClinicNumber
            'End If


        End If
        txtDateFrom.Value = DateTime.Today.ToString("dd/MM/yyyy")
        lstRequestType.SelectedIndex = 0
    End Sub

    Private Sub SetComboValue(ByRef cbo As DropDownList, ByVal strValue As String)
        Dim li As ListItem = cbo.Items.FindByValue(strValue)
        If Not li Is Nothing Then
            li.Selected = True
        End If
    End Sub



    Private Sub cmdNew_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdNew.ServerClick
        Dim iIndex As Integer
        If Session("BSHN_Independed") <> "1" Then
            iIndex = Doctor.DoctorCare.SelectedIndex
        End If
        MyBase.ViewState.Clear()
        FillDefaults()
        If Session("BSHN_Independed") <> "1" Then
            Doctor.DoctorCare.SelectedIndex = iIndex
        End If
        txtAnswer.InnerText = ""
        txtLName.Value = ""
        txtFName.Value = ""
        txtInsuredFamily.Value = ""
        txtInsuredName.Value = ""
        txtError.Value = ""

        Session.Remove("HDInsuredID")
        Session.Remove("HDSHEM")
        Session.Remove("HDMISP")



    End Sub

    Private Sub cmdNewReq_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdNewReq.ServerClick
        Response.Redirect(Utils.Navigation.GetURL("frmRequestt.aspx"))
    End Sub

    Private Sub cmdCopy_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCopy.ServerClick
        Session("MRequest_InsuredID") = txtInsuredID.Value
        If Session("BSHN_Independed") <> "1" Then
            Session("MRequest_DoctorCare") = CStr(Doctor.DoctorCare.SelectedIndex)
            Session("MRequest_DoctorCareName") = CStr(Doctor.DoctorCare.SelectedValue)
        Else
            Session("MRequest_DoctorCare") = "0"
            Session("MRequest_DoctorCareName") = Doctor.DoctorCareNumber.Value
        End If
        Session("MRequest_InsuredName") = txtInsuredName.Value
        Session("MRequest_InsuredFamily") = txtInsuredFamily.Value


        Session("MRequest_LName") = txtInsuredFamily.Value
        Session("MRequest_FName") = txtInsuredName.Value


        Session("MRequest_Source") = "1"
        Session("MRequest_RequestType") = "0"
        Response.Redirect(Utils.Navigation.GetURL("frmRequestt.aspx"))
    End Sub

    Private Sub CheckWindowName()
        If Session("winname") = "" Then
            If (hidWinName.Value <> "") Then
                Session("winname") = hidWinName.Value
            End If
        Else
            If hidWinName.Value <> Session("winname") Then
                Response.Redirect("frmInvalidOperation.aspx")
            End If
        End If
    End Sub


    Private Sub cmdReply_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReply.ServerClick
        GetInsuredDetails()

    End Sub


    Private Sub GetInsuredDetails()

        Dim objBO As New BOConnection.BOService
        objBO.Url = Application("BOWebService")

        Dim ds As New DataSet
        If (txtInsuredID.Value = "") Then
            txtError.Value = ""
            Return
        End If
        ds = objBO.GetInsuredDetails("BB91B46E-024D-41F0-97C0-D58FE62388E9", Val(txtInsuredID.Value))

        If Not ds Is Nothing Then

            If ds.Tables.Count > 0 Then

                If ds.Tables(0).Rows.Count = 0 Then
                    txtError.Value = "11"

                    Session.Remove("HDInsuredID")

                    Session.Remove("HDSHEM")

                    Session.Remove("HDMISP")

                Else
                    txtError.Value = ""
                End If
            Else
                txtError.Value = "11"

                Session.Remove("HDInsuredID")

                Session.Remove("HDSHEM")

                Session.Remove("HDMISP")
            End If
        Else
            txtError.Value = "11"

            Session.Remove("HDInsuredID")

            Session.Remove("HDSHEM")

            Session.Remove("HDMISP")
        End If

        'Dim Util As Utils = New Utils
        txtInsuredName.Value = Utils.Values.GetFirstTableFirstRowString(ds, "SHEM")
        txtInsuredFamily.Value = Utils.Values.GetFirstTableFirstRowString(ds, "MISP")
        'FamilyCover.Value = Utils.Values.GetFirstTableFirstRowString(ds, "MSL_TEUR_KISUY_MEVUTAH")
        If txtError.Value <> "11" Then
            Session("HDInsuredID") = Val(txtInsuredID.Value)
            Session("HDSHEM") = txtInsuredName.Value
            Session("HDMISP") = txtInsuredFamily.Value
        End If

    End Sub


End Class
