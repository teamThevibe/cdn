﻿Partial Public Class frmHDUrgentMessage
    Inherits System.Web.UI.Page

    Dim UrgentReportType As Integer = 0
    Dim TableType As Integer = 0
    Dim UserID As Integer = 0
    'Dim Util As Utils = New Utils
    Dim ReportService As New ReportConnect.ReportService()
    Dim objUser As New UserConnect.UserService()

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init

        ReportService.Url = Application("ReportWebService").ToString()
        objUser.Url = Application("UserWebService").ToString()

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        SetGlobalParameters()

        Dim sMainTitle As String = "מערכת הוד - " & "מידע למרפאה"
        CType(Master.FindControl("MainTitle"), Literal).Text = sMainTitle
        Page.Title = sMainTitle

        If Not IsPostBack Then
            BindGrid()
        End If


    End Sub

    Private Sub SetGlobalParameters()

        Dim ds As DataSet

        ds = objUser.GetUser("784C13D4-4DA2-49FC-9CDD-1BB6B0E869CB", User.Identity.Name)
        UserID = Val(Utils.Values.GetFirstTableFirstRowInteger(ds, "SysUserID"))
        ClinicName.Value = Utils.Values.GetFirstTableFirstRowString(ds, "ClinicName")
        ClinicNumber.Value = Utils.Values.GetFirstTableFirstRowString(ds, "ClinicID")

        ds = ReportService.GetReportTypesByUser("E33A5328-9C22-4FAA-A248-0F3744E78E42", User.Identity.Name)
        If Utils.GetRowsCount(ds) > 0 Then
            Dim Reports() As DataRow
            Reports = ds.Tables(0).Select("IsUrgentMessage=True")
            If Reports.Length > 0 Then
                UrgentReportType = Val(Utils.Values.GetDataRowString(Reports(0), "ReportType"))
                TableType = Val(Utils.Values.GetDataRowString(Reports(0), "TableType"))
            End If
        End If

    End Sub

    Private Sub BindGrid()

        Dim ds As DataSet
        If TableType = 2 Then
            ds = ReportService.GetReportsListExt("B23B098A-BFEB-47E3-98FF-70C23D884F1A", _
                                              UserID, _
                                              UserID, _
                                              UrgentReportType, _
                                              "00000000", _
                                              "00000000", _
                                              True, _
                                              True, _
                                              String.Empty, _
                                              String.Empty, _
                                              String.Empty)
        ElseIf TableType = 11 Then
            ds = ReportService.GetReportsList11Type("A201017E-2BC3-4376-A110-8B1B9183C2A2", _
                                              UserID, _
                                              UserID, _
                                              UrgentReportType, _
                                              "00000000", _
                                              "00000000", _
                                              True, _
                                              True, _
                                              String.Empty, _
                                              String.Empty, _
                                              -1, _
                                              0)
        Else
            ds = ReportService.GetReportsList("7A9C96B4-DB38-4780-AA37-CA714783D55A", _
                                              UserID, _
                                              UserID, _
                                              UrgentReportType, _
                                              "00000000", _
                                              "00000000", _
                                              True, _
                                              True, _
                                              String.Empty, _
                                              String.Empty, _
                                              String.Empty)
        End If


        Dim iCount As Integer = ds.Tables(0).Rows.Count
        Dim iPageCount As Integer = (iCount - 1) \ grdList.PageSize
        If grdList.CurrentPageIndex > iPageCount Then
            grdList.CurrentPageIndex = iPageCount
        End If

        If Not Application("AllowUrgentMessage") Or Utils.GetRowsCount(ds) = 0 Then
            'Response.Redirect(Application("FORMStart"))
            Dim url As String = Application("FORMStart")
            url = url + "?FromLogin=1"
            Response.Redirect(url)
        End If
         
        grdList.DataSource = ds
            grdList.DataBind()
            If iPageCount > 0 Then
                grdList.PagerStyle.Visible = True
            Else
                grdList.PagerStyle.Visible = False
            End If

    End Sub

    Private Sub grdList_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles grdList.PageIndexChanged

        grdList.CurrentPageIndex = e.NewPageIndex
        BindGrid()

    End Sub

    Private Sub grdList_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdList.ItemDataBound

        Dim Item As DataGridItem = e.Item
        Select Case (Item.ItemType)
            Case ListItemType.Item, ListItemType.AlternatingItem
                Item.Attributes.Add("RepID", Item.DataItem("RepID"))
                Item.Attributes.Add("Encrypted", Item.DataItem("Encrypted"))
                Item.Attributes.Add("ondblclick", "SelectRow($(this));")
        End Select

    End Sub

    Private Sub cmdClose_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.ServerClick
        'Response.Redirect(Application("FORMStart"))
        Dim url As String = Application("FORMStart")
        url = url + "?FromLogin=1"
        Response.Redirect(url)

    End Sub

    Public Function GetFlexpaperURL() As String

        Dim FlexpaperURL As String = ConfigurationSettings.AppSettings("flexpaperURL")
        If FlexpaperURL Is Nothing Then
            FlexpaperURL = String.Empty
        End If
        Return FlexpaperURL

    End Function
 
End Class