

Public Class CEncode

    Public Shared Function StringEncode(ByVal st As String) As String
        Return Microsoft.Security.Application.AntiXSSLibrary.HtmlEncode(st)
        '        Return Microsoft.Security.Application.AntiXss.HtmlAttributeEncode(st)


        'Return System.Web.HttpContext.Current.Server.HtmlEncode(st)
    End Function
' I added this line for new version in Source Safe
End Class

