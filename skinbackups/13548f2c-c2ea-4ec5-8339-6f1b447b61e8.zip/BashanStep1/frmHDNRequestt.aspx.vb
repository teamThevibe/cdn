﻿Imports System.Web.Script.Serialization

Partial Public Class frmHDNRequestt

    Inherits System.Web.UI.Page
    Protected WithEvents lstRequestType As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstDoctorCare As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstCareGroup As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstCareType As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstOccasion As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lstSum As System.Web.UI.HtmlControls.HtmlSelect

    Protected WithEvents txtDoctorCareName As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtDoctorCareNumber As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtClinicName As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtClinicNumber As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtInsuredID As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtInsuredName As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtInsuredFamily As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtSum As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtInvoiceID As System.Web.UI.HtmlControls.HtmlInputText

    Protected WithEvents txtNote As System.Web.UI.HtmlControls.HtmlTextArea

    Protected WithEvents chkPan As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents chkStatus As System.Web.UI.HtmlControls.HtmlInputCheckBox
    Protected WithEvents chkFace As System.Web.UI.HtmlControls.HtmlInputCheckBox

    Protected WithEvents txtMaxClaimSum As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents HidLeumit_Infant As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidSalParticipation As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidGovernmentTreatments As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidHaveGovernmentTreatments As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents hidShowOldTreatments As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtSmileAgrementClinic As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtSkipCheck As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtFromTooth As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtToTooth As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtCompany As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtXrayA As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtXrayB As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents HidExemptionFromDeductibles As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtFillingString As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtTeethMode As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtPriodontRequestMode As System.Web.UI.HtmlControls.HtmlInputHidden
    Protected WithEvents txtClaimID As System.Web.UI.HtmlControls.HtmlInputText

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            ' Delete (if exists) data for RequestBashanInWork
            ' Dim objTreatmentService As New TreatmentConnect.TreatmentService()
            ' objTreatmentService.Url = Context.Application("TreatmentWebService").ToString()
            ' Dim DelRequestBashanInWork As Boolean = objTreatmentService.DelRequestBashanInWork("1BE727A9-81B3-44FF-968A-A68E73ED8B95", String.Empty, 0, User.Identity.Name)

            Page.Title = "מערכת הוד - טיפול בפניות"
            CType(Master.FindControl("MainTitle"), Literal).Text = Page.Title

            If Not Session("HDInsuredID") Is Nothing Then
                If Session("HDInsuredID").ToString <> "" Then
                    txtInsuredID.Value = Session("HDInsuredID").ToString
                End If
            End If

            Dim objUser As New UserConnect.UserService()
            objUser.Url = Application("UserWebService").ToString()

            Dim DoctorType As Integer = objUser.GetUserDoctorType("C049B33B-243D-43C1-B2F5-AB4859F9EBD1", User.Identity.Name)
            txtDoctorType.Value = CStr(DoctorType)

            If DoctorType <> 3 Then
                cmdAddAttachForLastRequest.Visible = False
            End If

            txtToday.Value = Format(DateTime.Today, "ddMMyyyy")
            If Session("User_Login_First_Time") = "1" Then
                Response.Redirect("frmHDUserProp.aspx")
            End If
            HidLeumit_Infant.Value = "0"
            If Not Session("Leumit_Infant") Is Nothing Then
                HidLeumit_Infant.Value = Session("Leumit_Infant").ToString
            End If
            hidSalParticipation.Value = objUser.GetGeneralParameter("3FCAAB6E-4AAD-4231-A9F2-B9CCA67EE079", "SalParticipation").ToString()
            txtCompany.Value = Application("CompanyID").ToString
            If Session("BSHN_Independed") = "1" Then
                lstDoctorCare.Visible = False
                txtDoctorCareName.Visible = True
            Else
                lstDoctorCare.Visible = True
                txtDoctorCareName.Visible = False
            End If
            BindRequestType()
            FillDefaults()
            BindCareGroupCombo()
            lstCareGroup.SelectedIndex = 0
            lstCareType.Items.Add(New ListItem("בחר...", 0))
            lstCareType.SelectedIndex = 0
            hidHaveGovernmentTreatments.Value = Application("GovernmentTreatments").ToString()
            hidShowOldTreatments.Value = Application("ShowOldTreatments").ToString()
            If Application("Smile") = "1" Or Application("CompanyID").ToString = "3" Then
                ' Smile or Leumit
                If Application("Smile") = "1" Then
                    txtSkipCheck.Value = "1"
                Else
                    txtSkipCheck.Value = "2"
                End If
            End If
            txtSmileAgrementClinic.Value = ""
            lstSum.Visible = False
            If Application("TeethMode").ToString() = "1" Then
                txtTeethMode.Value = "1"
            End If
            Dim bAllowMouthRequest As Boolean = objUser.GetMouthRequestPermitions("AC616A4E-9E4B-4B27-BB73-B4A8AC31A63E", User.Identity.Name)
            If Not bAllowMouthRequest Then
                txtTeethMode.Value = "1"
            End If
            If objUser.GetPriodontRequestPermitions("1DDDF20C-5DC6-4656-A2CB-2D83B7CC13D9", User.Identity.Name) Then
                txtPriodontRequestMode.Value = "1"
            Else
                txtPriodontRequestMode.Value = "0"
            End If

            txtClaimID.Value = Utils.Values.GetQueryString("CurrentAsmacta") ' передали асмахту с другого экрана
            If txtClaimID.Value.Length > 0 Then
                lstRequestType.SelectedIndex = 2 ' не хочу задавать в js
                ' Похоже, прийдется заполнять и т.з.
                'Dim objTreatmentService As New TreatmentConnect.TreatmentService()
                'objTreatmentService.Url = Context.Application("TreatmentWebService")
                'Dim str As String
                'Dim ds As DataSet = objTreatmentService.GetInsuredPropByReference("C202994D-651F-4D03-8917-C59B30D590A7", txtClaimID.Value, str, str, str, str, str)
                'txtInsuredID.Value = Utils.Values.GetFirstTableFirstRowString(ds, "InsuredID")
                ' это тоже плохо... не заполняются зубы...
            End If
        Else
            txtClaimID.Value = String.Empty
            Session("MRequest_RequestType") = 0
        End If

        ErrorRequestIDs.Value = String.Empty

    End Sub

    Private Sub FillDefaults()
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        txtMaxClaimSum.Value = objTreatmentService.GetMaxClaimSum("D2D2CC74-A3CE-4420-B6CE-073F25E8E70A")
        Dim strDoctorCareName As String
        Dim strDoctorCareNumber As String
        Dim strClinicName As String
        Dim strClinicNumber As String
        If objTreatmentService.GetDoctorProperties("7EC6114A-62CD-4DC4-A940-1416BFB136D8", User.Identity.Name, strDoctorCareName, strDoctorCareNumber, strClinicName, strClinicNumber) Then
            If Session("BSHN_Independed") = "1" Then
                txtDoctorCareName.Value = strDoctorCareName
                txtDoctorCareNumber.Value = strDoctorCareNumber
            Else
                Dim objUser As New UserConnect.UserService()
                objUser.Url = Application("UserWebService").ToString()
                lstDoctorCare.DataSource = objUser.GetDoctorList("03407803-DE6A-41AA-87DC-60D1D0329753", User.Identity.Name)
                lstDoctorCare.DataBind()
                If lstDoctorCare.Items.Count > 1 Then
                    lstDoctorCare.Items.Insert(0, New ListItem("בחר...", "0"))
                Else
                    txtDoctorCareNumber.Value = strDoctorCareNumber
                End If
            End If
            txtClinicName.Value = strClinicName
            txtClinicNumber.Value = strClinicNumber
        End If

        lstRequestType.SelectedIndex = Utils.Values.GetSessionInteger("MRequest_RequestType")

        ' данные для открытия/закрытия зубов при выборе зуба
        Dim correlationList As New ArrayList
        Dim ds As DataSet = objTreatmentService.GetTeethCorrelation("C377E784-7F6E-412F-934F-D09BC18C2C56")
        If Utils.Values.GetFirstTableRowsCount(ds) > 0 Then
            For Each dr As DataRow In ds.Tables(0).Rows
                correlationList.Add(New Integer() {dr("Tooth"), dr("ResponseTooth")})
            Next
        End If
        Dim serializer As JavaScriptSerializer = New JavaScriptSerializer()
        TeethCorrelation.Value = serializer.Serialize(correlationList)
    End Sub

    Private Sub BindCareGroupCombo()
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

        Dim ds As Data.DataSet
        Dim isSmileAgrementClinic As Boolean = False
        Dim iSmileAgrementClinicPlus As Integer = 0
        If Application("Smile") = "1" Then
            iSmileAgrementClinicPlus = objUser.CheckIfAgrementClinicPlus("2AFAE3F5-79B5-459E-B1F9-C460BD34672A", User.Identity.Name)
            If iSmileAgrementClinicPlus > 0 Then
                isSmileAgrementClinic = True
            End If
        End If
        If Session("Leumit_OnlyServiceBasket") = "1" Or isSmileAgrementClinic Then
            If iSmileAgrementClinicPlus = 2 Then
                ds = objTreatmentService.GetTreatmentTypesForServiceBasketPlus("9E01224E-7A57-4E50-A64F-857E4DB868CC")
            Else
                ds = objTreatmentService.GetTreatmentTypesForServiceBasket("3E1378D4-4A76-4F92-B0AF-CB3AFBA60DA4")
            End If
        ElseIf Session("Smile_OnlyServiceBasketNet") = "1" Then
            ds = objTreatmentService.GetTreatmentTypesForServiceBasketNet("2DABD6CC-E754-44EF-8EAD-2044986E91E0")
        Else
            ds = objTreatmentService.GetTreatmentTypes("1C39E920-093F-46B2-BEE7-A4D459A3F1CC")
        End If
        If Application("Smile") = "1" And Application("Smile_Platinum_18_Supported") = "1" And Session("Smile_Platinum_18") = "1" And Not isSmileAgrementClinic Then
            lstCareGroup.Items.Add(New ListItem("בחר...", 0))
            lstCareGroup.Items.Add(New ListItem("משמר", 1))
            lstCareGroup.Items.Add(New ListItem("צילומים", 9))
        Else
            BindCombo("TreatmentType", "TreatmenTypetID", lstCareGroup, ds)
        End If
    End Sub

    Private Sub BindAmountCombo()
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Application("TreatmentWebService").ToString()
        Dim currRow As DataRow
        Dim ds As DataSet = objTreatmentService.GetClinicAmounts("7FC988DD-BAA2-4EBB-8D20-7AC1F67CA423")

        lstSum.Items.Add(New ListItem("בחר...", -1))
        For Each currRow In ds.Tables(0).Rows
            lstSum.Items.Add(New ListItem(currRow("Amount").ToString(), currRow("Amount").ToString()))
        Next
    End Sub

    Private Sub BindRequestType()
        lstRequestType.Items.Clear()

        'If birur
        'lstRequestType.Items.Add(New ListItem("בירור", 9))

        lstRequestType.Items.Add(New ListItem("תביעה", 0))
        lstRequestType.Items.Add(New ListItem("התייעצות", 4))
        lstRequestType.Items.Add(New ListItem("בירור", 9))

    End Sub

    Private Sub BindCombo(ByVal strTextField As String, ByVal strValueField As String, ByRef cbo As DropDownList, ByRef ds As Data.DataSet)
        Dim currRow As DataRow
        cbo.Items.Add(New ListItem("בחר...", 0))
        For Each currRow In ds.Tables(0).Rows
            cbo.Items.Add(New ListItem(currRow(strTextField).ToString(), currRow(strValueField).ToString()))
        Next
    End Sub

    Sub SetReadOnly(ByVal txtField As HtmlInputText)
        txtField.Attributes.Add("readonly", "true")
        txtField.Style.Add("background-Color", "#D6D3CE")
    End Sub

    'Private Sub cmdSetList_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSetList.ServerClick

    '    Dim objTreatmentService As New TreatmentConnect.TreatmentService()
    '    objTreatmentService.Url = Context.Application("TreatmentWebService").ToString()
    '    Dim objReport As New ReportConnect.ReportService()
    '    objReport.Url = Application("ReportWebService").ToString()

    '    Dim iInsuredID As Integer = Val(txtInsuredID.Value)
    '    Dim strUserName As String = User.Identity.Name
    '    Dim ds As DataSet = objTreatmentService.CheckRequestsJournal("83674676-3FA8-45D1-BAC1-463D2A39F2DD", strUserName, iInsuredID)
    '    Dim dr As DataRow
    '    Dim bHasErrors As Boolean = False

    '    If Not ds Is Nothing Then
    '        If ds.Tables.Count > 0 Then
    '            For Each dr In ds.Tables(0).Rows
    '                If Utils.Values.GetDataRowInteger(dr, "Status") <> 0 Then
    '                    bHasErrors = True
    '                End If
    '            Next
    '        End If
    '    End If

    '    If bHasErrors Then
    '        message.Value = "ביומן פניות יש שגיאה אחת או יותר"
    '    Else
    '        ds = objTreatmentService.GetRequestBashanInWork("0B89FD35-B814-4914-95E6-113801F086BC", strUserName, iInsuredID)

    '        Dim RequestID As Integer, strReferenceID As String
    '        For Each dr In ds.Tables(0).Rows
    '            RequestID = Utils.Values.GetDataRowInteger(dr, "RequestID")
    '            strReferenceID = dr("Reference").ToString()
    '            objTreatmentService.SetRequestComplited("1A529E7C-262A-4A6F-94D6-AA8C5AACBF8E", RequestID)
    '            objReport.AddRequestBashanReport("CF48E6AE-F060-4CCB-8A2B-2E39848B261A", strUserName, strReferenceID)
    '        Next

    '        message.Value = "הפניות נשלחו בהצלחה"
    '    End If
    'End Sub

    Private Sub cmdSetList_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSetList.ServerClick

        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Context.Application("TreatmentWebService").ToString()
        Dim objReport As New ReportConnect.ReportService()
        objReport.Url = Application("ReportWebService").ToString()

        Dim iInsuredID As Integer = Val(txtInsuredID.Value)
        Dim strUserName As String = User.Identity.Name
        Dim ds As DataSet
        Dim dr As DataRow
        Dim bHasErrors As Boolean = False

        ds = objTreatmentService.GetRequestBashanInWork("0B89FD35-B814-4914-95E6-113801F086BC", strUserName, iInsuredID)

        Dim RequestID As Integer, strReferenceID As String, iResult As Integer, strError As String = ""
        ' было так
        'For Each dr In ds.Tables(0).Rows
        '    RequestID = Utils.Values.GetDataRowInteger(dr, "RequestID")
        '    iResult = CheckOneRequest(RequestID, strUserName, strError)
        '    If iResult = 0 Then
        '        strReferenceID = dr("Reference").ToString()
        '        objTreatmentService.SetRequestComplited("1A529E7C-262A-4A6F-94D6-AA8C5AACBF8E", RequestID)
        '        objReport.AddRequestBashanReport("CF48E6AE-F060-4CCB-8A2B-2E39848B261A", strUserName, strReferenceID)
        '    Else
        '        bHasErrors = True
        '        Exit For
        '    End If
        'Next
        ' есть в этом что то не хорошее... возможно я что то сохранил (iResult = 0), а потом что то не сохранил и вышел из программы...
        ' видимо, надо два цикла... а кроме того, я хочу получить список того, что не правильно

        For Each dr In ds.Tables(0).Rows
            RequestID = Utils.Values.GetDataRowInteger(dr, "RequestID")
            iResult = CheckOneRequest(RequestID, strUserName, strError)
            If iResult = 0 Then
            Else
                If strError.Length > 0 Then
                    message.Value = strError
                End If
                ' тут вот какая мысль: если это бирур, так мне надо на клиенте сообщить об ошибке и после этого стереть строку из йомана....
                If (Utils.Values.GetDataRowInteger(dr, "RequestTypeID") = 9) Then
                    ErrorRequestIDs.Value += IIf(ErrorRequestIDs.Value.Length = 0, String.Empty, "$") + RequestID.ToString()
                End If
                bHasErrors = True
            End If
        Next

        If Not bHasErrors Then
            ' Т.е. я проверил данные и все хорошо... Можно данные сохранить...
            For Each dr In ds.Tables(0).Rows
                RequestID = Utils.Values.GetDataRowInteger(dr, "RequestID")
                strReferenceID = Utils.Values.GetDataRowString(dr, "Reference")
                objTreatmentService.SetRequestComplited("1A529E7C-262A-4A6F-94D6-AA8C5AACBF8E", RequestID)
                objReport.AddRequestBashanReport("CF48E6AE-F060-4CCB-8A2B-2E39848B261A", strUserName, strReferenceID)
            Next
            Session("HDInsuredID") = Nothing
            txtInsuredID.Value = String.Empty
            txtInvoiceID.Value = String.Empty
            txtSum.Value = String.Empty
            If lstDoctorCare.Visible Then
                txtDoctorCareName.Value = String.Empty
                txtDoctorCareNumber.Value = String.Empty
                lstDoctorCare.SelectedIndex = -1
            Else
            End If
            message.Value = "הפניות נשלחו בהצלחה"
        End If
    End Sub

    Private Function CheckOneRequest(ByVal iRequestID As Integer, ByVal strUserName As String, ByRef strError As String) As Integer
        Dim objTreatmentService As New TreatmentConnect.TreatmentService()
        objTreatmentService.Url = Context.Application("TreatmentWebService").ToString()
        Dim ds As DataSet = objTreatmentService.CheckOneRequestFromJournal("62BBF9C1-5975-4350-BC05-FE6BA6F5C03D", strUserName, iRequestID)
        Dim dr As DataRow
        Dim bHasErrors As Boolean = False
        Dim iResult As Integer = -1
        strError = ""

        If Not ds Is Nothing Then
            If ds.Tables.Count > 0 Then
                For Each dr In ds.Tables(0).Rows
                    iResult = Utils.Values.GetDataRowInteger(dr, "Status")
                    If iResult <> 0 Then
                        Select Case iResult
                            Case 1
                                strError = " דווח על ביצוע הטיפול בתאריך" & " " & Utils.Values.GetDataRowString(dr, "EntryDate", "{0:dd/MM/yyyy}") & "   מספר אסמכתא: " & Utils.Values.GetDataRowString(dr, "Reference")
                            Case 2
                                strError = "מספר האסמכתא שהוזן אינו נמצא ברשימת הפניות שהוגשו על ידך"
                            Case 3
                                strError = "מספר האסמכתא שהוזן אינו נמצא ברשימת הפניות שהוגשו על ידך"
                            Case 4
                                strError = "הבירור מיותר. נתוניו זהים לנתוני הפניה "
                            Case 5
                                ' strError = "הבירור לפניה כבר שודר בעבר"
                                strError = "הבירור מיותר. נתוניו זהים לנתוני הפניה"
                            Case 6
                                strError = "הבירור לפניה כבר שודר בעבר"
                            Case 7
                                strError = "שלחת לאחרונה התייעצות למטופל זה"
                        End Select
                        bHasErrors = True
                        Exit For
                    End If
                Next
            End If
        End If
        Return iResult
    End Function

    Public Function IfOldIE() As Boolean
        If Request.Browser.Browser.ToLower = "ie" Then
            If Double.Parse(Request.Browser.Version) >= 9 Then
                Return False
            End If
            'В Internet Explorer 8, 9 и 10 при изменении на просмотр в режиме совместимости, 
            'User Agent изменяется на MSIE 7.0.
            'Определить истинную версию браузера можно по Trident: 
            'Trident/5.0 Internet Explorer 9, 
            'Trident/4.0 Internet Explorer 8, 
            'Trident/6.0 Internet Explorer 10 и 
            'Trident/7.0 (возможно) Internet Explorer 11.
            Dim UserAgent As String = Request.UserAgent
            If UserAgent.ToLower().IndexOf("trident/4.0") >= 0 Then ' Internet Explorer 8
                Return True
            End If
            If UserAgent.ToLower().IndexOf("trident/5.0") >= 0 Then ' Internet Explorer 9
                Return False
            End If
            If UserAgent.ToLower().IndexOf("trident/6.0") >= 0 Then ' Internet Explorer 10
                Return False
            End If
            If UserAgent.ToLower().IndexOf("trident/7.0") >= 0 Then ' Internet Explorer 11
                Return False
            End If
        End If
        Return False
    End Function

    Private Sub cmdConsultationNew_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdConsultationNew.ServerClick
        Response.Redirect("frmHDTRequestt.aspx")
    End Sub

    Private Sub cmdConsultationReq_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdConsultationReq.ServerClick
        Session("TRequest_InsuredID") = txtInsuredID.Value
        Session("TRequest_InsuredName") = txtInsuredName.Value
        Session("TRequest_InsuredFamily") = txtInsuredFamily.Value
        Session("TRequest_LName") = Left(txtInsuredFamily.Value, 2)
        Session("TRequest_FName") = Left(txtInsuredName.Value, 2)

        Session("TRequest_PolGovTreatment") = hidPolGovTreatment.Value
        If Session("BSHN_Independed") <> "1" Then
            Session("MRequest_DoctorCare") = CStr(lstDoctorCare.SelectedIndex)
            Session("MRequest_DoctorCareName") = CStr(lstDoctorCare.SelectedValue)
        Else
            Session("MRequest_DoctorCare") = "0"
            Session("MRequest_DoctorCareName") = txtDoctorCareName.Value
        End If

        If (Application("MilkTeeth") = "1") Then
            Response.Redirect("frmTRequesttExt.aspx?fromCmdClean=1")
        Else
            Response.Redirect("frmHDTRequestt.aspx?fromCmdClean=1")
        End If
    End Sub

    Private Sub cmdShowConsultations_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdShowConsultations.ServerClick, cmdConsultations.ServerClick
        Dim objUser As New UserConnect.UserService()
        objUser.Url = Application("UserWebService").ToString()

        Dim iShowReportConsultationPerion As Integer

        iShowReportConsultationPerion = Val(objUser.GetGeneralParameter("3FCAAB6E-4AAD-4231-A9F2-B9CCA67EE079", "ConsultationShowPeriod"))

        If iShowReportConsultationPerion = 0 Then
            iShowReportConsultationPerion = 6
        End If


        Session("Filter_On") = "1"

        Session("Filter_To_Date") = DateTime.Now.ToString("ddMMyyyy")
        Session("Filter_From_Date") = DateAdd(DateInterval.Month, -iShowReportConsultationPerion, DateTime.Now).ToString("ddMMyyyy")
        Session("MRequest_Source") = "1"
        Session("Filter_InsuredID") = txtInsuredID.Value
        Session("Report_List_ReportType") = "41"
        Session("Filter_Viewed") = "1"
        Session("Filter_NotViewed") = "1"

        If Session("BSHN_Independed") <> "1" Then
            Session("MRequest_DoctorCare") = CStr(lstDoctorCare.SelectedIndex)
            Session("MRequest_DoctorCareName") = CStr(lstDoctorCare.SelectedValue)
        Else
            Session("MRequest_DoctorCare") = "0"
            Session("MRequest_DoctorCareName") = txtDoctorCareName.Value
        End If

        Session("MRequest_InsuredID") = txtInsuredID.Value
        Session("MRequest_InsuredName") = txtInsuredName.Value
        Session("MRequest_InsuredFamily") = txtInsuredFamily.Value
        Session("MRequest_LName") = Left(txtInsuredFamily.Value, 2)
        Session("MRequest_FName") = Left(txtInsuredName.Value, 2)
        Session("MRequest_RequestType") = lstRequestType.SelectedIndex
        Session("MRequest_PolGovTreatment") = hidPolGovTreatment.Value

        Session("From_Consultation") = "3"
        Session("BackUrl") = "frmHDNRequestt.aspx"

        Response.Redirect("frmHDRepList.aspx")
    End Sub
End Class